from __future__ import annotations

import hashlib
import hmac
import json
import time
from dataclasses import dataclass
from urllib.parse import parse_qsl


@dataclass(frozen=True, slots=True)
class TelegramWebAppIdentity:
    user_id: int
    username: str
    first_name: str
    last_name: str
    auth_date: int
    query_id: str


def validate_init_data(init_data: str, bot_token: str, *, max_age_seconds: int = 900) -> TelegramWebAppIdentity:
    raw = str(init_data or "")
    if len(raw) > 16384:
        raise ValueError("INIT_DATA_TOO_LARGE")
    entries = parse_qsl(raw, keep_blank_values=True, strict_parsing=False, max_num_fields=32)
    pairs = dict(entries)
    if len(pairs) != len(entries):
        raise ValueError("INIT_DATA_DUPLICATE_FIELD")
    supplied_hash = pairs.pop("hash", "")
    if not supplied_hash or not bot_token:
        raise ValueError("INIT_DATA_MISSING")
    data_check_string = "\n".join(f"{key}={pairs[key]}" for key in sorted(pairs))
    secret_key = hmac.new(b"WebAppData", bot_token.encode("utf-8"), hashlib.sha256).digest()
    expected_hash = hmac.new(secret_key, data_check_string.encode("utf-8"), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected_hash, supplied_hash):
        raise ValueError("INIT_DATA_SIGNATURE_INVALID")
    try:
        auth_date = int(pairs.get("auth_date", "0"))
    except ValueError as exc:
        raise ValueError("INIT_DATA_EXPIRED") from exc
    now = int(time.time())
    if auth_date <= 0 or auth_date > now + 60 or now - auth_date > max(60, int(max_age_seconds)):
        raise ValueError("INIT_DATA_EXPIRED")
    try:
        user = json.loads(pairs.get("user", "{}"))
        if not isinstance(user, dict) or isinstance(user.get("id"), bool):
            raise ValueError("INIT_DATA_USER_INVALID")
        user_id = int(user["id"])
        if user_id <= 0 or user_id > 2**53 - 1:
            raise ValueError("INIT_DATA_USER_INVALID")
    except (ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
        raise ValueError("INIT_DATA_USER_INVALID") from exc
    return TelegramWebAppIdentity(
        user_id=user_id,
        username=str(user.get("username") or ""),
        first_name=str(user.get("first_name") or ""),
        last_name=str(user.get("last_name") or ""),
        auth_date=auth_date,
        query_id=str(pairs.get("query_id") or ""),
    )
