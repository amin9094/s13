"""Read-through memberships with optimistic validation across both storage paths.

No orders or entitlements are mirrored. Legacy reward grants and normalized
purchase grants share the vip_users advisory lock at commit on PostgreSQL.
"""

from contextlib import contextmanager, closing
from contextvars import ContextVar

_scope = ContextVar("membership_reads", default=None)


def _table_exists(cursor, postgres, table):
    if postgres:
        cursor.execute("SELECT to_regclass(%s)", (table,))
        return bool(cursor.fetchone()[0])
    return bool(cursor.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone())


def _row(cursor, postgres, uid):
    if not _table_exists(cursor, postgres, "v8_vip_entitlements"):
        return None
    statement = "SELECT status,expires_at,updated_at FROM v8_vip_entitlements WHERE user_id=?"
    cursor.execute(statement.replace("?", "%s") if postgres else statement, (uid,))
    row = cursor.fetchone()
    return tuple(str(v or "") for v in row) if row else None


@contextmanager
def membership_mutation_scope():
    token = _scope.set({})
    try:
        yield
    finally:
        _scope.reset(token)


def reset_membership_reads():
    reads = _scope.get()
    if reads is not None:
        reads.clear()


def normalized_for_mutation(user_id):
    reads = _scope.get()
    if reads is None:
        return None
    uid = str(user_id)
    if uid not in reads:
        from core.db import _get_store, SQLiteStore, PostgresStore

        store = _get_store()
        if isinstance(store, SQLiteStore):
            with closing(store._connect()) as conn:
                reads[uid] = _row(conn.cursor(), False, uid)
        elif isinstance(store, PostgresStore):
            with store._connect() as conn, conn.cursor() as cursor:
                reads[uid] = _row(cursor, True, uid)
        else:
            reads[uid] = None
    value = reads[uid]
    return {"status": value[0], "expires_at": value[1], "updated_at": value[2]} if value else None


def normalized_expiry_candidates(now, limit=100):
    """Bounded authoritative worklist; completed removals cannot starve new ones.

    user_memberships stores only the existing Telegram removal/retry evidence.
    It does not replace the normalized entitlement as the subscription source.
    """
    from core.db import _get_store, SQLiteStore, PostgresStore
    from core.utils import utc_iso

    store = _get_store()
    postgres = isinstance(store, PostgresStore)
    if not isinstance(store, (SQLiteStore, PostgresStore)):
        return {}
    connection = store._connect()
    manager = connection if postgres else closing(connection)
    with manager as conn:
        with closing(conn.cursor()) as cursor:
            if not _table_exists(cursor, postgres, "v8_vip_entitlements"):
                return {}
            field = lambda name: (
                f"m.payload::jsonb->>'{name}'" if postgres else f"json_extract(m.payload, '$.{name}')"
            )
            # Only the three literal field names below enter SQL; all dates and limits are bound parameters.
            sql = (
                "SELECT e.user_id,e.status,e.expires_at,e.updated_at FROM v8_vip_entitlements e "  # nosec B608
                "LEFT JOIN user_memberships m ON m.user_id=e.user_id "
                "WHERE (e.status <> 'active' OR e.expires_at <= ?) "
                "AND NOT (COALESCE(m.status,'')='active' AND COALESCE(m.expires_at,'') > ?) "
                f"AND (COALESCE({field('channel_removed_at')},'')='' "  # nosec B608
                f"OR COALESCE({field('normalized_access_version')},'')<>e.updated_at) "
                f"AND (COALESCE({field('channel_removal_next_retry_at')},'') <= ? "
                f"OR COALESCE({field('normalized_access_version')},'')<>e.updated_at) "
                "ORDER BY e.expires_at,e.user_id LIMIT ?"
            )
            cursor.execute(
                sql.replace("?", "%s") if postgres else sql,
                (utc_iso(now), utc_iso(now), utc_iso(now), max(1, min(500, int(limit)))),
            )
            rows = cursor.fetchall()
    reads = _scope.get()
    result = {}
    for uid, status, expiry, version in rows:
        uid = str(uid)
        values = tuple(str(v or "") for v in (status, expiry, version))
        if reads is not None:
            reads[uid] = values
        result[uid] = {"status": values[0], "expires_at": values[1], "updated_at": values[2]}
    return result


def validate_membership_reads(cursor, *, postgres=False):
    from core.db import ConcurrentDatabaseUpdate

    for uid, expected in (_scope.get() or {}).items():
        if _row(cursor, postgres, uid) != expected:
            raise ConcurrentDatabaseUpdate("membership changed during reward grant; retry")


def later_membership(legacy, normalized):
    from core.utils import parse_dt, utc_now

    result = dict(legacy or {})
    expiry = parse_dt(result.get("expires_at"))
    incoming = parse_dt((normalized or {}).get("expires_at"))
    if normalized and normalized.get("status") == "active" and incoming and incoming > utc_now():
        if result.get("status") != "active" or not expiry or incoming > expiry:
            result.update(normalized)
    return result or None


def membership_snapshot():
    """An isolated presentation view; it must never be written as a full state."""
    from core.db import snapshot, _get_store, SQLiteStore, PostgresStore

    db = snapshot()
    store = _get_store()
    rows = []
    if isinstance(store, SQLiteStore):
        with closing(store._connect()) as conn:
            if _table_exists(conn.cursor(), False, "v8_vip_entitlements"):
                rows = conn.execute("SELECT user_id,status,expires_at FROM v8_vip_entitlements").fetchall()
    elif isinstance(store, PostgresStore):
        with store._connect() as conn, conn.cursor() as cursor:
            if _table_exists(cursor, True, "v8_vip_entitlements"):
                cursor.execute("SELECT user_id,status,expires_at FROM v8_vip_entitlements")
                rows = cursor.fetchall()
    for uid, status, expiry in rows:
        existing = db.setdefault("vip_users", {}).get(str(uid))
        effective = later_membership(existing, {"status": str(status), "expires_at": str(expiry)})
        if effective:
            db["vip_users"][str(uid)] = effective
    return db
