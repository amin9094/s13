from __future__ import annotations

import hashlib
import logging
import time
import os
from threading import RLock
from typing import Any

from config import SETTINGS
from core.runtime_topology import replica_count

logger = logging.getLogger(__name__)
_LOCK = RLock()
_LAST_SEEN: dict[tuple[int, str], float] = {}
_EXPIRES: dict[tuple[int, str], float] = {}
_MAX_ENTRIES = 20_000
_CLIENT_LOCK = RLock()
_REDIS: Any = None
_REDIS_DISABLED_UNTIL = 0.0


def _redis_client() -> Any:
    # Creation is shared by executor threads; never publish an unprobed client.
    with _CLIENT_LOCK:
        return _redis_client_locked()


def _redis_client_locked() -> Any:
    global _REDIS, _REDIS_DISABLED_UNTIL
    if not SETTINGS.redis_url or time.monotonic() < _REDIS_DISABLED_UNTIL:
        return None
    if _REDIS is not None:
        return _REDIS
    candidate = None
    try:
        import redis

        timeout = max(0.2, float(os.getenv("REDIS_SOCKET_TIMEOUT_SECONDS", "1.5") or 1.5))
        candidate = redis.Redis.from_url(
            SETTINGS.redis_url,
            decode_responses=True,
            socket_connect_timeout=timeout,
            socket_timeout=timeout,
            health_check_interval=30,
            max_connections=max(2, int(os.getenv("REDIS_MAX_CONNECTIONS", "30") or 30)),
            retry_on_timeout=True,
        )
        candidate.ping()
        _REDIS = candidate
        return _REDIS
    except Exception as exc:
        _REDIS = None
        _REDIS_DISABLED_UNTIL = time.monotonic() + 60
        logger.warning("Redis rate limiter unavailable; using local fallback: %s", exc.__class__.__name__)
        return None
    finally:
        if candidate is not None and candidate is not _REDIS:
            try:
                candidate.close()
            except Exception:
                logger.debug("Failed Redis rate limiter candidate cleanup", exc_info=True)


def _redis_key(uid: int, action: str) -> str:
    digest = hashlib.sha256(str(action).encode("utf-8")).hexdigest()[:24]
    return f"sentinel:rl:{uid}:{digest}"


def _truthy(value: str | None, default: bool = False) -> bool:
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def _production_fail_closed() -> bool:
    on_railway = bool(os.getenv("RAILWAY_PROJECT_ID") or os.getenv("RAILWAY_ENVIRONMENT"))
    environment = str(os.getenv("SENTINEL_ENV") or os.getenv("ENVIRONMENT") or "").lower()
    production = on_railway or environment in {"prod", "production"}
    replicas = replica_count()
    return (
        production
        and replicas > 1
        and _truthy(os.getenv("REQUIRE_REDIS_FOR_PRODUCTION"), True)
        and not _truthy(os.getenv("ALLOW_LOCAL_RATE_LIMIT"), False)
    )


def allow(user_id: int | str, action: str, cooldown_seconds: float) -> bool:
    """Return False when an action repeats inside its cooldown.

    Redis is used when configured, making limits shared by every replica. A
    bounded in-process fallback preserves availability when Redis is absent.
    """
    global _REDIS, _REDIS_DISABLED_UNTIL
    try:
        uid = int(user_id)
        cooldown = max(0.0, float(cooldown_seconds))
    except (TypeError, ValueError):
        return False
    if cooldown <= 0:
        return True

    client = _redis_client()
    if client is not None:
        try:
            ttl_ms = max(1, int(cooldown * 1000))
            return bool(client.set(_redis_key(uid, str(action)), "1", nx=True, px=ttl_ms))
        except Exception as exc:
            with _CLIENT_LOCK:
                if _REDIS is client:
                    _REDIS = None
                    _REDIS_DISABLED_UNTIL = time.monotonic() + 60
            try:
                client.close()
            except Exception:
                logger.debug("Redis rate limiter cleanup failed", exc_info=True)
            logger.warning("Redis rate limiter failed: %s", exc.__class__.__name__)

    if _production_fail_closed():
        logger.error("Redis rate limiter unavailable in production; request denied fail-closed")
        return False

    now = time.monotonic()
    key = (uid, str(action))
    with _LOCK:
        previous = _LAST_SEEN.get(key)
        if previous is not None and now - previous < cooldown:
            return False
        if key not in _LAST_SEEN and len(_LAST_SEEN) >= _MAX_ENTRIES:
            stale = [item for item, expiry in _EXPIRES.items() if expiry <= now]
            for item in stale:
                _LAST_SEEN.pop(item, None)
                _EXPIRES.pop(item, None)
            if len(_LAST_SEEN) >= _MAX_ENTRIES:
                return False
        _LAST_SEEN[key] = now
        _EXPIRES[key] = now + cooldown
        return True


def backend_status() -> dict[str, Any]:
    client = _redis_client()
    return {
        "backend": "redis" if client is not None else "memory",
        "redis_configured": bool(SETTINGS.redis_url),
        "local_entries": len(_LAST_SEEN),
    }


def reset_for_tests() -> None:
    global _REDIS, _REDIS_DISABLED_UNTIL
    with _LOCK:
        _LAST_SEEN.clear()
        _EXPIRES.clear()
    _REDIS = None
    _REDIS_DISABLED_UNTIL = 0.0
