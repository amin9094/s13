"""Clear only the current user's PTB conversations on explicit global exits.

PTB 22 has no public per-user reset API. Keep the two framework internals in
this adapter and cover them with real ConversationHandler tests.
"""
import os
import time

from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationHandlerStop, ConversationHandler

ACTIVITY_KEY = "_sentinel_last_activity_at"


async def reset_conversations_on_exit(update, context):
    query = getattr(update, 'callback_query', None)
    data = str(getattr(query, 'data', '') or '')
    message = getattr(update, 'effective_message', None)
    text = str(getattr(message, 'text', '') or '')
    command = text.split(maxsplit=1)[0].split('@')[0] if text else ''
    is_exit = data in {'home', 'admin_home', 'cancel_current', 'restart_bot'} or command in {'/start', '/menu', '/cancel', '/restart'}
    is_exit = is_exit or (data.startswith('nb:') and not data.startswith('nb:sig_back:'))
    # Opening another CRM case or list terminates the previous input form.
    # A note/phone answer must never land on a different selected customer.
    is_exit = is_exit or data in {'a_automations', 'a_milestones'}
    is_exit = is_exit or data.startswith(('crm_open:', 'crm_pipeline', 'crm_segment:', 'funnel_users:', 'a_crm'))
    is_exit = is_exit or data=='a_contest' or data.startswith(('up:','lesson_manage:'))
    is_exit = is_exit or data.startswith(('ir:', 'ls:'))
    values = getattr(context, 'user_data', None)
    now = time.time()
    timeout = max(60, min(86400, int(os.getenv('BOT_SESSION_TIMEOUT_SECONDS', '1800'))))
    last = float((values or {}).get(ACTIVITY_KEY, now))
    expired = now - last > timeout or last > now + 60
    if values is not None:
        values[ACTIVITY_KEY] = now
        if is_exit:values.pop('review45_form',None)
    if not is_exit and not expired:
        return
    seen = set()
    reset = False
    for handlers in context.application.handlers.values():
        for handler in handlers:
            if not isinstance(handler, ConversationHandler) or id(handler) in seen: continue
            seen.add(id(handler))
            try: key = handler._get_key(update)
            except RuntimeError: continue  # Inapplicable chat/user key.
            if key in handler._conversations:
                handler._update_state(ConversationHandler.END, key)
                reset = True

    if expired and values is not None:
        values.clear()
        values[ACTIVITY_KEY] = now
    if expired and reset and not is_exit:
        if query:
            await query.answer()
        if message:
            await message.reply_text(
                "مهلت عملیات قبلی تمام شد. از منوی اصلی دوباره شروع کنید؛ پیش‌نویس‌های ذخیره‌شده محفوظ‌اند.",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🏠 منوی اصلی", callback_data="home")]]),
            )
        raise ApplicationHandlerStop
