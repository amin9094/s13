from __future__ import annotations

from typing import Any

DatabaseEngine = Any

SCHEMA_REVISION = 18


def _sqlite_statements() -> list[str]:
    from core.economy_integrity import DDL
    from core.storage.market_schema import MARKET_DDL
    return [
        *MARKET_DDL,
        *DDL,
        """CREATE TABLE IF NOT EXISTS v8_schema_migrations(
            revision INTEGER PRIMARY KEY,
            applied_at TEXT NOT NULL
        )""",
        """CREATE TABLE IF NOT EXISTS v8_meta(
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )""",
        """CREATE TABLE IF NOT EXISTS v8_signals(
            id TEXT PRIMARY KEY,
            display_number INTEGER NOT NULL DEFAULT 0,
            symbol TEXT NOT NULL,
            side TEXT NOT NULL,
            status TEXT NOT NULL,
            market_category TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            payload TEXT NOT NULL
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_signals_feed ON v8_signals(created_at DESC, id DESC)",
        "CREATE INDEX IF NOT EXISTS idx_v8_signals_symbol_status ON v8_signals(symbol, status, created_at DESC)",
        """CREATE TABLE IF NOT EXISTS v8_signal_revisions(
            id TEXT PRIMARY KEY,
            signal_id TEXT NOT NULL,
            revision_number INTEGER NOT NULL,
            changed_at TEXT NOT NULL,
            changed_by TEXT,
            change_type TEXT NOT NULL,
            previous_hash TEXT,
            current_hash TEXT NOT NULL,
            changed_fields TEXT NOT NULL,
            payload TEXT NOT NULL,
            FOREIGN KEY(signal_id) REFERENCES v8_signals(id),
            UNIQUE(signal_id, revision_number)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_signal_revisions_feed ON v8_signal_revisions(signal_id, revision_number DESC)",
        """CREATE TABLE IF NOT EXISTS v8_signal_outcomes(
            signal_id TEXT PRIMARY KEY,
            status TEXT NOT NULL,
            result_r REAL,
            result_pips REAL,
            drawdown_r REAL,
            closed_at TEXT,
            evidence_hash TEXT NOT NULL,
            payload TEXT NOT NULL,
            FOREIGN KEY(signal_id) REFERENCES v8_signals(id)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_signal_outcomes_status ON v8_signal_outcomes(status, closed_at DESC)",
        """CREATE TABLE IF NOT EXISTS v8_trading_accounts(
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            name TEXT NOT NULL,
            account_type TEXT NOT NULL,
            phase TEXT NOT NULL,
            currency TEXT NOT NULL,
            balance REAL NOT NULL DEFAULT 0,
            equity REAL NOT NULL DEFAULT 0,
            starting_balance REAL NOT NULL DEFAULT 0,
            high_water_mark REAL NOT NULL DEFAULT 0,
            floating_pnl REAL NOT NULL DEFAULT 0,
            timezone TEXT NOT NULL DEFAULT 'UTC',
            is_default INTEGER NOT NULL DEFAULT 0,
            archived INTEGER NOT NULL DEFAULT 0,
            rule_template_id TEXT,
            data_source TEXT NOT NULL DEFAULT 'manual',
            data_confidence REAL NOT NULL DEFAULT 0.5,
            data_observed_at TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            payload TEXT NOT NULL
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_accounts_user ON v8_trading_accounts(user_id, archived, is_default DESC)",
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_v8_accounts_one_default ON v8_trading_accounts(user_id) WHERE is_default=1 AND archived=0",
        """CREATE TABLE IF NOT EXISTS v8_positions(
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            account_id TEXT NOT NULL,
            signal_id TEXT,
            symbol TEXT NOT NULL,
            side TEXT NOT NULL,
            status TEXT NOT NULL,
            actual_entry REAL NOT NULL,
            actual_stop REAL NOT NULL,
            actual_volume REAL NOT NULL,
            remaining_volume REAL NOT NULL,
            risk_percent REAL NOT NULL,
            risk_money REAL NOT NULL,
            realized_pnl REAL NOT NULL DEFAULT 0,
            unrealized_pnl REAL NOT NULL DEFAULT 0,
            opened_at TEXT NOT NULL,
            closed_at TEXT,
            updated_at TEXT NOT NULL,
            data_source TEXT NOT NULL DEFAULT 'manual',
            data_confidence REAL NOT NULL DEFAULT 0.5,
            payload TEXT NOT NULL,
            FOREIGN KEY(account_id) REFERENCES v8_trading_accounts(id)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_positions_user_status ON v8_positions(user_id, status, opened_at DESC)",
        "CREATE INDEX IF NOT EXISTS idx_v8_positions_account_status ON v8_positions(account_id, status, opened_at DESC)",
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_v8_positions_active_signal ON v8_positions(user_id,account_id,signal_id) WHERE signal_id IS NOT NULL AND status IN ('planned','open','partial')",
        """CREATE TABLE IF NOT EXISTS v8_position_pnl_events(
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            account_id TEXT NOT NULL,
            position_id TEXT NOT NULL,
            event_type TEXT NOT NULL,
            realized_pnl REAL NOT NULL,
            commission REAL NOT NULL DEFAULT 0,
            swap REAL NOT NULL DEFAULT 0,
            fees REAL NOT NULL DEFAULT 0,
            closed_volume REAL NOT NULL DEFAULT 0,
            occurred_at TEXT NOT NULL,
            account_local_date TEXT NOT NULL,
            payload TEXT NOT NULL,
            FOREIGN KEY(position_id) REFERENCES v8_positions(id)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_pnl_account_date ON v8_position_pnl_events(account_id, account_local_date, occurred_at)",
        """CREATE TABLE IF NOT EXISTS v8_equity_events(
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            account_id TEXT NOT NULL,
            balance REAL NOT NULL,
            equity REAL NOT NULL,
            floating_pnl REAL NOT NULL DEFAULT 0,
            high_water_mark REAL NOT NULL DEFAULT 0,
            observed_at TEXT NOT NULL,
            account_local_date TEXT NOT NULL,
            source TEXT NOT NULL,
            confidence REAL NOT NULL,
            payload TEXT NOT NULL
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_equity_account_time ON v8_equity_events(account_id, observed_at DESC)",
        """CREATE TABLE IF NOT EXISTS v8_broker_snapshots(
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            account_id TEXT NOT NULL,
            provider TEXT NOT NULL,
            account_reference TEXT NOT NULL,
            observed_at TEXT NOT NULL,
            confidence REAL NOT NULL,
            checksum TEXT NOT NULL,
            payload TEXT NOT NULL,
            UNIQUE(account_id, observed_at)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_broker_snapshot_account ON v8_broker_snapshots(account_id, observed_at DESC)",
        """CREATE TABLE IF NOT EXISTS v8_daily_account_snapshots(
            account_id TEXT NOT NULL,
            local_date TEXT NOT NULL,
            opening_balance REAL NOT NULL,
            opening_equity REAL NOT NULL,
            lowest_equity REAL NOT NULL,
            highest_equity REAL NOT NULL,
            realized_pnl REAL NOT NULL DEFAULT 0,
            floating_pnl REAL NOT NULL DEFAULT 0,
            updated_at TEXT NOT NULL,
            source_event_id TEXT,
            payload TEXT NOT NULL,
            PRIMARY KEY(account_id, local_date)
        )""",
        """CREATE TABLE IF NOT EXISTS v8_prop_rule_templates(
            id TEXT PRIMARY KEY,
            provider TEXT NOT NULL,
            name TEXT NOT NULL,
            version INTEGER NOT NULL,
            active INTEGER NOT NULL DEFAULT 1,
            rules TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            UNIQUE(provider, name, version)
        )""",
        """CREATE TABLE IF NOT EXISTS v8_prop_rule_evaluations(
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            account_id TEXT NOT NULL,
            position_id TEXT,
            template_id TEXT,
            decision TEXT NOT NULL,
            hard_blocks TEXT NOT NULL,
            warnings TEXT NOT NULL,
            metrics TEXT NOT NULL,
            evaluated_at TEXT NOT NULL,
            rules_version INTEGER NOT NULL
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_rule_eval_account ON v8_prop_rule_evaluations(account_id, evaluated_at DESC)",


        """CREATE TABLE IF NOT EXISTS v8_receipts(
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            storage_backend TEXT NOT NULL,
            object_key TEXT NOT NULL,
            checksum TEXT NOT NULL,
            mime_type TEXT NOT NULL,
            size_bytes INTEGER NOT NULL,
            status TEXT NOT NULL,
            order_id TEXT,
            created_at TEXT NOT NULL,
            payload TEXT NOT NULL
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_receipts_user ON v8_receipts(user_id, created_at DESC)",
        "CREATE INDEX IF NOT EXISTS idx_v8_receipts_order ON v8_receipts(order_id, status)",
        """DELETE FROM v8_receipts WHERE checksum <> '' AND id IN (
            SELECT id FROM (
                SELECT id, ROW_NUMBER() OVER (
                    PARTITION BY user_id, checksum
                    ORDER BY CASE WHEN status='attached' THEN 0 ELSE 1 END, created_at, id
                ) AS duplicate_rank
                FROM v8_receipts WHERE checksum <> ''
            ) duplicate_rows WHERE duplicate_rank > 1
        )""",
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_v8_receipts_user_checksum ON v8_receipts(user_id, checksum) WHERE checksum <> ''",

        """CREATE TABLE IF NOT EXISTS v8_checkout_quotes(
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            plan_id TEXT,
            status TEXT NOT NULL,
            payment_method TEXT NOT NULL,
            payable_toman BIGINT NOT NULL DEFAULT 0,
            usdt_amount REAL NOT NULL DEFAULT 0,
            expires_at TEXT NOT NULL,
            consumed_at TEXT,
            order_id TEXT,
            created_at TEXT NOT NULL,
            payload TEXT NOT NULL
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_quotes_user_status ON v8_checkout_quotes(user_id, status, expires_at)",
        "CREATE INDEX IF NOT EXISTS idx_v8_quotes_expiry ON v8_checkout_quotes(status, expires_at)",
        """CREATE TABLE IF NOT EXISTS v8_vip_orders(
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            plan_id TEXT,
            status TEXT NOT NULL,
            payment_method TEXT NOT NULL,
            amount_toman BIGINT NOT NULL DEFAULT 0,
            usdt_amount REAL NOT NULL DEFAULT 0,
            quote_id TEXT,
            transaction_hash TEXT,
            receipt_key TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            approved_at TEXT,
            payload TEXT NOT NULL
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_orders_user_feed ON v8_vip_orders(user_id, created_at DESC, id DESC)",
        "CREATE INDEX IF NOT EXISTS idx_v8_orders_status ON v8_vip_orders(status, created_at)",
        "CREATE INDEX IF NOT EXISTS idx_v8_orders_review_queue ON v8_vip_orders(status, updated_at, user_id)",
        "CREATE INDEX IF NOT EXISTS idx_v8_orders_user_open_lookup ON v8_vip_orders(user_id, status, updated_at)",
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_v8_orders_tx_unique ON v8_vip_orders(transaction_hash) WHERE transaction_hash IS NOT NULL AND transaction_hash <> ''",
        """CREATE TABLE IF NOT EXISTS v8_vip_entitlements(
            user_id TEXT PRIMARY KEY,
            plan_id TEXT,
            order_id TEXT NOT NULL,
            status TEXT NOT NULL,
            starts_at TEXT NOT NULL,
            expires_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            payload TEXT NOT NULL,
            FOREIGN KEY(order_id) REFERENCES v8_vip_orders(id)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_entitlements_expiry ON v8_vip_entitlements(status, expires_at)",
        """CREATE TABLE IF NOT EXISTS v8_tickets(
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            subject TEXT NOT NULL,
            category TEXT NOT NULL,
            priority TEXT NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            closed_at TEXT,
            satisfaction INTEGER,
            payload TEXT NOT NULL
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_tickets_user_feed ON v8_tickets(user_id, updated_at DESC, id DESC)",
        """CREATE TABLE IF NOT EXISTS v8_ticket_messages(
            id TEXT PRIMARY KEY,
            ticket_id TEXT NOT NULL,
            sender_type TEXT NOT NULL,
            sender_id TEXT NOT NULL,
            body TEXT NOT NULL,
            created_at TEXT NOT NULL,
            payload TEXT NOT NULL,
            FOREIGN KEY(ticket_id) REFERENCES v8_tickets(id)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_ticket_messages ON v8_ticket_messages(ticket_id, created_at, id)",

        """CREATE TABLE IF NOT EXISTS v8_user_preferences(
            user_id TEXT NOT NULL,
            section TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            payload TEXT NOT NULL,
            PRIMARY KEY(user_id, section)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_preferences_section ON v8_user_preferences(section, updated_at DESC)",
        """CREATE TABLE IF NOT EXISTS v8_journal_entries(
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            account_id TEXT,
            position_id TEXT,
            signal_id TEXT,
            symbol TEXT NOT NULL,
            side TEXT NOT NULL,
            status TEXT NOT NULL,
            entry_price REAL,
            exit_price REAL,
            volume REAL NOT NULL DEFAULT 0,
            remaining_volume REAL NOT NULL DEFAULT 0,
            pnl_amount REAL NOT NULL DEFAULT 0,
            pnl_percent REAL NOT NULL DEFAULT 0,
            opened_at TEXT NOT NULL,
            closed_at TEXT,
            updated_at TEXT NOT NULL,
            payload TEXT NOT NULL
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_journal_user_feed ON v8_journal_entries(user_id, opened_at DESC, id DESC)",
        "CREATE UNIQUE INDEX IF NOT EXISTS idx_v8_journal_position ON v8_journal_entries(position_id) WHERE position_id IS NOT NULL",
        """CREATE TABLE IF NOT EXISTS v8_admin_commands(
            id TEXT PRIMARY KEY,
            actor_id TEXT NOT NULL,
            command TEXT NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            payload TEXT NOT NULL,
            result TEXT
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_admin_commands_status ON v8_admin_commands(status, created_at)",
        """CREATE TABLE IF NOT EXISTS v8_idempotency(
            user_id TEXT NOT NULL,
            request_id TEXT NOT NULL,
            action TEXT NOT NULL,
            fingerprint TEXT NOT NULL,
            state TEXT NOT NULL,
            response TEXT,
            owner_token TEXT NOT NULL,
            expires_at TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            PRIMARY KEY(user_id, request_id)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_idempotency_expiry ON v8_idempotency(expires_at)",
        """CREATE TABLE IF NOT EXISTS v8_events(
            sequence INTEGER PRIMARY KEY AUTOINCREMENT,
            event_id TEXT NOT NULL UNIQUE,
            user_id TEXT NOT NULL,
            event_type TEXT NOT NULL,
            entity_type TEXT,
            entity_id TEXT,
            created_at TEXT NOT NULL,
            payload TEXT NOT NULL
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_events_user_seq ON v8_events(user_id, sequence)",
        """CREATE TABLE IF NOT EXISTS v8_data_provenance(
            entity_type TEXT NOT NULL,
            entity_id TEXT NOT NULL,
            field_name TEXT NOT NULL,
            source TEXT NOT NULL,
            provider TEXT,
            confidence REAL NOT NULL,
            observed_at TEXT NOT NULL,
            expires_at TEXT,
            checksum TEXT,
            payload TEXT NOT NULL,
            PRIMARY KEY(entity_type, entity_id, field_name)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_provenance_freshness ON v8_data_provenance(entity_type, observed_at DESC)",
        """CREATE TABLE IF NOT EXISTS v8_market_returns(
            symbol TEXT NOT NULL,
            timeframe TEXT NOT NULL,
            observed_at TEXT NOT NULL,
            return_value REAL NOT NULL,
            source TEXT NOT NULL,
            confidence REAL NOT NULL,
            PRIMARY KEY(symbol, timeframe, observed_at)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_returns_lookup ON v8_market_returns(timeframe, observed_at DESC, symbol)",
        """CREATE TABLE IF NOT EXISTS v8_audit_log(
            sequence INTEGER PRIMARY KEY AUTOINCREMENT,
            event_id TEXT NOT NULL UNIQUE,
            actor_id TEXT NOT NULL,
            action TEXT NOT NULL,
            entity_type TEXT,
            entity_id TEXT,
            request_id TEXT,
            created_at TEXT NOT NULL,
            before_hash TEXT,
            after_hash TEXT,
            payload TEXT NOT NULL
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_audit_actor_time ON v8_audit_log(actor_id, created_at DESC)",
        """CREATE TABLE IF NOT EXISTS v8_telegram_updates(
            update_id TEXT PRIMARY KEY,
            status TEXT NOT NULL,
            payload TEXT NOT NULL,
            attempts INTEGER NOT NULL DEFAULT 0,
            queued_at REAL NOT NULL,
            claimed_at REAL,
            completed_at REAL,
            updated_at REAL NOT NULL,
            last_error TEXT,
            worker_id TEXT
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_telegram_updates_status ON v8_telegram_updates(status, updated_at, queued_at)",
        """CREATE TABLE IF NOT EXISTS v8_mt5_pairing_codes(
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            account_id TEXT NOT NULL,
            code_hash TEXT NOT NULL UNIQUE,
            expires_at TEXT NOT NULL,
            consumed_at TEXT,
            connector_id TEXT,
            created_at TEXT NOT NULL,
            payload TEXT NOT NULL
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_mt5_pairing_user ON v8_mt5_pairing_codes(user_id, account_id, created_at DESC)",
        """CREATE TABLE IF NOT EXISTS v8_mt5_connectors(
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            account_id TEXT NOT NULL,
            platform TEXT NOT NULL,
            account_login TEXT NOT NULL,
            broker TEXT NOT NULL,
            server_name TEXT NOT NULL,
            account_name TEXT NOT NULL DEFAULT '',
            token_hash TEXT NOT NULL UNIQUE,
            secret_payload TEXT NOT NULL,
            status TEXT NOT NULL,
            readonly_mode INTEGER NOT NULL DEFAULT 1,
            last_seen_at TEXT,
            last_snapshot_at TEXT,
            last_event_at TEXT,
            revoked_at TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            payload TEXT NOT NULL,
            UNIQUE(user_id, account_id, account_login, server_name)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_mt5_connectors_user ON v8_mt5_connectors(user_id, status, updated_at DESC)",
        "CREATE INDEX IF NOT EXISTS idx_v8_mt5_connectors_account ON v8_mt5_connectors(account_id, status, last_seen_at DESC)",
        """CREATE TABLE IF NOT EXISTS v8_mt5_nonces(
            connector_id TEXT NOT NULL,
            nonce TEXT NOT NULL,
            received_at TEXT NOT NULL,
            expires_at TEXT NOT NULL,
            PRIMARY KEY(connector_id, nonce)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_mt5_nonces_expiry ON v8_mt5_nonces(expires_at)",
        """CREATE TABLE IF NOT EXISTS v8_mt5_events(
            id TEXT PRIMARY KEY,
            connector_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            account_id TEXT NOT NULL,
            external_id TEXT NOT NULL,
            event_type TEXT NOT NULL,
            occurred_at TEXT NOT NULL,
            checksum TEXT NOT NULL,
            payload TEXT NOT NULL,
            UNIQUE(connector_id, external_id, event_type, checksum)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_mt5_events_account ON v8_mt5_events(account_id, occurred_at DESC)",
        """CREATE TABLE IF NOT EXISTS v8_risk_daily_plans(
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            account_id TEXT NOT NULL,
            local_date TEXT NOT NULL,
            status TEXT NOT NULL,
            max_daily_risk_percent REAL NOT NULL,
            max_risk_per_trade_percent REAL NOT NULL,
            max_trades INTEGER NOT NULL,
            stop_after_losses INTEGER NOT NULL,
            minimum_rr REAL NOT NULL,
            accepted_at TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            payload TEXT NOT NULL,
            UNIQUE(user_id, account_id, local_date)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_risk_plan_user_date ON v8_risk_daily_plans(user_id, local_date DESC)",
        """CREATE TABLE IF NOT EXISTS v8_risk_checkins(
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            account_id TEXT,
            journal_id TEXT,
            checkin_type TEXT NOT NULL,
            occurred_at TEXT NOT NULL,
            payload TEXT NOT NULL
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_risk_checkins_user ON v8_risk_checkins(user_id, occurred_at DESC)",
        """CREATE TABLE IF NOT EXISTS v8_prop_alerts(
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            account_id TEXT NOT NULL,
            code TEXT NOT NULL,
            severity TEXT NOT NULL,
            status TEXT NOT NULL,
            observed_at TEXT NOT NULL,
            resolved_at TEXT,
            fingerprint TEXT NOT NULL,
            payload TEXT NOT NULL,
            UNIQUE(account_id, fingerprint)
        )""",
        "CREATE INDEX IF NOT EXISTS idx_v8_prop_alerts_account ON v8_prop_alerts(account_id, status, observed_at DESC)",
        """CREATE TABLE IF NOT EXISTS v8_recovery_runs(
            id TEXT PRIMARY KEY,
            backup_key TEXT NOT NULL,
            status TEXT NOT NULL,
            started_at TEXT NOT NULL,
            finished_at TEXT,
            checksum TEXT,
            records_verified INTEGER NOT NULL DEFAULT 0,
            error TEXT,
            payload TEXT NOT NULL
        )""",
    ]


def _postgres_statements() -> list[str]:
    statements = _sqlite_statements()
    converted: list[str] = []
    for statement in statements:
        sql = statement
        sql = sql.replace("INTEGER PRIMARY KEY AUTOINCREMENT", "BIGSERIAL PRIMARY KEY")
        sql = sql.replace(" REAL ", " DOUBLE PRECISION ")
        # JSON is stored as canonical text intentionally. This keeps checksum
        # semantics identical across SQLite/PostgreSQL and avoids driver-specific
        # JSON adaptation in the compatibility migration.
        converted.append(sql)
    return converted


def apply_schema(engine: DatabaseEngine) -> None:
    statements = _postgres_statements() if engine.dialect.name == "postgres" else _sqlite_statements()
    with engine.transaction() as cursor:
        if engine.dialect.name == 'postgres':
            cursor.execute('SELECT pg_advisory_xact_lock(719084410)')
        for statement in statements:
            cursor.execute(statement)
        if engine.dialect.name == "postgres":
            # Existing releases used floating-point columns for Toman. Migrate
            # them to exact integer storage without changing whole-Toman values.
            cursor.execute(
                """DO $$ BEGIN
                   IF EXISTS (
                       SELECT 1 FROM information_schema.columns
                       WHERE table_schema=current_schema() AND table_name='v8_checkout_quotes'
                         AND column_name='payable_toman' AND data_type <> 'bigint'
                   ) THEN
                       ALTER TABLE v8_checkout_quotes
                       ALTER COLUMN payable_toman TYPE BIGINT USING ROUND(payable_toman)::BIGINT;
                   END IF;
                   IF EXISTS (
                       SELECT 1 FROM information_schema.columns
                       WHERE table_schema=current_schema() AND table_name='v8_vip_orders'
                         AND column_name='amount_toman' AND data_type <> 'bigint'
                   ) THEN
                       ALTER TABLE v8_vip_orders
                       ALTER COLUMN amount_toman TYPE BIGINT USING ROUND(amount_toman)::BIGINT;
                   END IF;
                END $$"""
            )
            cursor.execute(
                """INSERT INTO v8_schema_migrations(revision, applied_at)
                   VALUES(?, CURRENT_TIMESTAMP)
                   ON CONFLICT(revision) DO NOTHING""",
                (SCHEMA_REVISION,),
            )
        else:
            cursor.execute(
                "INSERT OR IGNORE INTO v8_schema_migrations(revision, applied_at) VALUES(?, datetime('now'))",
                (SCHEMA_REVISION,),
            )
