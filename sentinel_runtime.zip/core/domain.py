from __future__ import annotations

import secrets
import string
from datetime import datetime, timedelta
from typing import Any

from config import SETTINGS
from core.db import next_id
from core.utils import parse_dt, utc_iso, utc_now
from modules.discount_campaigns import (
    discount_security_status,
    normalize_campaign_fields,
    record_discount_attempt,
    record_discount_crm_activity,
    record_discount_event,
    register_affiliate_commission,
    settle_discount_for_order,
    validate_campaign_conditions,
)

DISCOUNT_TIERS = (10, 20, 30, 40, 50)
DEFAULT_DISCOUNT_POOL_SIZE = 50
DISCOUNT_REWARD_POINTS = {10: 60, 20: 120, 30: 180, 40: 240, 50: 300}


def register_user(db: dict[str, Any], user: Any) -> dict[str, Any]:
    uid = str(user.id)
    record = db.setdefault("users", {}).setdefault(uid, {})
    record.update({
        "id": int(user.id),
        "username": user.username or "",
        "first_name": user.first_name or "",
        "last_name": user.last_name or "",
        "last_seen_at": utc_iso(),
    })
    record.setdefault("created_at", utc_iso())
    # Telegram's language_code is only a hint.  We keep it separately and do
    # not treat it as the user's explicit choice made in the bot.
    if getattr(user, "language_code", None):
        record["telegram_language_code"] = str(user.language_code)[:16]
    db.setdefault("user_points", {}).setdefault(uid, 0)
    db.setdefault("user_profiles", {}).setdefault(uid, {"user_id": uid, "created_at": record["created_at"]})
    return record


def add_points(db: dict[str, Any], user_id: int | str, amount: int, reason: str, *, source_event: str = "", actor: int | str = "system") -> int:
    from modules.user_intelligence import record_user_activity, refresh_user_profile

    uid = str(user_id)
    points = db.setdefault("user_points", {})
    if source_event:
        existing = next((r for r in db.get("point_history", []) if r.get("source_event") == source_event and str(r.get("user_id")) == uid), None)
        if existing:
            if int(existing.get("requested_amount",existing["amount"])) != int(amount):
                raise ValueError("POINT_SOURCE_CONFLICT")
            return int(points.get(uid, 0))
    previous = max(0, int(points.get(uid, 0)))
    requested_amount = int(amount)
    net_amount = requested_amount
    if requested_amount > 0:
        from modules.economic_refunds import outstanding_point_debt
        repayment = min(requested_amount, outstanding_point_debt(db, uid))
        if repayment:
            from core.economy_integrity import economic_event
            repayment_source = source_event or f"points:{db.get('next_ids',{}).get('point_transaction',1) or 1}"
            economic_event(db,f'points_debt_repayment:{uid}:{repayment_source}',uid,
                           kind='points_debt_repayment',value=repayment,actor=actor,reason=reason)
            net_amount -= repayment
    current = max(0, previous + net_amount)
    actual_delta = current - previous
    points[uid] = current
    ids = db.setdefault("next_ids", {})
    transaction_id = max(1, int(ids.get("point_transaction", 1) or 1))
    ids["point_transaction"] = transaction_id + 1
    db.setdefault("point_history", []).append({
        "id": transaction_id,
        "user_id": uid,
        "amount": actual_delta,
        "requested_amount": requested_amount,
        "direction": "earned" if actual_delta >= 0 else "spent",
        "balance_after": current,
        "source_event": source_event or f"points:{transaction_id}",
        "actor": str(actor),
        "reason": str(reason)[:200],
        "created_at": utc_iso(),
    })
    if actual_delta:
        record_user_activity(
            db,
            uid,
            "points_earned" if actual_delta > 0 else "points_spent",
            source="points",
            detail=str(reason),
            metadata={"amount": actual_delta, "balance_after": current},
        )
    refresh_user_profile(db, uid)
    return current


def audit(db: dict[str, Any], admin_id: int | str, action: str, details: str = "") -> None:
    from core.logging_context import operation_id
    db.setdefault("admin_logs", []).append({
        "admin_id": str(admin_id),
        "action": action,
        "operation_id": operation_id(),
        "details": details,
        "created_at": utc_iso(),
    })
    db["admin_logs"] = db["admin_logs"][-1000:]


def generate_code(length: int = 10) -> str:
    alphabet = string.ascii_uppercase + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(length))


def create_discount(
    db: dict[str, Any],
    percent: int,
    *,
    assigned_to: int | str | None = None,
    expires_days: int = 30,
    code: str | None = None,
    source: str = "manual",
    pool: bool = False,
) -> dict[str, Any]:
    if not 1 <= int(percent) <= 100:
        raise ValueError("درصد تخفیف نامعتبر است")
    all_codes = db.setdefault("discount_codes", {})
    candidate = (code or generate_code()).upper()
    if code and candidate in all_codes:
        raise ValueError("این کد قبلاً وجود دارد")
    for _ in range(10):
        if candidate not in all_codes:
            break
        candidate = generate_code()
    else:
        raise RuntimeError("DISCOUNT_CODE_GENERATION_FAILED")
    item = {
        "code": candidate,
        "percent": int(percent),
        "status": "active",
        "assigned_to": str(assigned_to or ""),
        "expires_at": utc_iso(utc_now() + timedelta(days=max(1, int(expires_days)))),
        "reserved_order_id": None,
        "created_at": utc_iso(),
        "used_at": None,
        "used_by": "",
        "source": str(source or "manual"),
        "pool": bool(pool),
        "assigned_at": utc_iso() if assigned_to is not None else None,
    }
    normalize_campaign_fields(item)
    all_codes[candidate] = item
    return item



def normalize_discount_tier(percent: int | str) -> int:
    try:
        value = int(percent)
    except (TypeError, ValueError) as exc:
        raise ValueError("دسته تخفیف نامعتبر است") from exc
    if value not in DISCOUNT_TIERS:
        raise ValueError("دسته تخفیف باید یکی از ۱۰، ۲۰، ۳۰، ۴۰ یا ۵۰ درصد باشد")
    return value


def _discount_is_expired(item: dict[str, Any]) -> bool:
    expiry = parse_dt(item.get("expires_at"))
    return bool(expiry and expiry <= utc_now())


def discount_pool_items(db: dict[str, Any], percent: int | str) -> list[dict[str, Any]]:
    tier = normalize_discount_tier(percent)
    result: list[dict[str, Any]] = []
    for item in db.setdefault("discount_codes", {}).values():
        if not isinstance(item, dict) or int(item.get("percent", 0) or 0) != tier:
            continue
        if item.get("status") == "active" and _discount_is_expired(item):
            item["status"] = "disabled"
        if item.get("status") != "active":
            continue
        if str(item.get("assigned_to") or ""):
            continue
        if not bool(item.get("pool")):
            continue
        result.append(item)
    result.sort(key=lambda row: str(row.get("created_at") or ""))
    return result


def discount_stock_snapshot(db: dict[str, Any]) -> dict[int, int]:
    return {tier: len(discount_pool_items(db, tier)) for tier in DISCOUNT_TIERS}


def ensure_discount_reward_items(db: dict[str, Any]) -> list[dict[str, Any]]:
    settings = db.setdefault("settings", {})
    source = settings.get("rewardItems", [])
    existing = [item for item in source if isinstance(item, dict)] if isinstance(source, list) else []
    tier_items: dict[int, dict[str, Any]] = {}
    non_discount: list[dict[str, Any]] = []
    max_id = 0
    for item in existing:
        try:
            max_id = max(max_id, int(item.get("id", 0) or 0))
        except (TypeError, ValueError):
            pass
        try:
            discount = int(item.get("discountPct", 0) or 0)
        except (TypeError, ValueError):
            discount = 0
        if discount <= 0:
            non_discount.append(dict(item))
            continue
        if discount in DISCOUNT_TIERS and discount not in tier_items:
            normalized = dict(item)
            normalized["discountPct"] = discount
            normalized["name"] = f"کد تخفیف {discount}٪ اشتراک"
            try:
                points = int(normalized.get("points", DISCOUNT_REWARD_POINTS[discount]) or DISCOUNT_REWARD_POINTS[discount])
            except (TypeError, ValueError):
                points = DISCOUNT_REWARD_POINTS[discount]
            normalized["points"] = max(1, points)
            tier_items[discount] = normalized

    for tier in DISCOUNT_TIERS:
        if tier in tier_items:
            continue
        max_id += 1
        tier_items[tier] = {
            "id": max_id,
            "name": f"کد تخفیف {tier}٪ اشتراک",
            "points": DISCOUNT_REWARD_POINTS[tier],
            "discountPct": tier,
        }

    # Private subscriptions are never redeemable with points. Buying an
    # approved private subscription awards 100 points instead. Remove the
    # legacy shop item automatically from existing databases.
    non_discount = [
        item
        for item in non_discount
        if str(item.get("rewardType") or "").strip() != "private_subscription"
        and str(item.get("name") or "").strip() != "اشتراک خصوصی"
    ]
    required_services = (
        {"name": "تحلیل درخواستی", "points": 20, "discountPct": 0, "rewardType": "analysis_request"},
    )
    existing_names = {str(item.get("name") or "").strip() for item in non_discount}
    for service in required_services:
        if service["name"] not in existing_names:
            max_id += 1
            non_discount.append({"id": max_id, **service})

    used_ids: set[int] = set()
    normalized_items: list[dict[str, Any]] = []
    for item in [tier_items[tier] for tier in DISCOUNT_TIERS] + non_discount:
        try:
            item_id = int(item.get("id", 0) or 0)
        except (TypeError, ValueError):
            item_id = 0
        if item_id <= 0 or item_id in used_ids:
            max_id += 1
            item_id = max_id
        item["id"] = item_id
        used_ids.add(item_id)
        normalized_items.append(item)
    settings["rewardItems"] = normalized_items
    return normalized_items


def refill_discount_pool(
    db: dict[str, Any],
    percent: int | str,
    *,
    count: int = DEFAULT_DISCOUNT_POOL_SIZE,
    expires_days: int = 90,
) -> list[dict[str, Any]]:
    tier = normalize_discount_tier(percent)
    amount = max(1, min(100, int(count)))
    created = [
        create_discount(
            db,
            tier,
            expires_days=expires_days,
            source="stock",
            pool=True,
        )
        for _ in range(amount)
    ]
    return created


def ensure_discount_system(
    db: dict[str, Any],
    *,
    target_per_tier: int = DEFAULT_DISCOUNT_POOL_SIZE,
) -> dict[int, int]:
    ensure_discount_reward_items(db)
    settings = db.setdefault("settings", {})
    system = settings.setdefault("discountSystem", {})
    target = max(1, min(50, int(target_per_tier)))
    # Keep every fixed tier stocked up to the configured target. Older releases
    # initialized only five rows and then never migrated existing databases.
    # This idempotent top-up safely upgrades those installations to 50.
    for tier in DISCOUNT_TIERS:
        missing = target - len(discount_pool_items(db, tier))
        if missing > 0:
            refill_discount_pool(db, tier, count=missing)
    system.update({
        "initialized": True,
        "initial_stock": max(target, int(system.get("initial_stock", 0) or 0)),
        "target_per_tier": target,
        "initialized_at": system.get("initialized_at") or utc_iso(),
        "last_stock_check_at": utc_iso(),
    })
    return discount_stock_snapshot(db)


def assign_discount_from_pool(
    db: dict[str, Any],
    percent: int | str,
    user_id: int | str,
    *,
    issued_via: str = "admin",
    allow_auto_create: bool = True,
    coupon_expires_at: str | None = None,
    apply_expiry_policy: bool = False,
) -> tuple[dict[str, Any], bool]:
    tier = normalize_discount_tier(percent)
    uid = str(user_id).strip()
    if not uid.isdigit() or int(uid) <= 0:
        raise ValueError("شناسه کاربر نامعتبر است")
    if apply_expiry_policy and coupon_expires_at is not None and parse_dt(coupon_expires_at) is None:
        raise ValueError("تاریخ اعتبار کد تخفیف نامعتبر است")
    available = discount_pool_items(db, tier)
    auto_created = False
    if available:
        item = available[0]
        item["assigned_to"] = uid
        item["assigned_at"] = utc_iso()
        item["source"] = str(item.get("source") or "stock")
    elif allow_auto_create:
        item = create_discount(
            db,
            tier,
            assigned_to=uid,
            expires_days=90,
            source=f"auto:{issued_via}",
            pool=True,
        )
        auto_created = True
    else:
        raise ValueError(f"موجودی کد {tier}٪ تمام شده است")
    if apply_expiry_policy:
        if coupon_expires_at is not None and parse_dt(coupon_expires_at) is None:
            raise ValueError("تاریخ اعتبار کد تخفیف نامعتبر است")
        item["expires_at"] = coupon_expires_at
    item["issued_via"] = issued_via
    db.setdefault("discount_history", []).append(
        {
            "action": "issued",
            "code": item["code"],
            "percent": tier,
            "user_id": uid,
            "issued_via": issued_via,
            "auto_created": auto_created,
            "created_at": utc_iso(),
        }
    )
    db["discount_history"] = db["discount_history"][-2000:]
    return item, auto_created


def return_discount_to_pool(db: dict[str, Any], code: str, user_id: int | str) -> bool:
    item = db.get("discount_codes", {}).get(str(code).strip().upper())
    if not isinstance(item, dict):
        return False
    if item.get("status") != "active" or str(item.get("assigned_to") or "") != str(user_id):
        return False
    if not bool(item.get("pool")):
        return False
    item["assigned_to"] = ""
    item["assigned_at"] = None
    item["issued_via"] = None
    db.setdefault("discount_history", []).append(
        {
            "action": "returned_to_pool",
            "code": item["code"],
            "percent": int(item.get("percent", 0) or 0),
            "user_id": str(user_id),
            "created_at": utc_iso(),
        }
    )
    db["discount_history"] = db["discount_history"][-2000:]
    return True


def resolve_registered_user_id(db: dict[str, Any], value: str) -> int:
    raw = str(value or "").strip()
    if raw.startswith("@"):
        raw = raw[1:]
    if raw.isdigit() and int(raw) > 0:
        return int(raw)
    username = raw.casefold()
    if not username:
        raise ValueError("آیدی عددی یا نام کاربری را وارد کنید")
    for uid, user in db.get("users", {}).items():
        if not isinstance(user, dict):
            continue
        if str(user.get("username") or "").strip().lstrip("@").casefold() == username:
            return int(uid)
    raise ValueError("این نام کاربری در ربات پیدا نشد؛ کاربر باید حداقل یک‌بار /start را زده باشد")

def validate_discount(
    db: dict[str, Any],
    code: str,
    user_id: int | str,
    *,
    plan_id: int | str | None = None,
    product_type: str = "vip",
    order_amount: int | str | None = None,
    payment_method: str | None = None,
) -> tuple[bool, str, dict[str, Any] | None]:
    clean_code = str(code).strip().upper()
    allowed, security_message = discount_security_status(db, user_id)
    if not allowed:
        return False, security_message, None
    item = db.get("discount_codes", {}).get(clean_code)

    def fail(message: str) -> tuple[bool, str, None]:
        record_discount_attempt(db, user_id, clean_code, success=False, reason=message)
        record_discount_event(db, "validation_failed", code=clean_code, user_id=user_id, detail=message)
        record_discount_crm_activity(db, user_id, "discount_rejected", code=clean_code, detail=message)
        return False, message, None

    if not item:
        return fail("کد تخفیف پیدا نشد.")
    normalize_campaign_fields(item)
    if item.get("status") == "expired":
        return fail("مهلت استفاده از این کد تمام شده است.")
    if item.get("status") != "active":
        return fail("این کد تخفیف فعال نیست.")
    now = utc_now()
    starts = parse_dt(item.get("starts_at"))
    if starts and starts > now:
        return fail("زمان استفاده از این کد هنوز شروع نشده است.")
    expiry = parse_dt(item.get("expires_at"))
    if expiry and expiry <= now:
        item["status"] = "expired"
        item.setdefault("expired_at", item.get("expires_at") or utc_iso())
        item["updated_at"] = utc_iso()
        return fail("مهلت استفاده از این کد تمام شده است.")
    uid = str(user_id)
    if str(item.get("scope") or "") == "public":
        used_by = [str(value) for value in item.get("used_by", [])]
        per_user_count = used_by.count(uid)
        max_per_user = max(0, int(item.get("max_uses_per_user", 1 if item.get("one_per_user", True) else 0) or 0))
        if max_per_user and per_user_count >= max_per_user:
            return fail("شما قبلاً به سقف استفاده از این کد رسیده‌اید.")
        reservations = item.get("reservations", {}) if isinstance(item.get("reservations"), dict) else {}
        if max_per_user and uid in {str(value) for value in reservations.values()}:
            return fail("این کد برای سفارش در حال بررسی شما رزرو شده است.")
        max_uses = max(0, int(item.get("max_uses", 0) or 0))
        used_count = max(0, int(item.get("used_count", 0) or 0))
        if max_uses and used_count + len(reservations) >= max_uses:
            return fail("ظرفیت استفاده از این کد تکمیل شده است.")
    else:
        assigned = str(item.get("assigned_to") or "")
        if bool(item.get("pool")) and not assigned:
            return fail("این کد هنوز برای کاربری صادر نشده است.")
        if assigned and assigned != uid:
            return fail("این کد برای کاربر دیگری صادر شده است.")

    eligible, message = validate_campaign_conditions(
        db,
        item,
        user_id,
        plan_id=plan_id,
        product_type=product_type,
        order_amount=order_amount,
        payment_method=payment_method,
    )
    if not eligible:
        return fail(message)
    record_discount_attempt(db, user_id, clean_code, success=True)
    record_discount_event(db, "validation_success", code=clean_code, user_id=user_id, amount=int(order_amount or 0))
    record_discount_crm_activity(
        db, user_id, "discount_validated", code=clean_code, detail="کد معتبر بود", metadata={"plan_id": plan_id, "payment_method": payment_method}
    )
    return True, "OK", item


def reserve_discount(item: dict[str, Any], order_id: str, user_id: int | str | None = None, *, db: dict[str, Any] | None = None) -> None:
    normalize_campaign_fields(item)
    if str(item.get("scope") or "") == "public":
        reservations = item.setdefault("reservations", {})
        if not isinstance(reservations, dict):
            reservations = {}
            item["reservations"] = reservations
        reservations[str(order_id)] = str(user_id or "")
    else:
        item["status"] = "reserved"
        item["reserved_order_id"] = order_id
    if db is not None:
        record_discount_event(db, "reserved", code=item.get("code", ""), user_id=user_id, order_id=order_id)
        record_discount_crm_activity(db, user_id, "discount_reserved", code=item.get("code", ""), detail=order_id)


def release_discount(db: dict[str, Any], order: dict[str, Any]) -> None:
    settle_discount_for_order(db, order, "rejected", reason="order_released")


def consume_discount(db: dict[str, Any], order: dict[str, Any]) -> None:
    code = str(order.get("coupon") or "").upper()
    item = db.get("discount_codes", {}).get(code)
    if not item:
        return
    normalize_campaign_fields(item)
    if str(item.get("scope") or "") == "public":
        order_id = str(order.get("order_id") or "")
        consumed_orders = item.setdefault("consumed_order_ids", [])
        if order_id and order_id in {str(value) for value in consumed_orders}:
            return
        reservations = item.get("reservations", {})
        if isinstance(reservations, dict):
            reservations.pop(order_id, None)
        uid = str(order.get("user_id") or "")
        used_by = item.setdefault("used_by", [])
        used_by.append(uid)
        if order_id:
            consumed_orders.append(order_id)
        item["used_count"] = int(item.get("used_count", 0) or 0) + 1
        item["last_used_at"] = utc_iso()
        max_uses = max(0, int(item.get("max_uses", 0) or 0))
        if max_uses and int(item["used_count"]) >= max_uses:
            item["status"] = "disabled"
    else:
        if item.get("reserved_order_id") not in {None, order.get("order_id")}:
            raise ValueError("کد تخفیف توسط سفارش دیگری رزرو شده است")
        item.update({
            "status": "used",
            "reserved_order_id": None,
            "used_at": utc_iso(),
            "used_by": str(order.get("user_id")),
        })
    register_affiliate_commission(db, item, order)
    record_discount_event(
        db,
        "consumed",
        code=code,
        user_id=order.get("user_id"),
        order_id=str(order.get("order_id") or ""),
        amount=int(order.get("price", 0) or 0),
        discount_amount=int(order.get("discount_amount", 0) or 0),
    )
    record_discount_crm_activity(
        db,
        order.get("user_id"),
        "discount_used",
        code=code,
        detail=f"order={order.get('order_id')}",
        metadata={"price": order.get("price"), "discount_amount": order.get("discount_amount")},
    )



def _vip_pricing_ready(db: dict[str, Any]) -> bool:
    settings = db.get("vip_settings", {})
    if not isinstance(settings, dict):
        return False
    try:
        price = int(settings.get("price", 0) or 0)
        days = int(settings.get("duration_days", 0) or 0)
    except (TypeError, ValueError):
        return False
    plans = db.get("vip_plans", []) if isinstance(db.get("vip_plans"), list) else []
    plan_ready = any(
        isinstance(row, dict)
        and bool(row.get("active", True))
        and int(row.get("price", 0) or 0) >= 0
        and int(row.get("duration_days", 0) or 0) > 0
        for row in plans
    )
    return (price > 0 and days > 0) or plan_ready


def card_payment_settings_ready(db: dict[str, Any]) -> bool:
    settings = db.get("vip_settings", {})
    if not isinstance(settings, dict) or not _vip_pricing_ready(db):
        return False
    card_digits = "".join(ch for ch in str(settings.get("card_number") or "") if ch.isdigit())
    owner = str(settings.get("owner_name") or "").strip()
    return len(card_digits) == 16 and 2 <= len(owner) <= 100


def usdt_payment_settings_ready(db: dict[str, Any]) -> bool:
    from modules.payment_verification import normalize_network, wallet_valid

    settings = db.get("vip_settings", {})
    if not isinstance(settings, dict) or not _vip_pricing_ready(db):
        return False
    if not bool(settings.get("usdt_enabled", False)):
        return False
    wallet = str(settings.get("usdt_wallet_address") or "").strip()
    network = normalize_network(str(settings.get("usdt_network") or ""))
    try:
        rate = float(settings.get("usdt_rate_toman", 0) or 0)
    except (TypeError, ValueError):
        return False
    return network in {"TRC20", "ERC20", "BEP20"} and wallet_valid(network, wallet) and rate > 0


def payment_settings_ready(db: dict[str, Any]) -> bool:
    return card_payment_settings_ready(db) or usdt_payment_settings_ready(db)


def projected_vip_expiry(db: dict[str, Any], user_id: int | str, days: int) -> datetime:
    from core.membership_bridge import later_membership, normalized_for_mutation
    current = later_membership(db.setdefault("vip_users", {}).get(str(user_id), {}), normalized_for_mutation(user_id)) or {}
    current_expiry = parse_dt(current.get("expires_at")) if isinstance(current, dict) else None
    start = current_expiry if current_expiry and current_expiry > utc_now() else utc_now()
    return start + timedelta(days=max(1, int(days)))


def find_vip_order(db: dict[str, Any], order_id: str) -> dict[str, Any] | None:
    return next(
        (item for item in db.get("vip_orders", []) if isinstance(item, dict) and item.get("order_id") == order_id),
        None,
    )


def claim_vip_order_approval(db: dict[str, Any], order_id: str, admin_id: int | str) -> dict[str, Any] | None:
    order = find_vip_order(db, order_id)
    if not order or order.get("status") != "pending":
        return None
    order.update(
        {
            "status": "approving",
            "processing_by": str(admin_id),
            "processing_started_at": utc_iso(),
            "processing_invite_link": None,
            "approval_last_error": None,
        }
    )
    return dict(order)


def store_vip_order_processing_invite(
    db: dict[str, Any],
    order_id: str,
    admin_id: int | str,
    invite_link: str,
) -> bool:
    order = find_vip_order(db, order_id)
    if (
        not order
        or order.get("status") != "approving"
        or str(order.get("processing_by")) != str(admin_id)
    ):
        return False
    order["processing_invite_link"] = str(invite_link)
    order["processing_invite_created_at"] = utc_iso()
    return True


def release_vip_order_approval(db: dict[str, Any], order_id: str, admin_id: int | str, error: str) -> None:
    order = find_vip_order(db, order_id)
    if not order:
        return
    if order.get("status") == "approving" and str(order.get("processing_by")) == str(admin_id):
        order.update(
            {
                "status": "pending",
                "processing_by": None,
                "processing_started_at": None,
                "processing_invite_link": None,
                "processing_invite_created_at": None,
                "approval_last_error": str(error)[:500],
                "approval_last_failed_at": utc_iso(),
            }
        )


def stale_vip_order_claims(db: dict[str, Any]) -> list[dict[str, Any]]:
    cutoff = utc_now() - timedelta(minutes=15)
    rows: list[dict[str, Any]] = []
    for order in db.get("vip_orders", []):
        if not isinstance(order, dict) or order.get("status") != "approving":
            continue
        started = parse_dt(order.get("processing_started_at"))
        if started is None or started <= cutoff:
            rows.append(dict(order))
    return rows


def recover_stale_order_claim(db: dict[str, Any], order_id: str, error: str = "") -> bool:
    order = find_vip_order(db, order_id)
    if not order or order.get("status") != "approving":
        return False
    started = parse_dt(order.get("processing_started_at"))
    cutoff = utc_now() - timedelta(minutes=15)
    if started is not None and started > cutoff:
        return False
    order.update(
        {
            "status": "pending",
            "processing_by": None,
            "processing_started_at": None,
            "processing_invite_link": None,
            "processing_invite_created_at": None,
            "processing_recovered_at": utc_iso(),
            "approval_last_error": (error or "stale approval claim recovered automatically")[:500],
            "approval_last_failed_at": utc_iso(),
            "admin_notified_at": None,
        }
    )
    return True


def finalize_vip_order_approval(
    db: dict[str, Any],
    order_id: str,
    admin_id: int | str,
    invite_link: str,
    expires_at: datetime,
) -> dict[str, Any] | None:
    order = find_vip_order(db, order_id)
    if not order or order.get("status") != "approving" or str(order.get("processing_by")) != str(admin_id):
        return None
    if not str(invite_link).startswith(("https://t.me/", "https://telegram.me/", "tg://")):
        raise ValueError("لینک دعوت معتبر ساخته نشده است")
    if expires_at <= utc_now():
        raise ValueError("تاریخ پایان VIP باید در آینده باشد")
    duration_days = int(order.get("duration_days") or db.get("vip_settings", {}).get("duration_days", 30) or 30)
    # Recalculate against the latest committed VIP state so a concurrent manual
    # extension cannot be overwritten by an older projected timestamp.
    effective_expiry = max(expires_at, projected_vip_expiry(db, order["user_id"], duration_days))
    vip = activate_vip(
        db,
        order["user_id"],
        duration_days,
        invite_link=invite_link,
        source_order_id=order_id,
        fixed_expires_at=effective_expiry,
    )
    consume_discount(db, order)
    order.update(
        {
            "status": "approved",
            "approved_at": utc_iso(),
            "approved_by": int(admin_id),
            "expires_at": vip["expires_at"],
            "invite_link": invite_link,
            "processing_by": None,
            "processing_started_at": None,
            "processing_invite_link": None,
            "processing_invite_created_at": None,
            "user_notified_at": None,
            "user_notification_attempts": 0,
            "user_notification_next_retry_at": None,
        }
    )
    # Award the purchase bonus exactly once per approved order. The marker is
    # stored on the order so retries or recovery cannot duplicate the reward.
    if not bool(order.get("purchase_points_awarded")):
        purchase_points = 100
        add_points(db, order["user_id"], purchase_points, f"vip_purchase:{order_id}")
        order["purchase_points_awarded"] = True
        order["purchase_points_amount"] = purchase_points
        order["purchase_points_awarded_at"] = utc_iso()
    audit(db, admin_id, "approve_vip", order_id)
    from modules.user_intelligence import record_user_activity, refresh_user_profile
    record_user_activity(
        db,
        order["user_id"],
        "vip_order_approved",
        source="subscription",
        detail=order_id,
        metadata={"price": int(order.get("price", 0) or 0), "expires_at": order.get("expires_at")},
    )
    refresh_user_profile(db, order["user_id"])
    from modules.sales_growth import register_plan_sale

    if not bool(order.get("sales_count_registered")):
        register_plan_sale(db, order.get("plan_id"))
        order["sales_count_registered"] = True
        order["sales_count_registered_at"] = utc_iso()
    referral_result = record_referral_purchase(db, order["user_id"], order_id)
    if referral_result.get("recorded"):
        order["referral_reward_result"] = referral_result
    return dict(order)

def activate_vip(
    db: dict[str, Any],
    user_id: int | str,
    days: int,
    *,
    invite_link: str | None = None,
    source_order_id: str | None = None,
    fixed_expires_at: datetime | None = None,
) -> dict[str, Any]:
    uid = str(user_id)
    current = db.setdefault("vip_users", {}).get(uid, {})
    from core.membership_bridge import later_membership,normalized_for_mutation
    effective = later_membership(current,normalized_for_mutation(uid)) or {}
    now = utc_now()
    prior = parse_dt(effective.get('expires_at')) if effective.get('status')=='active' else None
    base = max(now,prior) if prior else now
    source = source_order_id or f'manual:{secrets.token_hex(16)}'
    grant_key = f'vip_grant:{uid}:{source}'
    if grant_key in db.get('economic_events',{}):return dict(effective)
    expires_at = fixed_expires_at or (base + timedelta(days=max(1,int(days))))
    from core.economy_integrity import economic_event
    economic_event(db,grant_key,uid,kind='vip_grant',value=max(0,(expires_at-base).total_seconds()),
                   metadata={'starts_at':utc_iso(base),'expires_at':utc_iso(expires_at),'seconds':max(0,(expires_at-base).total_seconds()),'source_order_id':source})
    record = {
        "status": "active",
        "expires_at": utc_iso(expires_at),
        "invite_link": invite_link or current.get("invite_link"),
        "source_order_id": source_order_id or current.get("source_order_id"),
        "updated_at": utc_iso(),
        "channel_removed_at": None,
        "channel_removal_status": None,
        "channel_removal_phase": None,
        "channel_removal_attempts": 0,
        "channel_removal_next_retry_at": None,
        "channel_removal_last_error": None,
    }
    db["vip_users"][uid] = record
    from modules.user_intelligence import record_user_activity, refresh_user_profile
    action = "vip_renewed" if current else "vip_activated"
    record_user_activity(
        db,
        uid,
        action,
        source="subscription",
        detail=str(source_order_id or "manual"),
        metadata={"days": int(days), "expires_at": record["expires_at"], "source_order_id": source_order_id},
    )
    refresh_user_profile(db, uid)
    return record


def vip_record(db: dict[str, Any], user_id: int | str) -> dict[str, Any] | None:
    from core.membership_bridge import later_membership, normalized_for_mutation
    return later_membership(db.get("vip_users", {}).get(str(user_id)), normalized_for_mutation(user_id))


def is_vip(db: dict[str, Any], user_id: int | str) -> bool:
    record = vip_record(db, user_id)
    if not record or record.get("status") != "active":
        return False
    expiry = parse_dt(record.get("expires_at"))
    return bool(expiry and expiry > utc_now())


def expire_vips(db: dict[str, Any]) -> list[int]:
    """Mark expired records and return removals that are due for processing.

    Expired users remain retryable until the Telegram channel removal completes.
    Invalid/missing expiry values are treated as expired rather than granting
    accidental indefinite access.
    """
    due: list[int] = []
    now = utc_now()
    from core.membership_bridge import normalized_expiry_candidates, normalized_for_mutation
    memberships = db.setdefault("vip_users", {})
    candidates = normalized_expiry_candidates(now)
    for uid in dict.fromkeys([*memberships, *candidates]):
        normalized = candidates.get(uid) or normalized_for_mutation(uid)
        normalized_expiry = parse_dt((normalized or {}).get("expires_at"))
        record = memberships.get(uid)
        if record is None:
            # Access-control evidence only; no purchase or VIP grant is copied.
            record = memberships[uid] = {"status":"expired", "expires_at":(normalized or {}).get("expires_at")}
        version = (normalized or {}).get("updated_at")
        if normalized and version != record.get("normalized_access_version"):
            record.update(normalized_access_version=version, channel_removed_at=None,
                          channel_removal_status="pending", channel_removal_phase="ban",
                          channel_removal_attempts=0, channel_removal_next_retry_at=None,
                          channel_removal_last_error=None)
        if normalized and normalized.get("status") == "active" and normalized_expiry and normalized_expiry > now:
            continue
        status = str(record.get("status") or "")
        expiry = parse_dt(record.get("expires_at"))

        if status == "active" and (expiry is None or expiry <= now):
            record.update({
                "status": "expired",
                "updated_at": utc_iso(now),
                "channel_removal_status": "pending",
                "channel_removal_phase": record.get("channel_removal_phase") or "ban",
                "channel_removal_next_retry_at": None,
            })
            status = "expired"

        if status != "expired" or record.get("channel_removed_at"):
            continue
        retry_at = parse_dt(record.get("channel_removal_next_retry_at"))
        if retry_at and retry_at > now:
            continue
        record.setdefault("channel_removal_status", "pending")
        record.setdefault("channel_removal_phase", "ban")
        try:
            due.append(int(uid))
        except ValueError:
            record["channel_removal_status"] = "invalid_user_id"
    return due


def mark_vip_removal_phase(db: dict[str, Any], user_id: int | str, phase: str) -> None:
    record = db.get("vip_users", {}).get(str(user_id))
    if not record:
        return
    record.update({
        "channel_removal_status": "processing",
        "channel_removal_phase": phase,
        "updated_at": utc_iso(),
    })


def mark_vip_removal_failed(db: dict[str, Any], user_id: int | str, error: str) -> None:
    record = db.get("vip_users", {}).get(str(user_id))
    if not record:
        return
    attempts = int(record.get("channel_removal_attempts", 0)) + 1
    delay_minutes = min(24 * 60, 5 * (2 ** min(attempts - 1, 8)))
    record.update({
        "channel_removal_status": "retry",
        "channel_removal_attempts": attempts,
        "channel_removal_next_retry_at": utc_iso(utc_now() + timedelta(minutes=delay_minutes)),
        "channel_removal_last_error": str(error)[:500],
        "updated_at": utc_iso(),
    })


def mark_vip_removed(db: dict[str, Any], user_id: int | str) -> None:
    record = db.get("vip_users", {}).get(str(user_id))
    if not record:
        return
    record.update({
        "channel_removed_at": utc_iso(),
        "channel_removal_status": "done",
        "channel_removal_phase": "done",
        "channel_removal_next_retry_at": None,
        "channel_removal_last_error": None,
        "updated_at": utc_iso(),
    })


def complete_mission(db: dict[str, Any], user_id: int | str, mission: dict[str, Any]) -> bool:
    from modules.missions import mission_available, mission_period_key, mission_user_state

    if not mission_available(mission):
        return False
    uid = str(user_id)
    mid = str(mission.get("id"))
    row = mission_user_state(db, uid, mission)
    if row.get("completed"):
        return False
    target = max(1, int(mission.get("target", 1) or 1))
    base_reward = max(0, int(mission.get("reward", 0) or 0))
    random_max = max(0, int(mission.get("random_bonus_max", 0) or 0))
    random_max = min(random_max, max(0, 1_000_000 - base_reward))
    bonus = secrets.randbelow(random_max + 1) if random_max else 0
    reward = base_reward + bonus
    if mission.get('prize'):
        from modules.prize_delivery import deliver_prize
        prize = dict(mission['prize'])
        prize['points'] = int(prize.get('points', 0)) + bonus
        deliver_prize(db,uid,prize,source_event=f'mission:{mid}:{mission_period_key(mission)}:{uid}',title=mission.get('title','مأموریت'),source='mission')
    now = utc_iso()
    row.update({
        "completed": True,
        "completed_at": now,
        "reward": reward,
        "base_reward": base_reward,
        "random_bonus": bonus,
        "progress": target,
        "period_key": mission_period_key(mission),
    })
    root = db.setdefault("user_missions", {}).setdefault(uid, {}).setdefault(mid, {})
    root.update({
        "completed": True,
        "completed_at": now,
        "reward": reward,
        "progress": target,
        "current_period": mission_period_key(mission),
    })
    if mission.get("max_completions"):
        mission["completions_count"]=int(mission.get("completions_count",0))+1
    if reward and not mission.get("prize"):
        add_points(db, uid, reward, f"mission:{mid}:{mission_period_key(mission)}", source_event=f"mission:{mid}:{mission_period_key(mission)}:{uid}")
    return True


def record_event(db: dict[str, Any], user_id: int | str, event: str) -> list[dict[str, Any]]:
    from modules.missions import find_mission, mission_available, mission_user_state
    from modules.user_intelligence import record_user_activity

    record_user_activity(db, user_id, f"event:{event}", source="domain")
    awarded: list[dict[str, Any]] = []
    for mission in db.get("missions", []):
        if not isinstance(mission, dict) or mission.get("event") != event or event == "manual":
            continue
        if not mission_available(mission):
            continue
        prerequisite = mission.get("chain_after")
        if prerequisite:
            prior = find_mission(db, prerequisite)
            if prior and not mission_user_state(db, user_id, prior).get("completed"):
                continue
        row = mission_user_state(db, user_id, mission)
        if row.get("completed"):
            continue
        target = max(1, int(mission.get("target", 1) or 1))
        row["progress"] = min(target, int(row.get("progress", 0) or 0) + 1)
        root = db.setdefault("user_missions", {}).setdefault(str(user_id), {}).setdefault(str(mission.get("id")), {})
        root["progress"] = row["progress"]
        root["current_period"] = row.get("period_key")
        if row["progress"] >= target and complete_mission(db, user_id, mission):
            awarded.append(dict(mission))
    return awarded


def apply_referral(db: dict[str, Any], new_user_id: int, code: str) -> tuple[bool, str, int | None]:
    uid = str(new_user_id)
    user = db.setdefault("users", {}).setdefault(uid, {"id": new_user_id})
    if user.get("referred_by"):
        return False, "این کاربر قبلاً معرف داشته است.", None

    owner_uid: str | None = None
    owner_data: dict[str, Any] | None = None
    for candidate_uid, data in db.setdefault("user_referrals", {}).items():
        if str(data.get("code", "")).upper() == code.strip().upper():
            owner_uid, owner_data = str(candidate_uid), data
            break
    if not owner_uid or owner_data is None:
        return False, "کد معرف معتبر نیست.", None
    if owner_uid == uid:
        return False, "نمی‌توانی معرف خودت باشی.", None

    invited = owner_data.setdefault("invited", [])
    if uid in invited:
        return False, "این دعوت قبلاً ثبت شده است.", int(owner_uid)
    from core.economy_integrity import economic_event
    economic_event(db, f"referral_attribution:{uid}", owner_uid, kind="referral_attribution", value=1, actor=uid, metadata={"referred_user":uid})
    invited.append(uid)
    user["referred_by"] = owner_uid
    user["referred_at"] = utc_iso()

    from modules.referral_review import begin_qualification
    begin_qualification(db, uid, owner_uid)
    from modules.user_intelligence import record_user_activity, refresh_user_profile
    record_user_activity(db, uid, "referral_joined", source="referral", metadata={"referrer_id": owner_uid})
    record_user_activity(db, owner_uid, "referral_added", source="referral", metadata={"invited_user_id": uid})
    refresh_user_profile(db, uid)
    refresh_user_profile(db, owner_uid)
    return True, "دعوت ثبت شد؛ پاداش پس از بررسی و گذشت ۲۴ ساعت محاسبه می‌شود.", int(owner_uid)


def referral_program_settings(db: dict[str, Any]) -> dict[str, Any]:
    defaults = {
        "signup_batch_size": max(1, int(SETTINGS.referral_batch_size)),
        "signup_batch_points": max(0, int(SETTINGS.referral_batch_points)),
        "purchase_required": 2,
        "vip_reward_days": 30,
    }
    row = db.setdefault("settings", {}).setdefault("referralProgram", {})
    for key, value in defaults.items():
        row.setdefault(key, value)
    row["signup_batch_size"] = max(1, min(1000, int(row.get("signup_batch_size", defaults["signup_batch_size"]) or defaults["signup_batch_size"])))
    row["signup_batch_points"] = max(0, min(100_000, int(row.get("signup_batch_points", defaults["signup_batch_points"]) or 0)))
    row["purchase_required"] = max(1, min(100, int(row.get("purchase_required", 2) or 2)))
    row["vip_reward_days"] = max(1, min(3650, int(row.get("vip_reward_days", 30) or 30)))
    return row


def update_referral_program_setting(db: dict[str, Any], key: str, value: int, actor_id: int | str | None = None) -> dict[str, Any]:
    allowed = {"signup_batch_size", "signup_batch_points", "purchase_required", "vip_reward_days"}
    if key not in allowed:
        raise ValueError("تنظیم رفرال نامعتبر است")
    number = int(value)
    limits = {
        "signup_batch_size": (1, 1000), "signup_batch_points": (0, 100_000),
        "purchase_required": (1, 100), "vip_reward_days": (1, 3650),
    }
    low, high = limits[key]
    if not low <= number <= high:
        raise ValueError(f"مقدار باید بین {low} و {high} باشد")
    row = referral_program_settings(db)
    row[key] = number
    row["updated_at"] = utc_iso()
    row["updated_by"] = str(actor_id or "")
    return dict(row)


def ensure_referral(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    uid = str(user_id)
    refs = db.setdefault("user_referrals", {})
    if uid not in refs:
        used = {str(x.get("code", "")).upper() for x in refs.values()}
        for _ in range(10):
            code = generate_code(20)
            if code not in used:
                break
        else:
            raise RuntimeError("REFERRAL_CODE_GENERATION_FAILED")
        refs[uid] = {
            "code": code, "invited": [], "awarded_batches": 0, "points_awarded": 0,
            "purchasers": [], "purchase_order_ids": [], "vip_awarded_batches": 0,
        }
    row = refs[uid]
    row.setdefault("purchasers", [])
    row.setdefault("purchase_order_ids", [])
    row.setdefault("vip_awarded_batches", 0)
    return row


def record_vip_purchase_rewards(db: dict[str, Any], order: dict[str, Any]) -> dict[str, Any]:
    """Shared idempotent reward ledger for legacy, normalized and gift orders."""
    order_id = str(order.get('order_id') or order.get('id') or '')
    from core.economy_integrity import approved_purchase
    order = approved_purchase(db, order_id, order.get('user_id'))
    if order.get('vip_grant'):
        from core.economy_integrity import economic_event
        meta=order['vip_grant']
        economic_event(db,f"vip_grant:{order['user_id']}:{order_id}",order['user_id'],kind='vip_grant',value=meta['seconds'],actor=order.get('approved_by','payment_service'),metadata=meta)
    claims = db.setdefault('purchase_reward_claims', {})
    if order_id not in claims:
        if not order.get('purchase_points_awarded'):
            add_points(db, order['user_id'], 100, f'vip_purchase:{order_id}', source_event=f'vip_purchase:{order_id}')
        claims[order_id] = {'user_id':str(order['user_id']), 'points':100, 'created_at':utc_iso()}
        audit(db, order['user_id'], 'vip_purchase_points', order_id)
    return record_referral_purchase(db, order['user_id'], order_id, amount=int(order.get('amount_toman',order.get('price',0)) or 0))


def record_referral_purchase(db: dict[str, Any], purchaser_id: int | str, order_id: int | str, *, amount: int | None = None) -> dict[str, Any]:
    purchaser_uid = str(purchaser_id)
    order_key = str(order_id)
    from core.economy_integrity import approved_purchase, economic_event
    verified = approved_purchase(db, order_key, purchaser_uid)
    amount = max(0, int(verified.get("amount_toman", verified.get("price", 0)) or 0))
    purchaser = db.get("users", {}).get(purchaser_uid, {})
    referrer_uid = str(purchaser.get("referred_by") or "")
    if not referrer_uid or referrer_uid == purchaser_uid:
        return {"recorded": False, "reason": "NO_REFERRER"}
    referral = ensure_referral(db, referrer_uid)
    if amount is not None:
        referral.setdefault("purchase_amounts", {}).setdefault(order_key, max(0, int(amount)))
    order_ids = referral.setdefault("purchase_order_ids", [])
    already_recorded = order_key in {str(value) for value in order_ids}
    economic_event(db, f"referral_purchase:{order_key}", referrer_uid, kind="verified_purchase", value=amount, actor=verified.get("approved_by", "payment_service"), metadata={"referred_user": purchaser_uid, "payment_id": order_key})
    if not already_recorded:
        order_ids.append(order_key)
    from core.economy_integrity import verified_referral_activity
    _, verified_purchases = verified_referral_activity(db, referrer_uid)
    purchasers = sorted({buyer for buyer, _ in verified_purchases.values()})
    referral['purchasers'] = purchasers
    settings = referral_program_settings(db)
    required = int(settings["purchase_required"])
    earned_batches = len({str(value) for value in purchasers}) // required
    awarded_batches = int(referral.get("vip_awarded_batches", 0) or 0)
    awarded_days = 0
    if earned_batches > awarded_batches:
        delta_batches = earned_batches - awarded_batches
        awarded_days = delta_batches * int(settings["vip_reward_days"])
        economic_event(db, f"referral_vip:{referrer_uid}:{earned_batches}", referrer_uid,
                       kind='vip_days', value=awarded_days, reason='verified_referral_buyers',
                       metadata={'payment_id':order_key,'buyers':purchasers})
        activate_vip(db, referrer_uid, awarded_days, source_order_id=f"referral:{order_key}")
        from modules.advanced_features import record_user_reward
        record_user_reward(db, referrer_uid, "پاداش VIP معرفی", reward_type="vip_days", detail=f"{awarded_days} روز VIP", source="referral", status="delivered", reference_id=f"referral:{order_key}")
        referral["vip_awarded_batches"] = earned_batches
        referral["last_vip_reward_at"] = utc_iso()
        referral["last_vip_reward_order_id"] = order_key
        record_event(db, referrer_uid, "referral_vip_reward")
    referral["purchase_count"] = len({str(value) for value in purchasers})
    referral["updated_at"] = utc_iso()
    return {
        "recorded": not already_recorded, "reason": "ALREADY_RECORDED" if already_recorded else "RECORDED",
        "referrer_id": referrer_uid, "purchaser_id": purchaser_uid,
        "purchase_count": referral["purchase_count"], "required": required,
        "vip_days_awarded": awarded_days, "vip_awarded_batches": int(referral.get("vip_awarded_batches", 0) or 0),
    }


def create_reward_request(db: dict[str, Any], user_id: int | str, item: dict[str, Any]) -> dict[str, Any]:
    request = {
        "id": next_id(db, "reward_request"),
        "user_id": str(user_id),
        "reward_id": int(item["id"]),
        "reward_name": item["name"],
        "status": "pending",
        "created_at": utc_iso(),
    }
    db.setdefault("reward_requests", []).append(request)
    from modules.user_intelligence import record_user_activity, refresh_user_profile
    record_user_activity(
        db,
        user_id,
        "reward_requested",
        source="rewards",
        detail=str(item.get("name") or ""),
        metadata={"reward_id": item.get("id"), "request_id": request["id"]},
    )
    refresh_user_profile(db, user_id)
    return request
