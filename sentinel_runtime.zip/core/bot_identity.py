"""One thread-safe, token-bound identity obtained from Telegram getMe.

Configured/default usernames are never proof of the bot owning this Mini App.
"""
from hashlib import sha256
from threading import RLock
import re

_LOCK=RLock()
_IDENTITY=None


def remember_authenticated_bot(bot_id,username,*,token):
    global _IDENTITY
    username=str(username or '').strip().lstrip('@')
    if isinstance(bot_id,bool) or not str(bot_id).isdigit() or int(bot_id)<=0 or not re.fullmatch(r'[A-Za-z0-9_]{5,32}',username):
        raise ValueError('BOT_IDENTITY_INVALID')
    owner=str(token).split(':',1)[0]
    if not owner.isdigit() or int(owner)!=int(bot_id):raise ValueError('BOT_IDENTITY_TOKEN_MISMATCH')
    with _LOCK:
        _IDENTITY={'id':int(bot_id),'username':username,'token_hash':sha256(str(token).encode()).hexdigest()}


def public_bot_identity(token=None):
    if token is None:
        from config import SETTINGS
        token=SETTINGS.bot_token
    with _LOCK:
        row=dict(_IDENTITY) if _IDENTITY else None
    if not row or row['token_hash']!=sha256(str(token).encode()).hexdigest():
        return {'verified':False,'id':None,'username':'','url':''}
    return {'verified':True,'id':row['id'],'username':row['username'],'url':'https://t.me/'+row['username']}


def clear_authenticated_bot():
    global _IDENTITY
    with _LOCK:_IDENTITY=None
