#!/usr/bin/env python3
from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCOPES = ("core/storage", "repositories/v2", "services/actions_v2", "modules/prop_rules_v2")


def module_name(path: Path) -> str:
    relative = path.relative_to(ROOT).with_suffix("")
    parts = list(relative.parts)
    if parts[-1] == "__init__":
        parts.pop()
    return ".".join(parts)


def main() -> int:
    files = [path for scope in SCOPES for path in (ROOT / scope).rglob("*.py") if path.name != "__init__.py"]
    modules = {module_name(path): path for path in files}
    graph: dict[str, set[str]] = {name: set() for name in modules}
    for name, path in modules.items():
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        for node in ast.walk(tree):
            candidates: list[str] = []
            if isinstance(node, ast.Import):
                candidates.extend(alias.name for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                candidates.append(node.module)
            for candidate in candidates:
                for target in modules:
                    if target != name and (candidate == target or candidate.startswith(target + ".")):
                        graph[name].add(target)
    visiting: set[str] = set()
    visited: set[str] = set()
    stack: list[str] = []
    cycles: set[tuple[str, ...]] = set()

    def visit(node: str) -> None:
        if node in visited:
            return
        if node in visiting:
            start = stack.index(node)
            cycles.add(tuple(stack[start:] + [node]))
            return
        visiting.add(node); stack.append(node)
        for nxt in sorted(graph[node]):
            visit(nxt)
        stack.pop(); visiting.remove(node); visited.add(node)

    for node in sorted(graph):
        visit(node)
    if cycles:
        raise RuntimeError("circular imports:\n" + "\n".join(" -> ".join(cycle) for cycle in sorted(cycles)))
    print(f"CIRCULAR IMPORT CHECK OK: modules={len(modules)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
