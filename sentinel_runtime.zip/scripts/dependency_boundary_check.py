#!/usr/bin/env python3
from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RULES = {
    "repositories/v2": {"bot_runtime", "handlers", "ui", "telegram", "fastapi"},
    "core/storage": {"bot_runtime", "handlers", "ui", "telegram", "fastapi"},
    "services/actions_v2": {"bot_runtime", "handlers", "ui"},
    "modules/prop_rules_v2": {"bot_runtime", "handlers", "ui", "telegram", "fastapi"},
}


def imports(path: Path) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    output: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            output.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            output.add(node.module)
    return output


def main() -> int:
    violations: list[str] = []
    for relative, forbidden in RULES.items():
        root = ROOT / relative
        for path in root.rglob("*.py"):
            for module in imports(path):
                top = module.split(".", 1)[0]
                if top in forbidden:
                    violations.append(f"{path.relative_to(ROOT)} -> {module}")
    if violations:
        raise RuntimeError("dependency boundary violations:\n" + "\n".join(sorted(violations)))
    print("DEPENDENCY BOUNDARIES OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
