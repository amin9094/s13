#!/usr/bin/env python3
from __future__ import annotations
import argparse
import hashlib
import json
import re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
PIN=re.compile(r"^[A-Za-z0-9_.-]+(?:\[[A-Za-z0-9_,.-]+\])?==[^\s;\\]+(?:\s*;.*)?(?:\s+\\)?$")
HASH=re.compile(r"--hash=sha256:[0-9a-f]{64}")

def rows(path:Path)->list[str]:
 return [line.strip() for line in path.read_text(encoding='utf-8').splitlines() if line.strip() and not line.lstrip().startswith('#')]

def package_name(row:str)->str:
 value=row.split(';',1)[0].split('==',1)[0].split()[0].strip().lower().replace('_','-')
 return value.split('[',1)[0]

def logical_rows(path:Path)->list[str]:
 out=[]; current=''
 for raw in path.read_text(encoding='utf-8').splitlines():
  line=raw.strip()
  if not line or line.startswith('#'): continue
  current=(current+' '+line).strip()
  if current.endswith('\\'):
   current=current[:-1].strip(); continue
  out.append(current); current=''
 if current: out.append(current)
 return out

def pinned_rows(lines:list[str], *, development:bool=False)->dict[str,str]:
 pins={}
 for row in lines:
  if development and row == '-r requirements.lock.txt': continue
  body=HASH.sub('', row).strip()
  if not PIN.fullmatch(body) or '--' in body:
   raise RuntimeError('dependency lock contains an invalid pinned requirement or option')
  name=package_name(body)
  version=body.split(';',1)[0].split('==',1)[1].strip()
  if '*' in version: raise RuntimeError('dependency lock requires exact versions, not wildcards')
  if name in pins: raise RuntimeError(f'dependency lock repeats package {name}')
  pins[name]=version
 return pins

def main()->int:
 ap=argparse.ArgumentParser(); ap.add_argument('--require-hashes',action='store_true'); args=ap.parse_args()
 status=json.loads((ROOT/'DEPENDENCY_LOCK_STATUS.json').read_text(encoding='utf-8'))
 production=logical_rows(ROOT/'requirements.lock.txt')
 if not production: raise RuntimeError('requirements.lock.txt is empty')
 locked_pins=pinned_rows(production)
 direct=rows(ROOT/'requirements.txt')
 direct_pins=pinned_rows(direct)
 if any(locked_pins.get(name)!=version for name,version in direct_pins.items()):
  raise RuntimeError('lock omits or changes a direct requirement version')
 require_hashes=args.require_hashes or bool(status.get('hashes_required'))
 if require_hashes:
  missing=[line for line in production if not HASH.search(line)]
  if missing: raise RuntimeError('production lock is not fully hash-pinned')
  if not status.get('complete_transitive_lock'): raise RuntimeError('dependency lock status is not complete')
 development=rows(ROOT/'requirements-dev.txt')
 if development[:1] != ['-r requirements.lock.txt']: raise RuntimeError('requirements-dev.txt must inherit the production lock')
 dev_lock_path = ROOT/'requirements-dev.lock.txt'
 if not dev_lock_path.is_file(): raise RuntimeError('requirements-dev.lock.txt is missing')
 dev_lock = logical_rows(dev_lock_path)
 dev_pins=pinned_rows(dev_lock,development=True)
 if require_hashes:
  missing_dev=[line for line in dev_lock if not line.startswith(('-r ', '-c ')) and not HASH.search(line)]
  if missing_dev: raise RuntimeError('development lock is not fully hash-pinned')
  if any(dev_pins.get(name)!=version for name,version in locked_pins.items()):
   raise RuntimeError('development lock omits or changes a production dependency')
  for name,key in [('requirements.lock.txt','production_lock_sha256'),('requirements-dev.lock.txt','development_lock_sha256')]:
   expected=status.get(key)
   actual=hashlib.sha256((ROOT/name).read_bytes()).hexdigest()
   if not isinstance(expected,str) or not re.fullmatch(r'[0-9a-f]{64}',expected) or actual!=expected:
    raise RuntimeError(f'dependency lock checksum mismatch: {name}')
 print(f"DEPENDENCY LOCK OK: locked={len(production)} dev_locked={len(dev_lock)} direct={len(direct)} complete={bool(status.get('complete_transitive_lock'))} hashes={require_hashes}")
 return 0
if __name__=='__main__': raise SystemExit(main())
