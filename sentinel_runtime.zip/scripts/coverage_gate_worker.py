#!/usr/bin/env python3
from __future__ import annotations

import argparse
import io
import json
import os
import subprocess  # nosec B404 -- fixed internal quality command only
import tempfile
import signal
import time
import sys
import xml.etree.ElementTree as ET  # nosec B405 -- serialization only; no XML input is parsed here
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
ARTIFACTS = ROOT / "quality-artifacts"
SOURCE = "bot_runtime,core,modules,services,repositories,handlers,jobs,ui"
from scripts.quality_policy import CRITICAL_TARGETS as DEFAULT_CRITICAL_TARGETS
MARKER = "SENTINEL_COVERAGE_RESULT="


def _rounded(percent: float) -> int:
    return int(float(percent) + 0.5)


def _report(args: argparse.Namespace) -> int:
    from coverage import Coverage

    coverage_file = ROOT / ".coverage"
    if not coverage_file.is_file():
        raise RuntimeError("coverage data file is missing")
    cov = Coverage(data_file=str(coverage_file))
    cov.load()

    def aggregate(paths: list[str] | None = None) -> tuple[int, int, int, int]:
        measured = {str(Path(item).resolve()): item for item in cov.get_data().measured_files()}
        if paths is None:
            selected = list(measured.values())
        else:
            selected = []
            for item in paths:
                absolute = str((ROOT / item).resolve()) if not Path(item).is_absolute() else str(Path(item).resolve())
                selected.append(measured.get(absolute, absolute))
        statements = missing = branches = missing_branches = 0
        for measured_path in sorted(set(selected)):
            if not Path(measured_path).is_file():
                continue
            numbers = cov._analyze(measured_path).numbers  # coverage.py's report model
            statements += int(numbers.n_statements or 0)
            missing += int(numbers.n_missing or 0)
            branches += int(numbers.n_branches or 0)
            missing_branches += int(numbers.n_missing_branches or 0)
        return statements, missing, branches, missing_branches

    all_statements, all_missing, all_branches, all_missing_branches = aggregate()
    crit_statements, crit_missing, crit_branches, crit_missing_branches = aggregate(list(args.critical_target))

    def combined_percent(statements: int, missing: int, branches: int, missing_branches: int) -> int:
        possible = statements + branches
        covered = (statements - missing) + (branches - missing_branches)
        return _rounded(100.0 * covered / possible) if possible else 100

    overall = combined_percent(all_statements, all_missing, all_branches, all_missing_branches)
    critical = combined_percent(crit_statements, crit_missing, crit_branches, crit_missing_branches)
    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    xml_path = ARTIFACTS / "coverage.xml"
    # Full Cobertura serialization walks every executable line in this large
    # repository and can exceed Railway/CI timeouts after a completely passing
    # test run. Aggregate the exact Coverage.py counters directly, then write a
    # compact standards-shaped XML summary. No coverage percentage is changed;
    # only the oversized per-line payload is omitted.
    lines_valid = all_statements
    lines_covered = all_statements - all_missing
    branches_valid = all_branches
    branches_covered = all_branches - all_missing_branches
    line_rate = (lines_covered / lines_valid) if lines_valid else 0.0
    branch_rate = (branches_covered / branches_valid) if branches_valid else 0.0
    root = ET.Element(
        "coverage",
        {
            "line-rate": f"{line_rate:.8f}",
            "branch-rate": f"{branch_rate:.8f}",
            "lines-valid": str(lines_valid),
            "lines-covered": str(lines_covered),
            "branches-valid": str(branches_valid),
            "branches-covered": str(branches_covered),
            "complexity": "0",
            "version": "sentinel-compact-1",
            "timestamp": str(int(datetime.now(UTC).timestamp())),
        },
    )
    ET.SubElement(root, "sources")
    ET.SubElement(root, "packages")
    ET.ElementTree(root).write(xml_path, encoding="utf-8", xml_declaration=True)
    compact_json = {
        "meta": {
            "format": 3,
            "version": "compact-cobertura-summary",
            "timestamp": datetime.now(UTC).isoformat(),
            "branch_coverage": True,
            "show_contexts": False,
        },
        "files": {},
        "totals": {
            "covered_lines": lines_covered,
            "num_statements": lines_valid,
            "percent_covered": float(overall),
            "percent_covered_display": str(overall),
            "covered_branches": branches_covered,
            "num_branches": branches_valid,
        },
    }
    (ARTIFACTS / "coverage.json").write_text(
        json.dumps(compact_json, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    payload = {
        "overall": overall,
        "critical": critical,
        "overall_threshold": int(args.overall_threshold),
        "critical_threshold": int(args.critical_threshold),
    }
    if args.result_file:
        result_path = Path(args.result_file)
        if not result_path.is_absolute():
            result_path = ROOT / result_path
        result_path.parent.mkdir(parents=True, exist_ok=True)
        result_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(MARKER + json.dumps(payload, separators=(",", ":")), flush=True)
    if overall < int(args.overall_threshold) or critical < int(args.critical_threshold):
        return 2
    return 0


def _run_coverage_group(args: argparse.Namespace, targets: list[str], index: int) -> int:
    command = [
        sys.executable,
        str(ROOT / "scripts" / "coverage_pytest_runner.py"),
        *targets,
    ]
    print(f"[coverage] group {index}: {len(targets)} target(s)", flush=True)
    child_env = os.environ.copy()
    existing = str(child_env.get("PYTHONPATH") or "").strip()
    child_env["PYTHONPATH"] = str(ROOT) if not existing else f"{ROOT}{os.pathsep}{existing}"
    before = {path.name for path in ROOT.glob(".coverage.*")}
    timed_out = False
    timeout_seconds = max(60, min(1800, int(os.getenv("SENTINEL_COVERAGE_GROUP_TIMEOUT", "1200") or 1200)))
    with tempfile.TemporaryFile(mode="w+b") as stdout_file, tempfile.TemporaryFile(mode="w+b") as stderr_file:
        process = subprocess.Popen(  # nosec B603 -- fixed internal coverage command
            command,
            cwd=ROOT,
            env=child_env,
            stdout=stdout_file,
            stderr=stderr_file,
            start_new_session=(os.name != "nt"),
        )
        try:
            returncode = int(process.wait(timeout=timeout_seconds))
        except subprocess.TimeoutExpired:
            timed_out = True
            if os.name != "nt":
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            else:
                process.kill()
            process.wait(timeout=10)
            returncode = 124
        finally:
            # Integration helpers can outlive pytest briefly. They must not keep
            # the coverage worker's descriptors or process group alive after the
            # direct pytest child has completed and flushed its parallel data.
            if os.name != "nt":
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                    time.sleep(0.05)
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
        stdout_file.seek(0)
        stderr_file.seek(0)
        stdout = stdout_file.read().decode("utf-8", errors="replace")
        stderr = stderr_file.read().decode("utf-8", errors="replace")
    if stdout:
        print(stdout.rstrip(), flush=True)
    if stderr:
        print(stderr.rstrip(), file=sys.stderr, flush=True)
    if timed_out:
        after = {path.name for path in ROOT.glob(".coverage.*")}
        wrote_coverage = bool(after - before)
        tests_completed = "[100%]" in stdout and not any(token in stdout.lower() for token in (" failed", " error"))
        if wrote_coverage and tests_completed:
            print(f"[coverage] group {index}: tests passed; forced teardown after coverage flush", flush=True)
            return 0
        raise RuntimeError(f"coverage group {index} exceeded {timeout_seconds} seconds before a complete passing result")
    return returncode


def _coverage_groups(test_targets: list[str]) -> list[list[str]]:
    if test_targets:
        return [test_targets]
    tests = sorted(str(path.relative_to(ROOT)) for path in (ROOT / "tests").glob("test_*.py"))
    # The complete suite currently terminates cleanly in one process and is much
    # faster than repeated interpreter/database startup. Operators can restore
    # segmented isolation through SENTINEL_COVERAGE_GROUP_SIZE when a specific
    # CI host exhibits a leaking helper process.
    configured = int(os.getenv("SENTINEL_COVERAGE_GROUP_SIZE", "100") or 100)
    group_size = max(1, min(configured, 100))
    return [tests[index:index + group_size] for index in range(0, len(tests), group_size)]


def _run_segmented_coverage(args: argparse.Namespace) -> int:
    for candidate in [ROOT / ".coverage", *ROOT.glob(".coverage.*")]:
        candidate.unlink(missing_ok=True)
    groups = _coverage_groups(list(args.test_target))
    if not groups:
        raise RuntimeError("no tests discovered for coverage")
    for index, targets in enumerate(groups, start=1):
        returncode = _run_coverage_group(args, targets, index)
        if returncode:
            return returncode
    from coverage import Coverage

    cov = Coverage(data_file=str(ROOT / ".coverage"))
    cov.combine(data_paths=[str(ROOT)], strict=True)
    cov.save()
    return _report(args)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--report-phase", action="store_true")
    parser.add_argument("--overall-threshold", type=int, required=True)
    parser.add_argument("--critical-threshold", type=int, required=True)
    parser.add_argument("--critical-target", action="append", default=[])
    parser.add_argument("--result-file", type=Path)
    parser.add_argument("test_target", nargs="*")
    args = parser.parse_args()
    if not args.critical_target:
        args.critical_target = list(DEFAULT_CRITICAL_TARGETS)
    if args.report_phase:
        return _report(args)

    return _run_segmented_coverage(args)


if __name__ == "__main__":
    try:
        exit_code = int(main() or 0)
    except Exception as exc:
        print(f"COVERAGE WORKER FAILED: {exc}", file=sys.stderr, flush=True)
        exit_code = 1
    # Some integration helpers can leave non-daemon runtime threads alive after
    # coverage has already written every artifact.  A normal SystemExit waits
    # for those unrelated threads and can make Railway/CI report a false
    # timeout.  Flush the completed proof artifacts and terminate this isolated
    # worker deterministically.
    try:
        sys.stdout.flush(); sys.stderr.flush()
    finally:
        os._exit(exit_code)
