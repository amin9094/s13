from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from config import SETTINGS  # noqa: E402
from core.backup_service import (  # noqa: E402
    list_payload_backups,
    run_payload_restore_drill,
)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Restore a SENTINEL backup into an isolated temporary database.",
    )
    parser.add_argument("path", nargs="?", help="Backup path; defaults to newest payload backup.")
    arguments = parser.parse_args()
    if arguments.path:
        path = Path(arguments.path).resolve()
    else:
        backups = list_payload_backups(SETTINGS.backup_dir, limit=1)
        if not backups:
            raise SystemExit("No payload backup is available for a restore drill.")
        path = backups[0]
    result = run_payload_restore_drill(
        path,
        SETTINGS.backup_dir,
        encryption_key=SETTINGS.backup_encryption_key,
        decryption_keys=SETTINGS.backup_previous_keys,
        key_version=SETTINGS.backup_key_version,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
