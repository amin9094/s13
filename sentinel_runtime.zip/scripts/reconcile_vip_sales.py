from __future__ import annotations

import json

from core.db import with_db
from modules.sales_growth import reconcile_plan_sales


if __name__ == "__main__":
    result = with_db(reconcile_plan_sales)
    print(json.dumps(result, ensure_ascii=False, indent=2))
