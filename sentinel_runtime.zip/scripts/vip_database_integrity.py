#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from datetime import UTC, datetime, timedelta
from typing import Any

import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.storage.engine import DatabaseEngine, normalized_engine
from modules.vip_order_state import ORDER_STATES
from repositories.v2.common import json_dump, json_load, utc_iso
from services.vip_order_projection import project_all_normalized_orders_to_legacy


def _parse(value: Any) -> datetime | None:
    try:
        parsed = datetime.fromisoformat(str(value or "").replace("Z", "+00:00"))
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=UTC)
    except (TypeError, ValueError):
        return None


def _issue(kind: str, severity: str, entity_id: Any, detail: str, repairable: bool = False) -> dict[str, Any]:
    return {
        "kind": kind,
        "severity": severity,
        "entity_id": str(entity_id or ""),
        "detail": detail,
        "safe_repair_available": repairable,
    }


def audit_database(
    engine: DatabaseEngine | None = None,
    *,
    repair_safe: bool = False,
    project_legacy: bool | None = None,
) -> dict[str, Any]:
    db = engine or normalized_engine()
    # A caller-supplied engine is usually an isolated audit/test database. Never
    # project it into the production legacy store unless explicitly requested.
    should_project = (engine is None) if project_legacy is None else bool(project_legacy)
    db.ensure_schema()
    now = datetime.now(UTC)
    issues: list[dict[str, Any]] = []
    repairs: list[dict[str, Any]] = []

    with db.transaction() as cursor:
        orders = cursor.execute("SELECT * FROM v8_vip_orders ORDER BY created_at,id").fetchall()
        receipts = cursor.execute("SELECT * FROM v8_receipts ORDER BY created_at,id").fetchall()
        quotes = cursor.execute("SELECT * FROM v8_checkout_quotes ORDER BY created_at,id").fetchall()
        entitlements = cursor.execute("SELECT * FROM v8_vip_entitlements ORDER BY user_id").fetchall()

        receipt_by_id = {str(row["id"]): row for row in receipts}
        order_by_id = {str(row["id"]): row for row in orders}
        entitlement_by_order = {str(row["order_id"]): row for row in entitlements}
        open_by_user: dict[str, list[str]] = defaultdict(list)

        for quote in quotes:
            if str(quote.get("status")) == "active":
                expiry = _parse(quote.get("expires_at"))
                if expiry is None or expiry <= now:
                    issues.append(_issue("expired_active_quote", "warning", quote["id"], "Active quote is expired.", True))
                    if repair_safe:
                        payload = json_load(quote.get("payload"), {}) or {}
                        payload.update({"status": "expired", "expired_at": now.isoformat()})
                        cursor.execute(
                            "UPDATE v8_checkout_quotes SET status='expired',payload=? WHERE id=? AND status='active'",
                            (json_dump(payload), str(quote["id"])),
                        )
                        if cursor.rowcount == 1:
                            repairs.append({"kind": "expired_active_quote", "entity_id": str(quote["id"])})

        for row in orders:
            oid = str(row["id"])
            uid = str(row.get("user_id") or "")
            status = str(row.get("status") or "")
            payload = json_load(row.get("payload"), {}) or {}
            if status not in ORDER_STATES:
                issues.append(_issue("invalid_order_status", "critical", oid, f"Unsupported status: {status}"))
            if status in {"pending", "approving"}:
                open_by_user[uid].append(oid)

            amount_raw = float(row.get("amount_toman") or 0)
            if amount_raw < 0:
                issues.append(_issue("negative_order_amount", "critical", oid, f"amount_toman={amount_raw}"))
            elif amount_raw != round(amount_raw):
                distance = abs(amount_raw - round(amount_raw))
                representation_noise = distance < 0.000001
                issues.append(_issue(
                    "fractional_toman_amount",
                    "warning" if representation_noise else "critical",
                    oid,
                    f"amount_toman={amount_raw}",
                    representation_noise,
                ))
                if repair_safe and representation_noise:
                    amount = int(round(amount_raw))
                    payload.update({"amount_toman": amount, "price": amount, "updated_at": utc_iso()})
                    cursor.execute(
                        "UPDATE v8_vip_orders SET amount_toman=?,updated_at=?,payload=? WHERE id=?",
                        (amount, utc_iso(), json_dump(payload), oid),
                    )
                    repairs.append({"kind": "fractional_toman_amount", "entity_id": oid})

            receipt_id = str(row.get("receipt_key") or payload.get("receipt_id") or "")
            receipt = receipt_by_id.get(receipt_id) if receipt_id else None
            attached = bool(
                receipt
                and str(receipt.get("order_id") or "") == oid
                and str(receipt.get("status") or "") == "attached"
            )
            if amount_raw > 0 and not attached and status in {"pending", "approving", "approved"}:
                severity = "critical" if status == "approved" else "error"
                can_repair = status == "pending"
                issues.append(_issue("payable_order_without_attached_receipt", severity, oid, f"status={status}", can_repair))
                if repair_safe and can_repair:
                    payload.update({"status": "needs_receipt", "receipt_attached": False, "updated_at": utc_iso()})
                    cursor.execute(
                        "UPDATE v8_vip_orders SET status='needs_receipt',updated_at=?,payload=? WHERE id=? AND status='pending'",
                        (utc_iso(), json_dump(payload), oid),
                    )
                    if cursor.rowcount == 1:
                        repairs.append({"kind": "payable_order_without_attached_receipt", "entity_id": oid})

            if status == "approving":
                started = _parse(payload.get("processing_started_at"))
                if started is None or started <= now - timedelta(minutes=5):
                    has_invite = bool(str(payload.get("processing_invite_link") or ""))
                    issues.append(_issue(
                        "stale_approval_claim", "critical" if has_invite else "error", oid,
                        "Stale claim has an invite that must be revoked first." if has_invite else "Stale claim can return to pending.",
                        not has_invite,
                    ))
                    if repair_safe and not has_invite:
                        payload.update({
                            "status": "pending", "processing_by": None, "processing_started_at": None,
                            "approval_last_error": "recovered by database integrity repair", "updated_at": utc_iso(),
                        })
                        cursor.execute(
                            "UPDATE v8_vip_orders SET status='pending',updated_at=?,payload=? WHERE id=? AND status='approving'",
                            (utc_iso(), json_dump(payload), oid),
                        )
                        if cursor.rowcount == 1:
                            repairs.append({"kind": "stale_approval_claim", "entity_id": oid})

            if status == "approved" and oid not in entitlement_by_order:
                issues.append(_issue("approved_order_without_entitlement", "critical", oid, "No normalized entitlement exists."))
            if status != "approved" and oid in entitlement_by_order and str(entitlement_by_order[oid].get("status")) == "active":
                issues.append(_issue("active_entitlement_for_nonapproved_order", "critical", oid, f"order_status={status}"))

        for uid, ids in open_by_user.items():
            if len(ids) > 1:
                issues.append(_issue("multiple_open_orders_for_user", "critical", uid, ",".join(ids)))

        for receipt in receipts:
            rid = str(receipt["id"])
            order_id = str(receipt.get("order_id") or "")
            status = str(receipt.get("status") or "")
            if status == "attached" and (not order_id or order_id not in order_by_id):
                issues.append(_issue("orphan_attached_receipt", "critical", rid, f"order_id={order_id or 'missing'}"))
            if order_id and order_id in order_by_id and str(order_by_id[order_id].get("user_id")) != str(receipt.get("user_id")):
                issues.append(_issue("receipt_user_mismatch", "critical", rid, f"order_id={order_id}"))

    projection_changes = 0
    if repair_safe and should_project:
        projection_changes = project_all_normalized_orders_to_legacy(limit=10_000)

    if repair_safe and repairs:
        # Report post-repair health rather than failing deployment because of an
        # issue that was already repaired safely in this same transaction cycle.
        post = audit_database(db, repair_safe=False, project_legacy=False)
        post.update({
            "repair_safe": True,
            "repair_count": len(repairs),
            "projection_changes": projection_changes,
            "repairs": repairs,
        })
        return post

    counts = Counter(row["severity"] for row in issues)
    return {
        "checked_at": now.isoformat(),
        "repair_safe": repair_safe,
        "counts": dict(counts),
        "issue_count": len(issues),
        "repair_count": len(repairs),
        "projection_changes": projection_changes,
        "issues": issues,
        "repairs": repairs,
        "healthy": counts.get("critical", 0) == 0 and counts.get("error", 0) == 0,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Audit normalized VIP orders, receipts, quotes and entitlements.")
    parser.add_argument("--repair-safe", action="store_true", help="Apply only deterministic, non-financial repairs.")
    parser.add_argument("--pretty", action="store_true")
    args = parser.parse_args()
    report = audit_database(repair_safe=args.repair_safe)
    print(json.dumps(report, ensure_ascii=False, indent=2 if args.pretty else None))
    return 0 if report["healthy"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
