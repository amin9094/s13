"""Deterministic change map for review, not a deployment approval."""
import argparse,hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
RULES=(
 ('core/storage/',('schema','backup_restore','postgresql_concurrency')),
 ('repositories/v2/',('ledger_consistency','read_only_reports','backup_restore')),
 ('modules/strategies/',('entry_stop_target_regression','causality','replay')),
 ('modules/strategy_',('entry_stop_target_regression','paper_independence')),
 ('modules/admin_access.py',('rbac','role_preview','delegation')),
 ('services/',('api_authorization','paper_independence','failure_recovery')),
 ('webapp/',('mobile_webview','back_navigation','languages','chart_parity')),
 ('bot_runtime/',('telegram_flows','numbering','publication_guard')),
 ('core/google_sheets_backup.py',('backup_restore','rollback')),
)


def manifest(root=ROOT):
    from scripts.quality_utils import source_fingerprint
    files={}
    for prefix in ('core','modules','services','repositories','webapp/src','bot_runtime','handlers','jobs','ui','scripts'):
        for p in (root/prefix).rglob('*'):
            if p.is_file() and p.suffix in {'.py','.js','.css'} and '__pycache__' not in p.parts:
                files[p.relative_to(root).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
    return {'version':(root/'VERSION').read_text().strip(),'files':files,'source_sha256':source_fingerprint(root)}


def impact(before,after):
    changed=sorted(k for k in before['files'].keys()|after['files'].keys() if before['files'].get(k)!=after['files'].get(k))
    domains=set();mapping=[]
    for path in changed:
        checks=sorted({check for prefix,values in RULES if path.startswith(prefix) for check in values})
        if not checks:checks=['targeted_regression_review_required']
        domains.update(checks);mapping.append({'file':path,'checks':checks})
    return {'before':before.get('version'),'after':after.get('version'),'changed_count':len(changed),'changes':mapping,
            'required_checks':sorted(domains),'schema_rollback_requires_pre_upgrade_snapshot':any(p.startswith('core/storage/') for p in changed),
            'automatic_deployment':False,'passed_checks':[]}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--baseline');parser.add_argument('--output',required=True);args=parser.parse_args()
    current=manifest();result=impact(json.loads(Path(args.baseline).read_text()),current) if args.baseline else current
    Path(args.output).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')


if __name__=='__main__':main()
