#!/usr/bin/env python3
"""Read-only TSETMC connectivity check using the exact private desk adapter."""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


async def check(query, code, timeframe="1d"):
    from core.http_client import close_http_client
    from services.iran_equity_service import IranEquityUnavailable, equity_chart, search_instruments

    try:
        result = await equity_chart(code, timeframe=timeframe) if code else await search_instruments(query)
        if code:
            result = {k: v for k, v in result.items() if k != "bars"} | {"bars_received": len(result["bars"])}
        return {"state": "AVAILABLE", "read_only": True, "result": result}
    except (IranEquityUnavailable, ValueError):
        return {"state": "UNAVAILABLE", "reason": "TSETMC_SOURCE_OR_CONTRACT_UNAVAILABLE", "read_only": True}
    finally:
        await close_http_client()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--query", default="فولاد")
    parser.add_argument("--ins-code")
    parser.add_argument("--timeframe", choices=("4h", "1d"), default="1d")
    args = parser.parse_args()
    result = asyncio.run(check(args.query, args.ins_code, args.timeframe))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["state"] == "AVAILABLE" else 2


if __name__ == "__main__":
    raise SystemExit(main())
