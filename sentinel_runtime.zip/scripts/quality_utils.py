from __future__ import annotations

import hashlib
import json
import os
import re
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

GENERATED_FILES = {
    "QUALITY_PROOF.json",
    "RELEASE_MANIFEST.json",
    "SHA256SUMS.txt",
    "sentinel_runtime.zip",
    "sentinel_runtime.zip.sha256",
    "junit.xml",
    "coverage.xml",
    "coverage.json",
}
DEPLOY_ROOT_FILES = {
    ".dockerignore",
    ".pre-commit-config.yaml",
    ".env.example",
    "Dockerfile",
    "Dockerfile.dockerignore",
    "Dockerfile.quality",
    "Dockerfile.quality.dockerignore",
    "DEPENDENCY_LOCK_STATUS.json",
    "Procfile",
    "VERSION",
    "bot.py",
    "config.py",
    "docker-compose.yml",
    "main.py",
    "pyproject.toml",
    "pytest.ini",
    "railway.toml",
    "requirements.in",
    "requirements-dev.in",
    "requirements.txt",
    "requirements.lock.txt",
    "requirements-dev.txt",
    "requirements-dev.lock.txt",
    "restore_runtime.py",
}
DEPLOY_ROOT_DIRS = {
    ".github",
    "assets",
    "bot_runtime",
    "core",
    "handlers",
    "jobs",
    "modules",
    "nginx",
    "repositories",
    "scripts",
    "services",
    "systemd",
    "tests",
    "ui",
    "webapp",
}
DEPLOY_EXACT_FILES = {"data/database.json"}
IGNORED_DIRS = {
    ".git",
    ".pytest_cache",
    ".ruff_cache",
    ".audit-cache",
    ".venv",
    "venv",
    "__pycache__",
    "logs",
    "backups",
    "quality-artifacts",
}
IGNORED_SUFFIXES = {".pyc", ".pyo", ".sqlite", ".sqlite3", ".db", ".log", ".tmp", ".zip"}


def _is_ignored_directory(name: str) -> bool:
    return name in IGNORED_DIRS or name.startswith(".venv")


def source_files(root: Path) -> list[Path]:
    output: list[Path] = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(root)
        if any(_is_ignored_directory(part) for part in relative.parts):
            continue
        if path.name in GENERATED_FILES or path.suffix.lower() in IGNORED_SUFFIXES:
            continue
        relative_name = relative.as_posix()
        deploy_source = (
            (len(relative.parts) == 1 and relative.name in DEPLOY_ROOT_FILES)
            or (relative.parts and relative.parts[0] in DEPLOY_ROOT_DIRS)
            or relative_name in DEPLOY_EXACT_FILES
        )
        if deploy_source:
            output.append(path)
    return sorted(output, key=lambda item: item.relative_to(root).as_posix())


def source_fingerprint(root: Path) -> str:
    digest = hashlib.sha256()
    for path in source_files(root):
        relative_name = path.relative_to(root).as_posix()
        relative = relative_name.encode("utf-8")
        digest.update(len(relative).to_bytes(4, "big"))
        digest.update(relative)
        payload = path.read_bytes()
        if relative_name == "restore_runtime.py":
            # The release builder updates only the embedded runtime checksum.
            # Normalize that generated value while still fingerprinting every
            # executable line of the restore implementation.
            import re
            payload = re.sub(
                rb'BUNDLE_SHA256 = "[0-9a-fA-F_]+"',
                b'BUNDLE_SHA256 = "__RUNTIME_BUNDLE_SHA256__"',
                payload,
                count=1,
            )
        digest.update(len(payload).to_bytes(8, "big"))
        digest.update(payload)
    return digest.hexdigest()


def automated_test_count(root: Path) -> int:
    count = 0
    tests_root = root / "tests"
    for path in tests_root.rglob("test_*.py"):
        count += path.read_text(encoding="utf-8").count("def test_")
    return count


def configured_image_digest() -> str:
    primary = str(os.getenv("SENTINEL_IMAGE_DIGEST") or "").strip()
    legacy = str(os.getenv("SENTINEL_DOCKER_IMAGE_DIGEST") or "").strip()
    if primary and legacy and primary != legacy:
        return ""
    value = primary or legacy
    return value if re.fullmatch(r"sha256:[0-9a-f]{64}", value) else ""


def production_acceptance_errors(
    report: Any, *, version: str, source_sha256: str,
    image_digest: str, now: datetime | None = None,
) -> list[str]:
    """Validate fresh, complete external evidence for this exact release."""
    if not isinstance(report, dict):
        return ["production acceptance report is not an object"]
    errors = []
    if report.get("schema_version") != 2 or report.get("status") != "PASSED":
        errors.append("production acceptance is not a passed schema-2 report")
    if report.get("version") != version or report.get("source_sha256") != source_sha256:
        errors.append("production acceptance does not match this release source")
    if not re.fullmatch(r"sha256:[0-9a-f]{64}", image_digest) or report.get("docker_image_digest") != image_digest:
        errors.append("production acceptance does not match this Docker image")
    if not str(report.get("base_url") or "").startswith("https://"):
        errors.append("production acceptance requires an HTTPS deployment")
    try:
        started = datetime.fromisoformat(str(report.get("started_at") or ""))
        finished = datetime.fromisoformat(str(report.get("finished_at") or ""))
        current = now or datetime.now(UTC)
        if started.tzinfo is None or finished.tzinfo is None:
            raise ValueError("timestamps require timezone")
        if finished < started or current - started > timedelta(hours=24) or finished > current + timedelta(minutes=5):
            raise ValueError("expired or invalid timestamps")
    except (ValueError, TypeError):
        errors.append("production acceptance is expired or has invalid timestamps")
    required = {
        "production_configuration", "dependency_lock_attestation", "security_audit_chain",
        "release_gate", "postdeploy_http", "live_staging", "gemini_live_generation",
        "miniapp_playwright", "mt5_compiled_connector",
    }
    checks = report.get("checks")
    if not isinstance(checks, list) or any(not isinstance(c, dict) for c in checks):
        errors.append("production acceptance checks are missing or invalid")
        return errors
    names = [str(c.get("name") or "") for c in checks]
    if not required.issubset(names) or len(names) != len(set(names)):
        errors.append("production acceptance checks are incomplete or duplicated")
    if any(c.get("ok") is not True or c.get("skipped") not in (None, False) for c in checks) or report.get("failures") != []:
        errors.append("production acceptance includes failed or skipped checks")
    return errors


def mt5_acceptance_details(root: Path) -> dict[str, Any]:
    source = root / "webapp/downloads/SentinelConnector.mq5"
    binary = root / "webapp/downloads/SentinelConnector.ex5"
    details: dict[str, Any] = {
        "ok": False, "source_present": source.is_file(),
        "ex5_present": binary.is_file(), "errors": [],
    }
    try:
        if not source.is_file() or not binary.is_file() or binary.stat().st_size <= 0:
            raise ValueError("compiled MT5 connector is missing")
        details["source_sha256"] = hashlib.sha256(source.read_bytes()).hexdigest()
        details["ex5_sha256"] = hashlib.sha256(binary.read_bytes()).hexdigest()
        evidence = json.loads((root / "quality-artifacts/mt5_demo_acceptance.json").read_text(encoding="utf-8"))
        if evidence.get("schema_version") != 1 or evidence.get("compiler") != "MetaEditor":
            raise ValueError("official compiler evidence is required")
        if any(evidence.get(key) != details[key] for key in ("source_sha256", "ex5_sha256")):
            raise ValueError("MT5 evidence does not match the current source and binary")
        demo = evidence.get("demo")
        if not isinstance(demo, dict) or demo.get("account_type") != "demo" or demo.get("passed") is not True:
            raise ValueError("MT5 demo-account acceptance is required")
        required = {"connection", "authentication", "risk_limits", "signal_sync", "disconnect_recovery"}
        checks = demo.get("checks")
        if not isinstance(checks, dict) or any(checks.get(name) is not True for name in required):
            raise ValueError("MT5 demo checks are incomplete")
        for raw in (evidence.get("compiled_at"), demo.get("tested_at")):
            stamp = datetime.fromisoformat(str(raw or ""))
            age = datetime.now(UTC) - stamp if stamp.tzinfo is not None else timedelta(days=8)
            if not -timedelta(minutes=5) <= age <= timedelta(days=7):
                raise ValueError("MT5 evidence is expired or has invalid timestamps")
        details["ok"] = True
        details["demo_attested"] = True
    except (OSError, ValueError, TypeError, AttributeError) as exc:
        details["errors"].append(str(exc) if isinstance(exc, ValueError) else type(exc).__name__)
    return details
