#!/usr/bin/env python3
"""Real, read-only predeployment input audit. Exit 2 means blockers remain."""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))


async def inspect(symbols,timeframe,*,stream_sample=False):
    from services.strategy_readiness_service import inspect_market_readiness
    from core.http_client import close_http_client
    rows=[]
    try:
        for symbol in symbols:
            row=await inspect_market_readiness(symbol,timeframe)
            if stream_sample:
                from services.biquote_stream_check import sample_stream
                row={**row,'stream_probe':await sample_stream(row['symbol'])}
            rows.append(row)
    finally:
        await close_http_client()
    return {'kind':'READ_ONLY_REAL_INPUT_AUDIT','markets':rows,
            'deployment_only_remaining':all(row['deployment_only_remaining'] for row in rows),
            'messages_sent':0,'orders_sent':0}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--symbols',nargs='+',default=['XAUUSD','EURUSD','GBPUSD'])
    parser.add_argument('--timeframe',choices=['5m','1h'],default='5m')
    parser.add_argument('--stream',action='store_true',help='Also sample the public indicative stream; never grants execution approval')
    args=parser.parse_args()
    result=asyncio.run(inspect(args.symbols,args.timeframe,stream_sample=args.stream))
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if result['deployment_only_remaining'] else 2


if __name__=='__main__':
    raise SystemExit(main())
