#!/usr/bin/env python3
from __future__ import annotations
import json
from defusedxml.ElementTree import parse
from pathlib import Path
import coverage
ROOT=Path(__file__).resolve().parents[1]
ART=ROOT/'quality-artifacts'; ART.mkdir(parents=True,exist_ok=True)
cov=coverage.Coverage(data_file=str(ROOT/'.coverage')); cov.load()
xml_path=ART/'coverage.xml'; overall=int(float(cov.report(file=open('/dev/null','w'),skip_empty=True))+0.5)
cov.xml_report(outfile=str(xml_path))
root=parse(xml_path, forbid_dtd=True).getroot()
payload={"meta":{"format":3,"version":"compact-cobertura-summary","branch_coverage":True},"files":{},"totals":{"covered_lines":int(root.attrib.get('lines-covered','0') or 0),"num_statements":int(root.attrib.get('lines-valid','0') or 0),"percent_covered":overall,"percent_covered_display":str(overall),"covered_branches":int(root.attrib.get('branches-covered','0') or 0),"num_branches":int(root.attrib.get('branches-valid','0') or 0)}}
(ART/'coverage.json').write_text(json.dumps(payload,indent=2)+'\n',encoding='utf-8')
print(f'COVERAGE ARTIFACTS OK: {ART}')
