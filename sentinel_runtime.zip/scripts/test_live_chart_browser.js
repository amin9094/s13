/* Internal UI contract test. All prices below are synthetic, labeled fixtures. */
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');
const root = path.resolve(__dirname, '..');
async function run() {
    const browser = await chromium.launch({headless:true,executablePath:process.env.SENTINEL_TEST_BROWSER_PATH || undefined,args:['--no-sandbox']});
    const page = await browser.newPage({viewport:{width:412,height:915}});
    const errors=[];
    page.on('pageerror',error=>errors.push(error.message));
    const harness=`<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><title>CHART TEST · SYNTHETIC FIXTURES</title><style>${fs.readFileSync(path.join(root,'webapp/src/styles.css'),'utf8')}</style></head>
      <body><div id="modalLayer" hidden><h2 id="modalTitle"></h2><span id="modalEyebrow"></span><div id="modalBody"></div></div>
      <script>
      const state={lang:'fa',modalGeneration:0,resources:{overview:{admin_available:false}}};
      const tg={colorScheme:'dark'};
      const testCalls=[];
      const chartFaults={venue:false,offline:false,iranOffline:false,iranUnsupported:false};
      const $=selector=>document.querySelector(selector);
      const esc=value=>String(value).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('"','&quot;');
      function openModal(eyebrow,title,body,actions=[]){disposeMarketChart();state.modalGeneration++;$('#modalLayer').hidden=false;$('#modalTitle').textContent=title;$('#modalEyebrow').textContent=eyebrow;$('#modalBody').innerHTML=body;state.modalActions=actions;}
      function closeModal(){disposeMarketChart();state.modalGeneration++;$('#modalLayer').hidden=true;}
      async function request(url,options){
        testCalls.push({url,options});
        if(url.includes('/admin/iran-equities/desk'))return {items:[{id:'d'.repeat(32),symbol:'تحلیل ذخیره‌شده',timeframe:'4h',created_ms:1000}],legacy_items:[]};
        if(url.includes('/admin/iran-equities/analyses/'))return {id:'d'.repeat(32),ins_code:'46348559193224090',symbol:'تحلیل ذخیره‌شده',timeframe:'4h',created_ms:1000,payload:{timeframe:'4h',latest_trade_date:'2026-10-13',analysis:{state:'H4_REVIEW_AVAILABLE',indicators:{rsi14:'60'},latest_closed_date:'2026-10-13'}}};
        if(url.includes('/admin/iran-equities/search')){
          if(chartFaults.iranOffline)throw new Error('FIXTURE_OFFLINE');
          return {items:[{ins_code:'46348559193224090',symbol:'سهم آزمایشی',title:'SYNTHETIC ONLY',venue:'TSE'},
                         {ins_code:'46348559193224091',symbol:'سهم آزمایشی دوم',title:'SYNTHETIC ONLY 2',venue:'IFB'}]};
        }
        if(url.includes('/admin/iran-equities/chart')){
          if(chartFaults.iranUnsupported)throw Object.assign(new Error('SYNTHETIC_UNSUPPORTED_TYPE'),{code:'IR_CASH_EQUITY_REQUIRED'});
          const args=new URL(url,'https://sentinel.test').searchParams,code=args.get('ins_code'),timeframe=args.get('timeframe') || '1d';
          const end=Date.UTC(2026,9,13,20,30),before=Number(args.get('before_ms') || 0);
          const bars=Array.from({length:130},(_,i)=>({timestamp:(before || end+86400000)-(130-i)*86400000,open:1000+i,high:1020+i,low:990+i,close:1010+i,volume:5000+i}));
          return {ins_code:code,symbol:'سهم آزمایشی',currency:'IRR',adjustment:'UNADJUSTED',provider:'tsetmc',product:'iran_cash_equity',venue:'TSE',timeframe,
            bars,has_more:!before,display_price_precision:0,latest_trade_date:'2026-10-13',analysis:{state:timeframe==='4h'?'H4_REVIEW_AVAILABLE':'DAILY_REVIEW_AVAILABLE',continuous_price_base_bars:130,latest_closed_date:'2026-10-13',current_day_excluded:true,price_base_breaks:[],
              trend:'UP',momentum:'UP',all_directional_checks_agree:true,indicators:{ema20:'1100',rsi14:'60'},range20:{low:'1000',high:'1200'},volume_vs_previous20:'1.2'}};
        }
        if(url.includes('/universe'))return {core_symbols:['XAUUSD','EURUSD','BTCUSD'],crypto_top20:[]};
        if(url.includes('/readiness'))return {symbol:'XAUUSD',timeframe:'5m',provider:'biquote',observed_ms:Date.now(),execution_eligible:false,
          checks:[{code:'REPORTED_PRICE_GRID',state:'BLOCKED',detail_fa:'گام قیمت تأیید نشده'}],engines:{indicators:{blockers:['NATIVE_HISTORY_PROVENANCE']}},
          stream_probe:{state:'INITIAL_QUOTES_ONLY',timestamp_advancing_updates:0,execution_eligible:false}};
        if(url.includes('/research-profiles'))return {items:Array.from({length:10},(_,i)=>({profile_id:'fixture-'+i,production_qualified:false}))};
        if(url.includes('/analyze'))return {analysis_mode:'CANDLE_ONLY',provider:'synthetic-test-fixture',product:'spot',publicly_approved:false,
          independent_reference:{provider:'goldpricetoday_ir',attribution:'GoldPriceToday.ir',price:'4100',state:'REFERENCE_TIME_UNVERIFIED',updated_at:'2026-10-14T08:00:00Z',timestamp_kind:'SNAPSHOT_BUILD_TIME_NOT_NATIVE_ASSET_TIME'},
          results:[{state:'ANALYTICAL_OBSERVATION',available_ms:Date.now()-1000,observation:{observation_id:'observation-synthetic-only',
            provider:'synthetic-test-fixture',venue:'test-only',product:'spot',zone_low:'101',zone_high:'103'}}]};
        if(url.includes('/decision'))return {state:'QUEUED_NOT_SENT'};
        if(url.includes('/reviews'))return {items:[{id:'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',state:'NEEDS_REVIEW',payload:{engine:'indicators',review_kind:'PREENTRY_PROPOSAL',direction:'BUY',provider:'biquote',timeframe:'5m',draft_hash:'b'.repeat(64),draft_plan:{entry:'100',stop:'95',tp1:'110',tp2:'115',rr_tp1:'2'}}},{payload:{engine:'order_block',title_fa:'نیازمند بررسی: POC خارج از اوردر بلاک',poc:{price:'103',volume_kind:'tick_proxy'},original_zone:['99','101'],profile_id:'fixture-0'}},
          {payload:{engine:'market_data',reason:'PROVIDER_HTTP_404',explanation_fa:'مسیر یا نماد در منبع داده پیدا نشد.',required_action_fa:'نماد CFD همان منبع بررسی شود.'}},
          {payload:{engine:'sweep_fvg',state:'ANALYTICAL_OBSERVATION',submodel:'liquidity_reversal',symbol:'XAUUSD',provider:'synthetic-test-fixture',venue:'test-only',product:'spot',direction:'BUY',
            original_zone:['101','103'],observation:{last_closed_ms:Date.now()-300000},fibonacci_confirmation:{confirmations:[]}}}]};
        if(url.includes('/approve'))return {approval_id:'fixture-approval',state:'QUEUED_NOT_SENT'};
        if(url.includes('/setups')){
          const admin=state.resources.overview.admin_available;
          const plan={engine:'indicators',submodel:'fixture-only',symbol:'XAUUSD',timeframe:'5m',direction:'BUY',provider:'synthetic-test-fixture',venue:'test-only',product:'spot',evidence_cutoff_ms:Date.now()-60000,
            zone_low:'100',zone_high:'110',entry:'105',stop:'95',tp1:'125',tp2:'135',tp3:null,initial_rr_tp2:'3',plan_version:1,evidence:[]};
          return {admin,items:admin?[{id:'fixture-plan',plan_version:1,payload:{plan,admin_delivered_ms:Date.now()-30000,state:{phase:'PROPOSED_PRETOUCH'}}},
            {id:'fixture-entry',plan_version:1,payload:{plan,admin_delivered_ms:Date.now()-30000,state:{phase:'VERIFIED_ENTRY',entry_ms:Date.now()-10000}},admin_events:[{id:'fixture-exact-event',event_type:'VERIFIED_ENTRY',event_ms:Date.now()-10000,approved_audiences:[]}]},
            {id:'fixture-other-source',plan_version:1,payload:{plan:{...plan,provider:'twelve_data',venue:'alternate-fixture'},state:{phase:'PROPOSED_PRETOUCH'}}}]:[]};
        }
        if(url.includes('/feedback'))return {families:[{engine:'indicators',title_fa:'اندیکاتورها',groups:[]},{engine:'sweep_fvg',title_fa:'نقدینگی',groups:[]},{engine:'order_block',title_fa:'اردربلاک',groups:[]},{engine:'fibonacci',title_fa:'فیبوناچی',groups:[]},{engine:'fibonacci_pullback',title_fa:'فیبوناچی آزمایشی',groups:[]}],coverage:{sampled_setups:0,truncated:false}};
        const args=new URL(url,'https://sentinel.test').searchParams;
        const interval=args.get('timeframe')==='1h'?3600000:300000;
        if(chartFaults.offline)throw new Error('FIXTURE_OFFLINE');
        const now=Date.now(),end=args.get('before_ms')?Number(args.get('before_ms'))-interval:Math.floor(now/interval)*interval;
        const bars=Array.from({length:120},(_,i)=>({timestamp:end-(119-i)*interval,open:100+i/10,high:102+i/10,low:99+i/10,close:101+i/10,volume:10}));
        return {bars,display_price_precision:5,has_more:false,provider:args.get('provider') || 'synthetic-test-fixture',venue:chartFaults.venue?'UNEXPECTED_CHANGED_VENUE':args.get('provider')==='twelve_data'?'alternate-fixture':'test-only',product:'spot',volume_kind:'traded',state:'TEST_FIXTURE',last_closed_ms:end,observed_ms:now,poll_seconds:60,bid_ask_state:'UNAVAILABLE'};
      }
      </script><script src="/signal-scenario.js"></script><script src="/live-chart.js"></script><script src="/iran-equities.js"></script></body></html>`;
    await page.route('https://sentinel.test/**',async route=>{
        const url=new URL(route.request().url());
        if(url.pathname==='/harness')return route.fulfill({contentType:'text/html',body:harness});
        if(url.pathname==='/signal-scenario.js')return route.fulfill({contentType:'text/javascript',body:fs.readFileSync(path.join(root,'webapp/src/signal-scenario.js'),'utf8')});
        if(url.pathname==='/live-chart.js')return route.fulfill({contentType:'text/javascript',body:fs.readFileSync(path.join(root,'webapp/src/live-chart.js'),'utf8')});
        if(url.pathname==='/iran-equities.js')return route.fulfill({contentType:'text/javascript',body:fs.readFileSync(path.join(root,'webapp/src/iran-equities.js'),'utf8')});
        if(url.pathname.endsWith('klinecharts-10.0.3.min.js'))return route.fulfill({contentType:'text/javascript',body:fs.readFileSync(path.join(root,'webapp/assets/vendor/klinecharts-10.0.3.min.js'),'utf8')});
        return route.fulfill({status:404,body:'Not found'});
    });
    await page.goto('https://sentinel.test/harness');
    await page.evaluate(async()=>{
      const lib=await loadChartLibrary(),init=lib.init.bind(lib);
      lib.init=(...args)=>{
        const chart=init(...args),setLoader=chart.setDataLoader.bind(chart);
        chart.setDataLoader=loader=>{window.testCapturedLoader=loader;return setLoader(loader);};
        return chart;
      };
    });
    await page.evaluate(()=>openMarketChart('XAUUSD','5m'));
    await page.waitForFunction(()=>activeMarketChart?.chart?.getDataList().length===120);
    if(await page.locator('#liveMarketChart canvas').count()===0)throw new Error('NO_CHART_CANVAS');
    if((await page.locator('#liveMarketChart').boundingBox())?.height<350)throw new Error('CHART_HAS_NO_VISIBLE_HEIGHT');
    await page.selectOption('#chartIndicator','RSI');
    await page.selectOption('#chartTimeframe','1h');
    await page.waitForFunction(()=>activeMarketChart?.timeframe==='1h' && activeMarketChart.chart?.getDataList().length===120);
    const canvasCount=await page.locator('#liveMarketChart canvas').count();
    await page.evaluate(async()=>{
      const oldLast=activeMarketChart.lastMs,first=activeMarketChart.chart.getDataList()[0].timestamp;
      const older=await new Promise(resolve=>testCapturedLoader.getBars({type:'forward',timestamp:first,callback:resolve}));
      if(!older.length || older.at(-1).timestamp>=first || activeMarketChart.lastMs!==oldLast)throw new Error('HISTORY_PAGINATION_MOVED_LIVE_CURSOR');
    });
    if(await page.locator('#chartFeedbackButton').isVisible())throw new Error('PUBLIC_FEEDBACK_BUTTON_VISIBLE');
    if(await page.locator('#chartAnalyzeButton').isVisible())throw new Error('PUBLIC_ANALYSIS_BUTTON_VISIBLE');
    if(await page.locator('#chartReadinessButton').isVisible())throw new Error('PUBLIC_READINESS_BUTTON_VISIBLE');
    const ema=await page.evaluate(()=>activeMarketChart.chart.getIndicators().find(row=>row.name==='EMA'));
    if(JSON.stringify(ema?.calcParams)!=='[20,50,100]')throw new Error('EMA_PARAMETERS_MISMATCH');
    if(ema.paneId!=='candle_pane')throw new Error('EMA_NOT_ON_CANDLE_PANE');
    const rsi=await page.evaluate(()=>{addChartIndicator(activeMarketChart.chart,'RSI');addChartIndicator(activeMarketChart.chart,'RSI');return activeMarketChart.chart.getIndicators().filter(row=>row.name==='RSI');});
    if(rsi.length!==1 || rsi[0].paneId==='candle_pane')throw new Error('RSI_PANE_OR_DEDUP_FAILED');
    await page.evaluate(()=>{state.resources.overview.admin_available=true;return openMarketChart('XAUUSD','5m');});
    await page.waitForFunction(()=>activeMarketChart?.admin===true);
    await page.locator('[data-setup-approve="fixture-plan"][data-audience="telegram_public"]').click();
    await page.waitForFunction(()=>testCalls.some(row=>row.url.includes('/fixture-plan/approve')));
    await page.locator('details').filter({has:page.locator('[data-event-id="fixture-exact-event"]').first()}).locator('summary').click();
    await page.locator('[data-setup-approve="fixture-entry"][data-event-id="fixture-exact-event"][data-audience="telegram_public"]').click();
    const eventApproval=await page.evaluate(()=>testCalls.find(row=>row.url.includes('/fixture-entry/approve')));
    if(!eventApproval.options.csrf || JSON.parse(eventApproval.options.body).event_id!=='fixture-exact-event')throw new Error('PER_EVENT_APPROVAL_MISSING');
    await page.click('#chartFeedbackButton');
    await page.waitForFunction(()=>document.querySelectorAll('#chartFeedback details').length===5);
    await page.waitForFunction(()=>document.querySelectorAll('#chartResearchProfile option').length===11);
    await page.selectOption('#chartResearchProfile','fixture-0');
    await page.selectOption('#chartProfileEngine','order_block');
    await page.click('#chartSelectProfile');
    await page.waitForFunction(()=>document.querySelector('#chartReviews')?.textContent.includes('انتخاب ذخیره شد'));
    const selectedProfile=await page.evaluate(()=>testCalls.find(row=>row.url.includes('/research-profiles/select')));
    if(!selectedProfile.options.csrf || JSON.parse(selectedProfile.options.body).engine!=='order_block')throw new Error('DURABLE_PROFILE_SELECTION_MISSING');
    await page.click('#chartAnalyzeButton');
    await page.waitForFunction(()=>document.querySelector('#chartReviews')?.textContent.includes('POC خارج از اوردر بلاک'));
    await page.waitForFunction(()=>document.querySelector('#chartReviews')?.textContent.includes('اقدام لازم: نماد CFD همان منبع بررسی شود.') && document.querySelector('#chartReviews')?.textContent.includes('PROVIDER_HTTP_404'));
    await page.waitForFunction(()=>document.querySelector('#chartReviews')?.textContent.includes('مشاهدهٔ کندلی؛ سیگنال ورود نیست'));
    await page.waitForFunction(()=>document.querySelector('#chartReviews')?.textContent.includes('GoldPriceToday.ir') && document.querySelector('#chartReviews')?.textContent.includes('زمان انتشار مجموعه؛ زمان خود دارایی تأیید نشده'));
    await page.locator('[data-review-decision="aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"][data-review-action="telegram_public"]').click();
    await page.waitForFunction(()=>testCalls.some(c=>c.url.includes('/reviews/') && c.url.endsWith('/decision')));
    const reviewApproval=await page.evaluate(()=>testCalls.find(c=>c.url.includes('/reviews/') && c.url.endsWith('/decision')));
    if(!reviewApproval.options.csrf || JSON.parse(reviewApproval.options.body).draft_hash!=='b'.repeat(64) || JSON.parse(reviewApproval.options.body).audience!=='telegram_public')throw new Error('REVIEW_EXACT_PLAN_APPROVAL_MISSING');
    const overlays=await page.evaluate(()=>activeMarketChart.chart.getOverlays({groupId:'analysis-observations'}));
    if(overlays.length!==1 || overlays[0].extendData.kind!=='ANALYTICAL_OBSERVATION')throw new Error('OBSERVATION_SOURCE_BOUND_OVERLAY_MISSING');
    const analysis=await page.evaluate(()=>testCalls.find(row=>row.url.includes('/analyze')));
    if(!analysis.options.csrf || JSON.parse(analysis.options.body).profile_id!=='fixture-0')throw new Error('ANALYSIS_PROFILE_OR_CSRF_MISSING');
    const analysisMarket=JSON.parse(analysis.options.body);
    if(analysisMarket.provider!=='synthetic-test-fixture' || analysisMarket.venue!=='test-only' || analysisMarket.product!=='spot')throw new Error('CHART_SOURCE_NOT_PASSED_TO_ANALYSIS');
    await page.locator('[data-setup-chart-source="fixture-other-source"]').click();
    await page.waitForFunction(()=>activeMarketChart?.provider==='twelve_data' && activeMarketChart?.chart?.getDataList().length===120);
    if(await page.locator('[data-setup-chart-source="fixture-other-source"]').count())throw new Error('SETUP_SOURCE_CHART_DID_NOT_MATCH');
    await page.evaluate(async()=>{
      const chart=activeMarketChart,oldLast=chart.lastMs;
      chartFaults.venue=true;await chart.tick();
      if(chart.lastMs!==oldLast || chart.venue!=='alternate-fixture' || !$('#chartStatus').textContent.includes('MARKET_IDENTITY_CHANGED'))throw new Error('VENUE_CHANGE_ACCEPTED');
      chartFaults.venue=false;chartFaults.offline=true;await chart.tick();
      if(!$('#chartStatus').textContent.includes('FIXTURE_OFFLINE') || !chart.chart.getDataList().length)throw new Error('DISCONNECT_LOST_CHART');
      chartFaults.offline=false;
      chart.lastMs=Date.now()-60*300000;await chart.tick();
      const count=Number(new URL(testCalls.at(-1).url,'https://sentinel.test').searchParams.get('limit'));
      if(count<=20)throw new Error('RECONNECT_DID_NOT_REQUEST_GAP');
    });
    await page.click('#chartRefresh');
    await page.waitForFunction(()=>activeMarketChart?.provider==='twelve_data' && activeMarketChart.chart?.getDataList().length===120);
    await page.evaluate(()=>openMarketChart('XAUUSD','5m','biquote'));
    await page.waitForFunction(()=>activeMarketChart?.admin && !$('#chartReadinessButton').hidden);
    await page.click('#chartReadinessButton');
    await page.waitForFunction(()=>$('#chartReadiness').textContent.includes('فقط قیمت اولیه') && $('#chartReadiness').textContent.includes('تأیید سیگنال نیست'));
    const readinessRequest=await page.evaluate(()=>testCalls.find(c=>c.url.includes('/readiness')));
    if(!readinessRequest.url.includes('stream_sample=true') || !readinessRequest.url.includes('symbol=XAUUSD'))throw new Error('READINESS_SOURCE_OR_STREAM_SAMPLE_MISSING');
    await page.evaluate(()=>{
      window.focusedFixture={id:'private-inbox-fixture',paper_events:[{type:'ENTRY',price:'100',at_ms:1000},{type:'TP1',price:'110',at_ms:Date.now()+999999}],phase:'PENDING',payload:{plan:{engine:'sweep_fvg',submodel:'liquidity_reversal',symbol:'XAUUSD',timeframe:'5m',direction:'BUY',provider:'synthetic-test-fixture',venue:'test-only',product:'spot',evidence_cutoff_ms:Date.now()-60000,
        entry:'105.01',stop:'95',tp1:'126',tp2:'136',tp3:null,zone_low:'100',zone_high:'110',evidence:[
          {kind:'entry_selection',detail:{original_midpoint:'105',requested_offset:'0.01'}},
          {kind:'shared_fibonacci_confirmation',detail:{main_levels:{'0':'100','.61':'106.1','1':'110'},confirmations:[]}},
          {kind:'shared_goldbach_confirmation',detail:{confirmed:true,levels:[{ratio:'.03',label:'RB',price:'100.01'},{ratio:'.97',label:'RB',price:'109.99'}]}}
        ]}},returnTo:async()=>{window.focusReturned=true;closeModal();}};
      return openMarketChart('XAUUSD','5m','synthetic-test-fixture',focusedFixture);
    });
    await page.waitForFunction(()=>activeMarketChart?.focusPlan?.id==='private-inbox-fixture' && activeMarketChart.chart.getOverlays({groupId:'strategy-plans'}).length>=10);
    const actualEvents=await page.evaluate(()=>activeMarketChart.chart.getOverlays({groupId:'strategy-plans'}).filter(x=>x.name==='signalEvent').map(x=>x.extendData.label));
    if(JSON.stringify(actualEvents)!=='["ENTRY"]')throw new Error('Future or missing paper event');
    if(await page.locator('[data-signal-scenario]').count()!==1)throw new Error('Focused chart lacks conditional forecast');
    const focusedResult=await page.evaluate(()=>({plans:activeMarketChart.plans.map(x=>x.id),
      labels:activeMarketChart.chart.getOverlays({groupId:'strategy-plans'}).map(x=>x.extendData?.label).filter(Boolean),
      text:$('#chartPlans').textContent+' '+$('#chartStatus').textContent,
      legacyActions:document.querySelectorAll('[data-setup-cancel],[data-setup-approve]').length}));
    if(JSON.stringify(focusedResult.plans)!=='["private-inbox-fixture"]' || focusedResult.legacyActions)throw new Error('FOCUSED_SIGNAL_MIXED_WITH_OTHER_STRATEGIES');
    for(const label of ['Entry 105.01','SL 95','TP1 126','TP2 136','FVG 50% 105','Fib .61','PO3 .03 RB'])if(!focusedResult.labels.includes(label))throw new Error('FOCUSED_SIGNAL_LABEL_MISSING '+label);
    if(focusedResult.text.includes('synthetic-test-fixture') || focusedResult.text.includes('test-only'))throw new Error('PROVIDER_NAME_LEAKED_IN_SIGNAL_CHART');
    if(!(await page.locator('#chartAnalyzeButton').isHidden()))throw new Error('OTHER_STRATEGY_ANALYSIS_SHOWN_IN_FOCUSED_CHART');
    await page.locator('[data-chart-layer="goldbach"]').uncheck();
    if(await page.evaluate(()=>activeMarketChart.chart.getOverlays({groupId:'strategy-plans'}).some(x=>x.extendData?.label?.startsWith('PO3 '))))throw new Error('GOLDBACH_TOGGLE_IGNORED');
    await page.click('#chartRefresh');
    await page.waitForFunction(()=>activeMarketChart?.focusPlan?.id==='private-inbox-fixture' && activeMarketChart.chart.getOverlays({groupId:'strategy-plans'}).length>=10);
    await page.locator('[data-chart-return]').click();
    if(!(await page.evaluate(()=>focusReturned && activeMarketChart===null)))throw new Error('FOCUSED_DETAIL_RETURN_LOST');
    await page.evaluate(()=>{chartFaults.venue=true;return openMarketChart('XAUUSD','5m','synthetic-test-fixture',focusedFixture);});
    await page.waitForFunction(()=>$('#chartStatus').textContent.includes('MARKET_IDENTITY_CHANGED'));
    if(await page.locator('#liveMarketChart canvas').count())throw new Error('FOCUSED_SIGNAL_ACCEPTED_WRONG_VENUE');
    await page.evaluate(()=>{chartFaults.venue=false;closeModal();});
    if(!(await page.evaluate(()=>activeMarketChart===null)))throw new Error('CHART_NOT_DISPOSED');
    await page.evaluate(async()=>{chartFaults.offline=true;await openMarketChart('XAUUSD','5m');});
    await page.waitForFunction(()=>$('#chartStatus')?.textContent.includes('FIXTURE_OFFLINE'));
    await page.evaluate(()=>{chartFaults.offline=false;});
    await page.selectOption('#chartSymbol','EURUSD');
    await page.waitForFunction(()=>activeMarketChart?.symbol==='EURUSD' && activeMarketChart.chart?.getDataList().length===120);
    await page.evaluate(()=>closeModal());
    await page.evaluate(()=>{state.resources.overview.admin_available=false;return iranEquitiesDesk();});
    if(await page.locator('#iranEquitySearch').count())throw new Error('PUBLIC_IRAN_DESK_OPENED');
    await page.evaluate(()=>{state.resources.overview.admin_available=true;state.resources.overview.admin={role:'owner'};return iranEquitiesDesk();});
    await page.locator('#iranEquitySearch button').click();
    await page.waitForFunction(()=>document.querySelectorAll('[data-iran-equity]').length===2);
    await page.waitForSelector('[data-iran-analysis]');
    await page.click('[data-iran-analysis]');
    if(!(await page.locator('#modalBody').innerText()).includes('تحلیل ۴ساعته آماده است'))throw new Error('IRAN_SAVED_ANALYSIS_MISSING');
    await page.evaluate(()=>state.modalActions[1].action());
    await page.locator('#iranEquitySearch button').click();
    await page.locator('[data-iran-equity="46348559193224090"]').click();
    await page.waitForFunction(()=>activeIranEquityChart?.chart?.getDataList().length===130);
    if(await page.locator('#iranEquityCanvas canvas').count()===0)throw new Error('NO_IRAN_CHART_CANVAS');
    await page.waitForFunction(()=>$('#iranEquityAnalysis').textContent.includes('ریال') && $('#iranEquityAnalysis').textContent.includes('تعدیل‌نشده') && $('#iranEquityAnalysis').textContent.includes('روز تقویمی تهران'));
    await page.selectOption('#iranEquityIndicator','RSI');
    const iranEMA=await page.evaluate(()=>activeIranEquityChart.chart.getIndicators().find(row=>row.name==='EMA'));
    if(iranEMA?.paneId!=='candle_pane')throw new Error('IRAN_EMA_NOT_ON_CANDLE_PANE');
    await page.selectOption('#iranEquityTimeframe','4h');
    await page.waitForFunction(()=>activeIranEquityChart?.timeframe==='4h' && activeIranEquityChart.chart?.getDataList().length===130 && $('#iranEquityAnalysis').textContent.includes('تحلیل ۴ساعته آماده است'));
    const period=await page.evaluate(()=>activeIranEquityChart.chart.getPeriod());
    if(period.type!=='hour' || period.span!==4)throw new Error('IRAN_H4_PERIOD_INVALID');
    if(!(await page.locator('#iranEquityAnalysis').textContent()).includes('ریزمعاملات'))throw new Error('IRAN_H4_SOURCE_LABEL_MISSING');
    await page.click('#iranEquityHistory');
    await page.waitForFunction(()=>activeIranEquityChart.chart?.getDataList().length===260);
    await page.selectOption('#iranEquityTimeframe','1d');
    await page.waitForFunction(()=>activeIranEquityChart?.timeframe==='1d' && activeIranEquityChart.chart?.getDataList().length===130);
    await page.evaluate(()=>{chartFaults.iranUnsupported=true;});
    await page.locator('[data-iran-equity="46348559193224091"]').click();
    await page.waitForFunction(()=>$('#iranEquityStatus').textContent.includes('سهم نقدیِ پشتیبانی‌شده نیست'));
    if(await page.locator('#iranEquityCanvas canvas').count())throw new Error('UNSUPPORTED_INSTRUMENT_KEPT_OLD_CANVAS');
    if(await page.locator('#iranEquityIndicator').inputValue()!=='')throw new Error('STALE_INDICATOR_SELECTION');
    await page.evaluate(()=>{chartFaults.iranUnsupported=false;});
    await page.click('#iranEquityRefresh');
    await page.waitForFunction(()=>activeIranEquityChart?.code==='46348559193224091' && activeIranEquityChart.chart?.getDataList().length===130);
    const exactCode=await page.evaluate(()=>testCalls.filter(c=>c.url.includes('/iran-equities/chart')).at(-1).url);
    if(!exactCode.includes('46348559193224091'))throw new Error('IRAN_CODE_PRECISION_LOST');
    await page.click('#iranEquityRefresh');
    await page.waitForFunction(()=>activeIranEquityChart?.chart?.getDataList().length===130);
    await page.evaluate(()=>closeModal());
    if(!(await page.evaluate(()=>activeIranEquityChart===null)))throw new Error('IRAN_CHART_NOT_DISPOSED');
    if(errors.length)throw new Error(errors.join('; '));
    console.log(JSON.stringify({ok:true,library:'KLineChart 10.0.3',mobile_viewport:'412x915',bars:120,canvas_count:canvasCount,
      checks:['actual_paper_entry_only_no_future_events','v10_data_loader','candle_canvas','EMA_20_50_100','source_display_precision','price_indicators_on_candles','deduplicate_indicator_panes','RSI_pane','timeframe_switch','five_feedback_folders','private_analysis_button','selected_research_profile','durable_profile_selection','per_signal_channel_approval','separate_exact_event_approval','source_bound_setup_chart','poc_outside_review_header','admin_review_plan_levels','admin_review_exact_hash_approval','feedback_hidden_from_public','unsubscribe_disposal','source_bound_candle_observation','observation_not_entry_label','registered_rectangle_overlay','exact_chart_source_analysis','reject_changed_venue','disconnect_keeps_bars','gap_sized_reconnect','manual_refresh','history_does_not_rewind_live_cursor','symbol_change_after_initial_failure','admin_only_iran_desk','iran_private_history','iran_saved_analysis_separate','iran_daily_canvas','iran_h4_period','iran_h4_history_pagination','iran_h4_source_labels','iran_return_to_daily','iran_irr_unadjusted_labels','iran_large_code_exact','iran_symbol_switch','iran_chart_disposal'],
      continuation_checks:['admin_source_bound_readiness','initial_quote_is_not_live_continuity','unsupported_equity_specific_error','old_equity_canvas_disposed_on_rejection','indicator_selector_reset','single_frozen_signal_chart','source_chart_conditional_forecast','entry_stop_targets_named','fvg_midpoint_overlay','optional_goldbach_overlay_toggle','fibonacci_ratio_labels','provider_names_hidden_on_signal','refresh_keeps_exact_signal','detail_return_rebinds_controls','focused_chart_rejects_wrong_venue'],
      data_kind:'SYNTHETIC_UI_FIXTURE_NOT_MARKET_EVIDENCE',telegram_webview:'NOT_TESTED'}));
    await browser.close();
}
run().catch(error=>{console.error(error);process.exit(1);});
