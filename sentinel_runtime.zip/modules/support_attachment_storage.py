from __future__ import annotations

import hashlib
import os
import secrets
from pathlib import Path
from typing import Any

from config import SETTINGS
from core.utils import utc_iso

MAX_SUPPORT_ATTACHMENT_BYTES = 15 * 1024 * 1024
ALLOWED_MIME: dict[str, tuple[str, str]] = {
    "image/jpeg": ("photo", ".jpg"),
    "image/png": ("photo", ".png"),
    "image/webp": ("photo", ".webp"),
    "application/pdf": ("document", ".pdf"),
    "video/mp4": ("video", ".mp4"),
    "audio/ogg": ("voice", ".ogg"),
    "audio/mpeg": ("audio", ".mp3"),
    "audio/mp4": ("audio", ".m4a"),
    "audio/x-m4a": ("audio", ".m4a"),
}


def _root() -> Path:
    configured = str(os.getenv("SUPPORT_ATTACHMENT_STORAGE_DIR") or "").strip()
    if configured:
        root = Path(configured)
    else:
        mount = str(os.getenv("PERSISTENT_DATA_DIR") or os.getenv("RAILWAY_VOLUME_MOUNT_PATH") or os.getenv("VOLUME_MOUNT_PATH") or "").strip()
        root = Path(mount) / "support_attachments" if mount else SETTINGS.db_file.parent / "support_attachments"
    root = root.expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    return root


def _safe_name(name: str) -> str:
    clean = Path(str(name or "attachment")).name.replace("\x00", "")
    return clean[:180] or "attachment"


def _validate_signature(payload: bytes, mime_type: str) -> None:
    if mime_type == "application/pdf" and not payload.startswith(b"%PDF-"):
        raise ValueError("SUPPORT_ATTACHMENT_INVALID")
    if mime_type == "image/png" and not payload.startswith(b"\x89PNG\r\n\x1a\n"):
        raise ValueError("SUPPORT_ATTACHMENT_INVALID")
    if mime_type == "image/jpeg" and not payload.startswith(b"\xff\xd8\xff"):
        raise ValueError("SUPPORT_ATTACHMENT_INVALID")
    if mime_type == "image/webp" and not (payload.startswith(b"RIFF") and payload[8:12] == b"WEBP"):
        raise ValueError("SUPPORT_ATTACHMENT_INVALID")
    if mime_type == "video/mp4" and b"ftyp" not in payload[:64]:
        raise ValueError("SUPPORT_ATTACHMENT_INVALID")
    if mime_type == "audio/ogg" and not payload.startswith(b"OggS"):
        raise ValueError("SUPPORT_ATTACHMENT_INVALID")


def store_support_attachment(
    db: dict[str, Any],
    owner_id: int | str,
    payload: bytes,
    *,
    file_name: str,
    mime_type: str,
) -> dict[str, Any]:
    data = bytes(payload or b"")
    mime = str(mime_type or "").split(";", 1)[0].strip().lower()
    if mime not in ALLOWED_MIME:
        raise ValueError("SUPPORT_ATTACHMENT_TYPE_INVALID")
    if not data or len(data) > MAX_SUPPORT_ATTACHMENT_BYTES:
        raise ValueError("SUPPORT_ATTACHMENT_SIZE_INVALID")
    _validate_signature(data, mime)
    kind, suffix = ALLOWED_MIME[mime]
    storage_id = f"SAT-{secrets.token_urlsafe(18)}"
    path = _root() / f"{storage_id}{suffix}"
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_bytes(data)
    temporary.replace(path)
    row = {
        "storage_id": storage_id,
        "owner_id": str(owner_id),
        "ticket_id": None,
        "type": kind,
        "file_name": _safe_name(file_name),
        "mime_type": mime,
        "file_size": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "path": str(path),
        "status": "uploaded",
        "created_at": utc_iso(),
        "claimed_at": None,
    }
    db.setdefault("support_attachments", {})[storage_id] = row
    return public_attachment(row)


def public_attachment(row: dict[str, Any]) -> dict[str, Any]:
    storage_id = str(row.get("storage_id") or "")
    return {
        "type": str(row.get("type") or "document"),
        "storage_id": storage_id,
        "file_id": str(row.get("file_id") or ""),
        "file_unique_id": str(row.get("file_unique_id") or ""),
        "file_name": str(row.get("file_name") or "attachment"),
        "mime_type": str(row.get("mime_type") or "application/octet-stream"),
        "file_size": int(row.get("file_size", 0) or 0),
        "caption": str(row.get("caption") or ""),
        "download_url": f"./api/v1/support/attachments/{storage_id}" if storage_id else "",
    }


def claim_support_attachment(
    db: dict[str, Any],
    storage_id: str,
    *,
    actor_id: int | str,
    ticket_id: int | str,
    admin: bool = False,
) -> dict[str, Any]:
    row = db.setdefault("support_attachments", {}).get(str(storage_id or ""))
    if not isinstance(row, dict):
        raise ValueError("SUPPORT_ATTACHMENT_NOT_FOUND")
    if not admin and str(row.get("owner_id")) != str(actor_id):
        raise PermissionError("SUPPORT_ATTACHMENT_NOT_OWNED")
    bound = row.get("ticket_id")
    if bound not in {None, "", int(ticket_id), str(ticket_id)}:
        raise ValueError("SUPPORT_ATTACHMENT_ALREADY_USED")
    row["ticket_id"] = int(ticket_id)
    row["status"] = "attached"
    row["claimed_at"] = utc_iso()
    return public_attachment(row)


def attachment_record(db: dict[str, Any], storage_id: str) -> dict[str, Any] | None:
    row = db.setdefault("support_attachments", {}).get(str(storage_id or ""))
    return dict(row) if isinstance(row, dict) else None


def read_support_attachment(row: dict[str, Any]) -> bytes | None:
    path = Path(str(row.get("path") or ""))
    try:
        path.resolve().relative_to(_root())
    except (ValueError, OSError):
        return None
    if not path.is_file() or path.stat().st_size > MAX_SUPPORT_ATTACHMENT_BYTES:
        return None
    data = path.read_bytes()
    if hashlib.sha256(data).hexdigest() != str(row.get("sha256") or ""):
        return None
    return data
