"""Admin-defined AND combinations over independently validated entry plans.

No averaging of entries/stops; no new entry from a confirmation-only grid.
The complete base plan and selected rules are frozen with every custom signal.
"""
from dataclasses import dataclass, asdict, replace
from decimal import Decimal as D

from modules.indicator_suite import CATALOG, indicators, agreement
from repositories.v2.common import content_hash

BASES=('indicators','sweep_fvg','order_block','fibonacci_pullback')
FILTERS=('require_fvg','require_ob','require_poc','require_liquidity','require_dmm','require_fibonacci')


@dataclass(frozen=True)
class CustomSettings:
    enabled: bool=False
    base: str='sweep_fvg'
    indicators: tuple[str,...]=()
    require_fvg: bool=False
    require_ob: bool=False
    require_poc: bool=False
    require_liquidity: bool=False
    require_dmm: bool=False
    require_fibonacci: bool=False
    fib_levels: tuple[str,...]=('0.61','0.618','0.71','0.9')
    golden_low: str='1.61'
    golden_high: str='1.68'

    def validate(self):
        if type(self.enabled) is not bool or self.base not in BASES or any(type(getattr(self,k)) is not bool for k in FILTERS):
            raise ValueError('CUSTOM_SETTINGS_INVALID')
        if (not isinstance(self.indicators,tuple) or len(set(self.indicators))!=len(self.indicators)
                or set(self.indicators)-set(CATALOG) or self.enabled and self.base=='indicators' and not self.indicators):
            raise ValueError('CUSTOM_INDICATORS_INVALID')
        if not isinstance(self.fib_levels,tuple) or not 1<=len(self.fib_levels)<=12 or len(set(self.fib_levels))!=len(self.fib_levels):
            raise ValueError('CUSTOM_FIBONACCI_INVALID')
        try:
            nums=[D(x) for x in self.fib_levels]
            a,b=D(self.golden_low),D(self.golden_high)
            if (any(not isinstance(x,str) for x in self.fib_levels)
                or not isinstance(self.golden_low,str) or not isinstance(self.golden_high,str)
                or any(not x.is_finite() or not 0<=x<=1 for x in nums) or len(set(nums))!=len(nums)
                or not a.is_finite() or not b.is_finite() or not 1<a<b<=3):
                raise ValueError()
        except (ValueError,TypeError,ArithmeticError):raise ValueError('CUSTOM_FIBONACCI_INVALID') from None

    def dto(self):
        return {**asdict(self),'indicators':list(self.indicators),'fib_levels':list(self.fib_levels)}

    @property
    def profile_id(self):return 'custom-'+content_hash(self.dto())[:24]


def parse_settings(body):
    if not isinstance(body,dict) or set(body)-set(CustomSettings.__dataclass_fields__):
        raise ValueError('CUSTOM_SETTINGS_INVALID')
    try:
        values=dict(body)
        for key in ('indicators','fib_levels'):
            if key in values:
                if not isinstance(values[key],(list,tuple)) or any(not isinstance(x,str) for x in values[key]):raise ValueError()
                values[key]=tuple(values[key])
        if 'indicators' in values:
            supplied=values['indicators']
            if len(set(supplied))!=len(supplied) or set(supplied)-set(CATALOG):raise ValueError()
            values['indicators']=tuple(k for k in CATALOG if k in supplied)
        config=CustomSettings(**values);config.validate();return config
    except (ValueError,TypeError,ArithmeticError):raise ValueError('CUSTOM_SETTINGS_INVALID') from None


def _plan(row):return row.get('plan') or row.get('draft_plan')


def _facts(plan):return {f['kind']:f.get('detail',{}) for f in plan.get('evidence',())}


def _same_entry(a,b,tolerance):
    identity=('symbol','timeframe','direction','provider','venue','product')
    entry=D(a['entry'])
    return (all(a[k]==b[k] for k in identity) and D(b['zone_low'])<=entry<=D(b['zone_high'])
            and abs(entry-D(b['entry']))<=tolerance)


def _fib(context,plan,config):
    from modules.strategies.common import confirmed_swings
    facts=_facts(plan);wave=facts.get('causal_wave')
    if not wave:
        original=facts.get('shared_fibonacci_confirmation',{}).get('main_levels',{})
        if '0' in original and '1' in original:
            wave={'start_price':original['0'],'end_price':original['1'],'start_index':-1,'end_index':-1}
    levels={};matches=[]
    if wave:
        a,b=D(wave['start_price']),D(wave['end_price'])
        levels.update({'0':str(a),'1':str(b)})
        for ratio in config.fib_levels:
            value=a+(b-a)*D(ratio);levels[ratio]=str(value)
            if D(plan['zone_low'])<=value<=D(plan['zone_high']):
                matches.append({'kind':'MAIN_WAVE_LEVEL_IN_ZONE','ratio':ratio,'price':str(value)})
        magnitude=abs(b-a)
    else:
        magnitude=None
    bars=context.closed;swings=confirmed_swings(bars,context.parameters)
    for a,b in zip(swings,swings[1:]):
        if a.kind==b.kind or a.index>=b.index or (wave and [a.index,b.index]==[wave['start_index'],wave['end_index']]):continue
        if magnitude is None or abs(b.value-a.value)>=magnitude:continue
        if any(x.end_ms!=y.start_ms for x,y in zip(bars[a.index:b.index],bars[a.index+1:b.index+1])):continue
        x,y=(a.value+(b.value-a.value)*D(r) for r in (config.golden_low,config.golden_high))
        low,high=min(x,y),max(x,y)
        if low<=D(plan['zone_high']) and high>=D(plan['zone_low']):
            matches.append({'kind':'OTHER_MINOR_WAVE_GOLDEN_OVERLAP','golden_low':str(low),'golden_high':str(high),
                            'anchor_source_ids':[bars[a.index].source_id,bars[b.index].source_id],
                            'available_ms':max(a.available_ms,b.available_ms)})
    return {'main_levels':levels,'confirmations':matches,'confirmed':bool(matches),
            'golden_ratios':[config.golden_low,config.golden_high],'required_for_entry':config.require_fibonacci,
            'entry_changed':False,'is_win_probability':False}


def evaluate(context,rows):
    config=context.custom_settings or CustomSettings();config.validate()
    if not config.enabled:return []
    candidates=[r for r in rows if r.get('engine')==config.base and _plan(r)]
    if config.base=='indicators':
        from modules.strategies.indicators.engine import IndicatorsOnly
        from modules.strategies.fibonacci.engine import Fibonacci
        from modules.goldbach_confirmation import attach
        candidates=IndicatorsOnly().evaluate(replace(context,indicator_selection=config.indicators))
        for row in candidates:
            if not _plan(row):continue
            fib=Fibonacci().evaluate(context,[row]);row['fibonacci_confirmation']=fib[0] if fib else None
            plan=_plan(row)
            fact={'kind':'shared_fibonacci_confirmation','available_ms':context.cutoff_ms,'detail':row['fibonacci_confirmation']}
            if row.get('plan'):
                from modules.setup_lifecycle import SetupPlan
                row['plan']=replace(SetupPlan.from_dict(plan),evidence=(*plan['evidence'],fact)).as_dict()
            else:row['draft_plan']={**plan,'evidence':[*plan['evidence'],fact]}
            attach(context,row)
    stats=context.directional_stats if config.indicators else None
    from modules.strategies.common import indicators as core_indicators
    tolerance=max(context.tick_size*2,context.spread*2,context.core_stats['atr']*D('.1'))
    output=[]
    for row in candidates:
        base=_plan(row)
        if not base:continue
        facts=_facts(base);votes=agreement(stats,base['direction'],config.indicators)[1] if stats else {}
        if config.indicators and not all(votes.values()):continue
        matches={}
        for engine in ('sweep_fvg','order_block'):
            matches[engine]=next((_plan(r) for r in rows if r.get('engine')==engine and _plan(r)
                                   and _same_entry(base,_plan(r),tolerance)),None)
        if base['engine'] in matches:matches[base['engine']]=base
        if config.require_fvg and not matches['sweep_fvg']:continue
        if (config.require_ob or config.require_poc) and not matches['order_block']:continue
        poc=_facts(matches['order_block']).get('entry_selection',{}).get('poc') if matches['order_block'] else None
        if config.require_poc and (not poc or not D(base['zone_low'])<=D(poc['price'])<=D(base['zone_high'])
                                   or abs(D(poc['price'])-D(base['entry']))>tolerance):continue
        regime=facts.get('liquidity_direction_guard',{}).get('active_reversal')
        if config.require_liquidity and (not regime or regime['direction']!=base['direction']):continue
        dmm=facts.get('shared_goldbach_confirmation',{})
        if config.require_dmm and not dmm.get('confirmed'):continue
        fib=_fib(context,base,config)
        if config.require_fibonacci and not fib['confirmed']:continue
        from modules.goldbach_confirmation import priority_confluence
        priority=priority_confluence(base,fib,dmm)
        identity=content_hash([config.profile_id,base['thesis_key']])
        detail={'config':config.dto(),'profile_id':config.profile_id,'base_engine':base['engine'],
                'base_plan':base,'base_plan_hash':content_hash(base),'indicator_votes':votes,
                'matches':matches,
                'poc':poc,'liquidity':regime,'dmm':dmm,'fibonacci':fib,'confluence_priority':priority,
                'all_enabled_filters_required':True,'entry_stop_targets_averaged':False}
        plan={**base,'engine':'custom','submodel':base['submodel'],
              'thesis_key':identity,'setup_id':content_hash(['custom',identity])[:32],
              'evidence':[*base['evidence'],{'kind':'custom_strategy','available_ms':context.cutoff_ms,'detail':detail}]}
        new={**row,'engine':'custom','profile_id':config.profile_id,'thesis_key':identity,
             'fibonacci_confirmation':fib,'confluence_priority':priority}
        if row.get('plan'):
            from modules.setup_lifecycle import SetupPlan
            new['plan']=SetupPlan.from_dict(plan).as_dict()
        else:
            new['draft_plan']=plan;new['draft_hash']=content_hash(plan)
        output.append(new)
    return output


def validate_plan(plan):
    facts=[f.get('detail') for f in plan.get('evidence',()) if f.get('kind')=='custom_strategy']
    if len(facts)!=1 or not isinstance(facts[0],dict):raise ValueError('CUSTOM_EVIDENCE_REQUIRED')
    detail=facts[0];config=parse_settings(detail.get('config'))
    base=detail.get('base_plan',{})
    if not config.enabled or base.get('engine')!=config.base or base.get('engine') not in BASES:
        raise ValueError('CUSTOM_BASE_INVALID')
    if content_hash(base)!=detail.get('base_plan_hash') or config.profile_id!=detail.get('profile_id'):
        raise ValueError('CUSTOM_CONFIG_OR_BASE_CHANGED')
    if content_hash(plan['evidence'][:-1])!=content_hash(base.get('evidence',())):
        raise ValueError('CUSTOM_BASE_EVIDENCE_CHANGED')
    keys=('symbol','timeframe','direction','provider','venue','product','entry','stop','zone_low','zone_high','tp1','tp2','tp3',*(f'tp{i}' for i in range(4,11)),'submodel','source_ids','evidence_cutoff_ms')
    if content_hash([plan.get(k) for k in keys])!=content_hash([base.get(k) for k in keys]):raise ValueError('CUSTOM_BASE_GEOMETRY_CHANGED')
    if plan['thesis_key']!=content_hash([config.profile_id,base['thesis_key']]):raise ValueError('CUSTOM_IDENTITY_CHANGED')
    if plan['setup_id']!=content_hash(['custom',plan['thesis_key']])[:32]:raise ValueError('CUSTOM_IDENTITY_CHANGED')
    votes=detail.get('indicator_votes',{})
    if set(votes)!=set(config.indicators) or any(x is not True for x in votes.values()):raise ValueError('CUSTOM_INDICATOR_CONFIRMATION_REQUIRED')
    matches=detail.get('matches',{})
    if base['engine']=='indicators':
        base_votes=_facts(base).get('all_directional_indicators',{}).get('directional_agreement',{})
        if set(base_votes)!=set(config.indicators):raise ValueError('CUSTOM_BASE_SELECTION_CHANGED')
    if config.require_fvg and not matches.get('sweep_fvg'):raise ValueError('CUSTOM_FVG_REQUIRED')
    if (config.require_ob or config.require_poc) and not matches.get('order_block'):raise ValueError('CUSTOM_OB_REQUIRED')
    if config.require_poc and not detail.get('poc'):raise ValueError('CUSTOM_POC_REQUIRED')
    if config.require_liquidity and (detail.get('liquidity') or {}).get('direction')!=plan['direction']:raise ValueError('CUSTOM_LIQUIDITY_REQUIRED')
    if config.require_dmm and not (detail.get('dmm') or {}).get('confirmed'):raise ValueError('CUSTOM_DMM_REQUIRED')
    if config.require_fibonacci and not (detail.get('fibonacci') or {}).get('confirmed'):raise ValueError('CUSTOM_FIBONACCI_REQUIRED')
    from modules.signal_plan_policy import validate_locked_signal_plan
    for kind,other in matches.items():
        if other:
            if other.get('engine')!=kind or kind not in {'sweep_fvg','order_block'}:raise ValueError('CUSTOM_CONFIRMATION_KIND_INVALID')
            validate_locked_signal_plan(other)
    return base


def revalidate_plan(plan,bars,now_ms,spread):
    base=validate_plan(plan);detail=_facts(plan)['custom_strategy'];config=parse_settings(detail['config'])
    closed=[b for b in bars if b.is_closed and b.available_ms<=now_ms]
    if base['engine']=='indicators':
        from modules.indicator_suite import revalidate_plan as check_indicators
        check_indicators(base,closed,custom_scope=True)
    if config.indicators and not agreement(indicators(closed),plan['direction'],config.indicators)[0]:
        raise ValueError('CUSTOM_INDICATOR_DIRECTION_CHANGED')
    for key in ('sweep_fvg','order_block'):
        required=config.require_fvg if key=='sweep_fvg' else config.require_ob or config.require_poc
        other=detail['matches'].get(key)
        if not required or not other:continue
        window=[b for b in bars if b.end_ms>other['evidence_cutoff_ms']]
        if not window or window[0].start_ms>other['evidence_cutoff_ms'] or window[-1].end_ms<now_ms:
            raise ValueError('CUSTOM_CONFIRMATION_COVERAGE_MISSING')
        if any(a.end_ms!=b.start_ms for a,b in zip(window,window[1:])):raise ValueError('CUSTOM_CONFIRMATION_COVERAGE_GAP')
        if any(b.low<=D(other['zone_high']) and b.high>=D(other['zone_low']) for b in window):
            raise ValueError('CUSTOM_CONFIRMATION_ZONE_TOUCHED')
    if config.require_liquidity:
        from modules.strategies.common import Parameters,confirmed_swings,indicators as core_indicators
        from modules.strategies.liquidity import active_reversal
        saved=_facts(plan)['liquidity_direction_guard']['parameters']
        p=Parameters(**{k:int(v) if k.startswith('swing_') else D(v) for k,v in saved.items()})
        regime=active_reversal(closed,confirmed_swings(closed,p),p,core_indicators(closed)['atr'],spread)
        if not regime or regime['direction']!=plan['direction']:raise ValueError('CUSTOM_LIQUIDITY_CONFIRMATION_ENDED')
