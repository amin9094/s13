"""Read-only adaptive exit proposals. No ledger, price, or broker mutation."""
from decimal import Decimal as D, ROUND_FLOOR, ROUND_CEILING

from modules.canonical_market import TIMEFRAMES, validate_series
from modules.strategies.common import Parameters, confirmed_swings, indicators


def recommend(plan, trade, bars, *, now_ms):
    result = {'state':'WAITING_FOR_TP1','requires_admin_decision':True,
              'applied':False,'locked_plan_changed':False,'paper_result_changed':False,
              'broker_execution':False,'partial_fraction_of_remaining':None,'proposed_stop':None}
    if trade.get('state') != 'OPEN' or not any(e.get('type')=='TP1' for e in trade.get('events',())):
        return result
    try:
        remaining=D(trade.get('remaining','0'))
        if (not remaining.is_finite() or not 0<remaining<=1
                or type(trade.get('entered_ms')) is not int or trade['entered_ms']<=0):
            raise ValueError('EXIT_POSITION_INVALID')
    except (ValueError,TypeError,ArithmeticError):
        return {**result,'state':'POSITION_REVIEW_REQUIRED'}
    quote = trade.get('last_quote') or {}
    if (not bars or not quote or any(type(quote.get(k)) is not int or not 0<=now_ms-quote[k]<=5000
                                    for k in ('event_ms','received_ms'))):
        return {**result,'state':'FRESH_MARKET_DATA_REQUIRED'}
    bars = [b for b in bars if b.is_closed and b.available_ms <= now_ms]
    if (len(bars)<105 or now_ms-bars[-1].end_ms>2*TIMEFRAMES[plan['timeframe']]
            or any((b.symbol,b.provider,b.venue,b.product,b.timeframe) !=
                   tuple(plan[k] for k in ('symbol','provider','venue','product','timeframe'))
                   or b.quality_flags for b in bars)
            or any(a.end_ms!=b.start_ms for a,b in zip(bars,bars[1:]))):
        return {**result,'state':'FRESH_MARKET_DATA_REQUIRED'}
    try:
        validate_series(bars,now_ms=now_ms,allow_open=False)
        bid,ask = D(quote['bid']),D(quote['ask'])
        if not bid.is_finite() or not ask.is_finite() or bid<=0 or ask<bid:
            raise ValueError('EXIT_QUOTE_INVALID')
    except (ValueError,KeyError,ArithmeticError):
        return {**result,'state':'FRESH_MARKET_DATA_REQUIRED'}
    sign = D(1) if plan['direction']=='BUY' else D(-1)
    current = bid if sign==1 else ask
    stats = indicators(bars)
    params = Parameters()
    pivots = [s for s in confirmed_swings(bars,params)
              if s.kind==('low' if sign==1 else 'high') and s.available_ms<=now_ms
              and bars[s.index].start_ms>=trade.get('entered_ms',now_ms+1) and sign*(current-s.value)>0]
    aligned = sign*(stats['plus_di']-stats['minus_di'])>0
    strength = 'STRONG' if aligned and stats['adx']>=25 else 'WEAK' if not aligned else 'NORMAL'
    fraction = {'STRONG':'.25','NORMAL':'.50','WEAK':'.75'}[strength]
    target_levels=[D(plan[f'tp{i}']) for i in range(1,11) if plan.get(f'tp{i}') is not None
                   and sign*(D(plan[f'tp{i}'])-current)>0]
    nearest=min(target_levels,key=lambda v:abs(v-current)) if target_levels else None
    distance=abs(nearest-current)/stats['atr'] if nearest is not None and stats['atr']>0 else None
    if distance is not None and distance<=D('.5'):
        fraction=str(max(D(fraction),D('.5')))
    result.update(state='ADMIN_REVIEW_PROPOSAL',trend_strength=strength,
                  partial_fraction_of_remaining=fraction,
                  partial_basis='CURRENT_ADX_DMI_AND_REMAINING_OBJECTIVES',
                  baseline_partial_policy='HALF_REMAINING_AT_TP_LAST_CLOSES_ALL',
                  next_objective=str(nearest) if nearest is not None else None,
                  objective_distance_atr=str(distance) if distance is not None else None,
                  reason_fa='پیشنهاد مدیریت پس از تارگت اول؛ اجرای تغییر نیازمند تصمیم ادمین است.')
    tick = D(plan.get('tick_size',plan.get('calculation_quantum')))
    buffer = max(stats['atr']*params.stop_buffer_atr,(ask-bid)*2,tick*2)
    if pivots:
        pivot = pivots[-1]
        stop = pivot.value-sign*buffer
        stop = (stop/tick).to_integral_value(rounding=ROUND_FLOOR if sign==1 else ROUND_CEILING)*tick
        original = D(plan['stop'])
        if stop>0 and sign*(stop-original)>0 and sign*(current-stop)>=max(stats['atr'],(ask-bid)*3,tick*4):
            result.update(proposed_stop=str(stop),protective_swing=str(pivot.value),
                          swing_source_id=bars[pivot.index].source_id,stop_only_tightens=True,
                          no_automatic_breakeven=True)
    return result
