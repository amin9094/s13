from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from core.utils import utc_iso


@dataclass(frozen=True, slots=True)
class PlatformCapability:
    key: str
    label: str
    control_module: str
    permission: str
    dependencies: tuple[str, ...] = ()
    user_visible: bool = True
    admin_visible: bool = True
    external_cost: str = "none"
    description: str = ""


CAPABILITIES: tuple[PlatformCapability, ...] = (
    PlatformCapability("local_copilot", "Gemini AI Sentinel", "copilot", "ai_command_center", ("journal", "signals"), external_cost="optional", description="تحلیل شخصی و مدیریتی با Gemini و fallback محلی"),
    PlatformCapability("risk_coach", "مربی رفتار و ریسک", "risk_coach", "risk_coach", ("journal", "risk"), description="شناسایی الگوهای رفتاری از داده‌های کاربر"),
    PlatformCapability("paper_arena", "مسابقه معامله آزمایشی", "paper_trading", "paper_trading", ("signals", "league"), description="حساب مجازی و رتبه‌بندی ریسک‌محور"),
    PlatformCapability("prop_guardian", "نگهبان پراپ", "prop_guardian", "prop_guardian", ("risk", "journal"), description="پایش محدودیت‌ها و شبیه‌سازی نقض قوانین"),
    PlatformCapability("market_intelligence_v2", "هوش بازار ۲", "market_v2", "market_intelligence", ("prices", "calendar"), description="تجمیع داده‌های ذخیره‌شده و منابع رایگان"),
    PlatformCapability("multi_channel_publisher", "ناشر چندکاناله", "publisher", "publisher", ("broadcast", "admins"), user_visible=False, description="صف انتشار، تأیید و قالب‌بندی مستقل"),
    PlatformCapability("partner_hub", "مرکز همکاران", "partners", "partners", ("campaigns", "referrals"), user_visible=False, description="انتساب، ضدتقلب و تسویه داخلی"),
    PlatformCapability("public_performance", "عملکرد عمومی قابل راستی‌آزمایی", "performance", "public_performance", ("trust", "signals"), description="گزارش عمومی با هش و تاریخچه"),
    PlatformCapability("content_factory", "کارخانه محتوا", "content_factory", "content_factory", ("signals", "publisher"), user_visible=False, description="تولید متن و کارت از قالب‌های داخلی"),
    PlatformCapability("business_inbox", "صندوق کسب‌وکار", "business_inbox", "business_inbox", ("crm", "support"), user_visible=False, description="طبقه‌بندی پیام و تبدیل به سرنخ بدون AI پولی"),
    PlatformCapability("miniapp_next", "مینی‌اپ نسل بعد", "miniapp_next", "feature_management", (), description="Draft آفلاین، همگام‌سازی و تنظیمات دستگاه"),
    PlatformCapability("developer_platform", "پلتفرم توسعه‌دهندگان", "developer_api", "developer_api", ("audit", "security"), user_visible=False, description="Webhook امن، HMAC و صف تحویل غیرفعال‌پیش‌فرض"),
    PlatformCapability("workspace_saas", "هسته فضای کاری", "workspaces", "workspaces", ("admins", "security"), user_visible=False, description="تفکیک داده و آماده‌سازی White-label"),
)

CAPABILITY_BY_KEY = {item.key: item for item in CAPABILITIES}


def ensure_platform_registry(db: dict[str, Any]) -> dict[str, Any]:
    root = db.setdefault("platform_registry", {})
    if not isinstance(root, dict):
        root = {}
        db["platform_registry"] = root
    root.setdefault("schema_version", 1)
    root.setdefault("strict_free_mode", True)
    root.setdefault("allow_external_paid_providers", False)
    root.setdefault("updated_at", utc_iso())
    states = root.setdefault("capabilities", {})
    if not isinstance(states, dict):
        states = {}
        root["capabilities"] = states
    for item in CAPABILITIES:
        row = states.setdefault(item.key, {})
        if not isinstance(row, dict):
            row = {}
            states[item.key] = row
        row.setdefault("enabled", True)
        row.setdefault("external_cost", item.external_cost)
        row.setdefault("updated_at", utc_iso())
    root.setdefault("events", [])
    return root


def _control_enabled(db: dict[str, Any], module_key: str) -> bool:
    root = db.get("enterprise_control")
    if not isinstance(root, dict):
        return True
    modules = root.get("modules")
    if not isinstance(modules, dict):
        return True
    state = modules.get(module_key)
    if not isinstance(state, dict):
        return True
    return bool(state.get("enabled", True))


def capability_available(db: dict[str, Any], key: str) -> tuple[bool, list[str]]:
    item = CAPABILITY_BY_KEY.get(str(key))
    if not item:
        return False, ["UNKNOWN_CAPABILITY"]
    root = ensure_platform_registry(db)
    reasons: list[str] = []
    state = root["capabilities"].get(item.key, {})
    if not bool(state.get("enabled", True)):
        reasons.append("CAPABILITY_DISABLED")
    if not _control_enabled(db, item.control_module):
        reasons.append("CONTROL_MODULE_DISABLED")
    for dependency in item.dependencies:
        if not _control_enabled(db, dependency):
            reasons.append(f"DEPENDENCY_DISABLED:{dependency}")
    if bool(root.get("strict_free_mode", True)) and item.external_cost not in {"none", "optional"}:
        reasons.append("PAID_PROVIDER_BLOCKED")
    return not reasons, reasons


def set_capability_enabled(db: dict[str, Any], key: str, enabled: bool, actor_id: int | str) -> dict[str, Any]:
    if key not in CAPABILITY_BY_KEY:
        raise ValueError("CAPABILITY_NOT_FOUND")
    root = ensure_platform_registry(db)
    row = root["capabilities"][key]
    row["enabled"] = bool(enabled)
    row["updated_at"] = utc_iso()
    row["updated_by"] = str(actor_id)
    root["updated_at"] = utc_iso()
    root["events"].append({"type": "capability_toggle", "key": key, "enabled": bool(enabled), "actor_id": str(actor_id), "created_at": utc_iso()})
    root["events"] = root["events"][-3000:]
    return dict(row)


def cost_policy(db: dict[str, Any]) -> dict[str, Any]:
    root = ensure_platform_registry(db)
    return {
        "strict_free_mode": bool(root.get("strict_free_mode", True)),
        "allow_external_paid_providers": bool(root.get("allow_external_paid_providers", False)),
        "policy": "free_and_self_hosted_only" if bool(root.get("strict_free_mode", True)) else "optional_external_integrations",
    }


def platform_matrix(db: dict[str, Any]) -> dict[str, Any]:
    root = ensure_platform_registry(db)
    rows: list[dict[str, Any]] = []
    enabled_count = 0
    blocked_count = 0
    for item in CAPABILITIES:
        available, reasons = capability_available(db, item.key)
        state = root["capabilities"][item.key]
        enabled_count += int(available)
        blocked_count += int(not available)
        rows.append({
            "key": item.key,
            "label": item.label,
            "description": item.description,
            "control_module": item.control_module,
            "permission": item.permission,
            "dependencies": list(item.dependencies),
            "enabled": bool(state.get("enabled", True)),
            "available": available,
            "reasons": reasons,
            "external_cost": item.external_cost,
            "user_visible": item.user_visible,
            "admin_visible": item.admin_visible,
        })
    return {
        "schema_version": int(root.get("schema_version", 1)),
        "policy": cost_policy(db),
        "total": len(rows),
        "available": enabled_count,
        "blocked": blocked_count,
        "items": rows,
        "generated_at": utc_iso(),
    }
