"""Initial stops protect the latest confirmed structure and causal invalidation."""
from decimal import Decimal as D, ROUND_CEILING, ROUND_FLOOR


def structural_stop(context, direction, entry, zone, swings, *, required_extremes=(),
                    minimum_index=None, anchor_source_ids=(), anchor_available_ms=None, model=''):
    sign = D(1) if direction == 'BUY' else D(-1)
    kind = 'low' if direction == 'BUY' else 'high'
    eligible = [s for s in swings if s.kind == kind and s.available_ms <= context.cutoff_ms
                and sign*(entry-s.value)>0 and (minimum_index is None or s.index >= minimum_index)]
    pivot = eligible[-1] if eligible else None
    anchors = [D(v) for v in required_extremes]
    if pivot is None and not anchors:
        return None
    boundary = zone[0] if direction == 'BUY' else zone[1]
    structure = [boundary, *anchors, *([pivot.value] if pivot else [])]
    protected = min(structure) if direction == 'BUY' else max(structure)
    atr = context.core_stats['atr']
    buffer = max(atr*context.parameters.stop_buffer_atr, context.spread*2, context.tick_size*2)
    minimum = max(atr, context.spread*3, context.tick_size*4)
    stop = min(protected-buffer, entry-minimum) if direction == 'BUY' else max(protected+buffer, entry+minimum)
    stop = (stop/context.tick_size).to_integral_value(
        rounding=ROUND_FLOOR if direction == 'BUY' else ROUND_CEILING)*context.tick_size
    if stop <= 0:
        return None
    available = max(pivot.available_ms if pivot else 0, anchor_available_ms or 0)
    if available > context.cutoff_ms:
        raise ValueError('STRUCTURAL_STOP_FUTURE_ANCHOR')
    return stop, {'method':'CONFIRMED_STRUCTURE_ATR_SPREAD_FLOOR',
        'selection_policy':'LATEST_CONFIRMED_SWING_WITH_CAUSAL_INVALIDATION_V1',
        'protective_swing':str(pivot.value if pivot else protected),
        'swing_index':pivot.index if pivot else None, 'swing_available_ms':available,
        'swing_source_id':context.closed[pivot.index].source_id if pivot else None,
        'causal_anchor_source_ids':list(anchor_source_ids), 'causal_extremes':[str(v) for v in anchors],
        'anchor_basis':'CONFIRMED_SWING_AND_CAUSAL_LEG' if pivot else 'CLOSED_CAUSAL_LEG',
        'protected_boundary':str(protected), 'original_zone_boundary':str(boundary),
        'buffer':str(buffer), 'minimum_risk_distance':str(minimum), 'atr':str(atr),
        'spread_at_proposal':str(context.spread), 'stop':str(stop), 'model':model,
        'target_levels_moved':False, 'supertrend_is_initial_stop_anchor':False}
