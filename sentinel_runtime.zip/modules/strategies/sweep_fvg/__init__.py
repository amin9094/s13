"""Isolated sweep_fvg strategy family."""
