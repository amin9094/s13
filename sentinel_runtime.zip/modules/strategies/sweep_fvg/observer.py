"""Price-only observation of the same closed liquidity sequence as the engine."""
from modules.strategies.common import indicators
from modules.strategies.liquidity import reversals
from modules.strategies.observations import observation, safe_swings


def observe(context):
    bars, p = context.closed, context.parameters
    swings, atr = safe_swings(bars, p), indicators(bars)['atr']
    rows = []
    for event in reversals(bars, swings, p, atr):
        direction, sign = event['direction'], event['sign']
        i, reclaim, choch = (event[k] for k in ('sweep_index','reclaim_index','choch_index'))
        for third in range(event['origin_index'] + 2, event['impulse_end'] + 1):
            one, middle, three = bars[third - 2:third + 1]
            zone = (one.high, three.low) if direction == 'BUY' else (three.high, one.low)
            if (zone[1] <= zone[0] or zone[1] - zone[0] < atr * p.min_fvg_atr
                    or sign * (middle.close - middle.open) < atr * p.displacement_atr):
                continue
            ends = [s for s in swings if s.kind == ('high' if direction == 'BUY' else 'low')
                    and s.index >= max(choch, third - 1)]
            wave = {'start_index':event['origin_index'],'end_index':ends[0].index} if ends else None
            row = observation(context, 'sweep_fvg', 'liquidity_reversal', direction, zone,
                ['sweep-sequence-v3',bars[i].source_id,bars[choch].source_id,three.source_id],
                after_ms=three.end_ms, wave=wave,
                facts=[{'kind':'sweep_reclaim','pool_price':str(event['pool'].value),
                        'sweep_index':i,'reclaim_index':reclaim,'sweep_extreme':str(event['sweep_extreme'])},
                       {'kind':'closed_choch','index':choch,'protected_price':str(event['protected'].value),
                        'prior_structure':event['prior_structure']},
                       {'kind':'fvg','third_index':third,'midpoint_reference':str(sum(zone)/2),
                        'spread_gate_pending':True,'midpoint_is_entry':False}],
                missing=['NATIVE_SPREAD_FVG_WIDTH_CHECK','NATIVE_PIP_SIZE_FOR_OFFSET'])
            if row:
                rows.append(row)
                break
    return rows
