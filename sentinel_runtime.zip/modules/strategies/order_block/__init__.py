"""Isolated order_block strategy family."""
