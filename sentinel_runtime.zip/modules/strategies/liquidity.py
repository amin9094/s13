"""Causal closed-candle sweep/reclaim/CHoCH, shared by all entry engines.

An active reversal is a directional veto, not a standalone entry. Indices are
local to this window; persisted evidence also records immutable source ids.
"""
from decimal import Decimal as D

from modules.strategies.common import structure_direction
from modules.strategies.liquidity_map import pool_map


def reversals(bars, swings, parameters, atr, spread=D(0)):
    if atr <= 0:
        return []
    threshold = max(atr * parameters.sweep_atr, spread * 2)
    found, seen = [], set()
    for i in range(parameters.swing_left + parameters.swing_right, len(bars) - 2):
        known = [s for s in swings if s.index+parameters.swing_right < i and s.available_ms <= bars[i].start_ms]
        prior = structure_direction(known)
        mapped = None
        for direction, sign, kind in [('BUY', D(1), 'low'), ('SELL', D(-1), 'high')]:
            if prior != ('DOWN' if direction == 'BUY' else 'UP'):
                continue
            protected = [s for s in known if s.kind != kind]
            if not protected:
                continue
            if mapped is None:
                mapped = pool_map(bars,swings,parameters,atr,before_index=i,spread=spread)
            swept = [item for item in mapped if item['pivot'].kind == kind
                     and sign*(item['pivot'].value-getattr(bars[i],'low' if direction == 'BUY' else 'high')) >= threshold]
            if not swept:
                continue
            chosen = swept[0]
            pool,structure = chosen['pivot'],protected[-1]
            window = bars[min(pool.index, structure.index):]
            if any(a.end_ms != b.start_ms for a, b in zip(window, window[1:])):
                continue
            extreme_name = 'low' if direction == 'BUY' else 'high'
            if sign * (pool.value - getattr(bars[i], extreme_name)) < threshold:
                continue
            # One pool cannot be swept repeatedly by every subsequent candle.
            if any(sign * (pool.value - getattr(b, extreme_name)) >= threshold
                   for b in bars[pool.index + 1:i]):
                continue
            reclaim = next((j for j in range(i, len(bars)) if sign * (bars[j].close - pool.value) > 0), None)
            if reclaim is None:
                continue
            choch = next((j for j in range(reclaim, len(bars))
                          if sign * (bars[j].close - structure.value) > 0), None)
            if choch is None:
                continue
            identity = (direction, structure.index, choch)
            if identity in seen:
                continue
            seen.add(identity)
            origin = min(range(i, choch + 1), key=lambda j: sign * getattr(bars[j], extreme_name))
            ends = [s.index for s in swings if s.kind != kind and s.index >= choch]
            found.append({'direction': direction, 'sign': sign, 'pool': pool,
                          'protected': structure, 'sweep_index': i, 'reclaim_index': reclaim,
                          'choch_index': choch, 'origin_index': origin,
                          'sweep_extreme': getattr(bars[origin], extreme_name),
                          'pool_detail':chosen['detail'],'swept_pool_details':[item['detail'] for item in swept],
                          'prior_structure': prior,
                          'impulse_end': ends[0] if ends else len(bars) - 1})
    return sorted(found, key=lambda e: (e['choch_index'], e['sweep_index']))


def active_reversal(bars, swings, parameters, atr, spread=D(0)):
    """Latest reversal with real directional displacement/FVG, until invalidated.

    Swept-extreme violation or a later confirmed counter-structure close ends
    the veto. Merely RSI turning, touching the gap, or time passing does not.
    """
    for event in reversed(reversals(bars, swings, parameters, atr, spread)):
        sign, direction = event['sign'], event['direction']
        start, choch = event['sweep_index'], event['choch_index']
        gaps = []
        for third in range(event['origin_index'] + 2, event['impulse_end'] + 1):
            one, middle, three = bars[third - 2:third + 1]
            width = three.low - one.high if direction == 'BUY' else one.low - three.high
            if (width > 0 and width >= max(atr * parameters.min_fvg_atr, spread * parameters.spread_gap_multiple)
                    and sign * (middle.close - middle.open) >= atr * parameters.displacement_atr):
                gaps.append(third)
        if not gaps:
            continue
        active_from = max(choch, gaps[0])
        invalidated = False
        for i in range(choch + 1, len(bars)):
            extreme = bars[i].low if direction == 'BUY' else bars[i].high
            if sign * (extreme - event['sweep_extreme']) < 0:
                invalidated = True
                break
            counters = [s for s in swings if s.kind == ('low' if direction == 'BUY' else 'high')
                        and s.index > choch and s.index + parameters.swing_right < i]
            if counters and sign * (bars[i].close - counters[-1].value) < 0:
                invalidated = True
                break
        if invalidated:
            # This latest regime ended; an older opposite regime cannot revive.
            return None
        return {'direction': direction, 'sweep_source_id': bars[start].source_id,
                'choch_source_id': bars[choch].source_id,
                'fvg_source_id': bars[gaps[0]].source_id,
                'sweep_extreme': str(event['sweep_extreme']),
                'protected_price': str(event['protected'].value),
                'confirmed_ms': bars[active_from].end_ms,
                'available_ms': max(bars[active_from].available_ms, bars[choch].available_ms),
                'basis': 'CLOSED_SWEEP_CHOCH_DIRECTIONAL_FVG'}
    return None


def assert_plan_direction(plan, closed, spread=D(0)):
    """Recheck the current structure before publication with frozen thresholds."""
    from modules.strategies.common import Parameters, confirmed_swings, indicators
    facts = [f.get('detail', {}) for f in plan.get('evidence', ())
             if f.get('kind') == 'liquidity_direction_guard']
    if len(closed) < 105:
        raise ValueError('LIQUIDITY_DIRECTION_WARMUP_INCOMPLETE')
    # Old queued plans are checked using documented defaults, without changing
    # their historical prices/hash; new plans retain their selected thresholds.
    saved = facts[0].get('parameters', {}) if facts else {}
    fields = ('swing_left','swing_right','sweep_atr','displacement_atr','min_fvg_atr','spread_gap_multiple')
    parameters = Parameters(**{k: int(saved[k]) if k.startswith('swing_') else D(saved[k])
                               for k in fields if k in saved})
    checks = [parameters]
    # Pre-upgrade evidence used the entry engine's thresholds. It could miss
    # the sweep engine's reversal when that engine had a different profile.
    # Also check the documented shared defaults for those historical plans;
    # never rewrite their stored entry, stop, targets, evidence or hash.
    if not facts or facts[0].get('parameter_source') != 'SHARED_SWEEP_FVG_PROFILE':
        checks.append(Parameters())
    atr = indicators(closed)['atr']
    for selected in checks:
        regime = active_reversal(closed, confirmed_swings(closed, selected), selected, atr, spread)
        if regime and regime['direction'] != plan['direction']:
            raise ValueError('LIQUIDITY_DIRECTION_CHANGED_BEFORE_PUBLICATION')
