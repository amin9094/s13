"""Original three-candle gaps and observed mitigation; visits are not fills."""
from decimal import Decimal as D
from hashlib import sha256
from repositories.v2.common import json_dump


def gap_geometry(one, middle, three, direction):
    if direction not in {'BUY', 'SELL'}:
        raise ValueError('FVG_DIRECTION_INVALID')
    if (one.end_ms != middle.start_ms or middle.end_ms != three.start_ms
            or any(not b.is_closed for b in (one, middle, three))):
        return None
    if len({(b.symbol,b.provider,b.venue,b.product,b.timeframe) for b in (one,middle,three)}) != 1:
        return None
    low, high = (one.high,three.low) if direction == 'BUY' else (three.high,one.low)
    return (low,high) if high > low else None


def visit_history(bars, low, high, direction, *, after_ms, cutoff_ms):
    low, high = D(low), D(high)
    later = [b for b in bars if b.end_ms > after_ms and b.available_ms <= cutoff_ms]
    touches = [b for b in later if b.low <= high and b.high >= low]
    width, midpoint = high-low, (high+low)/2
    if width <= 0:
        raise ValueError('ORIGINAL_ZONE_WIDTH_INVALID')
    penetration = max((max(D(0),min(D(1),(high-b.low)/width if direction == 'BUY'
                                                   else (b.high-low)/width)) for b in touches),default=D(0))
    visits, previous = 0, False
    touched_ids = {b.source_id for b in touches}
    for bar in later:
        hit = bar.source_id in touched_ids
        if hit and not previous:
            visits += 1
        previous = hit
    return {'status':'UNTOUCHED' if not touches else 'FULLY_MITIGATED' if penetration == 1 else 'PARTIALLY_MITIGATED',
            'first_touch_ms':touches[0].start_ms if touches else None,
            'first_touch_source_id':touches[0].source_id if touches else None,
            'observed_touch_bars':len(touches),'observed_visit_episodes':visits,
            'maximum_fill_fraction':str(penetration),
            'midpoint_observed':any(b.low <= midpoint <= b.high for b in later),
            'original_zone_changed':False,'native_fill_verified':False,'intrabar_touch_time_verified':False}


def gap_inventory(context, direction, start_index, end_index, *, atr, spread=D(0)):
    bars, p = context.closed, context.parameters
    sign = D(1) if direction == 'BUY' else D(-1)
    result = []
    for third in range(max(2,start_index+2),min(end_index+1,len(bars))):
        one,middle,three = bars[third-2:third+1]
        zone = gap_geometry(one,middle,three,direction)
        if zone is None:
            continue
        low,high = zone
        ids = [b.source_id for b in (one,middle,three)]
        identity = [one.symbol,one.provider,one.venue,one.product,one.timeframe,direction,ids]
        history = visit_history(context.candles,low,high,direction,
                                after_ms=three.end_ms,cutoff_ms=context.cutoff_ms)
        reason = ('RELATED_DIRECTIONAL_DISPLACEMENT_INSUFFICIENT'
                  if sign*(middle.close-middle.open) < atr*p.displacement_atr else
                  'FVG_WIDTH_BELOW_ATR_OR_SPREAD_THRESHOLD'
                  if high-low < max(atr*p.min_fvg_atr,spread*p.spread_gap_multiple) else
                  'ORIGINAL_FULL_ZONE_NOT_FRESH' if history['status'] != 'UNTOUCHED' else None)
        result.append({'zone_id':sha256(json_dump(identity).encode()).hexdigest()[:32],
            'kind':'FVG','direction':direction,'third_index':third,'source_ids':ids,
            'zone_low':str(low),'zone_high':str(high),'midpoint':str((low+high)/2),
            'formed_ms':three.end_ms,'available_ms':max(b.available_ms for b in (one,middle,three)),
            'history':history,'eligible':reason is None,'rejection_reason':reason})
    return result


def ob_gap_overlap(context, direction, ob, departure_index, end_index, entry, *, atr):
    gaps = gap_inventory(context,direction,departure_index-1,end_index,atr=atr,spread=context.spread)
    matched = []
    for gap in gaps:
        low,high = max(ob.low,D(gap['zone_low'])),min(ob.high,D(gap['zone_high']))
        if low <= high:
            matched.append({**gap,'intersection_low':str(low),'intersection_high':str(high),
                            'relation':'AREA_OVERLAP' if low<high else 'BOUNDARY_TOUCH',
                            'entry_inside_intersection':low < high and low <= entry <= high})
    return {'kind':'OB_FVG_OVERLAP','ob_source_id':ob.source_id,
            'original_ob_low':str(ob.low),'original_ob_high':str(ob.high),'gaps':matched,
            'confirmed':any(g['eligible'] and g['entry_inside_intersection'] for g in matched),
            'boundary_touch_is_area_overlap':False,
            'entry_role':'CAUSAL_WAVE_POC','entry_changed':False,
            'required_for_entry':False,'is_independent_probability_vote':False}
