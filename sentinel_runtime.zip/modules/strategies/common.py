"""Shared chronological evidence and research parameters, never performance certificates."""

from __future__ import annotations

from dataclasses import dataclass
from functools import cached_property
from decimal import Decimal as D, ROUND_CEILING, ROUND_FLOOR
from hashlib import sha256

from modules.canonical_market import ANALYSIS_TIMEFRAMES, Candle, Quote, TIMEFRAMES, validate_series
from modules.setup_lifecycle import SetupPlan
from modules.goldbach_confirmation import GoldbachSettings
from repositories.v2.common import json_dump


@dataclass(frozen=True)
class Parameters:
    profile_id: str = "research-3-session-poc-tick-shared-fib-NOT-PRODUCTION-VALIDATED"
    swing_left: int = 2
    swing_right: int = 2
    adx_trend: D = D(25)
    adx_range: D = D(20)
    displacement_atr: D = D("0.8")
    min_fvg_atr: D = D(".05")
    spread_gap_multiple: D = D(2)
    sweep_atr: D = D(".05")
    stop_buffer_atr: D = D(".1")
    volume_ratio: D = D("1.2")
    compact_cluster_atr: D = D(".1")


@dataclass(frozen=True)
class Swing:
    index: int
    kind: str
    value: D
    available_ms: int


@dataclass(frozen=True)
class Context:
    candles: tuple[Candle, ...]
    cutoff_ms: int
    tick_size: D
    spread: D
    parameters: Parameters = Parameters()
    value_factors: tuple[dict, ...] = ()
    ob_departure_proofs: tuple[dict, ...] = ()
    profile_candles: tuple[Candle, ...] = ()
    current_quote: Quote | None = None
    pip_size: D | None = None
    engine_parameters: tuple[tuple[str, Parameters], ...] = ()
    goldbach_settings: GoldbachSettings = GoldbachSettings()
    # The shared direction veto must not change with each entry engine's
    # experimental profile. Registries lock the selected sweep profile here.
    liquidity_parameters: Parameters | None = None
    indicator_selection: tuple[str, ...] | None = None
    custom_settings: object | None = None

    @cached_property
    def closed(self):
        return [bar for bar in self.candles if bar.is_closed and bar.available_ms <= self.cutoff_ms]

    @cached_property
    def core_stats(self):return indicators(self.closed)

    @cached_property
    def directional_stats(self):
        from modules.indicator_suite import indicators as suite
        return suite(self.closed)

    def validate(self):
        bars = list(self.candles)
        if not bars or bars[0].timeframe not in ANALYSIS_TIMEFRAMES:
            raise ValueError("ANALYSIS_TIMEFRAME_UNAPPROVED")
        validate_series(bars, now_ms=self.cutoff_ms)
        if any(bar.quality_flags or bar.volume_kind=='reported_tick_proxy' for bar in bars):
            raise ValueError("MARKET_QUALITY_GATE_FAILED")
        if self.tick_size <= 0 or self.spread < 0:
            raise ValueError("MARKET_PRECISION_OR_SPREAD_INVALID")
        if self.current_quote is not None:
            quote = self.current_quote
            if (quote.symbol, quote.provider, quote.venue, quote.product, quote.tick_size) != (
                bars[-1].symbol, bars[-1].provider, bars[-1].venue, bars[-1].product, self.tick_size
            ) or quote.event_ms > self.cutoff_ms:
                raise ValueError("ANALYSIS_QUOTE_PROVENANCE_INVALID")
        if len(self.closed) < 105:
            raise ValueError("INDICATOR_WARMUP_INCOMPLETE")
        # No synthetic filling across gaps. Session-aware source completeness
        # requires a separate verified calendar; currently fail closed.
        if any(b.start_ms != a.end_ms for a, b in zip(bars, bars[1:])):
            raise ValueError("HISTORICAL_COVERAGE_GAP_NEEDS_REVIEW")
        if self.cutoff_ms - bars[-1].start_ms > TIMEFRAMES[bars[-1].timeframe] * 2:
            raise ValueError("MARKET_DATA_STALE_OR_SESSION_CLOSED")


def confirmed_swings(bars, parameters):
    result = []
    left = parameters.swing_left
    right = parameters.swing_right
    for i in range(left, len(bars) - right):
        neighborhood = bars[i - left : i + right + 1]
        if any(a.end_ms!=b.start_ms for a,b in zip(neighborhood,neighborhood[1:])):
            continue
        available = max(bar.available_ms for bar in bars[i : i + right + 1])
        if all(bars[i].high > bar.high for j, bar in enumerate(neighborhood) if j != left):
            result.append(Swing(i, "high", bars[i].high, available))
        if all(bars[i].low < bar.low for j, bar in enumerate(neighborhood) if j != left):
            result.append(Swing(i, "low", bars[i].low, available))
    return result


def ema(values, period):
    alpha = D(2) / D(period + 1)
    result = []
    value = values[0]
    for sample in values:
        value = alpha * sample + (1 - alpha) * value
        result.append(value)
    return result


def structure_direction(swings):
    """Direction requires two confirmed highs and lows, not a future pivot."""
    highs = [s.value for s in swings if s.kind == 'high']
    lows = [s.value for s in swings if s.kind == 'low']
    if len(highs) < 2 or len(lows) < 2:
        return 'UNCONFIRMED'
    if highs[-1] > highs[-2] and lows[-1] > lows[-2]:
        return 'UP'
    if highs[-1] < highs[-2] and lows[-1] < lows[-2]:
        return 'DOWN'
    return 'RANGE'


def wilder(values, period):
    if len(values) < period:
        return []
    average = sum(values[:period]) / D(period)
    result = [None] * (period - 1) + [average]
    for value in values[period:]:
        average = (average * (period - 1) + value) / D(period)
        result.append(average)
    return result


def indicators(bars):
    closes = [bar.close for bar in bars]
    ma = {n: ema(closes, n) for n in (20, 50, 100)}
    gains = [max(D(0), b - a) for a, b in zip(closes, closes[1:])]
    losses = [max(D(0), a - b) for a, b in zip(closes, closes[1:])]
    # Fourteen actual changes need fifteen closes; do not seed a fake zero.
    avg_g = [None] + wilder(gains, 14)
    avg_l = [None] + wilder(losses, 14)
    rsi = [
        None
        if gain is None
        else D(50)
        if gain == loss == 0
        else D(100)
        if loss == 0
        else D(100) - D(100) / (1 + gain / loss)
        for gain, loss in zip(avg_g, avg_l)
    ]
    fast = ema(closes, 12)
    slow = ema(closes, 26)
    macd = [a - b for a, b in zip(fast, slow)]
    signal = ema(macd, 9)
    hist = [a - b for a, b in zip(macd, signal)]
    tr = [bars[0].high - bars[0].low]
    plus = [D(0)]
    minus = [D(0)]
    for a, b in zip(bars, bars[1:]):
        tr.append(max(b.high - b.low, abs(b.high - a.close), abs(b.low - a.close)))
        up = b.high - a.high
        down = a.low - b.low
        plus.append(up if up > down and up > 0 else D(0))
        minus.append(down if down > up and down > 0 else D(0))
    atr = wilder(tr, 14)
    pdm = wilder(plus, 14)
    mdm = wilder(minus, 14)
    dx = []
    for p, m, vol in zip(pdm, mdm, atr):
        if p is None or vol is None:
            continue
        dx.append(D(0) if p + m == 0 else D(100) * abs(p - m) / (p + m))
    adx = wilder(dx, 14)
    vol = atr[-1] or D(0)
    return {
        "ma": ma, "rsi": rsi, "macd_hist": hist, "macd_line": macd, "macd_signal": signal,
        "atr": vol, "adx": adx[-1] if adx else D(0),
        "plus_di": D(100) * (pdm[-1] or D(0)) / vol if vol else D(0),
        "minus_di": D(100) * (mdm[-1] or D(0)) / vol if vol else D(0),
    }


def freshness(context, zone_low, zone_high, *, after_ms):
    bars = [bar for bar in context.candles if bar.end_ms > after_ms]
    if not bars:
        return {"untouched": False, "complete_coverage": False, "reason": "CURRENT_ZONE_COVERAGE_MISSING"}
    complete = bars[0].start_ms <= after_ms and bars[-1].end_ms >= context.cutoff_ms
    complete = complete and bars[-1].available_ms >= context.cutoff_ms
    if getattr(context,'review_only',False) and any(a.end_ms!=b.start_ms for a,b in zip(bars,bars[1:])):
        complete=False
    touched = any(bar.low <= zone_high and bar.high >= zone_low for bar in bars)
    quote = context.current_quote
    if quote is not None:
        touched = touched or zone_low <= quote.ask <= zone_high or zone_low <= quote.bid <= zone_high
    return {
        "untouched": not touched,
        "complete_coverage": complete,
        "observed_through_ms": context.cutoff_ms,
        "after_ms": after_ms,
        "bar_ids": [bar.source_id for bar in bars],
    }


def _targets(swings, entry, stop, direction, *, bars=None):
    sign = D(1) if direction == "BUY" else D(-1)
    target_kind = "high" if direction == "BUY" else "low"
    if bars is None:
        values = sorted({s.value for s in swings if s.kind == target_kind and sign * (s.value - entry) > 0}, reverse=direction == "SELL")
    else:
        from modules.strategies.liquidity_map import target_inventory
        values = [D(item['price']) for item in target_inventory(bars,swings,direction,entry,stop)['objectives']]
    if len(values) < 2:
        return None
    first = values[0]
    if entry == stop or abs(first - entry) / abs(entry - stop) < 2:
        # A closer genuine objective is an obstacle, not a level to silently
        # skip so a further price can be advertised as TP1 at an attractive RR.
        return None
    second = values[1]
    third = values[2] if len(values) > 2 else None
    return tuple(values[:10]) if len(values)>3 else (first, second, third)


def _candidate(context, engine, submodel, direction, zone, entry, stop, swings, thesis, facts, *, fresh_after, targets=None):
    from modules.strategies.liquidity import active_reversal
    guard_parameters = context.liquidity_parameters or dict(context.engine_parameters).get('sweep_fvg', context.parameters)
    guard_swings = swings if guard_parameters == context.parameters else confirmed_swings(context.closed, guard_parameters)
    regime = (active_reversal(context.closed, guard_swings, guard_parameters,
                              context.core_stats['atr'], context.spread)
              if len(guard_swings) >= 4 and len(context.closed) >= 15 else None)
    if regime and regime['direction'] != direction:
        return {'engine': engine, 'submodel': submodel, 'state': 'REJECTED',
                'reason': 'OPPOSES_CONFIRMED_LIQUIDITY_REVERSAL', 'liquidity_regime': regime}
    facts = [*facts, ('liquidity_direction_guard', context.cutoff_ms,
                     {'allowed': True, 'active_reversal': regime,
                      'parameters': {k: str(getattr(guard_parameters,k)) for k in
                          ('swing_left','swing_right','sweep_atr','displacement_atr','min_fvg_atr','spread_gap_multiple')},
                      'parameter_source': 'SHARED_SWEEP_FVG_PROFILE',
                      'profile_id': guard_parameters.profile_id,
                      'policy': 'SWEPT_EXTREME_OR_CONFIRMED_COUNTER_STRUCTURE_ENDS_VETO'})]
    low, high = zone
    fresh = freshness(context, low, high, after_ms=fresh_after)
    if not fresh.get("untouched") or not fresh.get("complete_coverage"):
        return {"engine": engine, "submodel": submodel, "state": "REJECTED", "reason": "ORIGINAL_FULL_ZONE_NOT_FRESH"}
    quote = context.current_quote
    current = (quote.ask if direction == "BUY" else quote.bid) if quote else context.candles[-1].close
    approach_above = (direction == "BUY") != (submodel == "range_breakout")
    if not (current > high if approach_above else current < low):
        return {"engine": engine, "submodel": submodel, "state": "REJECTED", "reason": "ENTRY_ZONE_NOT_AHEAD_ON_EXPECTED_APPROACH"}
    requested_stop = stop
    if (direction=='BUY' and stop>=low) or (direction=='SELL' and stop<=high):
        return {'engine':engine,'submodel':submodel,'state':'REJECTED','reason':'STOP_MUST_PROTECT_FULL_ORIGINAL_ZONE'}
    atr=context.core_stats['atr'] if len(context.closed)>=15 else D(0)
    minimum_risk=max(atr,context.spread*3,context.tick_size*4)
    stop=min(stop,entry-minimum_risk) if direction=='BUY' else max(stop,entry+minimum_risk)
    if stop<=0:
        return {'engine':engine,'submodel':submodel,'state':'REJECTED','reason':'STRUCTURAL_STOP_NOT_POSITIVE'}
    # ATR buffers are continuous prices. Round the stop away from entry before
    # checking risk/reward; an off-grid stop must not exaggerate the 2R ratio.
    stop = (stop / context.tick_size).to_integral_value(
        rounding=ROUND_FLOOR if direction == 'BUY' else ROUND_CEILING) * context.tick_size
    if (direction=='BUY' and stop>=low) or (direction=='SELL' and stop<=high):
        return {'engine':engine,'submodel':submodel,'state':'REJECTED','reason':'STOP_MUST_PROTECT_FULL_ORIGINAL_ZONE'}
    explicit_targets = targets is not None
    targets = targets or _targets(swings, entry, stop, direction,bars=context.closed)
    if targets is None:
        return {"engine": engine, "submodel": submodel, "state": "REJECTED", "reason": "NO_REAL_STRUCTURAL_TP1_AT_2R"}
    if any(value is not None and value % context.tick_size for value in targets):
        return {"engine":engine,"submodel":submodel,"state":"REJECTED","reason":"STRUCTURAL_TARGET_OFF_NATIVE_GRID"}
    from modules.strategies.liquidity_map import target_inventory
    target_detail = target_inventory(context.closed,swings,direction,entry,stop)
    target_detail.update(selection_policy='LOCKED_WAVE_OBJECTIVES' if explicit_targets else 'NEAREST_CONFIRMED_STRUCTURAL_OBJECTIVES',
                         selected_targets=[str(v) for v in targets if v is not None])
    facts.append(('target_selection',context.cutoff_ms,target_detail))
    last = context.candles[-1]
    # A thesis belongs to its actual source and causal bars. Window positions
    # change when history rolls and cannot identify a persistent setup.
    thesis_key = sha256(json_dump({"identity": thesis, "direction": direction,
                                  "engine":engine,"submodel":submodel,
                                  "market":[last.symbol,last.provider,last.venue,last.product,last.timeframe],
                                  "profile_id": context.parameters.profile_id}).encode()).hexdigest()
    setup_id = sha256(f"{engine}:{last.symbol}:{last.timeframe}:{thesis_key}".encode()).hexdigest()[:32]
    evidence = tuple({"kind": kind, "available_ms": available, "detail": detail} for kind, available, detail in facts)
    evidence += ({"kind":"native_grid_risk","available_ms":context.cutoff_ms,
                  "detail":{"requested_stop":str(requested_stop),"stop":str(stop),
                            "minimum_risk_distance":str(minimum_risk),"atr":str(atr),"spread":str(context.spread),
                            "floor_policy":"STRUCTURE_PLUS_ATR_SPREAD_TICK_V1",
                            "tick_size":str(context.tick_size),"rounding":"AWAY_FROM_ENTRY",
                            "risk_reward_checked_after_rounding":True}},)
    causal_times={b.source_id:b.start_ms for b in context.closed}
    evidence += ({"kind":"strategy_identity_v2","available_ms":context.cutoff_ms,
                  "detail":{"identity":thesis,"profile_id":context.parameters.profile_id,
                            "first_causal_ms":min((causal_times[item] for item in thesis if item in causal_times),default=context.cutoff_ms)}},)
    if getattr(context, 'review_only', False):
        sign = 1 if direction == 'BUY' else -1
        if sign*(entry-stop) <= 0 or sign*(targets[0]-entry) <= 0 or abs(targets[0]-entry)/abs(entry-stop) < 2:
            return {'engine':engine,'state':'REJECTED','reason':'REVIEW_TP1_BELOW_2R'}
        draft = {'setup_id':setup_id,'thesis_key':thesis_key,'engine':engine,'submodel':submodel,
                 'symbol':last.symbol,'timeframe':last.timeframe,'direction':direction,'provider':last.provider,
                 'venue':last.venue,'product':last.product,'zone_low':str(low),'zone_high':str(high),
                 'entry':str(entry),'stop':str(stop),'tp1':str(targets[0]),'tp2':str(targets[1]),
                 'tp3':str(targets[2]) if targets[2] is not None else None,
                 'calculation_quantum':str(context.tick_size),'evidence_cutoff_ms':context.cutoff_ms,
                 'fresh_after_ms':fresh_after,'evidence':list(evidence),
                 'source_ids':[b.source_id for b in context.candles],
                 'native_execution_grid_verified':False,'native_first_visit_proven':False,
                 'execution_eligible':False,'review_only':True,'rr_tp1':str(abs(targets[0]-entry)/abs(entry-stop))}
        draft.update({f'tp{i+1}':str(value) for i,value in enumerate(targets) if i>=3})
        digest=sha256(json_dump(draft).encode()).hexdigest()
        return {'engine':engine,'submodel':submodel,'state':'NEEDS_REVIEW','reason':'ADMIN_PREENTRY_REVIEW_PROPOSAL',
                'review_kind':'PREENTRY_PROPOSAL','draft_plan':draft,'draft_hash':digest,'profile_id':context.parameters.profile_id,
                'thesis_key':thesis_key,'available_ms':context.cutoff_ms,'symbol':last.symbol,'timeframe':last.timeframe,
                'provider':last.provider,'venue':last.venue,'product':last.product,'direction':direction,
                'original_zone':[str(low),str(high)],'title_fa':'پیشنهاد معامله پیش از ورود — تصمیم با ادمین',
                'execution_eligible':False,'requires_admin_decision':True}
    try:
        plan = SetupPlan(
            setup_id,
            thesis_key,
            engine,
            submodel,
            last.symbol,
            last.timeframe,
            direction,
            last.provider,
            last.venue,
            last.product,
            context.cutoff_ms,
            low,
            high,
            entry,
            stop,
            *targets[:3],
            context.tick_size,
            tuple(bar.source_id for bar in context.candles),
            evidence,
            **{f'tp{i+1}':value for i,value in enumerate(targets) if i>=3},
        )
    except (ValueError, ArithmeticError) as exc:
        return {"engine": engine, "submodel": submodel, "state": "REJECTED", "reason": str(exc)}
    return {
        "engine": engine,
        "submodel": submodel,
        "state": "RESEARCH_CANDIDATE",
        "reason": "PARAMETER_PROFILE_REQUIRES_OOS_VALIDATION",
        "profile_id": context.parameters.profile_id,
        "plan": plan.as_dict(),
        "freshness_proof": fresh,
    }
