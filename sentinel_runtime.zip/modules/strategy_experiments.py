"""Predeclared research variants. Selection never happens from fake win rates."""

from __future__ import annotations

from dataclasses import replace
from decimal import Decimal as D

from modules.strategy_engines import evaluate_all


def research_profiles(parameters):
    variants = []
    configurations = (
        {}, {"displacement_atr": D("1.0")}, {"displacement_atr": D("1.2")},
        {"adx_trend": D(20)}, {"adx_trend": D(30)},
        {"volume_ratio": D("1.5")}, {"volume_ratio": D("2.0")},
        {"swing_left": 3, "swing_right": 3}, {"min_fvg_atr": D(".1")},
        {"stop_buffer_atr": D(".15")},
    )
    for i, changes in enumerate(configurations, 1):
        variants.append(replace(parameters, **changes, profile_id=f"session-research-variant-{i:02d}-NOT-PRODUCTION-VALIDATED"))
    return tuple(variants)


def evaluate_variants(context):
    return {"sample_kind": "RESEARCH_SNAPSHOT_NOT_COMPLETED_TRADES", "automatic_live_selection": False,
            "variants": [evaluate_all(replace(context, parameters=profile)) for profile in research_profiles(context.parameters)],
            "win_rate": None, "performance_reason": "USE_SEPARATE_RECORDED_FORWARD_OR_OOS_COHORTS"}
