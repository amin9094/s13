"""Short human-readable lifecycle reasons; never changes a frozen plan."""
REASONS={
 'ZONE_VISITED_BEFORE_PUBLICATION':'قیمت پیش از انتشار به محدوده رسیده است.',
 'SOURCE_SESSION_CHANGED':'جلسهٔ دریافت قیمت عوض شده؛ پیوستگی نیازمند بررسی است.',
 'QUOTE_OWNER_PROCESS_RESTART':'برنامه دوباره راه‌اندازی شده؛ فاصلهٔ دریافت قیمت باید بررسی شود.',
 'QUOTE_COVERAGE_GAP':'در دریافت قیمت وقفه ثبت شده است.',
 'ENTRY_GAP_FILL_UNPROVEN':'قیمت از ورود عبور کرده؛ اجرای ورود قابل اثبات نیست.',
 'MARKET_PRICE_MOVED_RESCAN_REQUIRED':'قیمت مارکت از ورود اولیه فاصله گرفته؛ فرصت تازه را بررسی کنید.',
 'PAPER_REPLAY_WINDOW_MISSING':'بخشی از مسیر قیمت در سابقهٔ قابل بازپخش نیست.',
 'OPPOSES_CONFIRMED_LIQUIDITY_REVERSAL':'جهت ستاپ با برگشت نقدینگی تأییدشده مخالف شده است.',
 'RESET_WITHOUT_ASSUMED_EXIT':'دوره ریست شده؛ خروج فرضی ثبت نشده است.',
 'INVALIDATION_BEFORE_PAPER_ENTRY':'ساختار پیش از ورود باطل شده است.',
 'SL':'استاپ ثبت شده است.','ALL_TARGETS':'تمام تارگت‌ها ثبت شده‌اند.',
 'ADMIN_CLOSE':'ماندهٔ معامله با تصمیم ادمین بسته شده است.',
 'ADMIN_PAPER_CANCEL':'ورود آزمایشی با تصمیم ادمین لغو شده است.',
 'ADMIN_ENTRIES_PAUSED_NO_RETROACTIVE_FILL':'ورودهای جدید با تصمیم ادمین متوقف‌اند.'}

REASONS.update({
 'SOURCE_CANDLE_REVISION_PENDING':'اصلاح کندل از منبع ثبت شده و هنوز دربارهٔ پذیرش آن تصمیم گرفته نشده است.',
 'PAPER_SOURCE_STALE':'قیمت همان منبع تازه نیست؛ اتصال و مسیر دریافت آن بررسی شود.',
 'SOURCE_SESSION_CHANGED':'نشست منبع تغییر کرده؛ ابتدا پوشش فاصلهٔ دریافت بررسی شود.',
 'PROFILE_UNCLASSIFIED':'نسخهٔ تنظیمات این پیشنهاد ثبت نشده؛ اسکن تازه با تنظیم مشخص لازم است.',
 'PROFILE_MISMATCH':'این رکورد قدیمی به‌علت اختلاف پروفایل آزمایش نشده؛ سوابق آن بازنویسی نمی‌شوند.',
 'ACTUAL_FILL_TP1_BELOW_2R':'فاصلهٔ قیمت ورود قابل مشاهده تا تارگت اول، حداقل نسبت ریسک را ندارد.',
 'CONFIGURED_MIN_VOLUME_EXCEEDS_RISK_BUDGET':'حداقل حجم تنظیم‌شده از بودجهٔ ریسک این حساب بیشتر است.',
 'PAPER_NO_POSITIVE_CAPITAL':'موجودی مثبت برای ورود آزمایشی باقی نمانده است.'})


def lifecycle(row,paper):
    reason=row['payload'].get('status_reason') or paper.get('reason')
    from core.error_explanations import explain_error
    diagnostic=explain_error(reason or '',source='live_signal')
    state=paper.get('state','UNAVAILABLE')
    return {'publication_state':row['state'],'paper_state':state,
        'diagnostic':diagnostic,'reason_code':reason,'suggested_action':'OPEN_DIAGNOSTIC_AND_RESCAN' if row['state'] in {'EXPIRED','NEEDS_REVIEW'} else 'REVIEW_BEFORE_PUBLICATION',
        'last_check_ms':paper.get('last_event_ms') or row['created_ms'],
        'reason_fa':REASONS.get(reason,diagnostic['title_fa']+'؛ '+diagnostic['action_fa'] if reason else ''),
        'original_entry_immutable':True,'new_scan_creates_new_record':True,
        'opportunity_current':'RECHECK_REQUIRED' if row['state'] in {'EXPIRED','NEEDS_REVIEW'} else 'REVALIDATE_ON_PUBLICATION'}
