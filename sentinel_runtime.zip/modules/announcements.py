from __future__ import annotations

from typing import Any

from core.db import next_id
from core.utils import utc_iso

ANNOUNCEMENT_TOPICS: dict[str, str] = {
    "daily_analysis": "تحلیل روز",
    "market_update": "بروزرسانی بازار",
    "important": "اطلاعیه مهم",
    "news": "خبر بازار",
    "education": "آموزش کوتاه",
    "vip": "اطلاعیه VIP",
    "maintenance": "وضعیت خدمات",
    "promotion": "پیشنهاد ویژه",
    "other": "سایر",
}


def ensure_announcements(db: dict[str, Any]) -> list[dict[str, Any]]:
    rows = db.setdefault("announcements", [])
    if not isinstance(rows, list):
        rows = []
        db["announcements"] = rows
    return rows


def record_announcement(
    db: dict[str, Any],
    *,
    admin_id: int | str,
    topic: str,
    title: str,
    destination: str,
    content_type: str,
    source_chat_id: int | str | None,
    source_message_id: int | str | None,
    text: str = "",
    deliveries: list[dict[str, Any]] | None = None,
    errors: list[str] | None = None,
    campaign_id: int | str | None = None,
) -> dict[str, Any]:
    topic_key = topic if topic in ANNOUNCEMENT_TOPICS else "other"
    row = {
        "id": next_id(db, "announcement"),
        "admin_id": str(admin_id),
        "topic": topic_key,
        "topic_label": ANNOUNCEMENT_TOPICS[topic_key],
        "title": str(title or ANNOUNCEMENT_TOPICS[topic_key])[:160],
        "destination": destination if destination in {"public", "private", "both"} else "public",
        "content_type": str(content_type or "text")[:40],
        "source_chat_id": str(source_chat_id or ""),
        "source_message_id": int(source_message_id or 0),
        "text": str(text or "")[:4000],
        "deliveries": list(deliveries or []),
        "errors": list(errors or []),
        "status": "partial" if errors and deliveries else "failed" if errors else "sent",
        "created_at": utc_iso(),
    }
    if campaign_id not in {None, ""}:
        row["campaign_id"] = str(campaign_id)
    ensure_announcements(db).append(row)
    db["announcements"] = db["announcements"][-3000:]
    return row


def announcement_history(db: dict[str, Any], limit: int = 20) -> list[dict[str, Any]]:
    rows = [row for row in ensure_announcements(db) if isinstance(row, dict)]
    rows.sort(key=lambda row: (str(row.get("created_at") or ""), int(row.get("id", 0) or 0)), reverse=True)
    return rows[: max(1, min(int(limit), 100))]


def announcement_summary(db: dict[str, Any]) -> dict[str, int]:
    rows = announcement_history(db, limit=3000)
    return {
        "total": len(rows),
        "sent": sum(1 for row in rows if row.get("status") == "sent"),
        "partial": sum(1 for row in rows if row.get("status") == "partial"),
        "failed": sum(1 for row in rows if row.get("status") == "failed"),
        "public": sum(1 for row in rows if row.get("destination") in {"public", "both"}),
        "private": sum(1 for row in rows if row.get("destination") in {"private", "both"}),
    }
