from __future__ import annotations

from typing import Any

_STATUS_ALIASES = {
    "stop": "stopped",
    "sl": "stopped",
    "stop_loss": "stopped",
    "stopped_out": "stopped",
    "target": "tp1",
    "take_profit": "tp1",
    "be": "breakeven",
    "manual": "manual_close",
    "cancel": "cancelled",
    "canceled": "cancelled",
    "target_complete": "win",
    "complete": "win",
    "partial": "partial_close",
}

FINAL_SIGNAL_STATUSES = {
    "closed", "stopped", "win", "loss", "cancelled", "expired", "manual_close", "no_entry", "archived", "deleted"
}


def normalize_signal_status(value: Any) -> str:
    clean = str(value or "open").strip().lower().replace("-", "_").replace(" ", "_")
    return _STATUS_ALIASES.get(clean, clean or "open")


def signal_is_final(row_or_status: Any) -> bool:
    if isinstance(row_or_status, dict):
        row = row_or_status
        status = normalize_signal_status(row.get("status"))
        if status in FINAL_SIGNAL_STATUSES:
            return True
        if status.startswith("tp") and status[2:].isdigit():
            target_index = int(status[2:])
            targets = row.get("targets") or row.get("take_profits") or []
            return bool(targets) and target_index >= len(targets)
        return False
    return normalize_signal_status(row_or_status) in FINAL_SIGNAL_STATUSES


def signal_status_rank(row: dict[str, Any]) -> tuple[int, int]:
    status = normalize_signal_status(row.get("status"))
    if signal_is_final(row):
        return (3, 0)
    if status == "open":
        return (0, 0)
    if status == "entry_hit":
        return (0, 1)
    if status.startswith("tp") and status[2:].isdigit():
        return (1, -int(status[2:]))
    if status in {"partial_close", "breakeven"}:
        return (1, 0)
    return (2, 0)
