from __future__ import annotations

import threading
from collections import Counter, deque
from typing import Any

from core.utils import utc_iso

_RUNTIME_EVENTS: deque[dict[str, Any]] = deque(maxlen=250)
_LOCK = threading.Lock()
_SEVERITY_WEIGHT = {"info": 0, "low": 1, "medium": 3, "high": 7, "critical": 10}


def record_security_event(
    event_type: str,
    *,
    severity: str = "medium",
    subject: str = "",
    metadata: dict[str, Any] | None = None,
    db: dict[str, Any] | None = None,
) -> dict[str, Any]:
    level = str(severity or "medium").lower()
    if level not in _SEVERITY_WEIGHT:
        level = "medium"
    row = {
        "type": str(event_type or "unknown")[:80],
        "severity": level,
        "subject": str(subject or "")[:160],
        "metadata": dict(metadata or {}),
        "created_at": utc_iso(),
    }
    with _LOCK:
        _RUNTIME_EVENTS.append(row)
    if isinstance(db, dict):
        operations = db.setdefault("operations", {})
        if not isinstance(operations, dict):
            operations = {}
            db["operations"] = operations
        events = operations.setdefault("security_events", [])
        if not isinstance(events, list):
            events = []
            operations["security_events"] = events
        events.append(row)
        operations["security_events"] = events[-500:]
    return row


def security_sentinel_snapshot(db: dict[str, Any] | None = None) -> dict[str, Any]:
    with _LOCK:
        runtime = list(_RUNTIME_EVENTS)
    persisted: list[dict[str, Any]] = []
    if isinstance(db, dict):
        operations = db.get("operations") if isinstance(db.get("operations"), dict) else {}
        persisted = [dict(item) for item in (operations.get("security_events") or []) if isinstance(item, dict)]
    combined: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str]] = set()
    for row in (persisted + runtime)[-500:]:
        marker = (str(row.get("created_at")), str(row.get("type")), str(row.get("subject")))
        if marker in seen:
            continue
        seen.add(marker)
        combined.append(row)
    states = Counter(str(row.get("severity") or "medium") for row in combined)
    risk_score = min(100, sum(_SEVERITY_WEIGHT.get(str(row.get("severity")), 3) for row in combined[-50:]))
    if states.get("critical"):
        state = "critical"
    elif states.get("high") or risk_score >= 35:
        state = "warning"
    else:
        state = "healthy"
    return {
        "state": state,
        "risk_score": int(risk_score),
        "events": combined[-20:],
        "counts": dict(states),
        "total": len(combined),
        "generated_at": utc_iso(),
    }
