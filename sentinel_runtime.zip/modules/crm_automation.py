from __future__ import annotations
from core.logging_context import operation_id

from collections import Counter
from datetime import timedelta
from typing import Any
from uuid import uuid4
from zoneinfo import ZoneInfo

from core.utils import parse_dt, utc_iso, utc_now
from modules.crm_engine import CRM_STAGES, refresh_crm_profile

CRM_ACTIVITY_LABELS = {
    "note": "یادداشت",
    "tag_added": "افزودن برچسب",
    "tag_removed": "حذف برچسب",
    "stage_changed": "تغییر مرحله",
    "assigned": "تخصیص مسئول",
    "followup_scheduled": "ثبت پیگیری",
    "followup_snoozed": "تعویق پیگیری",
    "followup_completed": "تکمیل پیگیری",
    "automation_sent": "ارسال اتوماسیون",
    "automation_failed": "خطای اتوماسیون",
    "profile_refreshed": "بروزرسانی پروفایل",
    "discount_sent": "ارسال کد تخفیف",
    "discount_validated": "اعتبارسنجی موفق کد",
    "discount_rejected": "رد کد تخفیف",
    "discount_reserved": "رزرو کد تخفیف",
    "discount_used": "استفاده از کد تخفیف",
    "discount_released": "آزادسازی کد تخفیف",
    "discount_refunded": "بازگردانی کد پس از بازپرداخت",
}


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(str(value if value is not None else default).replace(",", ""))
    except (TypeError, ValueError):
        return default


def record_crm_activity(
    db: dict[str, Any],
    user_id: int | str,
    activity_type: str,
    *,
    actor_id: int | str = "system",
    detail: str = "",
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    uid = str(user_id)
    counters = db.setdefault("counters", {})
    if not isinstance(counters, dict):
        counters = {}
        db["counters"] = counters
    row = {
        "id": int(counters.get("crm_activity", 0) or 0) + 1,
        "user_id": uid,
        "type": str(activity_type or "activity")[:50],
        "label": CRM_ACTIVITY_LABELS.get(str(activity_type), str(activity_type)),
        "actor_id": str(actor_id),
        "detail": str(detail or "")[:1500],
        "metadata": dict(metadata or {}),
        "created_at": utc_iso(),
    }
    counters["crm_activity"] = row["id"]
    activities = db.setdefault("crm_activities", [])
    if not isinstance(activities, list):
        activities = []
        db["crm_activities"] = activities
    activities.append(row)
    # Keep enough history for practical use while preventing unbounded JSON growth.
    if len(activities) > 20_000:
        db["crm_activities"] = activities[-20_000:]
    return row


def crm_activity_timeline(db: dict[str, Any], user_id: int | str, *, limit: int = 30) -> list[dict[str, Any]]:
    uid = str(user_id)
    rows = [
        dict(row)
        for row in db.get("crm_activities", [])
        if isinstance(row, dict) and str(row.get("user_id")) == uid
    ]
    rows.sort(key=lambda row: str(row.get("created_at") or ""), reverse=True)
    return rows[: max(1, min(int(limit), 200))]


def assign_crm_admin(db: dict[str, Any], user_id: int | str, admin_id: int | str | None, *, actor_id=None) -> dict[str, Any]:
    uid = str(user_id)
    profile = db.setdefault("crm_profiles", {}).setdefault(uid, {})
    old = str(profile.get("assigned_admin") or "")
    new = str(admin_id or "")
    profile["assigned_admin"] = new
    profile['owner_revision']=int(profile.get('owner_revision',1))+1
    profile["updated_at"] = utc_iso()
    record_crm_activity(
        db,
        uid,
        "assigned",
        actor_id=actor_id or admin_id or "system",
        detail=f"{old or '-'} → {new or 'بدون مسئول'}",
    )
    return profile


def set_crm_custom_field(
    db: dict[str, Any],
    user_id: int | str,
    field: str,
    value: Any,
    *,
    admin_id: int | str,
) -> dict[str, Any]:
    allowed = {"phone", "source", "company", "preferred_market", "contact_method"}
    key = str(field or "").strip()
    if key not in allowed:
        raise ValueError("فیلد CRM نامعتبر است")
    profile = db.setdefault("crm_profiles", {}).setdefault(str(user_id), {})
    fields = profile.setdefault("custom_fields", {})
    fields[key] = str(value or "").strip()[:200]
    profile["updated_at"] = utc_iso()
    record_crm_activity(db, user_id, "profile_refreshed", actor_id=admin_id, detail=f"{key} بروزرسانی شد")
    return profile


def refresh_all_crm_profiles(db: dict[str, Any], *, force: bool = False, limit: int = 5000) -> dict[str, int]:
    changed = 0
    refreshed = 0
    users=sorted(map(str,db.get('users',{})))
    state=db.setdefault('crm_refresh_state',{})
    dirty=[uid for uid in db.get('crm_dirty_users',{}) if uid in db.get('users',{})]
    after=str(state.get('after') or '')
    remaining=[uid for uid in users if uid>after]+[uid for uid in users if uid<=after]
    capacity=max(1,min(int(limit),5000));dirty_quota=max(1,int(capacity*.7))
    priority=dirty[:dirty_quota]
    aging=[uid for uid in remaining if uid not in set(dirty)][:capacity-len(priority)]
    selected=list(dict.fromkeys([*priority,*aging,*dirty]))[:capacity]
    for uid in selected:
        old = dict(db.get("crm_profiles", {}).get(str(uid), {}))
        row = refresh_crm_profile(db, uid, force=force)
        refreshed += 1
        if old.get("stage") != row.get("stage") or old.get("lead_score") != row.get("lead_score"):
            changed += 1
            record_crm_activity(
                db,
                uid,
                "profile_refreshed",
                detail=f"مرحله {old.get('stage') or '-'} → {row.get('stage')} | امتیاز {old.get('lead_score', 0)} → {row.get('lead_score', 0)}",
            )
    if aging:state['after']=aging[-1]
    state.update(last_cycle_at=utc_iso(),last_batch_size=refreshed,dirty_backlog=len(db.get('crm_dirty_users',{})))
    return {"refreshed": refreshed, "changed": changed}


def crm_dashboard_snapshot(db: dict[str, Any]) -> dict[str, Any]:
    refresh_all_crm_profiles(db,limit=200)
    stage_counts: Counter[str] = Counter()
    persona_counts: Counter[str] = Counter()
    assigned_counts: Counter[str] = Counter()
    scores: list[int] = []
    due = 0
    overdue = 0
    now = utc_now()
    for uid in db.get("users", {}):
        row=db.get('crm_profiles',{}).get(str(uid),{})
        stage_counts[str(row.get('stage') or 'unclassified')]+=1
        persona_counts[str(row.get("behavior_persona") or "explorer")] += 1
        assigned = str(row.get("assigned_admin") or "")
        if assigned:
            assigned_counts[assigned] += 1
        if row.get('last_profile_refresh_at'):scores.append(_safe_int(row.get('lead_score')))
        follow = parse_dt(row.get("follow_up_at"))
        if follow:
            due += 1
            if follow <= now:
                overdue += 1
    automation = db.get("crm_automation_log", {})
    sent = failed = pending = retry = dead_letter = 0
    if isinstance(automation, dict):
        for row in automation.values():
            if not isinstance(row, dict):
                continue
            status = str(row.get("status") or "")
            sent += status == "sent"
            failed += status == "failed"
            pending += status == "pending"
            retry += status == "retry"
            dead_letter += status == "dead_letter"
    terminal = sent + failed + dead_letter
    return {
        'profile_refresh':dict(db.get('crm_refresh_state',{})),
        'profiles_calculated':len(scores),
        'unclassified':stage_counts.get('unclassified',0),
        "total": sum(stage_counts.values()),
        "stages": {key: int(stage_counts.get(key, 0)) for key in CRM_STAGES},
        "average_score": round(sum(scores) / len(scores), 1) if scores else 0.0,
        "hot_leads": sum(1 for score in scores if score >= 70),
        "followups": due,
        "overdue_followups": overdue,
        "assigned": dict(assigned_counts),
        "personas": dict(persona_counts),
        "high_intent": sum(
            1
            for uid,row in db.get("crm_profiles", {}).items() if uid in db.get('users',{})
            if isinstance(row, dict) and _safe_int(row.get("purchase_intent_score")) >= 60
        ),
        "churn_risk": sum(
            1
            for uid,row in db.get("crm_profiles", {}).items() if uid in db.get('users',{})
            if isinstance(row, dict) and _safe_int(row.get("churn_risk_score")) >= 60
        ),
        "automation": {
            "sent": sent,
            "failed": failed,
            "pending": pending,
            "retry": retry,
            "dead_letter": dead_letter,
            "success_rate": round(sent / terminal * 100, 2) if terminal else 0.0,
        },
    }


def _claim_log(
    db: dict[str, Any],
    key: str,
    payload: dict[str, Any],
    *,
    max_attempts: int = 5,
) -> bool:
    now = utc_now()
    logs = db.setdefault("crm_automation_log", {})
    existing = logs.get(key)
    if isinstance(existing, dict):
        status = str(existing.get("status") or "")
        if status in {"sent","uncertain","cancelled"}:
            return False
        claimed = parse_dt(existing.get("claimed_at"))
        attempts = _safe_int(existing.get("attempts"))
        if status == "pending" and claimed and now - claimed < timedelta(minutes=30):
            return False
        if status=='pending' and existing.get('delivery_started_at'):
            existing.update(status='uncertain',updated_at=utc_iso(now))
            return False
        next_attempt = parse_dt(existing.get("next_attempt_at"))
        if status == "retry" and next_attempt and next_attempt > now:
            return False
        if attempts >= max(1, int(max_attempts)):
            existing["status"] = "dead_letter"
            existing["updated_at"] = utc_iso(now)
            return False
    reservation=None
    if payload.get('audience')=='user':
        from modules.contact_budget import reserve
        reservation=reserve(db,str(payload['user_id']),'crm:'+key)
        if not reservation:return False
    logs[key] = {
        **dict(existing or {}),
        **payload,
        "key": key,
        "operation_id": operation_id("crm:"+key),
        "status": "pending",
        "claimed_at": utc_iso(now),
        "attempts": _safe_int((existing or {}).get("attempts")) + 1,
        'budget_reservation':reservation,
        'claim_token':uuid4().hex,'delivery_started_at':None,
    }
    return True


def _quiet_hours_active(settings: dict[str, Any]) -> bool:
    if not settings.get("crm_quiet_hours_enabled", True):
        return False
    try:
        now = utc_now().astimezone(ZoneInfo(str(settings.get("crm_timezone") or "Asia/Tehran")))
    except Exception:
        now = utc_now()
    start = max(0, min(23, _safe_int(settings.get("crm_quiet_start_hour"), 23)))
    end = max(0, min(23, _safe_int(settings.get("crm_quiet_end_hour"), 8)))
    if start == end:
        return False
    return start <= now.hour < end if start < end else now.hour >= start or now.hour < end


def _daily_user_contacts(db: dict[str, Any], user_id: str) -> int:
    from modules.contact_budget import usage
    return usage(db,user_id)


def _welcome_contact_key(user_id: int | str) -> str:
    return f"crm_welcome:{str(user_id)}"


def _welcome_already_consumed(db: dict[str, Any], user_id: int | str) -> bool:
    """Return True once a welcome delivery has ever been claimed.

    Telegram does not provide an idempotency key for ``send_message``.  The
    durable one-shot marker is therefore committed *before* the network call.
    This gives welcome messages at-most-once delivery across worker restarts,
    concurrent schedulers, and failures while persisting the post-send result.

    Existing releases only stored ``welcome:<uid>`` in the generic CRM log.  Any
    legacy row is treated as consumed and backfilled into the dedicated contact
    log so users who were already spammed are stopped immediately after upgrade.
    """
    uid = str(user_id)
    contact_log = db.setdefault("automation_contact_log", {})
    marker_key = _welcome_contact_key(uid)
    marker = contact_log.get(marker_key)
    if isinstance(marker, dict):
        return True

    user = db.get("users", {}).get(uid, {})
    if isinstance(user, dict) and (user.get("welcome_sent_at") or user.get("welcome_claimed_at")):
        contact_log[marker_key] = {
            "kind": "crm_welcome",
            "user_id": uid,
            "status": "sent" if user.get("welcome_sent_at") else "claimed",
            "claimed_at": str(user.get("welcome_claimed_at") or user.get("welcome_sent_at") or utc_iso()),
            "sent_at": user.get("welcome_sent_at"),
            "source": "user_record_backfill",
        }
        return True

    legacy = db.get("crm_automation_log", {}).get(f"welcome:{uid}")
    if isinstance(legacy, dict):
        legacy_status = str(legacy.get("status") or "claimed")
        contact_log[marker_key] = {
            "kind": "crm_welcome",
            "user_id": uid,
            "status": "sent" if legacy_status == "sent" else "claimed",
            "claimed_at": str(legacy.get("claimed_at") or legacy.get("updated_at") or utc_iso()),
            "sent_at": legacy.get("updated_at") if legacy_status == "sent" else None,
            "source": "legacy_crm_log_backfill",
            "legacy_status": legacy_status,
        }
        return True
    return False


def _claim_welcome_once(db: dict[str, Any], user_id: int | str) -> bool:
    """Atomically reserve a welcome message for one and only one attempt."""
    uid = str(user_id)
    if _welcome_already_consumed(db, uid):
        return False
    now = utc_iso()
    db.setdefault("automation_contact_log", {})[_welcome_contact_key(uid)] = {
        "kind": "crm_welcome",
        "user_id": uid,
        "status": "claimed",
        "claimed_at": now,
        "attempts": 1,
        "automatic_retry": False,
        "delivery_mode": "first_entry_once",
    }
    user = db.get("users", {}).get(uid)
    if isinstance(user, dict):
        user["welcome_claimed_at"] = now
        user["welcome_status"] = "claimed"
        user["welcome_delivery_mode"] = "first_entry_once"
    return True


def claim_first_entry_welcome(
    db: dict[str, Any],
    user_id: int | str,
    *,
    is_new_user: bool,
) -> bool:
    """Reserve the welcome only for the first ever bot interaction.

    Welcome delivery used to be owned by the hourly CRM scheduler.  That made
    a persistence or retry defect visible as repeated greetings.  The first
    interaction guard now owns the delivery and commits the durable marker
    before Telegram is called.  Existing users are never re-welcomed during an
    upgrade, and failed sends are not retried by a background job.
    """
    uid = str(user_id)
    user = db.setdefault("users", {}).get(uid)
    if not isinstance(user, dict):
        return False

    now = utc_iso()
    user.setdefault("entered_bot_at", user.get("created_at") or now)
    user.setdefault("entry_user_id", uid)
    user["welcome_policy_version"] = 2

    if not is_new_user:
        # Users already present before this release are treated as already
        # onboarded.  This prevents one more greeting after deployment even if
        # an old database never managed to persist the legacy welcome marker.
        if not _welcome_already_consumed(db, uid):
            db.setdefault("automation_contact_log", {})[_welcome_contact_key(uid)] = {
                "kind": "crm_welcome",
                "user_id": uid,
                "status": "suppressed_existing_user",
                "claimed_at": now,
                "automatic_retry": False,
                "delivery_mode": "first_entry_once",
                "source": "v8.15.8_existing_user_guard",
            }
            user.setdefault("welcome_status", "suppressed_existing_user")
            user.setdefault("welcome_suppressed_at", now)
        return False

    from modules.management_suite import automation_settings

    settings = automation_settings(db)
    if not bool(settings.get("crm_welcome_enabled", True)):
        db.setdefault("automation_contact_log", {})[_welcome_contact_key(uid)] = {
            "kind": "crm_welcome",
            "user_id": uid,
            "status": "suppressed_disabled",
            "claimed_at": now,
            "automatic_retry": False,
            "delivery_mode": "first_entry_once",
            "source": "welcome_disabled_on_first_entry",
        }
        user["welcome_status"] = "suppressed_disabled"
        user["welcome_suppressed_at"] = now
        return False

    if not _claim_welcome_once(db, uid):
        return False

    event = {
        "type": "welcome",
        "user_id": uid,
        "audience": "user",
        "delivery_mode": "first_entry_once",
    }
    # Keep the existing CRM audit screen useful, but never let this log become
    # a retry source.  The contact marker above remains the source of truth.
    _claim_log(db, f"welcome:{uid}", event, max_attempts=1)
    return True


def claim_crm_automation_events(db: dict[str, Any], *, limit: int = 200) -> list[dict[str, Any]]:
    from modules.management_suite import automation_settings
    from modules.contact_budget import quiet

    settings = automation_settings(db)
    if not settings.get("enabled") or not settings.get("crm_enabled", True):
        return []
    refresh_all_crm_profiles(db,force=False,limit=int(settings.get('crm_max_batch',200)))

    now = utc_now()
    output: list[dict[str, Any]] = []
    limit = max(1, min(int(limit), _safe_int(settings.get("crm_max_batch"), 200), 1000))
    max_attempts = max(1, min(_safe_int(settings.get("crm_max_attempts"), 5), 10))
    daily_cap = max(1, min(_safe_int(settings.get("crm_daily_contact_cap"), 3), 20))
    users = db.get("users", {}) if isinstance(db.get("users", {}), dict) else {}
    profiles = db.get("crm_profiles", {}) if isinstance(db.get("crm_profiles", {}), dict) else {}

    for uid, user in users.items():
        if len(output) >= limit:
            break
        if not isinstance(user, dict):
            continue
        profile=db.get('crm_profiles',{}).get(str(uid),{})
        if not profile or str(uid) in db.get('crm_dirty_users',{}):continue
        user_contact_allowed = not quiet(db,uid) and _daily_user_contacts(db,str(uid))<daily_cap
        last_seen = parse_dt(user.get("last_seen_at") or user.get("created_at"))

        # Welcome is intentionally not scheduled here.  Since v8.15.8 it is
        # claimed and delivered once by the first-interaction guard.  Keeping it
        # out of the hourly CRM loop makes repeated welcome messages impossible
        # even if a scheduler is restarted or a legacy retry row remains.

        if (
            settings.get("crm_churn_risk_enabled", True)
            and not settings.get("inactive_enabled", False)
            and last_seen
        ):
            days = max(1, _safe_int(settings.get("crm_churn_risk_days"), 21))
            has_purchase = _safe_int(profile.get("vip_purchase_count")) > 0
            if has_purchase and now - last_seen >= timedelta(days=days):
                period = now.strftime("%Y-%m")
                key = f"churn:{uid}:{period}"
                event = {"type": "churn_risk", "user_id": str(uid), "audience": "user", "inactive_days": (now - last_seen).days}
                if user_contact_allowed and _claim_log(db, key, event, max_attempts=max_attempts):
                    output.append({"key": key, **event})

        score = _safe_int(profile.get("lead_score"))
        if settings.get("crm_lead_alert_enabled", True) and score >= _safe_int(settings.get("crm_lead_alert_threshold"), 70):
            period = now.strftime("%Y-%m-%d")
            key = f"hot_lead:{uid}:{period}"
            event = {
                "type": "hot_lead",
                "user_id": str(uid),
                "audience": "admin",
                "lead_score": score,
                "assigned_admin": str(profiles.get(str(uid), {}).get("assigned_admin") or ""),
            }
            if _claim_log(db, key, event, max_attempts=max_attempts):
                output.append({"key": key, **event})

        if settings.get("crm_high_value_enabled", True) and _safe_int(profile.get("total_spend")) >= _safe_int(settings.get("crm_high_value_threshold"), 5_000_000):
            key = f"high_value:{uid}"
            event = {
                "type": "high_value",
                "user_id": str(uid),
                "audience": "admin",
                "total_spend": _safe_int(profile.get("total_spend")),
                "assigned_admin": str(profiles.get(str(uid), {}).get("assigned_admin") or ""),
            }
            if _claim_log(db, key, event, max_attempts=max_attempts):
                output.append({"key": key, **event})

    if settings.get("crm_abandoned_checkout_enabled", True):
        hours = max(1, _safe_int(settings.get("crm_abandoned_checkout_hours"), 2))
        for order in db.get("vip_orders", []):
            if len(output) >= limit:
                break
            if not isinstance(order, dict) or str(order.get("status")) != "pending":
                continue
            created = parse_dt(order.get("created_at"))
            uid = str(order.get("user_id") or "")
            order_id = str(order.get("order_id") or order.get("id") or "")
            if not uid.isdigit() or not created or now - created < timedelta(hours=hours):
                continue
            key = f"abandoned_checkout:{order_id or uid}"
            event = {"type": "abandoned_checkout", "user_id": uid, "audience": "user", "order_id": order_id}
            if not quiet(db,uid) and _daily_user_contacts(db, uid) < daily_cap and _claim_log(
                db,
                key,
                event,
                max_attempts=max_attempts,
            ):
                output.append({"key": key, **event})

    return [{**item,'claim_token':db['crm_automation_log'][item['key']].get('claim_token')} for item in output[:limit]]


def mark_crm_automation_event(
    db: dict[str, Any],
    key: str,
    *,
    success: bool,
    detail: str = "",
    uncertain: bool = False,
    claim_token: str | None = None,
) -> dict[str, Any]:
    logs = db.setdefault("crm_automation_log", {})
    row = logs.setdefault(str(key), {})
    if claim_token is not None and row.get('claim_token')!=claim_token:
        raise ValueError('CRM_DELIVERY_LEASE_CHANGED')
    if row.get('status') in {'sent','cancelled'}:return row
    now = utc_now()
    is_welcome = str(row.get("type") or "") == "welcome" or str(key).startswith("welcome:")
    if uncertain:
        row.update(status='uncertain',updated_at=utc_iso(now),next_attempt_at=None,detail=str(detail)[:500])
        return row
    if success:
        status = "sent"
        next_attempt_at = None
    elif is_welcome:
        # A welcome claim is intentionally never retried automatically.  The
        # pre-send marker is the anti-spam guarantee even if Telegram delivery
        # or post-send persistence was ambiguous.
        status = "dead_letter"
        next_attempt_at = None
    else:
        from modules.management_suite import automation_settings

        settings = automation_settings(db)
        attempts = _safe_int(row.get("attempts"))
        maximum = max(1, min(_safe_int(settings.get("crm_max_attempts"), 5), 10))
        if attempts >= maximum:
            status = "dead_letter"
            next_attempt_at = None
        else:
            base = max(1, min(_safe_int(settings.get("crm_retry_base_minutes"), 5), 240))
            delay = min(12 * 60, base * (2 ** max(0, attempts - 1)))
            status = "retry"
            next_attempt_at = utc_iso(now + timedelta(minutes=delay))
    row.update(
        {
            "status": status,
            "updated_at": utc_iso(now),
            "next_attempt_at": next_attempt_at,
            "detail": str(detail or "")[:500],
        }
    )
    uid = str(row.get("user_id") or "")
    if row.get('audience')=='user':
        from modules.contact_budget import release
        release(db,row.get('budget_reservation'),'crm:'+str(key),sent=success,kind='crm')
    if is_welcome and uid:
        marker = db.setdefault("automation_contact_log", {}).setdefault(
            _welcome_contact_key(uid),
            {
                "kind": "crm_welcome",
                "user_id": uid,
                "claimed_at": row.get("claimed_at") or utc_iso(now),
                "automatic_retry": False,
            },
        )
        marker.update(
            {
                "status": "sent" if success else "failed_no_retry",
                "updated_at": utc_iso(now),
                "sent_at": utc_iso(now) if success else marker.get("sent_at"),
                "detail": str(detail or "")[:500],
            }
        )
        user = db.get("users", {}).get(uid)
        if isinstance(user, dict):
            if success:
                user["welcome_sent_at"] = utc_iso(now)
                user["welcome_status"] = "sent"
            else:
                user["welcome_failed_at"] = utc_iso(now)
                user["welcome_status"] = "failed_no_retry"
            user["welcome_delivery_mode"] = "first_entry_once"
    if uid:
        record_crm_activity(
            db,
            uid,
            "automation_sent" if success else "automation_failed",
            detail=f"{row.get('type')}: {detail}".strip(),
        )
    # Trim only terminal old logs, preserving active claims.
    if len(logs) > 10_000:
        active = {
            log_key: item
            for log_key, item in logs.items()
            if isinstance(item, dict) and str(item.get("status") or "") == "pending"
        }
        terminal = sorted(
            (
                (log_key, item)
                for log_key, item in logs.items()
                if isinstance(item, dict) and str(item.get("status") or "") != "pending"
            ),
            key=lambda pair: str(pair[1].get("updated_at") or pair[1].get("claimed_at") or ""),
            reverse=True,
        )
        remaining = max(0, 10_000 - len(active))
        db["crm_automation_log"] = {**active, **dict(terminal[:remaining])}
    return row


def authorize_crm_delivery(db,event):
    from modules.management_suite import automation_settings
    from modules.contact_budget import release,quiet
    row=db.get('crm_automation_log',{}).get(event['key'])
    if not row or row.get('status')!='pending' or row.get('claim_token')!=event.get('claim_token'):return False
    cfg=automation_settings(db)
    if (not cfg.get('enabled',True) and cfg.get('pause_mode')!='drain') or not cfg.get('crm_enabled',True):
        row.update(status='cancelled',updated_at=utc_iso())
        release(db,row.get('budget_reservation'),'crm:'+event['key'])
        return False
    if row.get('audience')=='user' and quiet(db,str(row.get('user_id'))):
        row.update(status='retry',next_attempt_at=utc_iso(utc_now()+timedelta(minutes=30)))
        release(db,row.get('budget_reservation'),'crm:'+event['key'])
        return False
    row['delivery_started_at']=utc_iso()
    return True


def crm_automation_log_rows(db: dict[str, Any], *, limit: int = 30) -> list[dict[str, Any]]:
    rows = [dict(row) for row in db.get("crm_automation_log", {}).values() if isinstance(row, dict)]
    rows.sort(key=lambda row: str(row.get("updated_at") or row.get("claimed_at") or ""), reverse=True)
    return rows[: max(1, min(int(limit), 200))]
