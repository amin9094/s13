from __future__ import annotations

from collections import defaultdict
from datetime import UTC, datetime
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from core.utils import parse_dt, utc_iso

SESSION_LABELS = {
    "asia": "آسیا",
    "london": "لندن",
    "overlap": "هم‌پوشانی لندن/نیویورک",
    "new_york": "نیویورک",
    "off_hours": "خارج از سشن اصلی",
}


def classify_market_session(value: Any = None, *, timezone: str = "UTC") -> str:
    when = parse_dt(value) if value else datetime.now(UTC)
    when = when or datetime.now(UTC)
    try:
        local = when.astimezone(ZoneInfo(timezone))
    except ZoneInfoNotFoundError:
        local = when.astimezone(UTC)
    hour = local.hour
    # Defaults are intentionally stable rather than DST-sensitive exchange
    # session clocks. Admins can choose the timezone that best matches their desk.
    if 0 <= hour < 7:
        return "asia"
    if 7 <= hour < 13:
        return "london"
    if 13 <= hour < 16:
        return "overlap"
    if 16 <= hour < 21:
        return "new_york"
    return "off_hours"


def attach_market_session(row: dict[str, Any], *, timezone: str = "UTC", at: Any = None) -> dict[str, Any]:
    session = classify_market_session(at or row.get("created_at"), timezone=timezone)
    row["market_session"] = session
    row["market_session_label"] = SESSION_LABELS[session]
    row["session_timezone"] = timezone
    row.setdefault("session_assigned_at", utc_iso())
    return row


def session_performance(db: dict[str, Any]) -> list[dict[str, Any]]:
    grouped: dict[str, dict[str, Any]] = defaultdict(
        lambda: {
            "session": "off_hours",
            "label": SESSION_LABELS["off_hours"],
            "total": 0,
            "closed": 0,
            "wins": 0,
            "losses": 0,
            "profit_percent": 0.0,
            "rr_sum": 0.0,
        }
    )
    final_statuses = {"target_complete", "manual_close", "no_entry", "stop", "cancelled", "expired"}
    for row in db.get("signals", []):
        if not isinstance(row, dict):
            continue
        session = str(row.get("market_session") or classify_market_session(row.get("created_at")))
        item = grouped[session]
        item["session"] = session
        item["label"] = SESSION_LABELS.get(session, session)
        item["total"] += 1
        status = str(row.get("status") or "open")
        highest = int(row.get("highest_target_hit", 0) or 0)
        closed = status in final_statuses or status.startswith("tp") or highest > 0
        won = status.startswith("tp") or highest > 0 or float(row.get("profit_percent", 0) or 0) > 0
        lost = status == "stop" or float(row.get("profit_percent", 0) or 0) < 0
        if closed:
            item["closed"] += 1
        if won:
            item["wins"] += 1
        if lost:
            item["losses"] += 1
        item["profit_percent"] += float(row.get("profit_percent", 0) or 0)
        item["rr_sum"] += float(row.get("rr", 0) or 0)
    output: list[dict[str, Any]] = []
    for session in ("asia", "london", "overlap", "new_york", "off_hours"):
        item = grouped[session]
        closed = max(1, int(item["closed"]))
        item["win_rate"] = float(item["wins"]) / closed * 100
        item["average_rr"] = float(item["rr_sum"]) / closed
        output.append(dict(item))
    return output
