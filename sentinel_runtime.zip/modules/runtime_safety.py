from __future__ import annotations

from typing import Any

from core.utils import utc_iso

VALID_MODES = {"production", "staging"}


def runtime_safety(db: dict[str, Any]) -> dict[str, Any]:
    row = db.setdefault("runtime_safety", {})
    if not isinstance(row, dict):
        row = {}
        db["runtime_safety"] = row
    row.setdefault("mode", "production")
    row.setdefault("disaster_mode", False)
    row.setdefault("read_only", False)
    row.setdefault("reason", "")
    row.setdefault("changed_at", None)
    row.setdefault("changed_by", "system")
    return row


def set_runtime_mode(
    db: dict[str, Any],
    *,
    mode: str | None = None,
    disaster_mode: bool | None = None,
    read_only: bool | None = None,
    reason: str = "",
    actor_id: int | str = "system",
) -> dict[str, Any]:
    row = runtime_safety(db)
    if mode is not None:
        normalized = str(mode).lower().strip()
        if normalized not in VALID_MODES:
            raise ValueError("حالت اجرا باید production یا staging باشد")
        row["mode"] = normalized
    if disaster_mode is not None:
        row["disaster_mode"] = bool(disaster_mode)
        if disaster_mode:
            row["read_only"] = True
    if read_only is not None and not row.get("disaster_mode"):
        row["read_only"] = bool(read_only)
    row["reason"] = str(reason or "")[:500]
    row["changed_at"] = utc_iso()
    row["changed_by"] = str(actor_id)
    return dict(row)


def publication_allowed(db: dict[str, Any]) -> tuple[bool, str]:
    row = runtime_safety(db)
    if row.get("disaster_mode"):
        return False, str(row.get("reason") or "حالت اضطراری فعال است")
    if row.get("read_only"):
        return False, str(row.get("reason") or "سامانه در حالت فقط‌خواندنی است")
    return True, ""


def destination_channels(
    db: dict[str, Any],
    destination: str,
    *,
    public_channel_id: int,
    private_channel_id: int,
    staging_public_channel_id: int = 0,
    staging_private_channel_id: int = 0,
) -> list[int]:
    row = runtime_safety(db)
    staging = str(row.get("mode") or "production") == "staging"
    public_id = staging_public_channel_id if staging else public_channel_id
    private_id = staging_private_channel_id if staging else private_channel_id
    if staging and not public_id and not private_id:
        return []
    channels: list[int] = []
    if destination in {"public", "both"} and public_id:
        channels.append(int(public_id))
    if destination in {"private", "both"} and private_id:
        channels.append(int(private_id))
    return list(dict.fromkeys(channels))
