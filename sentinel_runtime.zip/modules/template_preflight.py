"""Readability diagnostics never alter a price or the owner's selected color."""
from pathlib import Path
from PIL import Image,ImageStat


def warnings(layout,side,background=None):
    from modules.signal_image import _sentinel_template_path
    from modules.signal_template_editor import FIELD_LABELS,OUTPUT_TEMPLATE_HEIGHT
    path=Path(background) if background else _sentinel_template_path(side.upper())
    result=[]
    with Image.open(path) as source:
        image=source.convert('RGB')
        try:
            for key,row in layout['fields'].items():
                box=row['box'];text=row['color']
                rgb=tuple(int(text[i:i+2],16) for i in (1,3,5))
                sample=ImageStat.Stat(image.crop(tuple(box))).median if box[1]<OUTPUT_TEMPLATE_HEIGHT else (8,15,29)
                def lum(values):
                    values=[v/255 for v in values]
                    linear=[v/12.92 if v<=.04045 else ((v+.055)/1.055)**2.4 for v in values]
                    return .2126*linear[0]+.7152*linear[1]+.0722*linear[2]
                a,b=lum(rgb),lum(sample);contrast=(max(a,b)+.05)/(min(a,b)+.05)
                if contrast<3:result.append({'field':key,'label':FIELD_LABELS[key],'reason':'رنگ عدد روی پس‌زمینه خوانایی کمی دارد','contrast':round(contrast,2)})
                if box[2]-box[0]<170:result.append({'field':key,'label':FIELD_LABELS[key],'reason':'کادر باریک است؛ جا شدن قیمت باید در پیش‌نمایش بررسی شود'})
        finally:image.close()
    return result
