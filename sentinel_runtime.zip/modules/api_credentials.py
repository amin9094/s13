from __future__ import annotations

import os
import re
from collections.abc import Iterable


def clean_secret(value: str | None) -> str:
    """Normalize keys pasted as raw values, KEY=value, quoted strings, or query fragments."""
    text = str(value or "").strip().strip('"').strip("'").strip()
    if not text:
        return ""
    if "=" in text and not re.fullmatch(r"[A-Za-z0-9._\-]+", text):
        left, right = text.split("=", 1)
        if left.strip().casefold() in {
            "apikey", "api_key", "token", "key", "alpha_vantage_api_key", "alphavantage_api_key",
            "twelve_data_api_key", "twelvedata_api_key", "fred_api_key", "eia_api_key",
        }:
            text = right.strip()
    text = text.split("&", 1)[0].strip().strip('"').strip("'")
    return text


def env_secret(*names: str) -> str:
    for name in names:
        value = clean_secret(os.getenv(name))
        if value:
            return value
    return ""


def configured_secret(names: Iterable[str]) -> bool:
    return bool(env_secret(*tuple(names)))


def alpha_vantage_key() -> str:
    return env_secret("ALPHA_VANTAGE_API_KEY", "ALPHAVANTAGE_API_KEY", "ALPHA_VANTAGE_KEY")


def twelve_data_key() -> str:
    return env_secret("TWELVE_DATA_API_KEY", "TWELVEDATA_API_KEY", "TWELVE_API_KEY")


def fred_key() -> str:
    return env_secret("FRED_API_KEY", "FRED_KEY")


def eia_key() -> str:
    return env_secret("EIA_API_KEY", "EIA_KEY")


def sec_user_agent() -> str:
    return str(os.getenv("SEC_USER_AGENT") or os.getenv("SEC_CONTACT") or "").strip()
