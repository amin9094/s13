"""One durable local-day contact budget, mutated inside core.db transactions."""
from datetime import timedelta
from zoneinfo import ZoneInfo
from core.utils import utc_iso,utc_now,parse_dt


def local_now(db,uid):
    from modules.management_suite import automation_settings
    zone=db.get('users',{}).get(str(uid),{}).get('timezone') or automation_settings(db).get('crm_timezone') or 'Asia/Tehran'
    try:return utc_now().astimezone(ZoneInfo(str(zone)))
    except (ValueError,KeyError):return utc_now()


def quiet(db,uid):
    from modules.management_suite import automation_settings
    cfg=automation_settings(db)
    if not cfg.get('crm_quiet_hours_enabled',True):return False
    def hour(key,default):
        v=cfg.get(key);return max(0,min(23,int(default if v is None else v)))
    start,end=hour('crm_quiet_start_hour',23),hour('crm_quiet_end_hour',8)
    h=local_now(db,uid).hour
    return False if start==end else start<=h<end if start<end else h>=start or h<end


def key(db,uid):return f'{local_now(db,uid).date().isoformat()}:{uid}'


def budget(db,uid):
    """Bootstrap old sent contacts once, avoiding a quota reset on upgrade."""
    k=key(db,uid);row=db.setdefault('automation_contact_log',{}).setdefault(k,{'count':0,'recipient_id':str(uid),'kinds':{}})
    if not row.get('shared_budget_version'):
        day=local_now(db,uid).date()
        legacy=0
        for item in db.get('crm_automation_log',{}).values():
            if item.get('status')!='sent' or item.get('audience')!='user' or str(item.get('user_id'))!=str(uid):continue
            stamp=parse_dt(item.get('updated_at') or item.get('claimed_at'))
            if stamp and stamp.astimezone(local_now(db,uid).tzinfo).date()==day:legacy+=1
        row['count']=int(row.get('count',0))+legacy
        row['shared_budget_version']=1
    row.setdefault('reservations',{})
    return k,row


def usage(db,uid):
    _,row=budget(db,uid)
    return int(row.get('count',0))+len(row['reservations'])


def reserve(db,uid,operation):
    from modules.management_suite import automation_settings
    k,row=budget(db,uid)
    if operation in row['reservations']:return k
    cap=max(1,min(20,int(automation_settings(db).get('crm_daily_contact_cap',3))))
    if usage(db,uid)>=cap:return None
    row['reservations'][operation]={'reserved_at':utc_iso()}
    row['updated_at']=utc_iso()
    return k


def release(db,reservation,operation,*,sent=False,kind='automation'):
    row=db.setdefault('automation_contact_log',{}).get(reservation,{})
    if operation not in row.get('reservations',{}):return False
    del row['reservations'][operation]
    if sent:
        row['count']=int(row.get('count',0))+1
        kinds=row.setdefault('kinds',{});kinds[kind]=int(kinds.get(kind,0))+1
    row['updated_at']=utc_iso()
    return True
