from __future__ import annotations

from collections import Counter, defaultdict
from datetime import UTC, datetime, timedelta
from typing import Any

from core.utils import parse_dt, utc_iso
from modules.market_scope import signal_market_category
from modules.outcome_engine import (
    NEUTRAL_OUTCOMES,
    OUTCOME_BREAKEVEN,
    OUTCOME_FULL_WIN,
    OUTCOME_LOSS,
    OUTCOME_PARTIAL_WIN,
    SETTLED_OUTCOMES,
    apply_signal_outcome,
    calculate_signal_outcome,
)


def _period_start(days: int | None) -> datetime | None:
    if not days:
        return None
    return datetime.now(UTC) - timedelta(days=max(1, int(days)))


def _max_drawdown(values: list[float]) -> float:
    equity = 0.0
    peak = 0.0
    drawdown = 0.0
    for value in values:
        equity += value
        peak = max(peak, equity)
        drawdown = max(drawdown, peak - equity)
    return round(drawdown, 6)


def _metric_block(rows: list[dict[str, Any]]) -> dict[str, Any]:
    outcomes = [calculate_signal_outcome(row) for row in rows]
    settled = [item for item in outcomes if item.bucket in SETTLED_OUTCOMES]
    neutral = [item for item in outcomes if item.bucket in NEUTRAL_OUTCOMES]
    wins = [item for item in settled if item.bucket in {OUTCOME_FULL_WIN, OUTCOME_PARTIAL_WIN}]
    losses = [item for item in settled if item.bucket == OUTCOME_LOSS]
    breakeven = [item for item in settled if item.bucket == OUTCOME_BREAKEVEN]
    net_values = [item.net_r for item in settled]
    gross_profit = sum(max(0.0, value) for value in net_values)
    gross_loss = abs(sum(min(0.0, value) for value in net_values))
    return {
        "signals": len(rows),
        "settled": len(settled),
        "active": sum(1 for item in outcomes if not item.final),
        "full_wins": sum(1 for item in wins if item.bucket == OUTCOME_FULL_WIN),
        "partial_wins": sum(1 for item in wins if item.bucket == OUTCOME_PARTIAL_WIN),
        "wins": len(wins),
        "losses": len(losses),
        "breakeven": len(breakeven),
        "neutral": len(neutral),
        "win_rate": round(len(wins) / max(1, len(wins) + len(losses)) * 100, 4),
        "net_r": round(sum(net_values), 6),
        "average_r": round(sum(net_values) / max(1, len(net_values)), 6),
        "expectancy_r": round(sum(net_values) / max(1, len(settled)), 6),
        "profit_factor": round(gross_profit / gross_loss, 6) if gross_loss else (None if not gross_profit else 999.0),
        "maximum_drawdown_r": _max_drawdown(net_values),
        "sample_size": len(settled),
    }


def build_trust_snapshot(db: dict[str, Any], *, days: int | None = None) -> dict[str, Any]:
    start = _period_start(days)
    signals: list[dict[str, Any]] = []
    for row in db.get("signals", []):
        if not isinstance(row, dict):
            continue
        created_at = parse_dt(row.get("created_at"))
        if start and created_at and created_at < start:
            continue
        signals.append(row)

    for row in signals:
        apply_signal_outcome(row)

    overall = _metric_block(signals)
    by_market_rows: dict[str, list[dict[str, Any]]] = defaultdict(list)
    by_analyst_rows: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in signals:
        by_market_rows[signal_market_category(row)].append(row)
        by_analyst_rows[str(row.get("admin_id") or "unknown")].append(row)

    risks = [
        float(row.get("risk", 0) or 0)
        for row in signals
        if float(row.get("risk", 0) or 0) > 0
    ]
    revisions = db.get("signal_revisions", [])
    revision_count = len(revisions) if isinstance(revisions, list) else 0
    edited_signal_ids = {
        str(row.get("signal_id"))
        for row in revisions
        if isinstance(row, dict) and int(row.get("revision", 1) or 1) > 1
    }
    if not edited_signal_ids:
        edited_signal_ids = {
            str(row.get("id"))
            for row in signals
            if int(row.get("revision", 1) or 1) > 1
        }

    outcome_counts = Counter(str(row.get("outcome_bucket") or "open") for row in signals)
    return {
        "generated_at": utc_iso(),
        "period_days": days,
        **overall,
        # Compatibility fields used by existing Telegram and Mini App views.
        "total_signals": overall["signals"],
        "closed_signals": overall["settled"] + overall["neutral"],
        "active_signals": overall["active"],
        "stops": overall["losses"],
        "average_risk": round(sum(risks) / max(1, len(risks)), 6),
        "average_rr": overall["average_r"],
        "edited_signals": len(edited_signal_ids),
        "revision_count": revision_count,
        "outcomes": dict(outcome_counts),
        "markets": {key: len(value) for key, value in by_market_rows.items()},
        "by_market": {key: _metric_block(value) for key, value in by_market_rows.items()},
        "by_analyst": {key: _metric_block(value) for key, value in by_analyst_rows.items()},
        "methodology": (
            "نتیجه‌ها با موتور واحد Outcome Engine محاسبه می‌شوند. برد کامل، برد جزئی، "
            "سربه‌سر و باخت بر پایه R خالص پس از کارمزد و لغزش تفکیک می‌شوند. "
            "لغو، بدون ورود و انقضا در وین‌ریت وارد نمی‌شوند."
        ),
        "disclaimer": (
            "عملکرد گذشته تضمین‌کننده نتایج آینده نیست. آمار فقط بر اساس سیگنال‌های "
            "ثبت‌شده و نتیجه‌های قابل ممیزی نمایش داده می‌شود."
        ),
    }


def refresh_trust_center(db: dict[str, Any]) -> dict[str, Any]:
    root = db.setdefault("trust_center", {"enabled": True, "history": []})
    snapshot = build_trust_snapshot(db)
    root["latest"] = snapshot
    root.setdefault("history", []).append(snapshot)
    root["history"] = root["history"][-365:]
    root["periods"] = {
        "30d": build_trust_snapshot(db, days=30),
        "90d": build_trust_snapshot(db, days=90),
        "all": snapshot,
    }
    return snapshot

