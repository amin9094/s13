from modules.signal_targets import TARGET_KEYS
"""Read-only conditional scenarios from locked pending plans, never new signals."""
from decimal import Decimal, InvalidOperation

from modules.signal_execution import mode_of


def describe(plan):
    if mode_of(plan)=='MARKET':return None
    try:
        entry,stop,target=(Decimal(str(plan[k])) for k in ('entry','stop','tp1'))
        if not all(x.is_finite() and x>0 for x in (entry,stop,target)):return None
        sign=Decimal(1) if plan['direction']=='BUY' else Decimal(-1) if plan['direction']=='SELL' else Decimal(0)
        if sign*(entry-stop)<=0 or sign*(target-entry)<=0:return None
        return {'kind':'CONDITIONAL_PRICE_SCENARIO','execution_mode':'PENDING',
                'approach':'BREAKOUT' if plan.get('submodel')=='range_breakout' else 'RETURN_TO_ZONE',
                'direction':plan['direction'],'entry':plan['entry'],'stop':plan['stop'],
                'targets':{k:plan[k] for k in TARGET_KEYS if plan.get(k) is not None},
                'zone':{'low':plan['zone_low'],'high':plan['zone_high']},
                'eta_ms':None,'is_guaranteed':False,'creates_additional_trade':False}
    except (InvalidOperation,KeyError,TypeError,ValueError):return None


def lines(plan):
    s=describe(plan)
    if s is None:return []
    direction='صعودی' if s['direction']=='BUY' else 'نزولی'
    action='ادامهٔ' if s['approach']=='BREAKOUT' else 'برگشت'
    return [f"پیش‌بینی شرطی: رسیدن به ورود {s['entry']}؛ سپس {action} {direction} به‌سوی TP1 {s['targets']['tp1']}.",
            'این سناریوی ثبت‌شده است؛ زمان رسیدن قیمت تعیین نشده است.']
