from __future__ import annotations

from typing import Any


def build_google_sheets_monitor(
    status: dict[str, Any] | None,
    observability: dict[str, Any] | None,
    *,
    normalized_pending: int = 0,
) -> dict[str, Any]:
    status = dict(status or {})
    obs = dict(observability or {})
    jobs = dict(obs.get("jobs") or {})
    sync_job = dict(jobs.get("google_sheets_secondary") or {})
    snapshot_job = dict(jobs.get("google_sheets_full_snapshot") or {})
    configured = bool(status.get("configured"))
    enabled = bool(status.get("enabled"))
    legacy_pending = len(status.get("pending_sections") or [])
    total_pending = legacy_pending + max(0, int(normalized_pending or 0))
    failover = bool(status.get("failover_active"))
    attestation = dict(status.get("attestation") or {})
    attestation_state = str(attestation.get("status") or "unknown")
    job_state = str(sync_job.get("status") or "unknown")
    snapshot_state = str(snapshot_job.get("status") or "unknown")
    error = str(
        status.get("error")
        or status.get("last_primary_error")
        or sync_job.get("last_error")
        or snapshot_job.get("last_error")
        or ""
    )
    if not enabled:
        health = "disabled"
    elif not configured:
        health = "offline"
    elif failover or attestation_state == "failed" or job_state in {"degraded", "failed"} or total_pending >= 20:
        health = "degraded"
    else:
        health = "healthy"
    return {
        "health": health,
        "enabled": enabled,
        "configured": configured,
        "service_account_email": str(status.get("service_account_email") or ""),
        "spreadsheet_id": str(status.get("spreadsheet_id") or ""),
        "legacy_pending": legacy_pending,
        "normalized_pending": max(0, int(normalized_pending or 0)),
        "total_pending": total_pending,
        "failover_active": failover,
        "failover_started_at": status.get("failover_started_at"),
        "attestation": {
            "status": attestation_state,
            "verified_at": attestation.get("verified_at"),
            "error": str(attestation.get("error") or "")[:500],
        },
        "last_primary_error": str(status.get("last_primary_error") or ""),
        "sync": {
            "status": job_state,
            "last_success_at": sync_job.get("last_success_at"),
            "last_failure_at": sync_job.get("last_failure_at"),
            "consecutive_failures": int(sync_job.get("consecutive_failures", 0) or 0),
            "duration_seconds": float(sync_job.get("duration_seconds", 0) or 0),
        },
        "snapshot": {
            "status": snapshot_state,
            "last_success_at": snapshot_job.get("last_success_at"),
            "last_failure_at": snapshot_job.get("last_failure_at"),
            "consecutive_failures": int(snapshot_job.get("consecutive_failures", 0) or 0),
            "duration_seconds": float(snapshot_job.get("duration_seconds", 0) or 0),
        },
        "error": error[:500],
    }
