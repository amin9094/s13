"""Direct permission buttons over current RBAC, with bounded page size."""

from hashlib import sha256

from modules.admin_access import ALL_PERMISSIONS, OWNER_ONLY_PERMISSIONS

PAGE_SIZE = 30
PERMISSIONS = tuple(permission for permission in ALL_PERMISSIONS if permission not in OWNER_ONLY_PERMISSIONS)
TOKEN_TO_PERMISSION = {sha256(permission.encode()).hexdigest()[:8]: permission for permission in PERMISSIONS}
if len(TOKEN_TO_PERMISSION) != len(PERMISSIONS):
    raise RuntimeError("permission token collision")


def permission_token(permission):
    return sha256(permission.encode()).hexdigest()[:8]


def permission_page(permission):
    return PERMISSIONS.index(permission) // PAGE_SIZE if permission in PERMISSIONS else 0


def clamp_permission_page(page):
    return min(max(0, int(page)), max(0, (len(PERMISSIONS) - 1) // PAGE_SIZE))
