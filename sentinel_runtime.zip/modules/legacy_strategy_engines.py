"""Four isolated analysis engines. Research parameters are NOT numbered user approvals.

The default parameter profile has no out-of-sample release evidence. Engines
return reproducible research candidates, never production-qualified signals.
Base Fibonacci's missing exact-entry selector remains explicitly gated.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from decimal import Decimal as D
from hashlib import sha256

from modules.canonical_market import ANALYSIS_TIMEFRAMES, Candle, TIMEFRAMES, validate_series
from modules.fibonacci_geometry import FVG_RETRACEMENT, OB_RETRACEMENT, golden_extension_band
from modules.setup_lifecycle import SetupPlan
from repositories.v2.common import json_dump


@dataclass(frozen=True)
class Parameters:
    profile_id: str = "research-2-session-fib-tp1-usdt-NOT-PRODUCTION-VALIDATED"
    swing_left: int = 2
    swing_right: int = 2
    adx_trend: D = D(25)
    adx_range: D = D(20)
    displacement_atr: D = D("0.8")
    min_fvg_atr: D = D(".05")
    spread_gap_multiple: D = D(2)
    sweep_atr: D = D(".05")
    stop_buffer_atr: D = D(".1")
    volume_ratio: D = D("1.2")
    compact_cluster_atr: D = D(".1")


@dataclass(frozen=True)
class Swing:
    index: int
    kind: str
    value: D
    available_ms: int


@dataclass(frozen=True)
class Context:
    candles: tuple[Candle, ...]
    cutoff_ms: int
    tick_size: D
    spread: D
    parameters: Parameters = Parameters()
    value_factors: tuple[dict, ...] = ()
    ob_departure_proofs: tuple[dict, ...] = ()

    @property
    def closed(self):
        return [bar for bar in self.candles if bar.is_closed and bar.available_ms <= self.cutoff_ms]

    def validate(self):
        bars = list(self.candles)
        if not bars or bars[0].timeframe not in ANALYSIS_TIMEFRAMES:
            raise ValueError("ANALYSIS_TIMEFRAME_UNAPPROVED")
        validate_series(bars, now_ms=self.cutoff_ms)
        if any(bar.quality_flags for bar in bars):
            raise ValueError("MARKET_QUALITY_GATE_FAILED")
        if self.tick_size <= 0 or self.spread < 0:
            raise ValueError("MARKET_PRECISION_OR_SPREAD_INVALID")
        if len(self.closed) < 105:
            raise ValueError("INDICATOR_WARMUP_INCOMPLETE")
        # No synthetic filling across gaps. Session-aware source completeness
        # requires a separate verified calendar; currently fail closed.
        if any(b.start_ms != a.end_ms for a, b in zip(bars, bars[1:])):
            raise ValueError("HISTORICAL_COVERAGE_GAP_NEEDS_REVIEW")
        if self.cutoff_ms - bars[-1].start_ms > TIMEFRAMES[bars[-1].timeframe] * 2:
            raise ValueError("MARKET_DATA_STALE_OR_SESSION_CLOSED")


def confirmed_swings(bars, parameters):
    result = []
    left = parameters.swing_left
    right = parameters.swing_right
    for i in range(left, len(bars) - right):
        neighborhood = bars[i - left : i + right + 1]
        available = max(bar.available_ms for bar in bars[i : i + right + 1])
        if all(bars[i].high > bar.high for j, bar in enumerate(neighborhood) if j != left):
            result.append(Swing(i, "high", bars[i].high, available))
        if all(bars[i].low < bar.low for j, bar in enumerate(neighborhood) if j != left):
            result.append(Swing(i, "low", bars[i].low, available))
    return result


def ema(values, period):
    alpha = D(2) / D(period + 1)
    result = []
    value = values[0]
    for sample in values:
        value = alpha * sample + (1 - alpha) * value
        result.append(value)
    return result


def wilder(values, period):
    if len(values) < period:
        return []
    average = sum(values[:period]) / D(period)
    result = [None] * (period - 1) + [average]
    for value in values[period:]:
        average = (average * (period - 1) + value) / D(period)
        result.append(average)
    return result


def indicators(bars):
    closes = [bar.close for bar in bars]
    ma = {n: ema(closes, n) for n in (20, 50, 100)}
    gains = [D(0)] + [max(D(0), b - a) for a, b in zip(closes, closes[1:])]
    losses = [D(0)] + [max(D(0), a - b) for a, b in zip(closes, closes[1:])]
    avg_g = wilder(gains, 14)
    avg_l = wilder(losses, 14)
    rsi = [
        None
        if gain is None
        else D(50)
        if gain == loss == 0
        else D(100)
        if loss == 0
        else D(100) - D(100) / (1 + gain / loss)
        for gain, loss in zip(avg_g, avg_l)
    ]
    fast = ema(closes, 12)
    slow = ema(closes, 26)
    macd = [a - b for a, b in zip(fast, slow)]
    signal = ema(macd, 9)
    hist = [a - b for a, b in zip(macd, signal)]
    tr = [bars[0].high - bars[0].low]
    plus = [D(0)]
    minus = [D(0)]
    for a, b in zip(bars, bars[1:]):
        tr.append(max(b.high - b.low, abs(b.high - a.close), abs(b.low - a.close)))
        up = b.high - a.high
        down = a.low - b.low
        plus.append(up if up > down and up > 0 else D(0))
        minus.append(down if down > up and down > 0 else D(0))
    atr = wilder(tr, 14)
    pdm = wilder(plus, 14)
    mdm = wilder(minus, 14)
    dx = []
    for p, m, vol in zip(pdm, mdm, atr):
        if p is None or vol is None:
            continue
        dx.append(D(0) if p + m == 0 else D(100) * abs(p - m) / (p + m))
    adx = wilder(dx, 14)
    return {"ma": ma, "rsi": rsi, "macd_hist": hist, "atr": atr[-1] or D(0), "adx": adx[-1] if adx else D(0)}


def freshness(context, zone_low, zone_high, *, after_ms):
    bars = [bar for bar in context.candles if bar.start_ms >= after_ms]
    if not bars:
        return {"untouched": False, "complete_coverage": False, "reason": "CURRENT_ZONE_COVERAGE_MISSING"}
    touched = any(bar.low <= zone_high and bar.high >= zone_low for bar in bars)
    return {
        "untouched": not touched,
        "complete_coverage": True,
        "observed_through_ms": context.cutoff_ms,
        "after_ms": after_ms,
        "bar_ids": [bar.source_id for bar in bars],
    }


def _targets(swings, entry, stop, direction):
    sign = D(1) if direction == "BUY" else D(-1)
    values = sorted({s.value for s in swings if sign * (s.value - entry) > 0}, reverse=direction == "SELL")
    if len(values) < 2:
        return None
    first = values[0]
    if entry == stop or abs(first - entry) / abs(entry - stop) < 2:
        # A closer genuine objective is an obstacle, not a level to silently
        # skip so a further price can be advertised as TP1 at an attractive RR.
        return None
    second = values[1]
    third = values[2] if len(values) > 2 else None
    return first, second, third


def _candidate(context, engine, submodel, direction, zone, entry, stop, swings, thesis, facts, *, fresh_after):
    low, high = zone
    fresh = freshness(context, low, high, after_ms=fresh_after)
    if not fresh.get("untouched") or not fresh.get("complete_coverage"):
        return {"engine": engine, "submodel": submodel, "state": "REJECTED", "reason": "ORIGINAL_FULL_ZONE_NOT_FRESH"}
    targets = _targets(swings, entry, stop, direction)
    if targets is None:
        return {"engine": engine, "submodel": submodel, "state": "REJECTED", "reason": "NO_REAL_STRUCTURAL_TP1_AT_2R"}
    last = context.candles[-1]
    thesis_key = sha256(json_dump({"identity": thesis, "direction": direction}).encode()).hexdigest()
    setup_id = sha256(f"{engine}:{last.symbol}:{last.timeframe}:{thesis_key}".encode()).hexdigest()[:32]
    evidence = tuple({"kind": kind, "available_ms": available, "detail": detail} for kind, available, detail in facts)
    try:
        plan = SetupPlan(
            setup_id,
            thesis_key,
            engine,
            submodel,
            last.symbol,
            last.timeframe,
            direction,
            last.provider,
            last.venue,
            last.product,
            context.cutoff_ms,
            low,
            high,
            entry,
            stop,
            *targets,
            context.tick_size,
            tuple(bar.source_id for bar in context.candles),
            evidence,
        )
    except (ValueError, ArithmeticError) as exc:
        return {"engine": engine, "submodel": submodel, "state": "REJECTED", "reason": str(exc)}
    return {
        "engine": engine,
        "submodel": submodel,
        "state": "RESEARCH_CANDIDATE",
        "reason": "PARAMETER_PROFILE_REQUIRES_OOS_VALIDATION",
        "profile_id": context.parameters.profile_id,
        "plan": plan.as_dict(),
        "freshness_proof": fresh,
    }


class IndicatorsOnly:
    name = "indicators"

    def evaluate(self, context):
        bars = context.closed
        p = context.parameters
        stats = indicators(bars)
        swings = confirmed_swings(bars, p)
        if len(swings) < 4 or stats["atr"] <= 0:
            return []
        output = []
        atr = stats["atr"]
        last = bars[-1]
        ma = stats["ma"]
        rsi = stats["rsi"]
        hist = stats["macd_hist"]
        for direction, sign, kind in [("BUY", D(1), "low"), ("SELL", D(-1), "high")]:
            protected = [s for s in swings if s.kind == kind]
            if len(protected) < 2:
                continue
            a, b = protected[-2:]
            opposites = [s for s in swings if s.kind != kind]
            if not opposites:
                continue
            anchor = opposites[-1]
            stop = b.value - sign * max(context.spread * 2, atr * p.stop_buffer_atr)
            trend = sign * (ma[20][-1] - ma[50][-1]) > 0 and sign * (ma[50][-1] - ma[100][-1]) > 0
            trend = trend and sign * (ma[20][-1] - ma[20][-4]) > 0 and stats["adx"] >= p.adx_trend
            if trend and sign * hist[-1] > 0:
                entry = (ma[20][-1] / context.tick_size).to_integral_value() * context.tick_size
                zone = (entry - atr * D(".05"), entry + atr * D(".05"))
                output.append(
                    _candidate(
                        context,
                        self.name,
                        "trend_continuation",
                        direction,
                        zone,
                        entry,
                        stop,
                        swings,
                        ["trend", b.index, anchor.index],
                        [("trend_regime", last.available_ms, "MA geometry + one momentum group")],
                        fresh_after=last.end_ms,
                    )
                )
            divergence = (
                rsi[a.index] is not None
                and rsi[b.index] is not None
                and sign * (b.value - a.value) < 0
                and sign * (rsi[b.index] - rsi[a.index]) > 0
            )
            weakening = sign * (hist[-1] - hist[-3]) > 0
            if divergence and weakening:
                entry = b.value
                zone = (entry - atr * D(".05"), entry + atr * D(".05"))
                output.append(
                    _candidate(
                        context,
                        self.name,
                        "early_reversal",
                        direction,
                        zone,
                        entry,
                        stop,
                        swings,
                        ["reversal", a.index, b.index],
                        [("regular_rsi_divergence", b.available_ms, {"first": a.index, "second": b.index})],
                        fresh_after=bars[b.index + p.swing_right].end_ms,
                    )
                )
            if stats["adx"] <= p.adx_range:
                lows = [s for s in swings if s.kind == "low"]
                highs = [s for s in swings if s.kind == "high"]
                if len(lows) < 2 or len(highs) < 2:
                    continue
                edge_low = max(s.value for s in lows[-2:])
                edge_high = min(s.value for s in highs[-2:])
                if edge_high <= edge_low:
                    continue
                boundary = edge_low if direction == "BUY" else edge_high
                stop = boundary - sign * max(context.spread * 2, atr * p.stop_buffer_atr)
                zone = (boundary - atr * D(".05"), boundary + atr * D(".05"))
                output.append(
                    _candidate(
                        context,
                        self.name,
                        "range_reversal",
                        direction,
                        zone,
                        boundary,
                        stop,
                        swings,
                        ["range_reversal", lows[-1].index, highs[-1].index],
                        [("range_regime", last.available_ms, "Confirmed boundaries, ADX")],
                        fresh_after=last.end_ms,
                    )
                )
                if sign * hist[-1] > 0:
                    entry = (edge_high + context.tick_size) if direction == "BUY" else (edge_low - context.tick_size)
                    stop = (
                        (edge_high - atr * p.stop_buffer_atr)
                        if direction == "BUY"
                        else (edge_low + atr * p.stop_buffer_atr)
                    )
                    zone = (entry - context.tick_size, entry + context.tick_size)
                    output.append(
                        _candidate(
                            context,
                            self.name,
                            "range_breakout",
                            direction,
                            zone,
                            entry,
                            stop,
                            swings,
                            ["range_breakout", lows[-1].index, highs[-1].index],
                            [("prospective_range_breakout", last.available_ms, "Breakout not assumed completed")],
                            fresh_after=last.end_ms,
                        )
                    )
        return output


class SweepCHoCHFVG:
    name = "sweep_fvg"

    def evaluate(self, context):
        bars = context.closed
        p = context.parameters
        swings = confirmed_swings(bars, p)
        atr = indicators(bars)["atr"]
        if atr <= 0:
            return []
        output = []
        used = set()
        for sweep_index in range(p.swing_left + p.swing_right, len(bars) - 3):
            sweep = bars[sweep_index]
            known = [s for s in swings if s.index + p.swing_right < sweep_index]
            for direction, sign, poolkind in [("BUY", D(1), "low"), ("SELL", D(-1), "high")]:
                pools = [s for s in known if s.kind == poolkind]
                protected = [s for s in known if s.kind != poolkind]
                if not pools or not protected:
                    continue
                pool = pools[-1]
                structure = protected[-1]
                extreme = sweep.low if direction == "BUY" else sweep.high
                if sign * (pool.value - extreme) < max(atr * p.sweep_atr, context.spread * 2):
                    continue
                # Reclaim must occur in a closed candle; enduring break without reclaim fails.
                if sign * (sweep.close - pool.value) <= 0:
                    continue
                choch = next(
                    (j for j in range(sweep_index + 1, len(bars)) if sign * (bars[j].close - structure.value) > 0), None
                )
                if choch is None:
                    continue
                identity = (direction, pool.index, structure.index, choch)
                if identity in used:
                    continue
                used.add(identity)
                failures = []
                for third in range(sweep_index + 2, len(bars)):
                    a, m, b = bars[third - 2 : third + 1]
                    zone = (a.high, b.low) if direction == "BUY" else (b.high, a.low)
                    if zone[1] <= zone[0]:
                        continue
                    if sign * (m.close - m.open) <= 0 or abs(m.close - m.open) < atr * p.displacement_atr:
                        failures.append({"index": third, "reason": "RELATED_DISPLACEMENT_INSUFFICIENT"})
                        continue
                    if zone[1] - zone[0] < max(atr * p.min_fvg_atr, context.spread * p.spread_gap_multiple):
                        failures.append({"index": third, "reason": "FVG_BELOW_ATR_SPREAD_QUALITY"})
                        continue
                    # FVG may precede CHoCH, but can only be proposed once CHoCH is actually closed.
                    low_extremes = [s.value for s in known if s.kind == poolkind]
                    invalidation = (
                        min([extreme, *low_extremes[-1:]]) if direction == "BUY" else max([extreme, *low_extremes[-1:]])
                    )
                    stop = invalidation - sign * max(context.spread * 2, atr * p.stop_buffer_atr)
                    candidate = _candidate(
                        context,
                        self.name,
                        "liquidity_reversal",
                        direction,
                        zone,
                        sum(zone) / 2,
                        stop,
                        swings,
                        list(identity),
                        [
                            (
                                "sweep_reclaim",
                                sweep.available_ms,
                                {"pool_index": pool.index, "sweep_index": sweep_index},
                            ),
                            (
                                "closed_choch",
                                bars[choch].available_ms,
                                {"index": choch, "protected_index": structure.index},
                            ),
                            ("fvg_third_close", b.available_ms, {"index": third, "prior_failures": failures}),
                        ],
                        fresh_after=b.end_ms,
                    )
                    if candidate["state"] == "RESEARCH_CANDIDATE":
                        output.append(candidate)
                        break  # first chronological actually valid FVG
                    failures.append({"index": third, "reason": candidate["reason"]})
        return output


class OrderBlockVolume:
    name = "order_block"

    def evaluate(self, context):
        bars = context.closed
        p = context.parameters
        swings = confirmed_swings(bars, p)
        atr = indicators(bars)["atr"]
        output = []
        for i in range(20, len(bars) - 2):
            ob = bars[i]
            departure = bars[i + 1]
            direction = "BUY" if departure.close > departure.open else "SELL"
            sign = D(1) if direction == "BUY" else D(-1)
            if sign * (ob.close - ob.open) > 0:
                continue
            # Reject the whole consecutive-opposing formation, never select its last candle.
            if sign * (bars[i - 1].close - bars[i - 1].open) < 0:
                continue
            if sign * (departure.close - departure.open) < atr * p.displacement_atr:
                continue
            if sign * (departure.close - (ob.high if direction == "BUY" else ob.low)) <= 0:
                continue
            if (
                ob.volume_kind != "traded"
                or departure.volume_kind != "traded"
                or ob.volume is None
                or departure.volume is None
            ):
                output.append(
                    {"engine": self.name, "state": "REJECTED", "reason": "AUTHENTIC_VOLUME_UNAVAILABLE", "index": i}
                )
                continue
            comparison = [b.volume for b in bars[i - 20 : i] if b.volume is not None and b.volume_kind == "traded"]
            if len(comparison) != 20 or sum(comparison) <= 0:
                continue
            if departure.volume < sum(comparison) / 20 * p.volume_ratio:
                continue
            proof = next(
                (
                    proof
                    for proof in context.ob_departure_proofs
                    if proof.get("ob_source_id") == ob.source_id
                    and proof.get("fully_exited_ms")
                    and proof.get("no_reentry")
                    and proof.get("observed_through_ms", 0) >= context.cutoff_ms
                ),
                None,
            )
            if not proof:
                output.append(
                    {
                        "engine": self.name,
                        "state": "NEEDS_REVIEW",
                        "reason": "OB_DEPARTURE_AND_NEXT_WICK_ORDER_UNPROVEN",
                        "index": i,
                    }
                )
                continue
            entry = (ob.high + ob.low) / 2
            known = [s for s in swings if s.index + p.swing_right <= i + 1]
            protected = [s.value for s in known if s.kind == ("low" if direction == "BUY" else "high")]
            invalidation = min([ob.low, *protected[-1:]]) if direction == "BUY" else max([ob.high, *protected[-1:]])
            stop = invalidation - sign * max(context.spread * 2, atr * p.stop_buffer_atr)
            output.append(
                _candidate(
                    context,
                    self.name,
                    "single_opposing_candle",
                    direction,
                    (ob.low, ob.high),
                    entry,
                    stop,
                    swings,
                    ["ob_impulse", ob.source_id, departure.source_id],
                    [
                        ("ob_full_candle", ob.available_ms, {"index": i}),
                        ("locked_ob_displacement_volume_window", departure.available_ms, {"start": i, "end": i + 1}),
                        ("quote_departure_proof", context.cutoff_ms, proof),
                    ],
                    fresh_after=departure.end_ms,
                )
            )
        return output


class Fibonacci:
    name = "fibonacci"

    def evaluate(self, context):
        bars = context.closed
        p = context.parameters
        swings = confirmed_swings(bars, p)
        atr = indicators(bars)["atr"]
        output = [
            {
                "engine": self.name,
                "submodel": "base",
                "state": "SPECIFICATION_GAP",
                "reason": "BASE_ENTRY_SELECTOR_UNRESOLVED",
            }
        ]
        if len(swings) < 5 or atr <= 0:
            return output
        for direction, sign, first_kind in [("BUY", D(1), "low"), ("SELL", D(-1), "high")]:
            starts = [s for s in swings if s.kind == first_kind]
            if not starts:
                continue
            start = starts[-1]
            ends = [s for s in swings if s.kind != first_kind and s.index > start.index]
            if not ends:
                continue
            end = ends[-1]
            magnitude = abs(end.value - start.value)
            if magnitude <= atr:
                continue
            minors = [s for s in swings if start.index < s.index < end.index]
            if len(minors) < 3:
                output.append(
                    {
                        "engine": self.name,
                        "submodel": "advanced",
                        "state": "REJECTED",
                        "reason": "INDEPENDENT_MINOR_WAVE_MISSING",
                    }
                )
                continue
            a, b, c = minors[-3:]
            # Locked three-anchor projection; profile records the convention explicitly.
            try:
                projection_low, projection_high = golden_extension_band(
                    a.value, b.value, c=c.value, convention="three_anchor"
                )
            except ValueError:
                continue
            values = [
                row
                for row in context.value_factors
                if row.get("volume_kind") == "traded"
                and row.get("kind") in {"POC", "AVWAP"}
                and row.get("window_locked_ms", context.cutoff_ms + 1) <= context.cutoff_ms
                and row.get("available_ms", context.cutoff_ms + 1) <= context.cutoff_ms
            ]
            if not values:
                output.append(
                    {
                        "engine": self.name,
                        "submodel": "advanced",
                        "state": "REJECTED",
                        "reason": "AUTHENTIC_PRELOCKED_VALUE_UNAVAILABLE",
                    }
                )
                continue
            for ratio in (OB_RETRACEMENT, FVG_RETRACEMENT):
                retracement = end.value - sign * magnitude * ratio
                tolerance = max(context.tick_size, atr * p.compact_cluster_atr)
                if not projection_low - tolerance <= retracement <= projection_high + tolerance:
                    continue
                # Sources are ordered ex ante: authentic POC then AVWAP; disagreement rejects.
                ordered = sorted(
                    values, key=lambda row: (0 if row["kind"] == "POC" else 1, str(row.get("source_id", "")))
                )
                entry = D(str(ordered[0]["price"]))
                if any(abs(D(str(row["price"])) - entry) > tolerance for row in ordered):
                    continue
                if (
                    abs(entry - retracement) > tolerance
                    or not projection_low - tolerance <= entry <= projection_high + tolerance
                ):
                    continue
                for i in range(start.index + 2, len(bars)):
                    one, middle, three = bars[i - 2 : i + 1]
                    fvg = (one.high, three.low) if direction == "BUY" else (three.high, one.low)
                    if fvg[1] <= fvg[0] or not fvg[0] <= entry <= fvg[1]:
                        continue
                    if sign * (middle.close - middle.open) < atr * p.displacement_atr:
                        continue
                    # It must belong to the selected wave, not simply cross the same price later.
                    if not start.index < i <= end.index + p.swing_right:
                        continue
                    zone = (retracement - tolerance, retracement + tolerance)
                    if zone[1] - zone[0] > atr * p.compact_cluster_atr * 2:
                        continue
                    stop = start.value - sign * max(context.spread * 2, atr * p.stop_buffer_atr)
                    candidate = _candidate(
                        context,
                        self.name,
                        f"advanced_{ratio}",
                        direction,
                        zone,
                        entry,
                        stop,
                        swings,
                        ["main_wave", start.index, end.index],
                        [
                            ("locked_main_wave", end.available_ms, asdict(end)),
                            (
                                "minor_golden_161_to_168_three_anchor",
                                max(s.available_ms for s in (a, b, c)),
                                {
                                    "anchors": [a.index, b.index, c.index],
                                    "projection_low": str(projection_low),
                                    "projection_high": str(projection_high),
                                    "convention": "three_anchor",
                                    "is_win_probability": False,
                                },
                            ),
                            ("related_fvg", three.available_ms, {"third_index": i, "zone": [str(v) for v in fvg]}),
                            ("prelocked_value", ordered[0]["available_ms"], ordered[0]),
                        ],
                        fresh_after=max(three.end_ms, bars[end.index + p.swing_right].end_ms),
                    )
                    output.append(candidate)
                    if candidate["state"] == "RESEARCH_CANDIDATE":
                        break
        return output


def evaluate_all(context):
    context.validate()
    results = []
    for engine in (IndicatorsOnly(), SweepCHoCHFVG(), OrderBlockVolume(), Fibonacci()):
        results.extend(engine.evaluate(context))
    deduped = []
    seen = set()
    for row in results:
        plan = row.get("plan")
        if plan:
            key = (plan["engine"], plan["symbol"], plan["timeframe"], plan["thesis_key"])
            if key in seen:
                continue
            seen.add(key)
            row["conflict_advisory"] = any(
                other.get("plan", {}).get("direction") != plan["direction"] for other in results if other.get("plan")
            )
        deduped.append(row)
    return {
        "profile_status": "REQUIRES_OOS_VALIDATION",
        "production_qualified": False,
        "results": deduped,
        "blocked_specifications": ["BASE_ENTRY_SELECTOR_UNRESOLVED"],
        "parameters": {k: str(v) if isinstance(v, D) else v for k, v in asdict(context.parameters).items()},
    }
