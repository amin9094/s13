from __future__ import annotations
from core.logging_context import operation_id

import uuid
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from config import SETTINGS
from core.utils import parse_dt, utc_iso

FINAL_STATUSES = {"completed", "cancelled"}
MAX_JOBS = 200
MAX_ATTEMPTS = 5
PRIORITY_ORDER = {"critical": 0, "high": 1, "normal": 2, "low": 3}


def trusted_local_media_path(value: str) -> str:
    """Resolve an AI-generated media path without allowing arbitrary file reads."""
    raw = str(value or "").strip()
    if not raw:
        raise ValueError("مسیر فایل رسانه‌ای خالی است")
    root = Path(SETTINGS.gemini_generated_ads_dir).expanduser().resolve()
    candidate = Path(raw).expanduser().resolve(strict=True)
    try:
        candidate.relative_to(root)
    except ValueError as exc:
        raise ValueError("مسیر رسانه خارج از فضای امن تبلیغات است") from exc
    if not candidate.is_file() or candidate.suffix.lower() not in {".jpg", ".jpeg", ".png", ".webp"}:
        raise ValueError("فایل رسانه‌ای معتبر نیست")
    return str(candidate)


def _normalize_content(message: str, content: dict[str, Any] | None) -> dict[str, Any]:
    if content is None:
        text = str(message or "").strip()
        if not text:
            raise ValueError("پیام همگانی خالی است")
        return {"type": "text", "text": text[:4096], "buttons": []}
    kind = str(content.get("type") or "text").strip().lower()
    if kind not in {"text", "photo", "video", "document", "audio", "voice"}:
        raise ValueError("نوع محتوای ارسال همگانی پشتیبانی نمی‌شود")
    normalized: dict[str, Any] = {"type": kind}
    if kind == "text":
        text = str(content.get("text") or message or "").strip()
        if not text:
            raise ValueError("پیام همگانی خالی است")
        normalized["text"] = text[:4096]
    else:
        file_id = str(content.get("file_id") or "").strip()
        file_path = str(content.get("file_path") or "").strip()
        if file_path:
            if kind != "photo":
                raise ValueError("فایل محلی فقط برای تصویر تبلیغاتی پشتیبانی می‌شود")
            normalized["file_path"] = trusted_local_media_path(file_path)
        elif file_id:
            normalized["file_id"] = file_id[:500]
        else:
            raise ValueError("شناسه یا مسیر فایل رسانه‌ای خالی است")
        normalized["caption"] = str(content.get("caption") or message or "").strip()[:1024]
    buttons: list[dict[str, str]] = []
    for item in content.get("buttons", []) if isinstance(content.get("buttons"), list) else []:
        if not isinstance(item, dict):
            continue
        label, url = str(item.get("label") or "").strip(), str(item.get("url") or "").strip()
        if label and url.startswith(("https://", "http://", "tg://")):
            buttons.append({"label": label[:64], "url": url[:2048]})
    normalized["buttons"] = buttons[:8]
    return normalized


def enqueue_broadcast(
    db: dict[str, Any],
    *,
    admin_id: int | str,
    segment: str,
    recipients: list[int | str],
    message: str = "",
    content: dict[str, Any] | None = None,
    scheduled_for: str | datetime | None = None,
    variant: str = "",
    two_step: bool = False,
    priority: str = "normal",
) -> dict[str, Any]:
    payload = _normalize_content(message, content)
    schedule_dt = (
        scheduled_for.astimezone(UTC) if isinstance(scheduled_for, datetime) else parse_dt(scheduled_for) if scheduled_for else None
    )
    if scheduled_for and schedule_dt is None:
        raise ValueError("زمان ارسال همگانی نامعتبر است")
    if schedule_dt and schedule_dt <= datetime.now(UTC):
        raise ValueError("زمان ارسال همگانی باید در آینده باشد")
    text = str(payload.get("text") or payload.get("caption") or "").strip()
    clean_priority = str(priority or "normal").strip().lower()
    if clean_priority not in PRIORITY_ORDER:
        raise ValueError("اولویت ارسال نامعتبر است")
    unique = list(dict.fromkeys(str(int(uid)) for uid in recipients))
    now = utc_iso()
    job = {
        "id": f"BC-{uuid.uuid4().hex[:12].upper()}",
        "admin_id": str(admin_id),
        "segment": str(segment),
        "operation_id": operation_id("broadcast:"+str(segment)),
        "message": text[:4096],
        "content": payload,
        "variant": str(variant or "")[:20],
        "scheduled_for": schedule_dt.isoformat() if schedule_dt else None,
        "status": "queued",
        "recipients": unique,
        "cursor": 0,
        "sent": 0,
        "failed": 0,
        "blocked": 0,
        "retry_queue": [],
        "last_error": "",
        "created_at": now,
        "started_at": None,
        "updated_at": now,
        "completed_at": None,
        "cancel_requested": False,
        "two_step": bool(two_step),
        "priority": clean_priority,
    }
    queue = db.setdefault("broadcast_queue", [])
    queue.append(job)
    active = [row for row in queue if row.get("status") not in FINAL_STATUSES]
    finished = [row for row in queue if row.get("status") in FINAL_STATUSES]
    db["broadcast_queue"] = finished[-MAX_JOBS:] + active
    return job


def find_broadcast_job(db: dict[str, Any], job_id: str) -> dict[str, Any] | None:
    wanted = str(job_id)
    return next(
        (row for row in db.get("broadcast_queue", []) if isinstance(row, dict) and row.get("id") == wanted),
        None,
    )


def cancel_broadcast(db: dict[str, Any], job_id: str) -> bool:
    job = find_broadcast_job(db, job_id)
    if not job or job.get("status") in FINAL_STATUSES:
        return False
    job["cancel_requested"] = True
    job["updated_at"] = utc_iso()
    return True


def pause_broadcast(db: dict[str, Any], job_id: str) -> bool:
    job = find_broadcast_job(db, job_id)
    if not job or job.get("status") in FINAL_STATUSES:
        return False
    job["status"] = "paused"
    job["updated_at"] = utc_iso()
    return True


def resume_broadcast(db: dict[str, Any], job_id: str) -> bool:
    job = find_broadcast_job(db, job_id)
    if not job or job.get("status") != "paused":
        return False
    job["status"] = "queued"
    job["updated_at"] = utc_iso()
    return True


def claim_broadcast_batch(db: dict[str, Any], batch_size: int, *, personal_only: bool = False) -> dict[str, Any] | None:
    now = datetime.now(UTC)
    queue = db.get("broadcast_queue", [])
    try:
        from modules.feature_flags import feature_enabled
        priority_enabled = feature_enabled(db, "messaging.priority_queue", default=True)
    except Exception:
        priority_enabled = True
    ordered_jobs = sorted(
        ((index, job) for index, job in enumerate(queue) if isinstance(job, dict)),
        key=(
            (lambda item: (PRIORITY_ORDER.get(str(item[1].get("priority") or "normal").lower(), 2), item[0]))
            if priority_enabled else (lambda item: item[0])
        ),
    )
    for _, job in ordered_jobs:
        budgeted=str(job.get('segment','')).startswith('campaign:')
        if budgeted:
            from modules.management_suite import automation_settings
            if not automation_settings(db).get('enabled',True):continue
        if personal_only and not job.get("notification_event"):
            continue
        if not isinstance(job, dict) or job.get("status") in FINAL_STATUSES | {"paused"}:
            continue
        scheduled_for = parse_dt(job.get("scheduled_for"))
        if scheduled_for and scheduled_for > now:
            continue
        if job.get("cancel_requested"):
            job["status"] = "cancelled"
            job["completed_at"] = utc_iso()
            job["updated_at"] = utc_iso()
            continue
        lease_until = parse_dt(job.get("lease_until"))
        if job.get("status") == "processing" and lease_until and lease_until > now:
            continue
        if job.get("status") == "processing":
            # A worker crashed or lost its lease.  Return uncommitted recipients
            # to the retry queue instead of silently skipping them because the
            # cursor had already advanced.
            recovered = [row for row in job.get("inflight", []) if isinstance(row, dict)]
            retry_queue = [row for row in job.get("retry_queue", []) if isinstance(row, dict)]
            existing = {(str(row.get("user_id")), int(row.get("attempt", 1) or 1)) for row in retry_queue}
            for item in recovered:
                if budgeted and item.get('sending'):
                    job.setdefault('uncertain_recipients',{})[str(item['user_id'])]=dict(item)
                    continue
                key = (str(item.get("user_id")), int(item.get("attempt", 1) or 1))
                if key not in existing:
                    retry_queue.append(
                        {
                            "user_id": key[0],
                            "attempt": min(MAX_ATTEMPTS, key[1] + 1),
                            "next_attempt_at": now.isoformat(),
                            "error": "worker lease expired",
                        }
                    )
            job["retry_queue"] = retry_queue
            job["inflight"] = []
            job.pop("lease_token", None)
            job.pop("lease_until", None)
            job["status"] = "queued"
        recipients = list(job.get("recipients", []))
        cursor = int(job.get("cursor", 0) or 0)
        retry_queue = [row for row in job.get("retry_queue", []) if isinstance(row, dict)]
        claimed: list[dict[str, Any]] = []
        # Retry due recipients before new recipients.
        remaining_retry: list[dict[str, Any]] = []
        for item in retry_queue:
            due = parse_dt(item.get("next_attempt_at"))
            if len(claimed) < batch_size and (due is None or due <= now):
                claimed.append({"user_id": str(item.get("user_id")), "attempt": int(item.get("attempt", 1))})
            else:
                remaining_retry.append(item)
        while len(claimed) < batch_size and cursor < len(recipients):
            claimed.append({"user_id": str(recipients[cursor]), "attempt": 1})
            cursor += 1
        if budgeted:
            from modules.contact_budget import quiet,reserve
            permitted=[]
            for item in claimed:
                uid=str(item['user_id']);reservation=None if quiet(db,uid) else reserve(db,uid,f"broadcast:{job['id']}:{uid}")
                if reservation:
                    item['budget_reservation']=reservation;permitted.append(item)
                else:
                    remaining_retry.append({**item,'next_attempt_at':(now+timedelta(hours=1)).isoformat(),'error':'contact policy deferred'})
            claimed=permitted
            job.update(cursor=cursor,retry_queue=remaining_retry,updated_at=utc_iso())
        if not claimed:
            if cursor >= len(recipients) and not remaining_retry:
                job["status"] = "completed"
                job["completed_at"] = utc_iso()
                job["updated_at"] = utc_iso()
            continue
        token = uuid.uuid4().hex
        job["status"] = "processing"
        job["started_at"] = job.get("started_at") or utc_iso()
        job["cursor"] = cursor
        job["retry_queue"] = remaining_retry
        job["lease_token"] = token
        job["lease_until"] = (now + timedelta(minutes=2)).isoformat()
        job["inflight"] = [dict(item) for item in claimed]
        job["updated_at"] = utc_iso()
        return {
            "id": job["id"],
            "message": job.get("message", ""),
            "content": dict(job.get("content") or {"type": "text", "text": job.get("message", ""), "buttons": []}),
            "items": claimed,
            "lease_token": token,
            "priority": str(job.get("priority") or "normal"),
            "notification_event": dict(job.get("notification_event") or {}),
            'contact_budget':budgeted,
        }
    return None


def renew_broadcast_lease(db: dict[str, Any], job_id: str, lease_token: str, *, lease_seconds: int = 120) -> bool:
    job = find_broadcast_job(db, job_id)
    if not job or job.get("status") != "processing" or str(job.get("lease_token") or "") != str(lease_token):
        return False
    job["lease_until"] = (datetime.now(UTC) + timedelta(seconds=max(30, int(lease_seconds)))).isoformat()
    job["updated_at"] = utc_iso()
    return True


def _apply_delivery_result(job: dict[str, Any], result: dict[str, Any]) -> None:
    retries = list(job.get("retry_queue", []))
    status = str(result.get("status") or "retry")
    uid = str(result.get("user_id") or "")
    attempt = max(1, int(result.get("attempt", 1) or 1))
    if status == "sent":
        job["sent"] = int(job.get("sent", 0) or 0) + 1
    elif status=='uncertain':
        job.setdefault('uncertain_recipients',{})[uid]=dict(result)
    elif status in {'cancelled','skipped'}:
        job['cancelled_recipients']=int(job.get('cancelled_recipients',0))+1
    elif status == "blocked":
        job["blocked"] = int(job.get("blocked", 0) or 0) + 1
        job["failed"] = int(job.get("failed", 0) or 0) + 1
    elif attempt < MAX_ATTEMPTS:
        retry_after = float(result.get("retry_after_seconds", 0) or 0)
        delay = max(retry_after, min(3600, 15 * (2 ** (attempt - 1))))
        retries.append(
            {
                "user_id": uid,
                "attempt": attempt + 1,
                "next_attempt_at": (datetime.now(UTC) + timedelta(seconds=delay)).isoformat(),
                "error": str(result.get("error") or "")[:200],
            }
        )
    else:
        job["failed"] = int(job.get("failed", 0) or 0) + 1
        job["last_error"] = str(result.get("error") or "")[:300]
    job["retry_queue"] = retries


def checkpoint_broadcast_result(
    db: dict[str, Any],
    job_id: str,
    lease_token: str,
    result: dict[str, Any],
) -> dict[str, Any] | None:
    """Persist one recipient result while retaining the active batch lease.

    Persisting after every recipient means a crashed worker only retries the
    single uncheckpointed send instead of the complete batch.  Telegram does
    not provide an idempotency key for sends, so a crash between the API
    response and this checkpoint can still cause at most one duplicate.
    """

    job = find_broadcast_job(db, job_id)
    if not job or job.get("status") != "processing" or str(job.get("lease_token") or "") != str(lease_token):
        return None
    uid = str(result.get("user_id") or "")
    attempt = max(1, int(result.get("attempt", 1) or 1))
    inflight = [row for row in job.get("inflight", []) if isinstance(row, dict)]
    match_index = next(
        (
            index
            for index, item in enumerate(inflight)
            if str(item.get("user_id") or "") == uid and max(1, int(item.get("attempt", 1) or 1)) == attempt
        ),
        None,
    )
    if match_index is None:
        # Idempotent replay of a checkpoint already committed.
        return job
    if str(job.get('segment','')).startswith('campaign:'):
        item=inflight[match_index]
        if result.get('status')!='uncertain':
            from modules.contact_budget import release
            release(db,item.get('budget_reservation'),f'broadcast:{job_id}:{uid}',sent=result.get('status')=='sent',kind='campaign')
    _apply_delivery_result(job, result)
    inflight.pop(match_index)
    job["inflight"] = inflight
    job["updated_at"] = utc_iso()
    return job


def authorize_broadcast_recipient(db,job_id,token,uid):
    job=find_broadcast_job(db,job_id)
    if not job or job.get('lease_token')!=token or job.get('cancel_requested') or job.get('status')!='processing':return False
    if not str(job.get('segment','')).startswith('campaign:'):return True
    from modules.management_suite import automation_settings
    cfg=automation_settings(db)
    if not cfg.get('enabled',True) and cfg.get('pause_mode')!='drain':return False
    for item in job.get('inflight',[]):
        if str(item.get('user_id'))==str(uid):
            item['sending']=True;return True
    return False


def finish_broadcast_batch(
    db: dict[str, Any],
    job_id: str,
    lease_token: str,
) -> dict[str, Any] | None:
    job = find_broadcast_job(db, job_id)
    if not job or str(job.get("lease_token") or "") != str(lease_token):
        return None
    if any(isinstance(row, dict) for row in job.get("inflight", [])):
        return None
    job.pop("lease_token", None)
    job.pop("lease_until", None)
    total = len(job.get("recipients", []))
    cursor = int(job.get("cursor", 0) or 0)
    retries = [row for row in job.get("retry_queue", []) if isinstance(row, dict)]
    if job.get("cancel_requested"):
        job["status"] = "cancelled"
        job["completed_at"] = utc_iso()
    elif cursor >= total and not retries:
        job["status"] = "completed"
        job["completed_at"] = utc_iso()
    else:
        job["status"] = "queued"
    job["updated_at"] = utc_iso()
    return job


def record_batch_results(
    db: dict[str, Any],
    job_id: str,
    lease_token: str,
    results: list[dict[str, Any]],
) -> dict[str, Any] | None:
    """Backward-compatible atomic batch commit used by older callers/tests."""

    for result in results:
        if checkpoint_broadcast_result(db, job_id, lease_token, result) is None:
            return None
    return finish_broadcast_batch(db, job_id, lease_token)


def broadcast_progress(job: dict[str, Any]) -> dict[str, Any]:
    total = len(job.get("recipients", []))
    processed = int(job.get("sent", 0) or 0) + int(job.get("failed", 0) or 0)
    return {
        "id": job.get("id"),
        "status": job.get("status"),
        "total": total,
        "processed": processed,
        "sent": int(job.get("sent", 0) or 0),
        "failed": int(job.get("failed", 0) or 0),
        "blocked": int(job.get("blocked", 0) or 0),
        "percent": round(processed / total * 100, 1) if total else 100.0,
    }
