from __future__ import annotations

import copy
import json
import secrets
from datetime import UTC, datetime, timedelta
from typing import Any

from core.utils import parse_dt, utc_iso

PERSONAL_DICT_SECTIONS = (
    "referral_qualification",
    "users",
    "vip_users",
    "user_points",
    "user_profiles",
    "user_referrals",
    "user_missions",
    "user_signal_choices",
    "education_access",
    "education_progress",
    "education_learning_state",
    "crm_profiles",
    "economic_calendar_preferences",
    "user_bans",
    "discount_security",
    "affiliate_balances",
    "public_channel_attribution_users",
)
PERSONAL_LIST_SECTIONS = (
    "vip_orders",
    "education_orders",
    "reward_requests",
    "user_rewards",
    "price_alerts",
    "tickets",
    "point_history",
    "user_activity",
    "discount_history",
    "discount_events",
    "affiliate_commissions",
    "crm_activities",
    "campaign_events",
    "public_channel_link_events",
    "kpi_trader_submissions",
    "kpi_trader_score_ledger",
)


def _uid(value: int | str) -> str:
    return str(int(value))


def _matches_user(row: dict[str, Any], uid: str) -> bool:
    for key in (
        "user_id", "uid", "telegram_id", "assigned_to", "used_by", "referred_user_id",
        "affiliate_user_id", "customer_user_id",
        "trader_id",
    ):
        if str(row.get(key) or "") == uid:
            return True
    return False


def export_user_data(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    uid = _uid(user_id)
    output: dict[str, Any] = {
        "exported_at": utc_iso(),
        "user_id": uid,
        "schema": "sentinel-user-export-v1",
        "records": {},
    }
    for section in PERSONAL_DICT_SECTIONS:
        source = db.get(section, {})
        if isinstance(source, dict) and uid in source:
            output["records"][section] = copy.deepcopy(source[uid])
    for section in PERSONAL_LIST_SECTIONS:
        source = db.get(section, [])
        if isinstance(source, list):
            matches = [copy.deepcopy(row) for row in source if isinstance(row, dict) and _matches_user(row, uid)]
            if matches:
                output["records"][section] = matches
    for section in ("crm_automation_log", "economic_calendar_notifications", "discount_automation_log"):
        source = db.get(section, {})
        if isinstance(source, dict):
            matches = {
                str(key): copy.deepcopy(row)
                for key, row in source.items()
                if isinstance(row, dict) and str(row.get("user_id") or "") == uid
            }
            if matches:
                output["records"][section] = matches
    signal_choices = db.get("user_signal_choices", {})
    if isinstance(signal_choices, dict):
        nested: dict[str, Any] = {}
        for signal_id, choices in signal_choices.items():
            if isinstance(choices, dict) and uid in choices:
                nested[str(signal_id)] = copy.deepcopy(choices[uid])
        if nested:
            output["records"]["signal_choices_by_signal"] = nested
    return output


def export_user_json(db: dict[str, Any], user_id: int | str) -> bytes:
    return json.dumps(export_user_data(db, user_id), ensure_ascii=False, indent=2, default=str).encode("utf-8")


def request_account_deletion(db: dict[str, Any], user_id: int | str, grace_days: int) -> dict[str, Any]:
    uid = _uid(user_id)
    now = datetime.now(UTC)
    row = {
        "user_id": uid,
        "status": "pending",
        "requested_at": now.isoformat(),
        "execute_after": (now + timedelta(days=max(1, int(grace_days)))).isoformat(),
        "cancelled_at": None,
        "completed_at": None,
    }
    db.setdefault("privacy_requests", {})[uid] = row
    db.setdefault("privacy_log", []).append({"event": "deletion_requested", "user_id": uid, "created_at": utc_iso()})
    db["privacy_log"] = db["privacy_log"][-5000:]
    return row


def cancel_account_deletion(db: dict[str, Any], user_id: int | str) -> bool:
    uid = _uid(user_id)
    row = db.setdefault("privacy_requests", {}).get(uid)
    if not isinstance(row, dict) or row.get("status") != "pending":
        return False
    row["status"] = "cancelled"
    row["cancelled_at"] = utc_iso()
    db.setdefault("privacy_log", []).append({"event": "deletion_cancelled", "user_id": uid, "created_at": utc_iso()})
    db["privacy_log"] = db["privacy_log"][-5000:]
    return True


def _pseudonym(db: dict[str, Any], uid: str) -> str:
    request = db.setdefault("privacy_requests", {}).get(uid)
    if isinstance(request, dict) and str(request.get("pseudonym") or "").startswith("deleted:"):
        return str(request["pseudonym"])
    return f"deleted:{secrets.token_hex(8)}"


def _anonymize_row(row: dict[str, Any], uid: str, pseudonym: str, *, redact_text: bool = False) -> None:
    for key in (
        "user_id", "uid", "telegram_id", "assigned_to", "used_by", "sender_id",
        "affiliate_user_id", "customer_user_id",
        "trader_id",
    ):
        if str(row.get(key) or "") == uid:
            row[key] = pseudonym
    for key in ("username", "first_name", "last_name", "full_name", "name", "phone", "email"):
        if key in row:
            row[key] = ""
    if redact_text:
        for key in ("text", "subject", "detail", "note", "notes"):
            if key in row:
                row[key] = "[حذف‌شده توسط کاربر]"


def anonymize_user(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    uid = _uid(user_id)
    pseudonym = _pseudonym(db, uid)
    from modules.automation_outbox import cancel_user_deliveries
    cancel_user_deliveries(db, uid, pseudonym)

    # Direct personal profiles are removed entirely.
    for section in PERSONAL_DICT_SECTIONS:
        source = db.get(section)
        if isinstance(source, dict):
            source.pop(uid, None)

    # Remove or pseudonymize referral cross-references kept under other users.
    referrals = db.get("user_referrals", {})
    if isinstance(referrals, dict):
        for referral in referrals.values():
            if not isinstance(referral, dict):
                continue
            invited = referral.get("invited", [])
            if isinstance(invited, list):
                referral["invited"] = [value for value in invited if str(value) != uid]
    users = db.get("users", {})
    if isinstance(users, dict):
        for profile in users.values():
            if isinstance(profile, dict) and str(profile.get("referred_by") or "") == uid:
                profile["referred_by"] = pseudonym

    # Pending broadcasts must never target an account that requested deletion.
    for job in db.get("broadcast_queue", []):
        if not isinstance(job, dict):
            continue
        recipients = job.get("recipients", [])
        if isinstance(recipients, list):
            job["recipients"] = [value for value in recipients if str(value) != uid]
        retry_queue = job.get("retry_queue", [])
        if isinstance(retry_queue, list):
            job["retry_queue"] = [
                item
                for item in retry_queue
                if not (isinstance(item, dict) and str(item.get("user_id") or "") == uid)
            ]

    # Signal choices are keyed first by user id, then by signal id. Remove
    # only the deleted user's own choice map. Iterating over every user's map
    # and removing ``uid`` would accidentally delete a signal whose id happens
    # to equal the deleted user's id.
    choices = db.get("user_signal_choices", {})
    if isinstance(choices, dict):
        choices.pop(uid, None)

    # Financial/audit rows are retained in pseudonymized form for accounting integrity.
    for section in (
        "vip_orders", "education_orders", "point_history", "discount_history",
        "discount_events", "affiliate_commissions", "campaign_events", "public_channel_link_events",
        "kpi_trader_score_ledger",
    ):
        rows = db.get(section, [])
        for row in rows if isinstance(rows, list) else []:
            if isinstance(row, dict) and _matches_user(row, uid):
                _anonymize_row(row, uid, pseudonym)
                row["privacy_anonymized_at"] = utc_iso()

    # Operational personal content is removed or redacted.
    for section in (
        "reward_requests",
        "user_rewards",
        "price_alerts",
        "user_activity",
        "crm_activities",
        "kpi_trader_submissions",
    ):
        rows = db.get(section, [])
        if isinstance(rows, list):
            db[section] = [row for row in rows if not (isinstance(row, dict) and _matches_user(row, uid))]

    # Automation and calendar delivery logs use composite keys rather than a
    # direct user-id key. Remove only rows that belong to the deleted account.
    for section in ("crm_automation_log", "economic_calendar_notifications", "discount_automation_log"):
        rows = db.get(section, {})
        if isinstance(rows, dict):
            db[section] = {
                key: row
                for key, row in rows.items()
                if not (isinstance(row, dict) and str(row.get("user_id") or "") == uid)
            }

    # Other users' activity metadata may contain referral cross-references.
    for row in db.get("user_activity", []):
        if not isinstance(row, dict):
            continue
        metadata = row.get("metadata")
        if not isinstance(metadata, dict):
            continue
        for key in ("referrer_id", "invited_user_id", "target_user_id"):
            if str(metadata.get(key) or "") == uid:
                metadata[key] = pseudonym

    # Discount campaign assignments and reservations can reference the user.
    for item in db.get("discount_codes", {}).values() if isinstance(db.get("discount_codes"), dict) else []:
        if not isinstance(item, dict):
            continue
        if str(item.get("assigned_to") or "") == uid:
            item["assigned_to"] = pseudonym
        used_by = item.get("used_by")
        if isinstance(used_by, list):
            item["used_by"] = [pseudonym if str(value) == uid else value for value in used_by]
        elif str(used_by or "") == uid:
            item["used_by"] = pseudonym
        reservations = item.get("reservations")
        if isinstance(reservations, dict):
            for order_id, value in list(reservations.items()):
                if str(value) == uid:
                    reservations[order_id] = pseudonym

    tickets = db.get("tickets", [])
    for ticket in tickets if isinstance(tickets, list) else []:
        if not isinstance(ticket, dict) or str(ticket.get("user_id") or "") != uid:
            continue
        ticket["user_id"] = pseudonym
        ticket["subject"] = "[حذف‌شده توسط کاربر]"
        for message in ticket.get("messages", []):
            if isinstance(message, dict) and message.get("sender") == "user":
                _anonymize_row(message, uid, pseudonym, redact_text=True)
        ticket["privacy_anonymized_at"] = utc_iso()

    request = db.setdefault("privacy_requests", {}).setdefault(uid, {})
    request.update({"status": "completed", "completed_at": utc_iso(), "pseudonym": pseudonym})
    db.setdefault("privacy_log", []).append({"event": "deletion_completed", "user_id": pseudonym, "created_at": utc_iso()})
    db["privacy_log"] = db["privacy_log"][-5000:]
    return {"user_id": uid, "pseudonym": pseudonym}


def process_due_deletions(db: dict[str, Any], now: datetime | None = None) -> list[dict[str, Any]]:
    current = now or datetime.now(UTC)
    due: list[str] = []
    for uid, row in db.setdefault("privacy_requests", {}).items():
        if not isinstance(row, dict) or row.get("status") != "pending":
            continue
        execute_after = parse_dt(row.get("execute_after"))
        if execute_after and execute_after <= current:
            due.append(str(uid))
    return [anonymize_user(db, uid) for uid in due]


def retention_cleanup(db: dict[str, Any], retention_days: int, now: datetime | None = None) -> dict[str, int]:
    current = now or datetime.now(UTC)
    cutoff = current - timedelta(days=max(30, int(retention_days)))
    counts: dict[str, int] = {}

    for section in ("user_activity", "privacy_log", "admin_logs"):
        rows = db.get(section, [])
        if not isinstance(rows, list):
            continue
        kept = []
        removed = 0
        for row in rows:
            if not isinstance(row, dict):
                continue
            created = parse_dt(row.get("created_at") or row.get("updated_at"))
            if created and created < cutoff:
                removed += 1
            else:
                kept.append(row)
        db[section] = kept
        counts[section] = removed

    # Closed tickets keep metadata but old message bodies are minimized.
    minimized = 0
    for ticket in db.get("tickets", []):
        if not isinstance(ticket, dict) or ticket.get("status") != "closed":
            continue
        closed_at = parse_dt(ticket.get("closed_at"))
        if not closed_at or closed_at >= cutoff:
            continue
        messages = ticket.get("messages", [])
        if isinstance(messages, list) and len(messages) > 2:
            ticket["messages"] = messages[-2:]
            ticket["retention_minimized_at"] = utc_iso()
            minimized += 1
    counts["tickets_minimized"] = minimized
    db.setdefault("operations", {})["last_cleanup_at"] = utc_iso()
    return counts
