from __future__ import annotations

import hashlib
import hmac
import json
import re
import secrets
from collections import Counter, defaultdict
from datetime import UTC, datetime
from typing import Any
from urllib.parse import urlparse

from core.db import next_id
from core.utils import parse_dt, utc_iso
from modules.platform_registry import capability_available, cost_policy, ensure_platform_registry, platform_matrix

_FINAL_SIGNAL_STATUSES = {"closed", "tp", "win", "loss", "stopped", "cancelled", "expired"}
_POSITIVE_RESULTS = {"tp", "win", "target", "tp1", "tp2", "tp3", "tp4", "tp5"}
_NEGATIVE_RESULTS = {"loss", "stop", "stopped", "sl"}


def ensure_platform_expansion(db: dict[str, Any]) -> None:
    ensure_platform_registry(db)
    defaults: dict[str, Any] = {
        "paper_accounts": [],
        "paper_trades": [],
        "prop_challenges": [],
        "publisher_channels": [],
        "publisher_queue": [],
        "partners": [],
        "partner_events": [],
        "partner_ledger": [],
        "public_performance_snapshots": [],
        "content_templates": [],
        "content_outputs": [],
        "business_inbox": [],
        "developer_webhooks": [],
        "webhook_outbox": [],
        "workspaces": [],
        "workspace_memberships": [],
        "miniapp_device_state": {},
        "platform_audit": [],
    }
    for key, value in defaults.items():
        db.setdefault(key, value.copy() if isinstance(value, list) else dict(value))
    if not db["content_templates"]:
        db["content_templates"].extend([
            {"id": 1, "key": "signal_public", "title": "سیگنال عمومی", "body": "📡 {symbol} · {side}\nورود: {entry}\nحدضرر: {stop}\nاهداف: {targets}\nریسک: {risk}%", "enabled": True},
            {"id": 2, "key": "signal_result", "title": "نتیجه سیگنال", "body": "📈 نتیجه {symbol} #{display_number}\nوضعیت: {result}\nبرآیند: {result_r}R", "enabled": True},
            {"id": 3, "key": "weekly_report", "title": "گزارش هفتگی", "body": "🛡 SENTINEL Weekly\nتعداد: {total}\nبرد: {wins}\nباخت: {losses}\nWin Rate: {win_rate}%\nNet R: {net_r}", "enabled": True},
        ])


def _audit(db: dict[str, Any], event: str, actor_id: int | str, payload: dict[str, Any]) -> None:
    ensure_platform_expansion(db)
    db["platform_audit"].append({
        "id": next_id(db, "platform_audit"),
        "event": str(event)[:80],
        "actor_id": str(actor_id),
        "payload": payload,
        "created_at": utc_iso(),
    })
    db["platform_audit"] = db["platform_audit"][-10000:]


def _require(db: dict[str, Any], key: str) -> None:
    available, reasons = capability_available(db, key)
    if not available:
        raise PermissionError("CAPABILITY_UNAVAILABLE:" + ",".join(reasons))


def _user_rows(db: dict[str, Any], keys: tuple[str, ...], user_id: int | str) -> list[dict[str, Any]]:
    uid = str(user_id)
    rows: list[dict[str, Any]] = []
    for key in keys:
        value = db.get(key)
        if isinstance(value, list):
            rows.extend(row for row in value if isinstance(row, dict) and str(row.get("user_id")) == uid)
    return rows


def _journal_rows(db: dict[str, Any], user_id: int | str) -> list[dict[str, Any]]:
    return _user_rows(db, ("journal_entries", "user_journal", "journal"), user_id)


def _trade_pnl_r(row: dict[str, Any]) -> float:
    for key in ("result_r", "net_r", "pnl_r", "r_multiple"):
        try:
            if row.get(key) not in {None, ""}:
                return float(row.get(key) or 0)
        except (TypeError, ValueError):
            pass
    result = str(row.get("result") or row.get("status") or "").lower()
    if result in _POSITIVE_RESULTS:
        return 1.0
    if result in _NEGATIVE_RESULTS:
        return -1.0
    try:
        return float(row.get("pnl_percent") or 0) / max(float(row.get("risk_percent") or 1), 0.01)
    except (TypeError, ValueError, ZeroDivisionError):
        return 0.0


def behavioral_risk_report(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    _require(db, "risk_coach")
    rows = sorted(_journal_rows(db, user_id), key=lambda row: str(row.get("closed_at") or row.get("created_at") or ""))
    values = [_trade_pnl_r(row) for row in rows]
    losses = [value for value in values if value < 0]
    wins = [value for value in values if value > 0]
    max_loss_streak = 0
    streak = 0
    revenge_flags = 0
    size_escalation = 0
    early_exit = 0
    missing_plan = 0
    previous: dict[str, Any] | None = None
    for row, value in zip(rows, values):
        streak = streak + 1 if value < 0 else 0
        max_loss_streak = max(max_loss_streak, streak)
        note = str(row.get("note") or row.get("analysis") or "").lower()
        if not any(row.get(key) for key in ("setup", "strategy", "plan", "signal_id")):
            missing_plan += 1
        if any(token in note for token in ("early", "زود", "ترس", "بستن سریع")):
            early_exit += 1
        if previous and _trade_pnl_r(previous) < 0:
            try:
                prev_risk = float(previous.get("risk_percent") or 0)
                current_risk = float(row.get("risk_percent") or 0)
            except (TypeError, ValueError):
                prev_risk = current_risk = 0.0
            if current_risk > max(prev_risk * 1.25, prev_risk + 0.5):
                size_escalation += 1
                revenge_flags += 1
            prev_dt = parse_dt(previous.get("closed_at") or previous.get("created_at"))
            curr_dt = parse_dt(row.get("created_at") or row.get("opened_at"))
            if prev_dt and curr_dt and 0 <= (curr_dt - prev_dt).total_seconds() <= 30 * 60:
                revenge_flags += 1
        previous = row
    sample = len(rows)
    discipline = 100.0
    discipline -= min(25, revenge_flags * 8)
    discipline -= min(20, size_escalation * 7)
    discipline -= min(20, early_exit * 4)
    discipline -= min(20, missing_plan / max(1, sample) * 35)
    discipline -= min(15, max(0, max_loss_streak - 2) * 5)
    discipline = round(max(0.0, discipline), 1)
    findings: list[dict[str, Any]] = []
    if revenge_flags:
        findings.append({"code": "revenge_risk", "severity": "high" if revenge_flags >= 3 else "medium", "count": revenge_flags, "title": "احتمال معامله انتقامی"})
    if size_escalation:
        findings.append({"code": "risk_escalation", "severity": "high", "count": size_escalation, "title": "افزایش ریسک پس از زیان"})
    if max_loss_streak >= 3:
        findings.append({"code": "loss_streak", "severity": "high", "count": max_loss_streak, "title": "زنجیره زیان"})
    if missing_plan:
        findings.append({"code": "missing_plan", "severity": "medium", "count": missing_plan, "title": "معامله بدون Setup ثبت‌شده"})
    recommendations: list[str] = []
    if revenge_flags:
        recommendations.append("پس از هر زیان حداقل ۳۰ دقیقه Cooldown فعال کن.")
    if size_escalation:
        recommendations.append("ریسک معامله بعدی را از ریسک معامله زیان‌ده بیشتر نکن.")
    if max_loss_streak >= 3:
        recommendations.append("پس از ۳ زیان متوالی، ادامه معاملات روز را متوقف کن.")
    if missing_plan:
        recommendations.append("قبل از ورود، Setup و دلیل ابطال را در ژورنال ثبت کن.")
    if not recommendations:
        recommendations.append("الگوی پرخطر واضحی دیده نشد؛ ثبت منظم ژورنال را ادامه بده.")
    return {
        "user_id": str(user_id),
        "sample_size": sample,
        "wins": len(wins),
        "losses": len(losses),
        "net_r": round(sum(values), 3),
        "max_loss_streak": max_loss_streak,
        "discipline_score": discipline,
        "findings": findings,
        "recommendations": recommendations,
        "cooldown_recommended_minutes": 30 if revenge_flags or max_loss_streak >= 3 else 0,
        "method": "transparent_local_rules",
        "generated_at": utc_iso(),
    }


def local_copilot_answer(db: dict[str, Any], user_id: int | str, question: str) -> dict[str, Any]:
    _require(db, "local_copilot")
    clean = str(question or "").strip()
    if len(clean) < 2:
        raise ValueError("QUESTION_REQUIRED")
    report = behavioral_risk_report(db, user_id)
    lower = clean.casefold()
    if any(token in lower for token in ("چرا", "ضرر", "loss", "باختم")):
        answer = f"در {report['sample_size']} رکورد، برآیند شما {report['net_r']}R و بیشترین زنجیره زیان {report['max_loss_streak']} بوده است."
        if report["findings"]:
            answer += " مهم‌ترین الگو: " + "، ".join(item["title"] for item in report["findings"][:3]) + "."
    elif any(token in lower for token in ("ریسک", "حجم", "risk", "lot")):
        answer = f"امتیاز انضباط شما {report['discipline_score']} از ۱۰۰ است. برای حفظ سرمایه، ریسک ثابت و توقف پس از سه زیان متوالی پیشنهاد می‌شود."
    elif any(token in lower for token in ("امروز", "برنامه", "plan")):
        answer = "برنامه پیشنهادی امروز: فقط Setupهای از پیش تعریف‌شده، سقف ریسک روزانه مشخص، و ثبت دلیل ورود و ابطال پیش از معامله."
    else:
        answer = f"بر اساس داده‌های داخلی SENTINEL، امتیاز انضباط شما {report['discipline_score']} و برآیند ثبت‌شده {report['net_r']}R است. سؤال را درباره ریسک، ضررها، ژورنال یا برنامه روزانه دقیق‌تر بنویس."
    return {
        "question": clean[:500],
        "answer": answer,
        "evidence": {"sample_size": report["sample_size"], "net_r": report["net_r"], "discipline_score": report["discipline_score"]},
        "limitations": ["از API هوش مصنوعی پولی استفاده نشده است", "فقط داده‌های ثبت‌شده داخل SENTINEL بررسی شده‌اند"],
        "engine": "sentinel-local-copilot-v1",
        "generated_at": utc_iso(),
    }


def create_paper_account(db: dict[str, Any], user_id: int | str, title: str, starting_balance: float = 10_000) -> dict[str, Any]:
    _require(db, "paper_arena")
    ensure_platform_expansion(db)
    balance = float(starting_balance)
    if balance < 100 or balance > 1_000_000_000:
        raise ValueError("INVALID_STARTING_BALANCE")
    existing = [row for row in db["paper_accounts"] if str(row.get("user_id")) == str(user_id) and row.get("status") == "active"]
    if len(existing) >= 5:
        raise ValueError("PAPER_ACCOUNT_LIMIT")
    row = {
        "id": next_id(db, "paper_account"), "user_id": str(user_id), "title": str(title or "حساب آزمایشی")[:80],
        "starting_balance": round(balance, 2), "balance": round(balance, 2), "equity": round(balance, 2),
        "peak_balance": round(balance, 2), "max_drawdown_percent": 0.0, "status": "active", "created_at": utc_iso(),
    }
    db["paper_accounts"].append(row)
    return dict(row)


def _paper_account(db: dict[str, Any], user_id: int | str, account_id: int | str) -> dict[str, Any]:
    target = int(account_id)
    row = next((item for item in db.get("paper_accounts", []) if int(item.get("id", 0) or 0) == target and str(item.get("user_id")) == str(user_id)), None)
    if not row:
        raise ValueError("PAPER_ACCOUNT_NOT_FOUND")
    return row


def open_paper_trade(
    db: dict[str, Any], user_id: int | str, account_id: int | str, *,
    symbol: str, side: str, entry: float, stop: float, target: float | None = None,
    targets: list[float] | None = None, target_allocations: list[float] | None = None,
    risk_percent: float = 1.0, signal_id: int | str | None = None,
) -> dict[str, Any]:
    _require(db, "paper_arena")
    ensure_platform_expansion(db)
    account = _paper_account(db, user_id, account_id)
    side_value = str(side or "").lower()
    if side_value not in {"buy", "sell"}:
        raise ValueError("INVALID_SIDE")
    entry_v, stop_v, risk_v = float(entry), float(stop), float(risk_percent)
    target_values = [float(value) for value in (targets or ([] if target is None else [target]))]
    target_values = list(dict.fromkeys(value for value in target_values if value > 0))[:10]
    if min(entry_v, stop_v) <= 0 or not target_values or not 0.1 <= risk_v <= 5:
        raise ValueError("INVALID_TRADE_VALUES")
    if side_value == "buy" and (stop_v >= entry_v or any(value <= entry_v for value in target_values)):
        raise ValueError("INVALID_BUY_LEVELS")
    if side_value == "sell" and (stop_v <= entry_v or any(value >= entry_v for value in target_values)):
        raise ValueError("INVALID_SELL_LEVELS")
    risk_distance = abs(entry_v - stop_v)
    reward_distance = abs(target_values[0] - entry_v)
    if risk_distance <= 0:
        raise ValueError("STOP_EQUALS_ENTRY")
    rr = reward_distance / risk_distance
    if rr < 0.5:
        raise ValueError("RR_TOO_LOW")
    open_risk = sum(float(row.get("risk_percent") or 0) for row in db["paper_trades"] if str(row.get("user_id")) == str(user_id) and int(row.get("account_id", 0) or 0) == int(account_id) and row.get("status") == "open")
    if open_risk + risk_v > 10:
        raise ValueError("PAPER_TOTAL_RISK_LIMIT")
    allocations = [float(value) for value in (target_allocations or [])][:len(target_values)]
    if len(allocations) != len(target_values) or any(value <= 0 for value in allocations):
        allocations = [1 / len(target_values)] * len(target_values)
    total_allocation = sum(allocations)
    allocations = [round(value / total_allocation, 6) for value in allocations]
    trade = {
        "id": next_id(db, "paper_trade"), "user_id": str(user_id), "account_id": int(account_id), "signal_id": int(signal_id) if signal_id not in {None, ""} else None,
        "symbol": str(symbol or "").upper()[:30], "side": side_value, "entry": entry_v, "stop": stop_v,
        "initial_stop": stop_v, "target": target_values[0], "targets": target_values,
        "target_allocations": allocations, "target_hits": [], "cancelled_targets": [],
        "remaining_fraction": 1.0, "realized_r": 0.0, "realized_pnl": 0.0,
        "events": [{"action": "opened", "at": utc_iso(), "entry": entry_v, "stop": stop_v, "targets": target_values}],
        "risk_percent": risk_v, "risk_amount": round(float(account.get("balance") or 0) * risk_v / 100, 2), "planned_rr": round(rr, 3),
        "status": "open", "opened_at": utc_iso(), "closed_at": None, "exit_price": None, "result_r": None, "pnl_amount": None,
    }
    db["paper_trades"].append(trade)
    return dict(trade)


def _paper_result_r(trade: dict[str, Any], price: float) -> float:
    direction = 1 if trade["side"] == "buy" else -1
    risk_distance = abs(float(trade["entry"]) - float(trade.get("initial_stop") or trade["stop"]))
    return direction * (float(price) - float(trade["entry"])) / max(risk_distance, 1e-12)


def _apply_paper_account_pnl(db: dict[str, Any], user_id: int | str, trade: dict[str, Any], pnl: float) -> None:
    account = _paper_account(db, user_id, trade["account_id"])
    account["balance"] = round(float(account.get("balance") or 0) + pnl, 2)
    account["equity"] = account["balance"]
    account["peak_balance"] = max(float(account.get("peak_balance") or 0), float(account["balance"]))
    peak = max(float(account.get("peak_balance") or 1), 1)
    drawdown = max(0.0, (peak - float(account["balance"])) / peak * 100)
    account["max_drawdown_percent"] = round(max(float(account.get("max_drawdown_percent") or 0), drawdown), 3)


def paper_trade_action(
    db: dict[str, Any], user_id: int | str, trade_id: int | str, action: str, *,
    price: float | None = None, target_index: int | None = None, fraction: float | None = None,
    new_stop: float | None = None, targets: list[float] | None = None, reason: str = "",
) -> dict[str, Any]:
    _require(db, "paper_arena")
    ensure_platform_expansion(db)
    target = int(trade_id)
    trade = next((row for row in db["paper_trades"] if int(row.get("id", 0) or 0) == target and str(row.get("user_id")) == str(user_id)), None)
    if not trade or trade.get("status") != "open":
        raise ValueError("OPEN_PAPER_TRADE_NOT_FOUND")
    action_value = str(action or "").lower().strip()
    now = utc_iso()
    trade.setdefault("events", [])
    trade.setdefault("targets", [float(trade.get("target") or 0)])
    trade.setdefault("target_allocations", [1 / max(1, len(trade["targets"]))] * len(trade["targets"]))
    trade.setdefault("target_hits", [])
    trade.setdefault("cancelled_targets", [])
    trade.setdefault("remaining_fraction", 1.0)
    trade.setdefault("realized_r", 0.0)
    trade.setdefault("realized_pnl", 0.0)
    if action_value == "move_sl":
        stop_v = float(new_stop or 0)
        if stop_v <= 0:
            raise ValueError("INVALID_STOP")
        old_stop = float(trade["stop"])
        trade["stop"] = stop_v
        trade["events"].append({"action": "move_sl", "at": now, "from": old_stop, "to": stop_v, "reason": str(reason)[:300]})
        return dict(trade)
    if action_value == "replace_targets":
        values = [float(value) for value in (targets or []) if float(value) > 0][:10]
        if not values:
            raise ValueError("TARGETS_REQUIRED")
        trade["targets"] = values
        trade["target"] = values[0]
        trade["target_allocations"] = [round(1 / len(values), 6)] * len(values)
        trade["events"].append({"action": "replace_targets", "at": now, "targets": values})
        return dict(trade)
    if action_value == "cancel_target":
        index = int(target_index or 0)
        if index < 1 or index > len(trade["targets"]):
            raise ValueError("TARGET_NOT_FOUND")
        if index in trade["target_hits"] or index in trade["cancelled_targets"]:
            raise ValueError("TARGET_ALREADY_RESOLVED")
        trade["cancelled_targets"].append(index)
        trade["events"].append({"action": "cancel_target", "at": now, "target_index": index})
        return dict(trade)
    if action_value == "cancel":
        trade.update({"status": "cancelled", "closed_at": now, "cancel_reason": str(reason or "cancelled_by_user")[:300]})
        trade["events"].append({"action": "cancel", "at": now, "reason": trade["cancel_reason"]})
        return dict(trade)
    target_match = action_value.startswith("tp") and action_value[2:].isdigit()
    if action_value == "take_profit" or target_match:
        index = int(target_index or (action_value[2:] if target_match else 1))
        if index < 1 or index > len(trade["targets"]):
            raise ValueError("TARGET_NOT_FOUND")
        if index in trade["target_hits"] or index in trade["cancelled_targets"]:
            raise ValueError("TARGET_ALREADY_RESOLVED")
        exit_v = float(price or trade["targets"][index - 1])
        default_fraction = float(trade["target_allocations"][index - 1])
        close_fraction = min(float(trade["remaining_fraction"]), max(0.000001, float(fraction or default_fraction)))
        trade["target_hits"].append(index)
        event_action = f"tp{index}"
    else:
        if action_value == "sl":
            exit_v = float(price or trade["stop"])
        elif action_value == "breakeven":
            exit_v = float(price or trade["entry"])
        elif action_value == "manual":
            exit_v = float(price or 0)
        else:
            raise ValueError("INVALID_PAPER_TRADE_ACTION")
        if exit_v <= 0:
            raise ValueError("INVALID_EXIT_PRICE")
        close_fraction = min(float(trade["remaining_fraction"]), max(0.000001, float(fraction or trade["remaining_fraction"])))
        event_action = action_value
    result_r = _paper_result_r(trade, exit_v)
    pnl = float(trade.get("risk_amount") or 0) * result_r * close_fraction
    _apply_paper_account_pnl(db, user_id, trade, pnl)
    trade["realized_r"] = round(float(trade.get("realized_r") or 0) + result_r * close_fraction, 4)
    trade["realized_pnl"] = round(float(trade.get("realized_pnl") or 0) + pnl, 2)
    trade["remaining_fraction"] = round(max(0.0, float(trade["remaining_fraction"]) - close_fraction), 6)
    trade["events"].append({"action": event_action, "at": now, "price": exit_v, "fraction": close_fraction, "result_r": round(result_r, 4), "pnl": round(pnl, 2)})
    if trade["remaining_fraction"] <= 0.000001:
        trade.update({
            "status": "closed", "exit_price": exit_v, "result_r": trade["realized_r"],
            "pnl_amount": trade["realized_pnl"], "closed_at": now,
        })
    return dict(trade)


def close_paper_trade(db: dict[str, Any], user_id: int | str, trade_id: int | str, exit_price: float) -> dict[str, Any]:
    return paper_trade_action(db, user_id, trade_id, "manual", price=float(exit_price), fraction=1.0)


def paper_arena_snapshot(db: dict[str, Any], user_id: int | str | None = None) -> dict[str, Any]:
    _require(db, "paper_arena")
    ensure_platform_expansion(db)
    accounts = [dict(row) for row in db["paper_accounts"] if user_id is None or str(row.get("user_id")) == str(user_id)]
    trades = [dict(row) for row in db["paper_trades"] if user_id is None or str(row.get("user_id")) == str(user_id)]
    leaderboard: list[dict[str, Any]] = []
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for account in db["paper_accounts"]:
        grouped[str(account.get("user_id"))].append(account)
    for uid, rows in grouped.items():
        starting = sum(float(row.get("starting_balance") or 0) for row in rows)
        balance = sum(float(row.get("balance") or 0) for row in rows)
        return_pct = ((balance - starting) / starting * 100) if starting else 0.0
        max_dd = max((float(row.get("max_drawdown_percent") or 0) for row in rows), default=0.0)
        score = return_pct - max_dd * 1.5
        leaderboard.append({"user_id": uid, "return_percent": round(return_pct, 3), "max_drawdown_percent": round(max_dd, 3), "risk_adjusted_score": round(score, 3)})
    leaderboard.sort(key=lambda row: (-row["risk_adjusted_score"], row["user_id"]))
    return {
        "accounts": accounts, "trades": trades[-200:], "leaderboard": leaderboard[:100],
        "summary": {
            "open": sum(1 for row in trades if row.get("status") == "open"),
            "closed": sum(1 for row in trades if row.get("status") == "closed"),
            "cancelled": sum(1 for row in trades if row.get("status") == "cancelled"),
        },
        "generated_at": utc_iso(),
    }


def configure_prop_challenge(db: dict[str, Any], user_id: int | str, account_id: int | str, rules: dict[str, Any]) -> dict[str, Any]:
    _require(db, "prop_guardian")
    account = _paper_account(db, user_id, account_id)
    normalized = {
        "daily_loss_limit_percent": min(max(float(rules.get("daily_loss_limit_percent", 5)), 0.5), 20),
        "total_loss_limit_percent": min(max(float(rules.get("total_loss_limit_percent", 10)), 1), 30),
        "profit_target_percent": min(max(float(rules.get("profit_target_percent", 8)), 1), 100),
        "min_trading_days": min(max(int(rules.get("min_trading_days", 5)), 0), 365),
        "max_risk_per_trade_percent": min(max(float(rules.get("max_risk_per_trade_percent", 2)), 0.1), 10),
        "news_trading_allowed": bool(rules.get("news_trading_allowed", True)),
        "weekend_holding_allowed": bool(rules.get("weekend_holding_allowed", True)),
    }
    existing = next((row for row in db.get("prop_challenges", []) if str(row.get("user_id")) == str(user_id) and int(row.get("account_id", 0) or 0) == int(account_id) and row.get("status") == "active"), None)
    row = existing or {"id": next_id(db, "prop_challenge"), "user_id": str(user_id), "account_id": int(account_id), "status": "active", "created_at": utc_iso()}
    row.update({"rules": normalized, "starting_balance": float(account["starting_balance"]), "updated_at": utc_iso()})
    if not existing:
        db.setdefault("prop_challenges", []).append(row)
    return dict(row)


def prop_guardian_snapshot(db: dict[str, Any], user_id: int | str, account_id: int | str, candidate_risk_percent: float = 0.0) -> dict[str, Any]:
    _require(db, "prop_guardian")
    account = _paper_account(db, user_id, account_id)
    challenge = next((row for row in db.get("prop_challenges", []) if str(row.get("user_id")) == str(user_id) and int(row.get("account_id", 0) or 0) == int(account_id) and row.get("status") == "active"), None)
    if not challenge:
        return {"status": "unconfigured", "account": dict(account), "hard_blocks": [], "warnings": ["PROP_RULES_REQUIRED"]}
    rules = challenge["rules"]
    starting = float(challenge.get("starting_balance") or account.get("starting_balance") or 1)
    balance = float(account.get("balance") or 0)
    total_drawdown = max(0.0, (starting - balance) / max(starting, 1e-9) * 100)
    today = datetime.now(UTC).date().isoformat()
    today_trades = [row for row in db.get("paper_trades", []) if str(row.get("user_id")) == str(user_id) and int(row.get("account_id", 0) or 0) == int(account_id) and str(row.get("closed_at") or "").startswith(today)]
    daily_loss_amount = abs(sum(min(float(row.get("pnl_amount") or 0), 0) for row in today_trades))
    daily_loss_percent = daily_loss_amount / max(starting, 1e-9) * 100
    days = len({str(row.get("closed_at") or "")[:10] for row in db.get("paper_trades", []) if str(row.get("user_id")) == str(user_id) and int(row.get("account_id", 0) or 0) == int(account_id) and row.get("status") == "closed"})
    profit_progress = max(0.0, (balance - starting) / max(starting, 1e-9) * 100)
    blocks: list[str] = []
    warnings: list[str] = []
    if total_drawdown >= float(rules["total_loss_limit_percent"]): blocks.append("TOTAL_DRAWDOWN_BREACH")
    if daily_loss_percent >= float(rules["daily_loss_limit_percent"]): blocks.append("DAILY_LOSS_BREACH")
    if candidate_risk_percent > float(rules["max_risk_per_trade_percent"]): blocks.append("MAX_RISK_PER_TRADE")
    projected_daily = daily_loss_percent + max(0.0, float(candidate_risk_percent))
    projected_total = total_drawdown + max(0.0, float(candidate_risk_percent))
    if not blocks and projected_daily >= float(rules["daily_loss_limit_percent"]) * 0.8: warnings.append("DAILY_LIMIT_NEAR")
    if not blocks and projected_total >= float(rules["total_loss_limit_percent"]) * 0.8: warnings.append("TOTAL_LIMIT_NEAR")
    passed = profit_progress >= float(rules["profit_target_percent"]) and days >= int(rules["min_trading_days"])
    return {
        "status": "passed" if passed else ("blocked" if blocks else "warning" if warnings else "safe"),
        "hard_blocks": blocks, "warnings": warnings,
        "metrics": {
            "balance": balance, "starting_balance": starting, "daily_loss_percent": round(daily_loss_percent, 3),
            "daily_loss_remaining_percent": round(max(0, float(rules["daily_loss_limit_percent"]) - daily_loss_percent), 3),
            "total_drawdown_percent": round(total_drawdown, 3), "total_loss_remaining_percent": round(max(0, float(rules["total_loss_limit_percent"]) - total_drawdown), 3),
            "profit_progress_percent": round(profit_progress, 3), "trading_days": days, "min_trading_days": int(rules["min_trading_days"]),
            "projected_daily_loss_percent": round(projected_daily, 3), "projected_total_drawdown_percent": round(projected_total, 3),
        },
        "rules": dict(rules), "generated_at": utc_iso(),
    }


def _signal_result_r(row: dict[str, Any]) -> float | None:
    status = str(row.get("status") or row.get("result") or "").lower()
    if status not in _FINAL_SIGNAL_STATUSES and row.get("result_r") in {None, ""}:
        return None
    return _trade_pnl_r(row)


def local_market_intelligence(db: dict[str, Any]) -> dict[str, Any]:
    _require(db, "market_intelligence_v2")
    price_sources = [db.get(key) for key in ("market_prices", "price_cache", "crypto_prices", "stock_prices", "iran_prices_cache")]
    prices: dict[str, Any] = {}
    for source in price_sources:
        if isinstance(source, dict):
            prices.update(source)
    events = [row for row in db.get("economic_events", []) if isinstance(row, dict)]
    news = [row for row in db.get("market_news", []) if isinstance(row, dict)]
    provider_health = db.get("provider_health", {}) if isinstance(db.get("provider_health"), dict) else {}
    freshness_values: list[float] = []
    now = datetime.now(UTC)
    for row in list(prices.values())[:500]:
        if isinstance(row, dict):
            dt = parse_dt(row.get("updated_at") or row.get("fetched_at") or row.get("observed_at"))
            if dt:
                freshness_values.append(max(0.0, (now - dt).total_seconds()))
    stale_seconds = max(freshness_values) if freshness_values else None
    status = "fresh" if stale_seconds is not None and stale_seconds <= 300 else "stale" if stale_seconds is not None else "no_data"
    return {
        "price_items": len(prices), "event_items": len(events), "news_items": len(news), "freshness": {"status": status, "max_age_seconds": round(stale_seconds, 1) if stale_seconds is not None else None},
        "provider_health": provider_health,
        "high_impact_events": [row for row in events if str(row.get("impact") or "").lower() in {"high", "very_high", "important", "خیلی مهم", "مهم"}][:20],
        "latest_news": sorted(news, key=lambda row: str(row.get("published_at") or row.get("created_at") or ""), reverse=True)[:20],
        "policy": cost_policy(db), "method": "cached_free_sources_only", "generated_at": utc_iso(),
    }


def register_publisher_channel(db: dict[str, Any], actor_id: int | str, *, chat_id: str, title: str, language: str = "fa", channel_type: str = "public", template_key: str = "signal_public", approval_required: bool = True) -> dict[str, Any]:
    _require(db, "multi_channel_publisher")
    ensure_platform_expansion(db)
    chat = str(chat_id or "").strip()
    if not chat or len(chat) > 100:
        raise ValueError("CHANNEL_ID_REQUIRED")
    existing = next((row for row in db["publisher_channels"] if str(row.get("chat_id")) == chat), None)
    row = existing or {"id": next_id(db, "publisher_channel"), "chat_id": chat, "created_at": utc_iso()}
    row.update({"title": str(title or chat)[:100], "language": "en" if str(language).lower() == "en" else "fa", "channel_type": str(channel_type)[:30], "template_key": str(template_key)[:50], "approval_required": bool(approval_required), "enabled": True, "updated_at": utc_iso(), "updated_by": str(actor_id)})
    if not existing: db["publisher_channels"].append(row)
    _audit(db, "publisher.channel_upsert", actor_id, {"channel_id": row["id"], "chat_id": chat})
    return dict(row)


def enqueue_publication(db: dict[str, Any], actor_id: int | str, *, channel_ids: list[int | str], content: str, content_type: str = "text", scheduled_at: str | None = None, reference_type: str = "", reference_id: str | int | None = None) -> list[dict[str, Any]]:
    _require(db, "multi_channel_publisher")
    ensure_platform_expansion(db)
    text = str(content or "").strip()
    if not text:
        raise ValueError("CONTENT_REQUIRED")
    valid = {int(row["id"]): row for row in db["publisher_channels"] if row.get("enabled", True)}
    created: list[dict[str, Any]] = []
    for raw_id in channel_ids[:50]:
        cid = int(raw_id)
        channel = valid.get(cid)
        if not channel:
            continue
        status = "awaiting_approval" if bool(channel.get("approval_required", True)) else "queued"
        row = {"id": next_id(db, "publisher_job"), "channel_id": cid, "chat_id": channel["chat_id"], "content": text[:4096], "content_type": str(content_type)[:20], "status": status, "scheduled_at": scheduled_at, "reference_type": str(reference_type)[:30], "reference_id": str(reference_id or ""), "attempts": 0, "created_by": str(actor_id), "created_at": utc_iso(), "updated_at": utc_iso()}
        db["publisher_queue"].append(row); created.append(dict(row))
    if not created: raise ValueError("NO_VALID_CHANNEL")
    _audit(db, "publisher.enqueue", actor_id, {"jobs": [row["id"] for row in created]})
    return created


def set_publication_status(db: dict[str, Any], actor_id: int | str, job_id: int | str, status: str) -> dict[str, Any]:
    _require(db, "multi_channel_publisher")
    allowed = {"awaiting_approval", "queued", "processing", "sent", "failed", "cancelled"}
    if status not in allowed: raise ValueError("INVALID_PUBLICATION_STATUS")
    row = next((item for item in db.get("publisher_queue", []) if int(item.get("id", 0) or 0) == int(job_id)), None)
    if not row: raise ValueError("PUBLICATION_NOT_FOUND")
    row["status"] = status; row["updated_at"] = utc_iso(); row["updated_by"] = str(actor_id)
    _audit(db, "publisher.status", actor_id, {"job_id": row["id"], "status": status})
    return dict(row)


def create_partner(db: dict[str, Any], actor_id: int | str, *, name: str, channel: str = "", commission_mode: str = "points", commission_value: float = 0.0) -> dict[str, Any]:
    _require(db, "partner_hub")
    ensure_platform_expansion(db)
    if commission_mode not in {"points", "percent", "fixed_internal"}: raise ValueError("INVALID_COMMISSION_MODE")
    value = max(0.0, min(float(commission_value), 1000000.0))
    code = secrets.token_urlsafe(6).replace("-", "").replace("_", "")[:10].upper()
    row = {"id": next_id(db, "partner"), "name": str(name or "").strip()[:100], "channel": str(channel)[:100], "code": code, "commission_mode": commission_mode, "commission_value": value, "status": "active", "created_by": str(actor_id), "created_at": utc_iso()}
    if len(row["name"]) < 2: raise ValueError("PARTNER_NAME_REQUIRED")
    db["partners"].append(row); _audit(db, "partner.create", actor_id, {"partner_id": row["id"]})
    return dict(row)


def record_partner_event(db: dict[str, Any], *, code: str, event_type: str, user_id: int | str, amount: float = 0.0, fingerprint: str = "") -> dict[str, Any]:
    _require(db, "partner_hub")
    ensure_platform_expansion(db)
    partner = next((row for row in db["partners"] if str(row.get("code")) == str(code).upper() and row.get("status") == "active"), None)
    if not partner: raise ValueError("PARTNER_NOT_FOUND")
    if event_type not in {"view", "join", "trial", "purchase"}: raise ValueError("INVALID_PARTNER_EVENT")
    uid = str(user_id)
    duplicate = any(str(row.get("partner_id")) == str(partner["id"]) and str(row.get("user_id")) == uid and str(row.get("event_type")) == event_type for row in db["partner_events"][-10000:])
    row = {"id": next_id(db, "partner_event"), "partner_id": partner["id"], "user_id": uid, "event_type": event_type, "amount": max(0.0, float(amount)), "fingerprint": hashlib.sha256(str(fingerprint).encode()).hexdigest()[:16] if fingerprint else "", "duplicate": duplicate, "created_at": utc_iso()}
    db["partner_events"].append(row)
    if event_type == "purchase" and not duplicate:
        mode, value = partner["commission_mode"], float(partner["commission_value"])
        commission = value if mode in {"points", "fixed_internal"} else max(0.0, float(amount)) * value / 100
        db["partner_ledger"].append({"id": next_id(db, "partner_ledger"), "partner_id": partner["id"], "event_id": row["id"], "amount": round(commission, 2), "unit": "points" if mode == "points" else "internal_credit", "status": "pending", "created_at": utc_iso()})
    return dict(row)


def partner_dashboard(db: dict[str, Any]) -> dict[str, Any]:
    _require(db, "partner_hub")
    ensure_platform_expansion(db)
    result = []
    for partner in db["partners"]:
        events = [row for row in db["partner_events"] if int(row.get("partner_id", 0) or 0) == int(partner["id"]) and not row.get("duplicate")]
        counts = Counter(str(row.get("event_type")) for row in events)
        ledger = [row for row in db["partner_ledger"] if int(row.get("partner_id", 0) or 0) == int(partner["id"])]
        result.append({**dict(partner), "events": dict(counts), "conversion_rate": round(counts.get("purchase", 0) / max(1, counts.get("join", 0)) * 100, 2), "pending_credits": round(sum(float(row.get("amount") or 0) for row in ledger if row.get("status") == "pending"), 2)})
    return {"items": result, "generated_at": utc_iso()}


def verified_public_performance(db: dict[str, Any], *, persist: bool = False, actor_id: int | str = "system") -> dict[str, Any]:
    _require(db, "public_performance")
    ensure_platform_expansion(db)
    rows = [row for row in db.get("signals", []) if isinstance(row, dict)]
    final = [(row, _signal_result_r(row)) for row in rows]
    final = [(row, value) for row, value in final if value is not None]
    values = [float(value) for _, value in final]
    wins = sum(1 for value in values if value > 0); losses = sum(1 for value in values if value < 0)
    revisions = sum(max(0, int(row.get("revision", row.get("version", 1)) or 1) - 1) for row, _ in final)
    payload = {"total": len(values), "wins": wins, "losses": losses, "breakeven": len(values) - wins - losses, "win_rate": round(wins / max(1, wins + losses) * 100, 2), "net_r": round(sum(values), 4), "average_r": round(sum(values) / max(1, len(values)), 4), "max_win_r": round(max(values), 4) if values else 0.0, "max_loss_r": round(min(values), 4) if values else 0.0, "revision_count": revisions, "generated_at": utc_iso(), "methodology": "finalized_signals_only_v1"}
    digest = hashlib.sha256(json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")).hexdigest()
    result = {**payload, "evidence_hash": digest}
    if persist:
        db["public_performance_snapshots"].append({"id": next_id(db, "public_performance"), **result, "created_by": str(actor_id)})
        db["public_performance_snapshots"] = db["public_performance_snapshots"][-1000:]
        _audit(db, "performance.snapshot", actor_id, {"evidence_hash": digest})
    return result


def render_content(db: dict[str, Any], actor_id: int | str, template_key: str, values: dict[str, Any]) -> dict[str, Any]:
    _require(db, "content_factory")
    ensure_platform_expansion(db)
    template = next((row for row in db["content_templates"] if row.get("key") == template_key and row.get("enabled", True)), None)
    if not template: raise ValueError("CONTENT_TEMPLATE_NOT_FOUND")
    safe_values = defaultdict(str, {str(k): str(v)[:1000] for k, v in values.items()})
    class SafeMap(defaultdict):
        def __missing__(self, key: str) -> str: return "{" + key + "}"
    output = str(template["body"]).format_map(SafeMap(str, safe_values))
    row = {"id": next_id(db, "content_output"), "template_key": template_key, "content": output[:4096], "values": dict(safe_values), "status": "draft", "created_by": str(actor_id), "created_at": utc_iso()}
    db["content_outputs"].append(row); db["content_outputs"] = db["content_outputs"][-5000:]
    return dict(row)


def classify_business_message(db: dict[str, Any], user_id: int | str, text: str, *, source: str = "telegram") -> dict[str, Any]:
    _require(db, "business_inbox")
    ensure_platform_expansion(db)
    clean = str(text or "").strip()
    lower = clean.casefold()
    category = "general"
    priority = "normal"
    if any(token in lower for token in ("پرداخت", "واریز", "رسید", "payment", "buy", "خرید")): category = "sales"
    elif any(token in lower for token in ("خطا", "کار نمی", "مشکل", "error", "support")): category = "support"
    elif any(token in lower for token in ("همکاری", "تبلیغ", "partner", "affiliate")): category = "partnership"
    if any(token in lower for token in ("فوری", "urgent", "بلوکه", "هک", "سرقت")): priority = "urgent"
    row = {"id": next_id(db, "business_message"), "user_id": str(user_id), "source": str(source)[:30], "text": clean[:4000], "category": category, "priority": priority, "status": "new", "created_at": utc_iso()}
    db["business_inbox"].append(row); db["business_inbox"] = db["business_inbox"][-10000:]
    return dict(row)


def update_device_state(db: dict[str, Any], user_id: int | str, device_id: str, state: dict[str, Any]) -> dict[str, Any]:
    _require(db, "miniapp_next")
    ensure_platform_expansion(db)
    device = re.sub(r"[^A-Za-z0-9_.:-]", "", str(device_id or ""))[:100]
    if not device: raise ValueError("DEVICE_ID_REQUIRED")
    allowed = {"offline_drafts", "last_sync_cursor", "theme", "language", "compact_mode", "home_shortcut", "notification_token_hash"}
    clean = {key: value for key, value in state.items() if key in allowed}
    clean["updated_at"] = utc_iso()
    db["miniapp_device_state"].setdefault(str(user_id), {})[device] = clean
    return dict(clean)


def register_webhook(db: dict[str, Any], actor_id: int | str, *, url: str, events: list[str], secret: str | None = None) -> dict[str, Any]:
    _require(db, "developer_platform")
    ensure_platform_expansion(db)
    parsed = urlparse(str(url or "").strip())
    if parsed.scheme != "https" or not parsed.netloc or parsed.hostname in {"localhost", "127.0.0.1", "::1"}:
        raise ValueError("HTTPS_PUBLIC_WEBHOOK_REQUIRED")
    event_list = sorted({str(item)[:80] for item in events if str(item).strip()})[:50]
    if not event_list: raise ValueError("WEBHOOK_EVENTS_REQUIRED")
    token = secret or secrets.token_urlsafe(32)
    row = {"id": next_id(db, "developer_webhook"), "url": str(url)[:500], "events": event_list, "secret_hash": hashlib.sha256(token.encode()).hexdigest(), "secret_preview": token[:4] + "…" + token[-4:], "enabled": True, "delivery_enabled": False, "created_by": str(actor_id), "created_at": utc_iso()}
    db["developer_webhooks"].append(row); _audit(db, "webhook.register", actor_id, {"webhook_id": row["id"]})
    return {**dict(row), "secret": token}


def queue_webhook_event(db: dict[str, Any], event: str, payload: dict[str, Any]) -> list[dict[str, Any]]:
    _require(db, "developer_platform")
    ensure_platform_expansion(db)
    created = []
    body = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    for hook in db["developer_webhooks"]:
        if not hook.get("enabled", True) or event not in hook.get("events", []): continue
        row = {"id": next_id(db, "webhook_outbox"), "webhook_id": hook["id"], "event": str(event)[:80], "payload": payload, "payload_sha256": hashlib.sha256(body.encode()).hexdigest(), "status": "held" if not hook.get("delivery_enabled", False) else "queued", "attempts": 0, "created_at": utc_iso()}
        db["webhook_outbox"].append(row); created.append(dict(row))
    return created


def webhook_signature(secret: str, payload: dict[str, Any]) -> str:
    body = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hmac.new(str(secret).encode("utf-8"), body, hashlib.sha256).hexdigest()


def create_workspace(db: dict[str, Any], actor_id: int | str, *, name: str, slug: str, brand_name: str = "SENTINEL") -> dict[str, Any]:
    _require(db, "workspace_saas")
    ensure_platform_expansion(db)
    clean_slug = re.sub(r"[^a-z0-9-]", "", str(slug or "").lower())[:50].strip("-")
    if len(clean_slug) < 3: raise ValueError("WORKSPACE_SLUG_REQUIRED")
    if any(row.get("slug") == clean_slug for row in db["workspaces"]): raise ValueError("WORKSPACE_SLUG_EXISTS")
    row = {"id": next_id(db, "workspace"), "name": str(name or "").strip()[:100], "slug": clean_slug, "brand_name": str(brand_name or "SENTINEL")[:100], "owner_id": str(actor_id), "status": "active", "data_namespace": f"ws:{clean_slug}", "created_at": utc_iso()}
    if len(row["name"]) < 2: raise ValueError("WORKSPACE_NAME_REQUIRED")
    db["workspaces"].append(row); db["workspace_memberships"].append({"workspace_id": row["id"], "user_id": str(actor_id), "role": "owner", "created_at": utc_iso()})
    _audit(db, "workspace.create", actor_id, {"workspace_id": row["id"], "slug": clean_slug})
    return dict(row)


def workspace_bucket(db: dict[str, Any], workspace_id: int | str, bucket: str) -> dict[str, Any] | list[Any]:
    ensure_platform_expansion(db)
    workspace = next((row for row in db["workspaces"] if int(row.get("id", 0) or 0) == int(workspace_id)), None)
    if not workspace: raise ValueError("WORKSPACE_NOT_FOUND")
    safe_bucket = re.sub(r"[^a-z0-9_]", "", str(bucket).lower())[:50]
    if not safe_bucket: raise ValueError("WORKSPACE_BUCKET_REQUIRED")
    root = db.setdefault("workspace_data", {}).setdefault(str(workspace_id), {})
    return root.setdefault(safe_bucket, {})


def platform_dashboard(db: dict[str, Any]) -> dict[str, Any]:
    ensure_platform_expansion(db)
    matrix = platform_matrix(db)
    return {
        "matrix": matrix,
        "paper": {"accounts": len(db["paper_accounts"]), "open_trades": sum(1 for row in db["paper_trades"] if row.get("status") == "open")},
        "publisher": {"channels": len(db["publisher_channels"]), "queued": sum(1 for row in db["publisher_queue"] if row.get("status") in {"queued", "awaiting_approval"})},
        "partners": {"active": sum(1 for row in db["partners"] if row.get("status") == "active"), "events": len(db["partner_events"])},
        "developer": {"webhooks": len(db["developer_webhooks"]), "held_events": sum(1 for row in db["webhook_outbox"] if row.get("status") == "held")},
        "workspaces": len(db["workspaces"]),
        "cost_policy": cost_policy(db),
        "generated_at": utc_iso(),
    }
