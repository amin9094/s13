"""Gift entitlements use existing VIP plans, manual orders, and activation."""
from __future__ import annotations
import secrets
from datetime import timedelta
from core.db import next_id
from core.domain import activate_vip, audit
from core.utils import utc_iso, utc_now, parse_dt
from modules.sales_growth import get_vip_plan
from modules.advanced_features import record_user_reward
from modules.admin_access import has_permission, PERMISSION_PAYMENT_RECEIPT_APPROVE, PERMISSION_PAYMENT_VIP_ACTIVATE


def create_gift(db, purchaser, plan_id, recipient=None, request_key=''):
    if request_key:
        old = next((g for g in db.get('vip_gifts', {}).values() if g.get('request_key') == request_key and str(g['purchaser_user_id']) == str(purchaser)), None)
        if old: return dict(old)
    plan = get_vip_plan(db, plan_id)
    if not plan or not plan.get('active', True): raise ValueError('پلن فعال نیست.')
    if recipient and (not str(recipient).isdigit() or str(recipient) not in db.get('users', {})):
        raise ValueError('گیرنده باید ابتدا ربات را استارت کند؛ شناسه عددی او را وارد کنید.')
    if not 0 <= int(plan.get('price', 0)) <= 10**12: raise ValueError('قیمت پلن نامعتبر است.')
    gid = str(next_id(db, 'vip_gift'))
    row = {'gift_id': gid, 'purchaser_user_id': str(purchaser), 'recipient_user_id': str(recipient or ''),
           'plan_id': plan['id'], 'duration_days': int(plan['duration_days']), 'price': int(plan['price']),
           'gift_token': secrets.token_urlsafe(24), 'status': 'pending_payment', 'created_at': utc_iso(),
           'expires_at': utc_iso(utc_now() + timedelta(days=365)), 'paid_at': None, 'redeemed_at': None,
           'request_key': request_key, 'order_id': None}
    db.setdefault('vip_gifts', {})[gid] = row
    audit(db, purchaser, 'gift_created', gid)
    return dict(row)


def approve_gift_order(db, order_id, actor):
    if not all(has_permission(db, actor, p) for p in (PERMISSION_PAYMENT_RECEIPT_APPROVE, PERMISSION_PAYMENT_VIP_ACTIVATE)):
        raise PermissionError('مجوز تأیید پرداخت و فعال‌سازی لازم است.')
    from core.domain import find_vip_order, consume_discount
    from modules.vip_order_state import assert_reviewable
    order = find_vip_order(db, order_id)
    gift = db.get('vip_gifts', {}).get(str((order or {}).get('gift_id')))
    if not order or not gift: raise ValueError('سفارش هدیه پیدا نشد.')
    if order.get('status') == 'approved': return dict(gift)
    if order.get('status') != 'pending': raise ValueError('سفارش قابل تأیید نیست.')
    assert_reviewable(order)
    if gift['status'] != 'pending_payment': raise ValueError('وضعیت هدیه نامعتبر است.')
    gift.update(status='paid', paid_at=utc_iso())
    order.update(status='approved', approved_by=int(actor), approved_at=utc_iso(), gift_id=gift['gift_id'])
    consume_discount(db, order)
    from core.domain import record_vip_purchase_rewards
    record_vip_purchase_rewards(db, order)
    audit(db, actor, 'gift_payment_approved', gift['gift_id'])
    return dict(gift)


def redeem_gift(db, user_id, token):
    row = next((g for g in db.get('vip_gifts', {}).values() if secrets.compare_digest(str(g.get('gift_token', '')), str(token))), None)
    if not row: raise ValueError('کد هدیه معتبر نیست.')
    uid = str(user_id)
    if row['status'] == 'redeemed':
        if row.get('redeemed_by') == uid: return dict(row)
        raise ValueError('این هدیه قبلاً استفاده شده است.')
    if row['status'] not in {'paid', 'active'}: raise ValueError('هدیه هنوز فعال نیست.')
    expiry = parse_dt(row.get('expires_at'))
    if not expiry or expiry <= utc_now(): raise ValueError('مهلت هدیه تمام شده است.')
    if row.get('recipient_user_id') and row['recipient_user_id'] != uid: raise PermissionError('این هدیه متعلق به کاربر دیگری است.')
    vip = activate_vip(db, uid, row['duration_days'], source_order_id=f"gift:{row['gift_id']}")
    row.update(status='redeemed', redeemed_by=uid, redeemed_at=utc_iso(), vip_expires_at=vip['expires_at'])
    record_user_reward(db, uid, 'هدیه VIP', reward_type='vip_days', detail=f"{row['duration_days']} روز | {vip['expires_at']}",
                       source='gift_vip', status='delivered', reference_id=row['gift_id'])
    audit(db, uid, 'gift_redeemed', row['gift_id'])
    return dict(row)


def gift_for_owner(db, user_id, gift_id):
    row = db.get('vip_gifts', {}).get(str(gift_id))
    if not row or str(row['purchaser_user_id']) != str(user_id): raise PermissionError('هدیه در دسترس نیست.')
    return dict(row)


def reconcile_gifts(db):
    orders = {str(o.get('order_id')):o for o in db.get('vip_orders', [])}
    now = utc_now()
    for row in db.get('vip_gifts', {}).values():
        order = orders.get(str(row.get('order_id')))
        expiry = parse_dt(row.get('expires_at'))
        if row['status'] == 'pending_payment' and order and order.get('status') in {'rejected','cancelled'}:
            row['status']='cancelled'
        elif row['status'] in {'paid','active','pending_payment'} and expiry and expiry <= now:
            row['status']='expired'
        if row['status'] in {'paid','active'} and row.get('recipient_user_id'):
            redeem_gift(db,row['recipient_user_id'],row['gift_token'])
    return True
