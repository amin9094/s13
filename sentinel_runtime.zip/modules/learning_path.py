"""Version-pinned learning; reading, passing quizzes and graduation are distinct."""
from copy import deepcopy
import re
from core.utils import utc_iso

CONTENT_KEYS=('category','course','chapter','title','text','attachments','quiz','prerequisite_ids','position','duration_minutes')


def snapshot(lesson):return {key:deepcopy(lesson.get(key)) for key in CONTENT_KEYS}


def ensure_versions(lesson):
    revision=int(lesson.setdefault('content_revision',1))
    lesson.setdefault('content_versions',{}).setdefault(str(revision),snapshot(lesson))


def record_revision(lesson):
    ensure_versions(lesson);revision=int(lesson['content_revision'])
    current=snapshot(lesson)
    if lesson['content_versions'][str(revision)]!=current:
        revision+=1;lesson['content_revision']=revision;lesson['content_versions'][str(revision)]=current


def natural_key(value):
    text=str(value or '').translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩','01234567890123456789'))
    return tuple((1,int(part)) if part.isdigit() else (0,part.casefold()) for part in re.split(r'(\d+)',text))


def lesson_for_user(db,uid,lesson_id,*,pin=False):
    from modules.education import find_lesson
    lesson=find_lesson(db,lesson_id)
    if not lesson:return None
    uid=str(uid);access=db.get('education_access',{}).get(uid,{}).get(str(lesson_id),{})
    progress=db.get('education_progress',{}).get(uid,{}).get(str(lesson_id),{})
    revision=(access.get('lesson_revision') if isinstance(access,dict) else None) or progress.get('lesson_revision') or lesson['content_revision']
    result=deepcopy(lesson)
    result.update(deepcopy(lesson.get('content_versions',{}).get(str(revision),{})))
    result['content_revision']=int(revision)
    if pin:
        row=db.setdefault('education_progress',{}).setdefault(uid,{}).setdefault(str(lesson_id),{})
        row.setdefault('lesson_revision',int(revision));row['last_opened_at']=utc_iso()
        db.setdefault('education_learning_state',{}).setdefault(uid,{})['last_lesson_id']=str(lesson_id)
    return result


def require_access(db,uid,lesson):
    from modules.admin_control_center import is_module_enabled
    from modules.management_suite import has_education_access
    from core.domain import is_vip
    if (not is_module_enabled(db,'edu') or not lesson or lesson.get('status','published')!='published' or not lesson.get('active',True)
            or not has_education_access(db,uid,lesson) or lesson.get('vip') and not is_vip(db,uid)):
        raise ValueError('درس در دسترس نیست')


def validate_learning_config(db,lesson):
    from modules.education import find_lesson
    ids=[str(i) for i in lesson.get('prerequisite_ids',[])]
    if len(ids)!=len(set(ids)) or str(lesson['id']) in ids:raise ValueError('پیش‌نیاز نامعتبر است')
    def walk(identifier,trail):
        if identifier in trail:raise ValueError('پیش‌نیازها حلقه دارند')
        prior=find_lesson(db,identifier)
        if not prior:raise ValueError('درس پیش‌نیاز پیدا نشد')
        for linked in prior.get('prerequisite_ids',[]):walk(str(linked),trail|{identifier})
    for identifier in ids:walk(identifier,{str(lesson['id'])})
    quiz=lesson.get('quiz',[])
    if not isinstance(quiz,list) or len(quiz)>30:raise ValueError('آزمون نامعتبر است')
    for q in quiz:
        if (not isinstance(q,dict) or not str(q.get('question','')).strip() or not isinstance(q.get('options'),list)
                or not 2<=len(q['options'])<=6 or not all(isinstance(x,str) and x.strip() for x in q['options'])
                or type(q.get('correct')) is not int or not 0<=q['correct']<len(q['options'])):
            raise ValueError('هر سؤال باید متن، ۲ تا ۶ گزینه و شمارهٔ گزینهٔ درست داشته باشد')


def assess(db,uid,lesson_id,answers):
    lesson=lesson_for_user(db,uid,lesson_id,pin=False);require_access(db,uid,lesson)
    if not all(db.get('education_progress',{}).get(str(uid),{}).get(str(k),{}).get('passed') for k in lesson.get('prerequisite_ids',[])):
        raise ValueError('ابتدا پیش‌نیازها را با موفقیت بگذرانید')
    quiz=lesson.get('quiz',[])
    if len(answers)!=len(quiz) or any(type(v) is not int for v in answers):raise ValueError('پاسخ تمام سؤال‌ها لازم است')
    correct=sum(q['correct']==answer for q,answer in zip(quiz,answers))
    percent=correct*100/len(quiz) if quiz else 100
    row=db.setdefault('education_progress',{}).setdefault(str(uid),{}).setdefault(str(lesson_id),{})
    if row.get('lesson_revision') and row['lesson_revision']!=lesson['content_revision']:raise ValueError('نسخهٔ درس تغییر کرده است')
    row['lesson_revision']=lesson['content_revision']
    row.setdefault('assessment_attempts',[]).append({'at':utc_iso(),'correct':correct,'total':len(quiz),'score':percent,'revision':lesson['content_revision']})
    row['assessment_attempts']=row['assessment_attempts'][-100:]
    if percent==100:
        first=not row.get('passed');row.update(passed=True,passed_at=utc_iso())
        if first:
            from modules.user_intelligence import record_user_activity
            record_user_activity(db,uid,'education_assessment_passed',source='education',detail=str(lesson_id),
                                 metadata={'lesson_revision':lesson['content_revision'],'operation_id':f'lesson:{lesson_id}:user:{uid}:revision:{lesson["content_revision"]}'})
    return {'score':percent,'passed':bool(row.get('passed')),'revision':lesson['content_revision']}


def recommendations(db,uid):
    """Explainable suggestions only from recorded learning/risk actions."""
    from modules.education import visible_lessons
    state=db.get('education_learning_state',{}).get(str(uid),{})
    selected=set(state.get('topics',[]))
    # Deliberately do not infer ability from win/loss.
    for event in db.get('user_activity',[]):
        if str(event.get('user_id'))==str(uid) and event.get('action') in {'risk_calculator_used','risk_plan_saved'}:selected.add('ریسک')
    rows=[]
    for lesson in visible_lessons(db):
        try:require_access(db,uid,lesson)
        except ValueError:continue
        if db.get('education_progress',{}).get(str(uid),{}).get(str(lesson['id']),{}).get('passed'):continue
        reason=next((topic for topic in sorted(selected) if topic in str(lesson.get('title',''))+' '+str(lesson.get('category',''))),None)
        if reason:rows.append({'lesson_id':lesson['id'],'title':lesson['title'],'reason':'موضوع انتخابی یا اقدام ثبت‌شده: '+reason})
    return {'items':rows[:10],'last_lesson_id':state.get('last_lesson_id'),'topics':sorted(selected)}
