"""Bot API 10.2+ slideshows through the pinned PTB request transport.

PTB 22.8 has no typed RichMessage method. This adapter keeps its bounded HTTP
transport, exceptions and multipart uploads instead of adding a second client.
"""
from __future__ import annotations

import asyncio
import copy
import json
from pathlib import Path
from typing import Any

from telegram import InputFile, Message
from telegram.error import BadRequest, TelegramError

from core.async_runtime import run_blocking


class UncertainSignalReceipt(TelegramError):
    """The send was attempted, but its response cannot prove the receipt."""


def validate_message_receipt(message: Any) -> None:
    identifier = getattr(message, 'message_id', None)
    if type(identifier) is not int or identifier <= 0:
        raise UncertainSignalReceipt('invalid message receipt')


def rich_signal_html(text: str, slide_count: int) -> str:
    images = "".join(f'<img src="tg://photo?id=slide{index}"/>' for index in range(slide_count))
    paragraphs = "".join(f"<p>{line}</p>" for line in str(text).splitlines() if line.strip())
    return f"<tg-slideshow>{images}</tg-slideshow>{paragraphs}"


def rich_api_unavailable(exc: BadRequest) -> bool:
    message = str(exc).lower()
    return any(value in message for value in ("method not found", "unknown method", "rich messages are not supported"))


def _response_photo_ids(raw: dict[str, Any]) -> list[str]:
    result: list[str] = []

    def walk(value: Any) -> None:
        if isinstance(value, dict):
            if value.get("type") == "photo" and isinstance(value.get("photo"), list):
                photos = [photo for photo in value["photo"] if isinstance(photo, dict) and photo.get("file_id")]
                if photos:
                    result.append(str(max(photos, key=lambda photo: int(photo.get("width", 0)) * int(photo.get("height", 0)))["file_id"]))
            for key, child in value.items():
                if key != "photo":
                    walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)

    walk(raw.get("rich_message", {}))
    return result


async def _rich_request(bot: Any, endpoint: str, data: dict[str, Any]) -> dict[str, Any]:
    # No retry after an ambiguous timeout: Telegram might already have posted.
    result = await asyncio.wait_for(
        bot._post(endpoint, data=data, read_timeout=30, write_timeout=30, connect_timeout=10, pool_timeout=10),
        timeout=50,
    )
    if not isinstance(result, dict) or type(result.get("message_id")) is not int or result['message_id'] <= 0:
        raise UncertainSignalReceipt("invalid rich message response")
    return result


async def send_signal_slideshow(bot: Any, chat_id: int, text: str, charts: list[str], *, image_path: str | None = None) -> tuple[Message, list[dict[str, Any]]]:
    media: list[dict[str, Any]] = []
    data: dict[str, Any] = {"chat_id": chat_id}
    if image_path:
        payload = await run_blocking(Path(image_path).read_bytes)
        data["sentinel_card"] = InputFile(payload, filename="sentinel-card.png")
        media.append({"id": "slide0", "media": {"type": "photo", "media": "attach://sentinel_card"}})
    for index,file_id in enumerate(charts):
        if isinstance(file_id,InputFile):
            name=f'sentinel_chart_{index}'
            data[name]=file_id
            file_id='attach://'+name
        media.append({"id": f"slide{len(media)}", "media": {"type": "photo", "media": file_id}})
    if len(media) < 2:
        raise ValueError("slideshow requires at least two slides")
    data["rich_message"] = json.dumps({"html": rich_signal_html(text, len(media)), "media": media, "is_rtl": True}, ensure_ascii=False)
    raw = await _rich_request(bot, "sendRichMessage", data)
    photo_ids = _response_photo_ids(raw)
    reusable = copy.deepcopy(media)
    for index, item in enumerate(reusable):
        if index < len(photo_ids):
            item["media"]["media"] = photo_ids[index]
        elif str(item["media"]["media"]).startswith("attach://"):
            # Editing must render a fresh template if a server omitted its ID.
            item["media"]["media"] = ""
    return Message.de_json(raw, bot), reusable


async def edit_signal_slideshow(bot: Any, chat_id: int, message_id: int, text: str, media: list[dict[str, Any]], *, image_path: str | None = None, has_template: bool = False) -> None:
    reusable = copy.deepcopy(media)
    data: dict[str, Any] = {"chat_id": chat_id, "message_id": message_id}
    if has_template and image_path:
        data["sentinel_card"] = InputFile(await run_blocking(Path(image_path).read_bytes), filename="sentinel-card.png")
        reusable[0]["media"]["media"] = "attach://sentinel_card"
    if not reusable or any(not item.get("media", {}).get("media") for item in reusable):
        raise TelegramError("slideshow media unavailable; rebuild required")
    data["rich_message"] = json.dumps({"html": rich_signal_html(text, len(reusable)), "media": reusable, "is_rtl": True}, ensure_ascii=False)
    await _rich_request(bot, "editMessageText", data)
