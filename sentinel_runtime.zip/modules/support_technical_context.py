"""Explicit opt-in, tiny allow-list. No URL, token, header, device ID or account data."""
import re
from pathlib import Path


def sanitize(opt_in,raw):
    if opt_in is not True:return None
    if not isinstance(raw,dict):raise ValueError('TECHNICAL_CONTEXT_INVALID')
    result={'consent':True,'version':(Path(__file__).resolve().parents[1]/'VERSION').read_text().strip()}
    if raw.get('language') in {'fa','en'}:result['language']=raw['language']
    if raw.get('viewport') in {'mobile','tablet','desktop'}:result['viewport']=raw['viewport']
    page=raw.get('page')
    if isinstance(page,str) and re.fullmatch('[a-z_]{1,32}',page):result['page']=page
    code=raw.get('error_code')
    if isinstance(code,str) and re.fullmatch('[A-Z_]{3,64}',code):result['error_code']=code
    return result
