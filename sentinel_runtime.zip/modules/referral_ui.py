"""Human-readable referral stages over the canonical milestone ledger."""

TRIGGER_LABELS = {
    "referrals_joined": "دعوت معتبر",
    "referrals_purchased": "خریدار تأییدشده",
    "referral_revenue": "تومان خرید تأییدشده",
}
REWARD_LABELS = {
    "points": "امتیاز",
    "vip_days": "روز VIP",
    "discount_coupon": "درصد کد تخفیف",
    "reward_item": "جایزهٔ انتخابی",
}
LOCKED_FIELDS = frozenset({"trigger_type", "required_count", "reward_type", "reward_value", "repeatable", "max_claims"})
CHOICES = {
    "trigger_type": TRIGGER_LABELS,
    "reward_type": REWARD_LABELS,
    "enabled": {"1": "فعال", "0": "غیرفعال"},
    "repeatable": {"1": "بله، قابل تکرار", "0": "خیر، فقط یک‌بار"},
}


def reward_label(db, row):
    value = row.get("reward_value", 0)
    kind = row.get("reward_type")
    if kind == "reward_item":
        return next(
            (
                str(item.get("name"))
                for item in db.get("settings", {}).get("rewardItems", [])
                if str(item.get("id")) == str(value)
            ),
            "جایزهٔ انتخابی",
        )
    return f"{int(value):,} {REWARD_LABELS.get(kind, 'پاداش')}"


def has_claims(db, mid):
    return any(str(row.get("milestone_id")) == str(mid) for row in db.get("referral_milestone_claims", {}).values())


def progress_line(row):
    goal = (
        int(row["required_count"]) * (int(row.get("claimed", 0)) + 1)
        if row.get("repeatable")
        else int(row["required_count"])
    )
    done = int(row.get("progress", 0))
    filled = min(10, max(0, int(done * 10 / max(1, goal))))
    return "🟩" * filled + "⬜" * (10 - filled) + f"  {done:,} / {goal:,}"
