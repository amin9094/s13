"""Human-review plans reuse strategy geometry without certifying native execution."""
from dataclasses import dataclass, replace

from modules.strategies.common import Context
from modules.strategies.observations import ObservationContext


@dataclass(frozen=True)
class AdminReviewContext(Context):
    review_only: bool = True

    def validate(self):
        ObservationContext(self.candles,self.cutoff_ms,self.parameters,self.engine_parameters).validate()
        if not self.review_only or self.tick_size <= 0 or self.spread < 0:
            raise ValueError('ADMIN_REVIEW_CONTEXT_INVALID')
        flags={'AGGREGATED_INDICATIVE_HISTORY_NO_EXECUTION_QUOTE','UPSTREAM_PER_BAR_PROVENANCE_UNVERIFIED','REPORTED_TICK_VOLUME_UNVERIFIED'}
        if any(b.provider!='biquote' or b.product!='indicative' or set(b.quality_flags)!=flags for b in self.candles):
            raise ValueError('ADMIN_REVIEW_SOURCE_INVALID')
        quote=self.current_quote
        if (quote is None or not 0<=self.cutoff_ms-quote.event_ms<=5000
            or (quote.symbol,quote.provider,quote.venue,quote.product)!=(self.candles[-1].symbol,'biquote',self.candles[-1].venue,'indicative')):
            raise ValueError('ADMIN_REVIEW_FRESH_QUOTE_REQUIRED')


def evaluate_review_proposals(context):
    from modules.strategies.indicators.engine import IndicatorsOnly
    from modules.strategies.sweep_fvg.engine import SweepCHoCHFVG
    from modules.strategies.order_block.engine import OrderBlockVolume
    from modules.strategies.fibonacci_pullback.engine import FibonacciPullback
    from modules.strategies.fibonacci.engine import Fibonacci

    context.validate()
    profiles=dict(context.engine_parameters)
    guard_parameters=profiles.get('sweep_fvg',context.parameters)
    rows=[];seen=set()
    for engine in (IndicatorsOnly(),SweepCHoCHFVG(),OrderBlockVolume(),FibonacciPullback()):
        selected=replace(context,parameters=profiles.get(engine.name,context.parameters),
                         liquidity_parameters=guard_parameters)
        for row in engine.evaluate(selected):
            row.setdefault('symbol',context.candles[-1].symbol)
            row.setdefault('timeframe',context.candles[-1].timeframe)
            row.setdefault('available_ms',context.cutoff_ms)
            draft=row.get('draft_plan')
            if draft:
                if draft['setup_id'] in seen:continue
                seen.add(draft['setup_id'])
                supports=Fibonacci().evaluate(selected,[row])
                row['fibonacci_confirmation']=supports[0] if supports else None
                # Lock the same optional geometry into the review snapshot so
                # its detail view/chart cannot silently recalculate another wave.
                row['draft_plan']={**draft,'evidence':[*draft['evidence'],{
                    'kind':'shared_fibonacci_confirmation','available_ms':context.cutoff_ms,
                    'detail':row['fibonacci_confirmation']} ]}
                row['quality_disclosure']={
                    'mode':'HUMAN_REVIEW_ONLY','provider':'biquote','product':'indicative',
                    'volume':'REPORTED_TICK_ACTIVITY_NOT_TRADED_VOLUME',
                    'price_quantum':'OBSERVED_DECIMAL_QUANTUM_NOT_BROKER_TICK_SIZE',
                    'native_broker_identity_verified':False,'native_first_visit_proven':False,
                    'history_has_gaps':any(a.end_ms!=b.start_ms for a,b in zip(context.candles,context.candles[1:])),
                    'execution_eligible':False}
                from modules.goldbach_confirmation import attach
                attach(selected,row)
                row['current_quote']={'bid':str(context.current_quote.bid),'ask':str(context.current_quote.ask),
                                      'event_ms':context.current_quote.event_ms}
            if row.get('state')=='NEEDS_REVIEW':rows.append(row)
    from modules.custom_strategy import evaluate as evaluate_custom
    custom_context=replace(context,parameters=profiles.get(getattr(context.custom_settings,'base',''),context.parameters),
                           liquidity_parameters=guard_parameters)
    rows.extend(evaluate_custom(custom_context,rows))
    return {'analysis_mode':'ADMIN_PREENTRY_REVIEW','provider':'biquote','product':'indicative',
            'symbol':context.candles[-1].symbol,'timeframe':context.candles[-1].timeframe,
            'results':rows,'public_auto_publish':False,'execution_eligible':False,'production_qualified':False}
