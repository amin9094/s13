from __future__ import annotations

import csv
import io
import re
import secrets
from datetime import UTC, datetime, timedelta
from typing import Any

from core.db import next_id
from core.utils import parse_dt, utc_iso, utc_now
from modules.admin_control_center import module_state as control_module_state
from modules.market_catalog import ASSET_BY_SYMBOL, LOCAL_ASSETS, asset_title, normalize_asset_symbol
from modules.signal_engine import enrich_signal_payload

ALERT_ASSETS = {**LOCAL_ASSETS, **{symbol: item.title for symbol, item in ASSET_BY_SYMBOL.items()}}
ALERT_LOCAL_ASSETS = set(LOCAL_ASSETS)
ALERT_CONDITIONS = {"above", "below", "up_pct", "down_pct", "proximity"}
SIGNAL_RESULTS = {"target": "تارگت", "tp1": "تارگت ۱", "tp2": "تارگت ۲", "tp3": "تارگت ۳", "tp4": "تارگت ۴", "tp5": "تارگت ۵", "breakeven": "ریسک‌فری", "partial_close": "بستن بخشی", "manual_close": "بستن دستی", "no_entry": "ورود نداده", "stop": "استاپ", "cancelled": "کنسل‌شده"}


def normalize_signal_message_channel_id(value: Any) -> str:
    """Normalize the optional channel identity appended to signal captions."""
    text = str(value or "").strip()
    if text.casefold() in {"", "-", "حذف", "پاک", "پاک کردن", "remove", "clear", "none"}:
        return ""
    if len(text) > 100 or any(character.isspace() for character in text):
        raise ValueError("آیدی کانال باید یک عبارت بدون فاصله و حداکثر ۱۰۰ کاراکتر باشد")
    if re.fullmatch(r"[A-Za-z0-9_]{3,64}", text):
        text = f"@{text}"
    if text.startswith("t.me/"):
        text = f"https://{text}"
    valid = bool(
        re.fullmatch(r"@[A-Za-z0-9_]{3,64}", text)
        or re.fullmatch(r"https://t\.me/[A-Za-z0-9_+\-/=]{3,100}", text)
        or re.fullmatch(r"-?\d{5,30}", text)
    )
    if not valid:
        raise ValueError("آیدی کانال معتبر نیست؛ مانند @MyChannel یا t.me/MyChannel وارد کنید")
    return text


def signal_message_channel_id(db: dict[str, Any]) -> str:
    raw = (db.get("settings") or {}).get("signalMessageChannelId")
    try:
        return normalize_signal_message_channel_id(raw)
    except ValueError:
        return ""


def set_signal_message_channel_id(db: dict[str, Any], value: Any, actor_id: int | str) -> str:
    normalized = normalize_signal_message_channel_id(value)
    settings = db.setdefault("settings", {})
    settings["signalMessageChannelId"] = normalized
    settings["signalMessageChannelIdUpdatedAt"] = utc_iso()
    settings["signalMessageChannelIdUpdatedBy"] = str(actor_id)
    return normalized


def record_user_reward(
    db: dict[str, Any],
    user_id: int | str,
    title: str,
    *,
    reward_type: str,
    detail: str = "",
    source: str = "system",
    status: str = "delivered",
    reference_id: str | int | None = None,
) -> dict[str, Any]:
    item = {
        "id": next_id(db, "user_reward"),
        "user_id": str(user_id),
        "title": str(title)[:200],
        "type": str(reward_type)[:40],
        "detail": str(detail)[:1000],
        "source": str(source)[:80],
        "status": status if status in {"pending", "delivered", "cancelled"} else "delivered",
        "reference_id": str(reference_id or ""),
        "created_at": utc_iso(),
        "delivered_at": utc_iso() if status == "delivered" else None,
    }
    db.setdefault("user_rewards", []).append(item)
    # Durable reward ownership is not a cache; old rewards remain accessible.
    return item


def rewards_for_user(db: dict[str, Any], user_id: int | str, *, limit: int = 50) -> list[dict[str, Any]]:
    uid = str(user_id)
    rows = [row for row in db.get("user_rewards", []) if isinstance(row, dict) and str(row.get("user_id")) == uid]
    rows.sort(key=lambda row: str(row.get("created_at") or ""), reverse=True)
    return rows[: max(1, limit)]


def update_reward_status(db: dict[str, Any], reference_id: str | int, status: str) -> None:
    ref = str(reference_id)
    for row in reversed(db.get("user_rewards", [])):
        if isinstance(row, dict) and str(row.get("reference_id") or "") == ref:
            row["status"] = status
            if status == "delivered":
                row["delivered_at"] = utc_iso()
            return


def set_reward_points(db: dict[str, Any], reward_id: int | str, points: int) -> dict[str, Any]:
    value = int(points)
    if value < 1 or value > 1_000_000:
        raise ValueError("امتیاز جایزه باید بین ۱ تا ۱٬۰۰۰٬۰۰۰ باشد")
    target = int(reward_id)
    for item in db.setdefault("settings", {}).setdefault("rewardItems", []):
        if isinstance(item, dict) and int(item.get("id", 0) or 0) == target:
            item["points"] = value
            item["updated_at"] = utc_iso()
            return item
    raise ValueError("جایزه پیدا نشد")


def create_price_alert(
    db: dict[str, Any],
    user_id: int | str,
    asset: str,
    condition: str,
    target_price: float,
    *,
    recurring: bool = False,
    baseline_price: float | None = None,
    expiry_hours: int | None = None,
    proximity_percent: float = 1.0,
) -> dict[str, Any]:
    asset = normalize_asset_symbol(asset)
    ALERT_ASSETS.setdefault(asset, asset_title(asset))
    if condition not in ALERT_CONDITIONS:
        raise ValueError("شرط هشدار نامعتبر است")
    value = float(target_price)
    if value <= 0:
        raise ValueError("مقدار هدف باید بیشتر از صفر باشد")
    if condition in {"up_pct", "down_pct"} and value > 1000:
        raise ValueError("درصد تغییر نمی‌تواند بیشتر از ۱۰۰۰ باشد")
    if baseline_price is not None and float(baseline_price) <= 0:
        raise ValueError("قیمت مبنا نامعتبر است")
    controls = control_module_state(db, "alerts")
    if recurring and not bool(controls.get("recurring", True)):
        raise ValueError("هشدار تکرارشونده توسط مدیریت غیرفعال است")
    if condition in {"up_pct", "down_pct"} and not bool(controls.get("percent_change", True)):
        raise ValueError("هشدار درصدی توسط مدیریت غیرفعال است")
    if condition == "proximity" and not bool(controls.get("proximity", True)):
        raise ValueError("هشدار نزدیک‌شدن توسط مدیریت غیرفعال است")
    uid = str(user_id)
    max_per_user = int(controls.get("max_per_user", 25) or 25)
    active_count = sum(
        1
        for row in db.get("price_alerts", [])
        if isinstance(row, dict) and row.get("status") == "active" and str(row.get("user_id")) == uid
    )
    if active_count >= max_per_user:
        raise ValueError(f"حداکثر {max_per_user} هشدار فعال می‌توانید داشته باشید")
    now = datetime.now(UTC)
    expires_at = None
    if expiry_hours and int(expiry_hours) > 0:
        expires_at = (now + timedelta(hours=min(int(expiry_hours), 24 * 365))).isoformat()
    alert = {
        "id": next_id(db, "price_alert"),
        "user_id": uid,
        "asset": asset,
        "condition": condition,
        "target_price": value,
        "baseline_price": float(baseline_price) if baseline_price is not None else None,
        "proximity_percent": max(0.01, min(float(proximity_percent), 50.0)),
        "recurring": bool(recurring),
        "status": "active",
        "created_at": now.isoformat(),
        "expires_at": expires_at,
        "triggered_at": None,
        "last_triggered_at": None,
        "trigger_count": 0,
        "last_price": float(baseline_price) if baseline_price is not None else None,
    }
    db.setdefault("price_alerts", []).append(alert)
    db["price_alerts"] = db["price_alerts"][-5000:]
    return alert


def user_price_alerts(db: dict[str, Any], user_id: int | str, *, active_only: bool = False) -> list[dict[str, Any]]:
    uid = str(user_id)
    rows = [row for row in db.get("price_alerts", []) if isinstance(row, dict) and str(row.get("user_id")) == uid]
    if active_only:
        rows = [row for row in rows if row.get("status") == "active"]
    rows.sort(key=lambda row: int(row.get("id", 0)), reverse=True)
    return rows


def price_alert_history(db: dict[str, Any], user_id: int | str, *, limit: int = 50) -> list[dict[str, Any]]:
    uid = str(user_id)
    rows = [row for row in db.get("price_alert_history", []) if isinstance(row, dict) and str(row.get("user_id")) == uid]
    rows.sort(key=lambda row: str(row.get("triggered_at") or ""), reverse=True)
    return rows[: max(1, min(int(limit), 500))]


def delete_price_alert(db: dict[str, Any], user_id: int | str, alert_id: int | str) -> bool:
    uid = str(user_id)
    target = int(alert_id)
    for row in db.get("price_alerts", []):
        if isinstance(row, dict) and int(row.get("id", 0) or 0) == target and str(row.get("user_id")) == uid:
            row["status"] = "disabled"
            row["disabled_at"] = utc_iso()
            return True
    return False


def toggle_price_alert(db: dict[str, Any], user_id: int | str, alert_id: int | str) -> dict[str, Any]:
    uid = str(user_id)
    target = int(alert_id)
    for row in db.get("price_alerts", []):
        if isinstance(row, dict) and int(row.get("id", 0) or 0) == target and str(row.get("user_id")) == uid:
            row["status"] = "disabled" if row.get("status") == "active" else "active"
            row["updated_at"] = utc_iso()
            return row
    raise ValueError("هشدار پیدا نشد")


def _alert_hit(row: dict[str, Any], current: float) -> bool:
    condition = str(row.get("condition") or "")
    target = float(row.get("target_price", 0) or 0)
    previous = row.get("last_price")
    previous_price = float(previous) if previous not in {None, ""} else None
    if condition == "above":
        return current >= target and (not row.get("recurring") or previous_price is None or previous_price < target)
    if condition == "below":
        return current <= target and (not row.get("recurring") or previous_price is None or previous_price > target)
    if condition == "proximity":
        threshold = float(row.get("proximity_percent", 1.0) or 1.0)
        distance = abs(current - target) / target * 100 if target else 100.0
        was_far = True
        if previous_price is not None and target:
            was_far = abs(previous_price - target) / target * 100 > threshold
        return distance <= threshold and (not row.get("recurring") or was_far)
    baseline = float(row.get("baseline_price") or previous_price or current)
    if baseline <= 0:
        return False
    change = (current - baseline) / baseline * 100
    return change >= target if condition == "up_pct" else change <= -target


def triggered_price_alerts(
    db: dict[str, Any],
    prices: dict[str, float],
    *,
    allowed_user_ids: set[str] | None = None,
) -> list[dict[str, Any]]:
    triggered: list[dict[str, Any]] = []
    now = datetime.now(UTC)
    controls = control_module_state(db, "alerts")
    keep_history = bool(controls.get("history", True))
    for row in db.get("price_alerts", []):
        if not isinstance(row, dict) or row.get("status") != "active":
            continue
        if allowed_user_ids is not None and str(row.get("user_id")) not in allowed_user_ids:
            continue
        expires_at = parse_dt(row.get("expires_at"))
        if expires_at and expires_at <= now:
            row["status"] = "expired"
            row["expired_at"] = now.isoformat()
            continue
        current_raw = prices.get(str(row.get("asset")))
        if current_raw is None:
            continue
        current = float(current_raw)
        if not _alert_hit(row, current):
            row["last_price"] = current
            continue
        row["triggered_at"] = now.isoformat()
        row["last_triggered_at"] = now.isoformat()
        row["trigger_price"] = current
        row["trigger_count"] = int(row.get("trigger_count", 0) or 0) + 1
        snapshot = dict(row)
        triggered.append(snapshot)
        if keep_history:
            db.setdefault("price_alert_history", []).append({
                "id": next_id(db, "price_alert_history"),
                "alert_id": row.get("id"),
                "user_id": row.get("user_id"),
                "asset": row.get("asset"),
                "condition": row.get("condition"),
                "target_price": row.get("target_price"),
                "trigger_price": current,
                "recurring": bool(row.get("recurring")),
                "triggered_at": now.isoformat(),
            })
            db["price_alert_history"] = db["price_alert_history"][-10000:]
        if bool(row.get("recurring")):
            row["status"] = "active"
            row["last_price"] = current
            if row.get("condition") in {"up_pct", "down_pct"}:
                row["baseline_price"] = current
        else:
            row["status"] = "triggered"
            row["last_price"] = current
    return triggered


def prepare_price_alert_deliveries(
    db: dict[str, Any],
    prices: dict[str, float],
    *,
    allowed_user_ids: set[str] | None = None,
) -> list[dict[str, Any]]:
    """Stage alert notifications without marking them delivered.

    Telegram delivery is not transactional.  The older implementation changed
    the alert state and history before ``send_message`` completed, which could
    silently lose one-shot alerts.  A short-lived delivery token keeps the
    mutation reversible and also recovers from a process crash.
    """
    now = datetime.now(UTC)
    prepared: list[dict[str, Any]] = []
    deliveries = db.setdefault("price_alert_deliveries", [])
    for row in db.get("price_alerts", []):
        if not isinstance(row, dict) or row.get("status") != "active":
            continue
        uid = str(row.get("user_id"))
        if allowed_user_ids is not None and uid not in allowed_user_ids:
            continue
        expires_at = parse_dt(row.get("expires_at"))
        if expires_at and expires_at <= now:
            row["status"] = "expired"
            row["expired_at"] = now.isoformat()
            continue
        pending_id = str(row.get("pending_delivery_id") or "")
        pending_at = parse_dt(row.get("pending_delivery_at"))
        if pending_id and pending_at and pending_at > now - timedelta(minutes=5):
            continue
        if pending_id:
            row.pop("pending_delivery_id", None)
            row.pop("pending_delivery_at", None)
        retry_at = parse_dt(row.get("delivery_retry_at"))
        if retry_at and retry_at > now:
            continue
        current_raw = prices.get(str(row.get("asset")))
        if current_raw is None:
            continue
        current = float(current_raw)
        if not _alert_hit(row, current):
            row["last_price"] = current
            continue
        token = secrets.token_urlsafe(18)
        delivery = {
            "id": token,
            "alert_id": int(row.get("id", 0) or 0),
            "user_id": uid,
            "asset": row.get("asset"),
            "condition": row.get("condition"),
            "target_price": row.get("target_price"),
            "trigger_price": current,
            "recurring": bool(row.get("recurring")),
            "status": "pending",
            "attempt": int(row.get("delivery_failures", 0) or 0) + 1,
            "created_at": now.isoformat(),
        }
        deliveries.append(delivery)
        row["pending_delivery_id"] = token
        row["pending_delivery_at"] = now.isoformat()
        prepared.append(dict(delivery))
    db["price_alert_deliveries"] = deliveries[-10000:]
    return prepared


def complete_price_alert_delivery(
    db: dict[str, Any],
    delivery_id: str,
    *,
    delivered: bool,
    error: str = "",
) -> bool:
    token = str(delivery_id or "")
    delivery = next(
        (
            row for row in reversed(db.get("price_alert_deliveries", []))
            if isinstance(row, dict) and str(row.get("id")) == token
        ),
        None,
    )
    if not delivery or delivery.get("status") != "pending":
        return False
    alert = next(
        (
            row for row in db.get("price_alerts", [])
            if isinstance(row, dict)
            and int(row.get("id", 0) or 0) == int(delivery.get("alert_id", 0) or 0)
        ),
        None,
    )
    now = datetime.now(UTC)
    delivery["status"] = "delivered" if delivered else "failed"
    delivery["completed_at"] = now.isoformat()
    delivery["error"] = str(error or "")[:300]
    if alert is None or str(alert.get("pending_delivery_id") or "") != token:
        return False
    alert.pop("pending_delivery_id", None)
    alert.pop("pending_delivery_at", None)
    current = float(delivery.get("trigger_price", 0) or 0)
    if not delivered:
        failures = int(alert.get("delivery_failures", 0) or 0) + 1
        alert["delivery_failures"] = failures
        alert["last_delivery_error"] = str(error or "")[:300]
        alert["delivery_retry_at"] = (now + timedelta(seconds=min(900, 15 * (2 ** min(failures - 1, 6))))).isoformat()
        return True

    alert.pop("delivery_retry_at", None)
    alert["delivery_failures"] = 0
    alert["last_delivery_error"] = ""
    alert["triggered_at"] = now.isoformat()
    alert["last_triggered_at"] = now.isoformat()
    alert["trigger_price"] = current
    alert["trigger_count"] = int(alert.get("trigger_count", 0) or 0) + 1
    controls = control_module_state(db, "alerts")
    if bool(controls.get("history", True)):
        db.setdefault("price_alert_history", []).append(
            {
                "id": next_id(db, "price_alert_history"),
                "alert_id": alert.get("id"),
                "delivery_id": token,
                "user_id": alert.get("user_id"),
                "asset": alert.get("asset"),
                "condition": alert.get("condition"),
                "target_price": alert.get("target_price"),
                "trigger_price": current,
                "recurring": bool(alert.get("recurring")),
                "triggered_at": now.isoformat(),
            }
        )
        db["price_alert_history"] = db["price_alert_history"][-10000:]
    alert["last_price"] = current
    if bool(alert.get("recurring")):
        alert["status"] = "active"
        if alert.get("condition") in {"up_pct", "down_pct"}:
            alert["baseline_price"] = current
    else:
        alert["status"] = "triggered"
    return True


def find_registered_user(db: dict[str, Any], value: str) -> tuple[str, dict[str, Any]]:
    raw = str(value or "").strip().lstrip("@")
    if raw.isdigit() and raw in db.get("users", {}):
        return raw, db["users"][raw]
    needle = raw.casefold()
    for uid, user in db.get("users", {}).items():
        if isinstance(user, dict) and str(user.get("username") or "").lstrip("@").casefold() == needle:
            return str(uid), user
    raise ValueError("کاربر در دیتابیس پیدا نشد")


def set_user_ban(db: dict[str, Any], user_id: int | str, *, days: int | None, reason: str, admin_id: int | str) -> dict[str, Any]:
    uid = str(user_id)
    if uid not in db.get("users", {}):
        raise ValueError("کاربر پیدا نشد")
    expires_at = None if days is None else utc_iso(utc_now() + timedelta(days=max(1, int(days))))
    record = {
        "user_id": uid,
        "status": "active",
        "reason": str(reason or "بدون توضیح")[:500],
        "expires_at": expires_at,
        "admin_id": str(admin_id),
        "created_at": utc_iso(),
    }
    db.setdefault("user_bans", {})[uid] = record
    return record


def unban_user(db: dict[str, Any], user_id: int | str) -> bool:
    return db.setdefault("user_bans", {}).pop(str(user_id), None) is not None


def active_ban(db: dict[str, Any], user_id: int | str) -> dict[str, Any] | None:
    row = db.get("user_bans", {}).get(str(user_id))
    if not isinstance(row, dict) or row.get("status") != "active":
        return None
    expiry = parse_dt(row.get("expires_at"))
    if expiry and expiry <= utc_now():
        row["status"] = "expired"
        return None
    return row


def user_segments(db: dict[str, Any], segment: str) -> list[int]:
    users = db.get("users", {})
    now = utc_now()
    winners = {
        str(row.get("user_id") or row.get("uid"))
        for row in db.get("user_rewards", [])
        if isinstance(row, dict) and row.get("source", "").startswith("contest")
    }
    result: list[int] = []
    for uid, user in users.items():
        if not str(uid).isdigit() or active_ban(db, uid):
            continue
        if segment == "vip" and str(uid) not in db.get("vip_users", {}):
            continue
        if segment == "normal" and str(uid) in db.get("vip_users", {}):
            continue
        if segment == "inactive":
            last_seen = parse_dt(user.get("last_seen_at")) if isinstance(user, dict) else None
            if last_seen and (now - last_seen).days < 30:
                continue
        if segment == "winners" and str(uid) not in winners:
            continue
        result.append(int(uid))
    return result


def random_reward_recipients(db: dict[str, Any], count: int) -> list[int]:
    eligible = user_segments(db, "all")
    amount = max(1, min(int(count), len(eligible))) if eligible else 0
    return secrets.SystemRandom().sample(eligible, amount) if amount else []


def register_signal_record(db: dict[str, Any], payload: dict[str, Any]) -> dict[str, Any]:
    from modules.market_sessions import attach_market_session
    from modules.signal_portal import ensure_signal_portal
    from modules.outcome_engine import apply_signal_outcome
    from modules.signal_versioning import ensure_initial_version

    cycle = ensure_signal_portal(db)
    record = enrich_signal_payload(payload)
    session_timezone = str(db.get("market_session_settings", {}).get("timezone") or "UTC")
    attach_market_session(record, timezone=session_timezone, at=record.get("created_at"))
    if not record.get("id"):
        record["id"] = next_id(db, "signal")
    if str(record["id"]) in db.get("signal_deletion_audit", {}):
        raise ValueError("SIGNAL_DELETED")
    record.setdefault("cycle_id", int(cycle.get("current_id", 1) or 1))
    record.setdefault("display_number", int(record.get("id", 0) or 0))
    record.setdefault("status", "open")
    record.setdefault("result_at", None)
    record.setdefault("created_at", utc_iso())
    apply_signal_outcome(record)
    ensure_initial_version(
        record,
        actor_id=record.get("admin_id") or "system",
        reason="created",
        revision_store=db.setdefault("signal_revisions", []),
    )
    db.setdefault("signal_versions", {})[str(record.get("id"))] = record.get("versions", [])
    db.setdefault("signals", []).append(record)
    # The caption was rendered with its reserved number. Completion order may
    # differ from reservation order; only an explicit deletion compacts display.
    record.setdefault('publication_number', record['display_number'])
    db.setdefault('signal_number_reservations', {}).pop(str(record['id']), None)
    return record


def set_signal_result(db: dict[str, Any], signal_id: int | str, result: str, admin_id: int | str) -> dict[str, Any]:
    if result not in SIGNAL_RESULTS:
        raise ValueError("نتیجه سیگنال نامعتبر است")
    target = int(signal_id)
    for row in reversed(db.get("signals", [])):
        if isinstance(row, dict) and int(row.get("id", 0) or 0) == target:
            if row.get("status") != "open":
                raise ValueError("نتیجه این سیگنال قبلاً ثبت شده است")
            row["status"] = result
            row["result_at"] = utc_iso()
            row["result_admin_id"] = str(admin_id)
            from modules.outcome_engine import record_outcome_event

            record_outcome_event(db, row, actor_id=admin_id, event=f"legacy_result:{result}")
            return row
    raise ValueError("سیگنال پیدا نشد")


def reset_signal_result(db: dict[str, Any], signal_id: int | str, admin_id: int | str) -> dict[str, Any]:
    """Reopen a completed signal so an admin can register its result again."""
    target = int(signal_id)
    for row in reversed(db.get("signals", [])):
        if not isinstance(row, dict) or int(row.get("id", 0) or 0) != target:
            continue
        previous_status = str(row.get("status") or "open")
        if previous_status == "open":
            raise ValueError("این سیگنال از قبل برای ثبت نتیجه باز است")
        reset_at = utc_iso()
        history = row.get("result_history")
        if not isinstance(history, list):
            history = []
            row["result_history"] = history
        history.append(
            {
                "status": previous_status,
                "result_at": row.get("result_at"),
                "result_admin_id": row.get("result_admin_id"),
                "result_chart_photo_file_id": row.get("result_chart_photo_file_id"),
                "result_chart_caption": row.get("result_chart_caption"),
                "result_chart_added_at": row.get("result_chart_added_at"),
                "reset_at": reset_at,
                "reset_admin_id": str(admin_id),
            }
        )
        row["result_history"] = history[-20:]
        lifecycle = row.get("lifecycle_history")
        if isinstance(lifecycle, list) and lifecycle:
            row.setdefault("lifecycle_archive", []).append(
                {
                    "reset_at": reset_at,
                    "reset_admin_id": str(admin_id),
                    "history": lifecycle[-100:],
                    "highest_target_hit": int(row.get("highest_target_hit", 0) or 0),
                }
            )
            row["lifecycle_archive"] = row["lifecycle_archive"][-20:]
        row["status"] = "open"
        row["result_at"] = None
        row["result_admin_id"] = None
        row["highest_target_hit"] = 0
        row["lifecycle_history"] = []
        for key in (
            "result_chart_photo_file_id", "result_chart_photo_unique_id", "result_chart_photo_width",
            "result_chart_photo_height", "result_chart_caption", "result_chart_added_by",
            "result_chart_added_at", "result_chart_deliveries",
        ):
            row.pop(key, None)
        for key in list(row):
            if key in {"entry_hit_at", "entry_hit_price", "breakeven_at", "partial_close_at"}:
                row.pop(key, None)
            elif key.startswith("tp") and (key.endswith("_hit_at") or key.endswith("_hit_price")):
                row.pop(key, None)
        row["result_reset_at"] = reset_at
        row["result_reset_admin_id"] = str(admin_id)
        from modules.outcome_engine import apply_signal_outcome, record_outcome_event

        apply_signal_outcome(row)
        record_outcome_event(db, row, actor_id=admin_id, event="result_reset")
        return row
    raise ValueError("سیگنال پیدا نشد")


def signal_channel_stats_reset_at(db: dict[str, Any], channel: str) -> str | None:
    if channel not in {"public", "private"}:
        raise ValueError("کانال نامعتبر است")
    payload = db.get("settings", {}).get("signalStatsResetAt", {}).get(channel)
    if isinstance(payload, dict):
        value = payload.get("reset_at")
    else:
        value = payload
    return str(value) if parse_dt(value) else None


def reset_signal_channel_stats(db: dict[str, Any], channel: str, admin_id: int | str) -> str:
    if channel not in {"public", "private"}:
        raise ValueError("کانال نامعتبر است")
    reset_at = utc_iso()
    db.setdefault("settings", {}).setdefault("signalStatsResetAt", {})[channel] = {
        "reset_at": reset_at,
        "admin_id": str(admin_id),
    }
    return reset_at


def signal_channel_stats(db: dict[str, Any], channel: str, days: int | None = None) -> dict[str, Any]:
    """Return mutually-exclusive, decision-ready channel performance metrics."""
    if channel not in {"public", "private"}:
        raise ValueError("کانال نامعتبر است")
    if days is not None and days not in {7, 30}:
        raise ValueError("بازه گزارش نامعتبر است")
    since = utc_now() - timedelta(days=days) if days is not None else None
    reset_at = parse_dt(signal_channel_stats_reset_at(db, channel))
    if reset_at is not None and (since is None or reset_at > since):
        since = reset_at
    rows: list[dict[str, Any]] = []
    for row in db.get("signals", []):
        if not isinstance(row, dict):
            continue
        if since is not None:
            created_at = parse_dt(row.get("created_at"))
            if created_at is None or created_at < since:
                continue
        delivered = row.get("delivered_channels")
        if isinstance(delivered, list):
            if channel in delivered:
                rows.append(row)
        elif row.get("target") in {channel, "both"}:
            rows.append(row)

    metrics: dict[str, Any] = {
        "total": len(rows),
        "open": 0,
        "waiting_entry": 0,
        "active_trade": 0,
        "full_win": 0,
        "partial_win": 0,
        "breakeven": 0,
        "loss": 0,
        "stop": 0,
        "manual_positive": 0,
        "manual_negative": 0,
        "no_entry": 0,
        "cancelled": 0,
        "expired": 0,
        "target": 0,  # backwards-compatible total wins
        "settled": 0,
        "win_rate": 0.0,
        "profit_percent_sum": 0.0,
        "average_rr": 0.0,
    }
    rr_values: list[float] = []
    for row in rows:
        status = str(row.get("status") or "open")
        highest = int(row.get("highest_target_hit", 0) or 0)
        profit = float(row.get("profit_percent", 0) or 0)
        rr = float(row.get("rr", 0) or 0)
        metrics["profit_percent_sum"] += profit
        if rr:
            rr_values.append(rr)

        if status not in {"target", "target_complete", "manual_close", "no_entry", "stop", "cancelled", "expired"}:
            metrics["open"] += 1
            if row.get("entry_hit_at") or status != "open":
                metrics["active_trade"] += 1
            else:
                metrics["waiting_entry"] += 1
            continue
        if status in {"target", "target_complete"}:
            metrics["full_win"] += 1
            continue
        if status == "no_entry":
            metrics["no_entry"] += 1
            continue
        if status == "cancelled":
            metrics["cancelled"] += 1
            continue
        if status == "expired":
            metrics["expired"] += 1
            continue
        if status == "manual_close":
            if profit > 0 or highest > 0:
                metrics["partial_win"] += 1
                metrics["manual_positive"] += 1
            elif profit < 0:
                metrics["loss"] += 1
                metrics["manual_negative"] += 1
            else:
                metrics["breakeven"] += 1
            continue
        if status == "stop":
            metrics["stop"] += 1
            if highest > 0 and profit >= 0:
                metrics["partial_win"] += 1
            else:
                metrics["loss"] += 1

    metrics["target"] = metrics["full_win"] + metrics["partial_win"]
    metrics["settled"] = metrics["target"] + metrics["loss"] + metrics["breakeven"]
    decisive = metrics["target"] + metrics["loss"]
    metrics["win_rate"] = metrics["target"] / decisive * 100 if decisive else 0.0
    metrics["average_rr"] = sum(rr_values) / len(rr_values) if rr_values else 0.0
    metrics["profit_percent_sum"] = round(metrics["profit_percent_sum"], 4)
    metrics["average_rr"] = round(metrics["average_rr"], 4)
    return metrics


def users_csv(db: dict[str, Any]) -> bytes:
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["user_id", "username", "first_name", "last_name", "points", "vip", "created_at", "last_seen_at", "banned"])
    for uid, user in sorted(db.get("users", {}).items(), key=lambda pair: int(pair[0]) if str(pair[0]).isdigit() else 0):
        user = user if isinstance(user, dict) else {}
        writer.writerow([
            uid,
            user.get("username", ""),
            user.get("first_name", ""),
            user.get("last_name", ""),
            db.get("user_points", {}).get(str(uid), 0),
            "yes" if str(uid) in db.get("vip_users", {}) else "no",
            user.get("created_at", ""),
            user.get("last_seen_at", ""),
            "yes" if active_ban(db, uid) else "no",
        ])
    return output.getvalue().encode("utf-8-sig")


def transactions_csv(db: dict[str, Any]) -> bytes:
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["type", "id", "user_id", "status", "amount_or_detail", "created_at"])
    for row in db.get("vip_orders", []):
        if isinstance(row, dict):
            writer.writerow(["vip_order", row.get("order_id"), row.get("user_id"), row.get("status"), row.get("price"), row.get("created_at")])
    for row in db.get("user_rewards", []):
        if isinstance(row, dict):
            writer.writerow(["reward", row.get("id"), row.get("user_id"), row.get("status"), row.get("title"), row.get("created_at")])
    for row in db.get("point_history", []):
        if isinstance(row, dict):
            writer.writerow(["points", "", row.get("user_id"), "done", row.get("amount"), row.get("created_at")])
    return output.getvalue().encode("utf-8-sig")
