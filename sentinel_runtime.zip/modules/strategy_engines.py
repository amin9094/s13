"""Session engine registry. Research outputs are not performance certificates."""
from __future__ import annotations
from dataclasses import asdict, replace
from decimal import Decimal as D
from modules.strategies.common import Context, Parameters, Swing, _targets, confirmed_swings, indicators  # noqa: F401
from modules.strategies.fibonacci.engine import Fibonacci
from modules.strategies.fibonacci_pullback.engine import FibonacciPullback
from modules.strategies.indicators.engine import IndicatorsOnly
from modules.strategies.order_block.engine import OrderBlockVolume
from modules.strategies.sweep_fvg.engine import SweepCHoCHFVG


def evaluate_all(context):
    context.validate()
    profiles = dict(context.engine_parameters)
    allowed = {'indicators', 'sweep_fvg', 'order_block', 'fibonacci_pullback'}
    if set(profiles) - allowed or len(profiles) != len(context.engine_parameters):
        raise ValueError('ENGINE_PROFILE_SELECTION_INVALID')
    results = []
    guard_parameters = profiles.get('sweep_fvg', context.parameters)
    for engine in (IndicatorsOnly(), SweepCHoCHFVG(), OrderBlockVolume(), FibonacciPullback()):
        selected = replace(context, parameters=profiles.get(engine.name, context.parameters),
                           liquidity_parameters=guard_parameters)
        results.extend(engine.evaluate(selected))
    deduped, seen = [], set()
    for row in results:
        plan = row.get("plan")
        if plan:
            key = (plan["engine"], plan["symbol"], plan["timeframe"], plan["thesis_key"])
            if key in seen:
                continue
            seen.add(key)
            row["conflict_advisory"] = any(other.get("plan", {}).get("direction") != plan["direction"] for other in results if other.get("plan"))
        deduped.append(row)
    confirmations = []
    for row in deduped:
        if row.get('plan'):
            selected = replace(context, parameters=profiles.get(row['engine'], context.parameters))
            confirmations.extend(Fibonacci().evaluate(selected, [row]))
    by_id = {row["setup_id"]: row for row in confirmations}
    for row in deduped:
        if row.get("plan"):
            row["fibonacci_confirmation"] = by_id.get(row["plan"]["setup_id"])
            from modules.setup_lifecycle import SetupPlan

            locked = SetupPlan.from_dict(row["plan"])
            confirmation = {"kind": "shared_fibonacci_confirmation", "available_ms": context.cutoff_ms,
                            "detail": row["fibonacci_confirmation"]}
            row["plan"] = replace(locked, evidence=(*locked.evidence, confirmation)).as_dict()
    from modules.goldbach_confirmation import attach
    for row in deduped:
        attach(replace(context,parameters=profiles.get(row['engine'],context.parameters)),row)
    from modules.custom_strategy import evaluate as evaluate_custom
    custom_context=replace(context,parameters=profiles.get(getattr(context.custom_settings,'base',''),context.parameters),
                           liquidity_parameters=guard_parameters)
    deduped.extend(evaluate_custom(custom_context,deduped))
    collaborations = []
    plans = [row["plan"] for row in deduped if row.get("plan")]
    for i, a in enumerate(plans):
        for b in plans[i + 1:]:
            if a["engine"] == b["engine"] or a["direction"] != b["direction"]:
                continue
            if max(D(a["zone_low"]), D(b["zone_low"])) > min(D(a["zone_high"]), D(b["zone_high"])):
                continue
            collaborations.append({"setup_ids": [a["setup_id"], b["setup_id"]], "same_entry": a["entry"] == b["entry"],
                                   "direction": a["direction"], "entry_or_stop_averaged": False,
                                   "preferred_setup_id": a["setup_id"] if a["engine"] == "order_block" else b["setup_id"] if b["engine"] == "order_block" else None,
                                   "preference_basis": "VALID_CAUSAL_POC_PRIORITY_IF_AVAILABLE",
                                   "independent_plans_preserved": True})
    return {
        "profile_status": "REQUIRES_OOS_VALIDATION", "production_qualified": False,
        "results": deduped, "confirmations": confirmations, "collaborations": collaborations,
        "blocked_specifications": [],
        "engine_roles": {"indicators": "INDEPENDENT", "sweep_fvg": "INDEPENDENT", "order_block": "INDEPENDENT",
                         "fibonacci": "SHARED_OPTIONAL_CONFIRMATION", "fibonacci_pullback": "EXPERIMENTAL_INDEPENDENT",
                         "custom":"ADMIN_SELECTED_AND_COMBINATION"},
        "parameters": {k: str(v) if isinstance(v, D) else v for k, v in asdict(context.parameters).items()},
        "selected_engine_profiles": {engine: profile.profile_id for engine, profile in profiles.items()},
    }
