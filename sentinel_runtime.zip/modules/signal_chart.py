"""Deterministic chart images from the exact closed candles of a signal.

No price fetching, fabricated candles, current-price substitution or Pine
execution. The independent PO3 grid is explicitly distinguished from DMN.
"""
from datetime import UTC, datetime
from decimal import Decimal as D
from io import BytesIO

from PIL import Image, ImageDraw, ImageFont

from modules.canonical_market import Candle, TIMEFRAMES
from repositories.v2.common import content_hash

IDENTITY = ('symbol', 'provider', 'venue', 'product', 'timeframe')
BAR_FIELDS = ('start_ms', 'end_ms', 'available_ms', 'source_id', 'open', 'high', 'low', 'close')


def freeze(plan, bars):
    cutoff = plan['evidence_cutoff_ms']
    ids = set(plan.get('source_ids', ()))
    selected = [b for b in bars if b.source_id in ids and b.is_closed
                and b.available_ms <= cutoff and b.end_ms <= cutoff
                and all(getattr(b, k) == plan[k] for k in IDENTITY)][-96:]
    if len(selected) < 20 or cutoff-selected[-1].end_ms >= TIMEFRAMES[plan['timeframe']]:
        raise ValueError('SIGNAL_CHART_EXACT_CANDLES_UNAVAILABLE')
    body = {'version': 1, 'plan_hash': content_hash(plan), 'cutoff_ms': cutoff,
            'identity': {k: plan[k] for k in IDENTITY},
            'bars': [{k: b.as_dict()[k] for k in BAR_FIELDS} for b in selected]}
    snapshot = {**body, 'snapshot_hash': content_hash(body)}
    validate(plan, snapshot)
    return snapshot


def validate(plan, snapshot):
    if not isinstance(snapshot, dict):
        raise ValueError('SIGNAL_CHART_SNAPSHOT_INVALID')
    body = {k: v for k, v in snapshot.items() if k != 'snapshot_hash'}
    if (snapshot.get('version') != 1 or snapshot.get('plan_hash') != content_hash(plan)
            or snapshot.get('cutoff_ms') != plan.get('evidence_cutoff_ms')
            or snapshot.get('identity') != {k: plan.get(k) for k in IDENTITY}
            or content_hash(body) != snapshot.get('snapshot_hash')):
        raise ValueError('SIGNAL_CHART_PLAN_OR_SNAPSHOT_CHANGED')
    rows = snapshot.get('bars')
    if not isinstance(rows, list) or not 20 <= len(rows) <= 96:
        raise ValueError('SIGNAL_CHART_SNAPSHOT_INVALID')
    parsed = []
    try:
        for row in rows:
            if not isinstance(row, dict) or set(row) != set(BAR_FIELDS):
                raise ValueError()
            b = Candle(**snapshot['identity'], **row, is_closed=True, volume=None, volume_kind='unavailable')
            if (b.available_ms > snapshot['cutoff_ms'] or b.end_ms > snapshot['cutoff_ms']
                    or b.source_id not in plan.get('source_ids', ())
                    or parsed and b.start_ms < parsed[-1].end_ms):
                raise ValueError()
            parsed.append(b)
    except (ValueError, TypeError, ArithmeticError):
        raise ValueError('SIGNAL_CHART_SNAPSHOT_INVALID') from None
    if snapshot['cutoff_ms']-parsed[-1].end_ms >= TIMEFRAMES[plan['timeframe']]:
        raise ValueError('SIGNAL_CHART_EXACT_CANDLES_UNAVAILABLE')
    return parsed


def render_png(plan, snapshot, *, public=False):
    bars = validate(plan, snapshot)
    image = Image.new('RGB', (1200, 720), '#101827')
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default(size=18)
    small = ImageFont.load_default(size=14)
    heading = ImageFont.load_default(size=25)
    left, top, right, bottom = 28, 100, 955, 634
    from modules.signal_execution import reference_plan,mode_of
    facts = {f.get('kind'): f.get('detail', {}) for f in reference_plan(plan).get('evidence', ())}
    if public:facts={}
    levels = [(label, D(plan[key])) for label, key in
              [('Entry','entry'),('SL','stop'),*[(f'TP{i}',f'tp{i}') for i in range(1,11)]]
              if plan.get(key) is not None]
    low = min([b.low for b in bars] + [p for _, p in levels] + [D(plan['zone_low'])])
    high = max([b.high for b in bars] + [p for _, p in levels] + [D(plan['zone_high'])])
    pad = (high-low)*D('.06')
    low, high = low-pad, high+pad
    start, end = bars[0].start_ms, bars[-1].end_ms+TIMEFRAMES[plan['timeframe']]*10
    def x(stamp): return left+int(D(stamp-start)/D(end-start)*(right-left))
    def y(price): return bottom-int((price-low)/(high-low)*(bottom-top))
    annotations = []
    def line(label, price, color, width=1):
        if low <= price <= high:
            draw.line((left, y(price), right, y(price)), fill=color, width=width)
            annotations.append((y(price), f'{label} {price}', color))
    draw.text((28, 18), f"{plan['symbol']}  {plan['direction']}" if public else f"{plan['symbol']}  {plan['direction']}  {plan['timeframe']}", fill='#f1f5f9', font=heading)
    mode = mode_of(plan)
    draw.text((28, 56), 'SENTINEL | price levels' if public else f"SENTINEL | {plan['engine']} | {'FORECAST / PENDING' if mode == 'PENDING' else 'MARKET'} | closed candles at proposal", fill='#94a3b8', font=font)
    for n in range(6):
        price = low+(high-low)*D(n)/5
        draw.line((left, y(price), right, y(price)), fill='#243047')
    draw.rectangle((left, y(D(plan['zone_high'])), right, y(D(plan['zone_low']))),
                   fill='#272d50', outline='#a78bfa', width=2)
    custom = facts.get('custom_strategy', {})
    for engine, matched in (custom.get('matches') or {}).items():
        cfg = custom.get('config', {})
        required = cfg.get('require_fvg') if engine == 'sweep_fvg' else cfg.get('require_ob') or cfg.get('require_poc')
        if matched and required:
            a, b = max(low, D(matched['zone_low'])), min(high, D(matched['zone_high']))
            if a <= b:
                draw.rectangle((left, y(b), right, y(a)), outline='#c084fc', width=2)
    selection = facts.get('entry_selection', {})
    if selection.get('original_midpoint') is not None:
        line('FVG 50%', D(selection['original_midpoint']), '#a78bfa')
    poc = selection.get('poc') or facts.get('custom_strategy', {}).get('poc') or {}
    if poc.get('price') is not None:
        line('POC', D(poc['price']), '#f59e0b')
    fib = custom.get('fibonacci') or facts.get('shared_fibonacci_confirmation') or {}
    for ratio, price in fib.get('main_levels', {}).items():
        line('Fib '+str(ratio), D(price), '#818cf8')
    for factor in fib.get('confirmations', ()):
        if factor.get('kind') == 'OTHER_MINOR_WAVE_GOLDEN_OVERLAP':
            a, b = max(low, D(factor['golden_low'])), min(high, D(factor['golden_high']))
            if a <= b:
                draw.rectangle((left, y(b), right, y(a)), outline='#fbbf24', width=2)
    sweep = facts.get('sweep_reclaim') or {}
    structure = facts.get('closed_choch') or {}
    if sweep.get('pool_price') is not None:
        line('Liquidity', D(sweep['pool_price']), '#38bdf8')
    if structure.get('protected_price') is not None:
        line('CHoCH', D(structure['protected_price']), '#c084fc')
    grid = facts.get('shared_goldbach_confirmation') or {}
    for level in grid.get('matches', ())[:3]:
        if level.get('direction_aligned'):
            line('PO3 independent', D(level['price']), '#facc15' if level.get('is_outer_boundary') else '#d9a441')
    candle_width = max(2, min(7, x(bars[0].end_ms)-x(bars[0].start_ms)-2))
    for bar in bars:
        cx = x((bar.start_ms+bar.end_ms)//2)
        color = '#34d399' if bar.close >= bar.open else '#fb7185'
        draw.line((cx, y(bar.high), cx, y(bar.low)), fill=color, width=1)
        a, b = sorted((y(bar.open), y(bar.close)))
        draw.rectangle((cx-candle_width//2, a, cx+candle_width//2, max(a+1, b)), fill=color)
    for label, price in levels:
        color = '#fb7185' if label == 'SL' else '#60a5fa' if label == 'Entry' else '#34d399'
        line(plan['direction']+' Entry' if public and label=='Entry' else label, price, color, 2)
    from modules.signal_forecast import describe
    if not public and describe(plan) is not None:
        # The reserved blank area is a conditional diagram, never future candles.
        # Horizontal spacing carries no forecast of an arrival time.
        blank = right-x(bars[-1].end_ms)
        points = [(x(bars[-1].end_ms)+8, y(bars[-1].close)),
                  (right-int(blank*.5), y(D(plan['entry']))), (right-8, y(D(plan['tp1'])))]
        for a, b in zip(points, points[1:]):
            distance = max(abs(b[0]-a[0]), abs(b[1]-a[1]), 1)
            for offset in range(0, distance, 12):
                fraction_start, fraction_end = offset/distance, min(offset+6, distance)/distance
                draw.line((a[0]+(b[0]-a[0])*fraction_start, a[1]+(b[1]-a[1])*fraction_start,
                           a[0]+(b[0]-a[0])*fraction_end, a[1]+(b[1]-a[1])*fraction_end), fill='#fbbf24', width=3)
        for px, py in points[1:]:
            draw.ellipse((px-4, py-4, px+4, py+4), fill='#fbbf24')
        draw.text((28, 80), 'CONDITIONAL: reach Entry -> '+plan['direction']+' -> TP1 | illustrative route, no ETA', fill='#fbbf24', font=small)
    # Nearby Entry/midpoint/POC/grid labels remain readable without moving
    # any price line. Leaders connect displaced text to its exact price.
    labels = sorted(set(annotations))
    previous = top-22
    positions = []
    for actual, text, color in labels:
        desired = max(actual-9, previous+22)
        positions.append([actual, text, color, desired]);previous = desired
    overflow = max(0, previous-(bottom-18))
    for actual, text, color, desired in positions:
        label_y = desired-overflow
        draw.line((right, actual, right+8, label_y+8), fill=color)
        draw.text((right+12, label_y), text, fill=color, font=small)
    for index in (0, len(bars)//2, len(bars)-1):
        stamp = datetime.fromtimestamp(bars[index].start_ms/1000, UTC).strftime('%m-%d %H:%M')
        draw.text((max(left, min(right-100, x(bars[index].start_ms))), bottom+14), stamp, fill='#94a3b8', font=small)
    cutoff = datetime.fromtimestamp(snapshot['cutoff_ms']/1000, UTC).isoformat(timespec='seconds')
    draw.text((28, 685), 'SENTINEL' if public else f'UTC {cutoff} | snapshot {snapshot["snapshot_hash"][:12]} | not a live chart', fill='#94a3b8', font=small)
    stream = BytesIO()
    image.save(stream, 'PNG', optimize=True)
    return stream.getvalue()
