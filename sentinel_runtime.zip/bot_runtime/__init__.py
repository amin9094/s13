"""Modular Telegram bot runtime for SENTINEL v8."""
FEATURE_MODULES = ('navigation', 'commerce_calculator', 'market_data', 'signals_portfolio', 'account_support', 'crm_content', 'admin_operations', 'growth_campaigns', 'analytics_governance', 'platform_expansion', 'operations_governance', 'system_center', 'user_today', 'experience', 'creation', 'automation_ui', 'runtime_jobs')
