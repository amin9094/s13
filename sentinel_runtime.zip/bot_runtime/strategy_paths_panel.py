"""Native Telegram controls for strategy routes; decisions keep per-user versions."""
from html import escape
from uuid import uuid4
from telegram import InlineKeyboardButton as B,InlineKeyboardMarkup
from core.async_runtime import run_blocking
from core.error_explanations import admin_error_text
from repositories.v2.live_signal_inbox import STRATEGIES
from services.strategy_paths_service import path_overview,path_action,path_report


async def paths_panel(q,context,parts,user):
    kind=parts[1]
    try:
        if kind=='paths':
            rows=[[B(label,callback_data=f'ls:pl:{i}:0')] for i,label in enumerate(STRATEGIES.values())]
            rows.append([B('بازگشت به حساب‌ها',callback_data='ls:o')])
            await q.edit_message_text('مسیرها، مقایسه و کنترل استراتژی\nاستراتژی را انتخاب کنید.',reply_markup=InlineKeyboardMarkup(rows));return
        if kind in {'pc','pn','pt','pd'}:
            saved=context.user_data.get('strategy_path_views',{}).get(parts[2])
            if not saved:raise ValueError('STRATEGY_PATH_CHANGED')
            strategy=saved['engine'];data=saved['data'];index=list(STRATEGIES).index(strategy)
            if kind=='pd':
                import io
                content=await run_blocking(path_report,user,strategy,timeout=30)
                stream=io.BytesIO(content);stream.name='strategy-paths.csv'
                await q.message.reply_document(document=stream,caption='مقایسهٔ مسیرهای آزمایشی؛ هزینه و نتیجهٔ نامعلوم در سند مشخص‌اند.');return
            if kind=='pt':
                await run_blocking(path_action,user,strategy,{'action':'control','enabled':not data['enabled'],'revision':data['control_revision']},timeout=10)
            elif kind=='pc':
                selected=data['items'][int(parts[3])];active=next(r for r in data['items'] if r['active'])
                if len(parts)<5:
                    text='انتخاب '+selected['payload']['name']+'\nدو دورهٔ تازهٔ ۵۰۰۰ دلاری آغاز می‌شود. معاملات و نتایج قبلی بایگانی می‌شوند؛ خروج فرضی ثبت نمی‌شود.'
                    await q.edit_message_text(text,reply_markup=InlineKeyboardMarkup([[B('تأیید انتخاب مسیر',callback_data=f'ls:pc:{parts[2]}:{parts[3]}:ok')],[B('بازگشت بدون تغییر',callback_data=f'ls:pl:{index}:0')]]));return
                await run_blocking(path_action,user,strategy,{'action':'select','id':selected['id'],'active_id':active['id'],'revision':active['revision']},timeout=30)
            else:
                choices=data['profiles'] if strategy!='custom' else data.get('custom_candidates',[])
                used={r['payload']['profile_id'] for r in data['items']}
                choices=[r for r in choices if r['profile_id'] not in used]
                if len(parts)<4:
                    rows=[[B(c['label'],callback_data=f'ls:pn:{parts[2]}:{i}')] for i,c in enumerate(choices[:12])]
                    rows.append([B('بازگشت',callback_data=f'ls:pl:{index}:0')])
                    await q.edit_message_text('تنظیم مسیر تازه را انتخاب کنید. نتیجه‌ای برای گذشته ساخته نمی‌شود.',reply_markup=InlineKeyboardMarkup(rows));return
                choice=choices[int(parts[3])];body={'action':'create','name':'مسیر '+chr(65+min(25,len(data['items'])))}
                body.update({'custom_config':choice['config']} if strategy=='custom' else {'profile_id':choice['profile_id']})
                await run_blocking(path_action,user,strategy,body,timeout=10)
            parts=['ls','pl',str(index),'0']
        index=int(parts[2]);page=int(parts[3])
        if not 0<=index<len(STRATEGIES) or not 0<=page<=10:raise ValueError('INVALID_REQUEST')
        strategy=list(STRATEGIES)[index];data=await run_blocking(path_overview,user,strategy,timeout=30)
        token=uuid4().hex[:8];views=context.user_data.setdefault('strategy_path_views',{})
        if len(views)>=10:views.pop(next(iter(views)))
        views[token]={'engine':strategy,'data':data}
        text=STRATEGIES[strategy]+'\nسیگنال‌های جدید: '+('فعال' if data['enabled'] else 'متوقف')
        text+='\nنتایج از معاملات ثبت‌شده‌اند؛ شرایط بازار و اندازهٔ نمونهٔ مسیرها الزاماً یکسان نیست. انتخاب خودکار انجام نمی‌شود.'
        rows=[]
        for i,path in enumerate(data['items'][page*6:(page+1)*6],page*6):
            text+='\n\n'+path['payload']['name']+(' · فعال' if path['active'] else '')
            for mode,s in path['results'].items():
                text+=f"\n{'انتظار' if mode=='PENDING' else 'مارکت'}: {s['closed']} بسته · P/L ${s['realized_usd']} · خالص "+(str(s['net_realized_usd']) if s['net_realized_usd'] is not None else 'نامعلوم')+f" · {s['unresolved_positions']} نتیجهٔ نامعلوم"
            if not path['active']:rows.append([B('انتخاب '+path['payload']['name'][:36],callback_data=f'ls:pc:{token}:{i}')])
        if (page+1)*6<len(data['items']):rows.append([B('مسیرهای بعدی',callback_data=f'ls:pl:{index}:{page+1}')])
        if page:rows.append([B('مسیرهای قبلی',callback_data=f'ls:pl:{index}:{page-1}')])
        rows += [[B('ساخت مسیر تازه',callback_data=f'ls:pn:{token}'),B('سند مقایسه',callback_data=f'ls:pd:{token}')],
                 [B('توقف سیگنال‌های جدید' if data['enabled'] else 'ادامهٔ سیگنال‌های جدید',callback_data=f'ls:pt:{token}')],
                 [B('بازگشت به استراتژی‌ها',callback_data='ls:paths')]]
        await q.edit_message_text(escape(text),parse_mode='HTML',reply_markup=InlineKeyboardMarkup(rows))
    except (ValueError,KeyError,IndexError,PermissionError) as exc:
        await q.edit_message_text(admin_error_text(exc,source='strategy_paths'),reply_markup=InlineKeyboardMarkup([[B('مسیرهای استراتژی',callback_data='ls:paths')]]))
