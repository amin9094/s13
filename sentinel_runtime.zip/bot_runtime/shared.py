"""Shared imports and immutable constants for modular Telegram features."""

from __future__ import annotations

import asyncio

import io

import logging

import os

import re

import shutil

import uuid

import warnings

from collections import Counter

from datetime import UTC, datetime, timedelta

from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

from pathlib import Path

from typing import Any


from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from telegram import (
    InlineKeyboardMarkup,
    InputMediaPhoto,
    ReplyKeyboardRemove,
    Update,
    WebAppInfo,
)


try:
    from telegram import MenuButtonCommands, MenuButtonWebApp
except ImportError:  # minimal Telegram test stubs may not expose menu button types
    class MenuButtonCommands:  # type: ignore[no-redef]
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

    class MenuButtonWebApp:  # type: ignore[no-redef]
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

from telegram.constants import ParseMode

from telegram.error import BadRequest, Forbidden, RetryAfter, TelegramError

from telegram.ext import (
    Application,
    ApplicationHandlerStop,
    CallbackQueryHandler,
    ChatMemberHandler,
    CommandHandler,
    ContextTypes,
    ConversationHandler,
    MessageHandler,
    filters,
)

from handlers.callback_routes import callback_routes

from handlers.registration_plan import COMMAND_ROUTES, CONVERSATION_HANDLER_NAMES, GUARD_STACK

from handlers.registry import (
    register_callback_routes,
    register_command_plan,
    register_guard_plan,
    register_handlers,
    resolve_named,
)

from telegram.warnings import PTBUserWarning

from config import SETTINGS, is_admin, persistent_storage_status


def telegram_webapp_launch_url(username: str = "") -> str:
    """Return the exact canonical URL configured for Telegram Web App launches.

    BotFather/menu launches and inline ``web_app`` buttons must point to the
    same URL. Adding an application-owned query parameter here made Telegram
    clients treat the inline launch as a different document and could delay or
    omit the signed ``initData`` bridge. Identity always comes from Telegram's
    signed payload, never from a URL hint.
    """
    if not SETTINGS.has_webapp:
        return ""
    return str(SETTINGS.webapp_url or "").strip()

from core.async_db import async_read_db_section, async_snapshot, async_with_db

from core.backup_service import (
    backup_metadata,
    create_operational_backup,
    create_payload_backup,
    create_postgres_dump_backup,
    list_payload_backups,
    load_payload_backup,
    prune_operational_backups,
    run_payload_restore_drill,
    run_postgres_dump_restore_drill,
    upload_external_backup,
    verify_payload_backup,
)

from core.db import database_healthcheck, load_db, with_db

from core.distributed_jobs import close_distributed_jobs, distributed_job

from core.domain import (
    DISCOUNT_TIERS,
    activate_vip,
    add_points,
    apply_referral,
    assign_discount_from_pool,
    audit,
    card_payment_settings_ready,
    claim_vip_order_approval,
    complete_mission,
    create_reward_request,
    discount_stock_snapshot,
    ensure_discount_system,
    ensure_referral,
    referral_program_settings,
    update_referral_program_setting,
    record_referral_purchase,
    finalize_vip_order_approval,
    find_vip_order,
    is_vip,
    projected_vip_expiry,
    record_event,
    recover_stale_order_claim,
    refill_discount_pool,
    register_user,
    release_discount,
    release_vip_order_approval,
    reserve_discount,
    resolve_registered_user_id,
    return_discount_to_pool,
    stale_vip_order_claims,
    store_vip_order_processing_invite,
    usdt_payment_settings_ready,
    validate_discount,
)

from core.async_runtime import run_blocking

from core.heartbeat import write_heartbeat

from core.http_client import circuit_snapshot, close_http_client

from core.observability import (
    configure as configure_observability,
)

from core.observability import gauge as metric_gauge

from core.observability import (
    increment as metric_increment,
)

from core.observability import (
    observed_job,
    register_readiness_check,
    set_readiness_state,
    start_health_server,
    stop_health_server,
)

from core.observability import (
    persist as persist_observability,
)

from core.observability import (
    record_error as record_observability_error,
)
from core.observability import snapshot as observability_snapshot

from core.persistence import SafePostgresPersistence, SafeSQLitePersistence

from core.shared_cache import shared_cache_healthcheck

from modules.receipt_storage import receipt_storage_status

from core.process_lock import acquire_single_instance

from core.rate_limit import allow as rate_limit_allow

from core.shared_cache import cache_get as shared_cache_get

from core.shared_cache import cache_set as shared_cache_set

from core.shared_cache import close_shared_cache

from core.telemetry import configure_telemetry

from core.update_processor import KeyedUpdateProcessor

from core.utils import (
    chunk_text,
    configure_logging,
    display_dt,
    esc,
    parse_dt,
    parse_finite_float,
    parse_positive_int,
    utc_iso,
    utc_now,
)

from modules.admin_access import (
    ALL_PERMISSIONS,
    OWNER_ONLY_PERMISSIONS,
    ADMIN_ROLE_PRESETS,
    PERMISSION_SIGNALS_VIEW,
    PERMISSION_SIGNAL_PUBLISH_NOW,
    PERMISSION_SIGNAL_SCHEDULE,
    PERMISSION_SIGNAL_APPROVE,
    PERMISSION_SIGNAL_CHART_MANAGE,
    PERMISSION_SIGNAL_BOARD_MANAGE,
    PERMISSION_SIGNAL_STATUS_MANAGE,
    PERMISSION_SIGNAL_METRICS_EDIT,
    PERMISSION_USERS_VIEW,
    PERMISSION_USER_BAN_MANAGE,
    PERMISSION_USER_DIRECT_MESSAGE,
    PERMISSION_USER_VIP_ASSIGN,
    PERMISSION_USER_SENSITIVE_DATA_VIEW,
    PERMISSION_CRM_VIEW,
    PERMISSION_CRM_PIPELINE_MANAGE,
    PERMISSION_CRM_DISCOUNT_SEND,
    PERMISSION_CRM_NOTES_MANAGE,
    PERMISSION_CRM_EXPORT,
    PERMISSION_TICKETS_VIEW,
    PERMISSION_TICKETS_REPLY,
    PERMISSION_TICKETS_ASSIGN,
    PERMISSION_TICKETS_STATUS_MANAGE,
    PERMISSION_TICKETS_PRIORITY_MANAGE,
    PERMISSION_TICKET_ATTACHMENTS_VIEW,
    PERMISSION_TICKET_INTERNAL_NOTES,
    PERMISSION_TICKETS_DELETE,
    PERMISSION_CHANNEL_POSTS_PUBLISH,
    PERMISSION_CHANNEL_POSTS_EDIT,
    PERMISSION_CHANNEL_POSTS_DELETE,
    PERMISSION_CHANNEL_PIN_MANAGE,
    PERMISSION_CHANNEL_LINKS_MANAGE,
    PERMISSION_FORCED_JOIN_MANAGE,
    PERMISSION_PUBLISHER_QUEUE_MANAGE,
    PERMISSION_ANNOUNCEMENT_PREVIEW,
    PERMISSION_ANNOUNCEMENT_PUBLISH,
    PERMISSION_EDUCATION_VIEW,
    PERMISSION_EDUCATION_CREATE,
    PERMISSION_EDUCATION_EDIT,
    PERMISSION_EDUCATION_PUBLISH,
    PERMISSION_EDUCATION_PRICE_MANAGE,
    PERMISSION_EDUCATION_DELETE,
    PERMISSION_CONTEST_VIEW,
    PERMISSION_CONTEST_CREATE,
    PERMISSION_CONTEST_PUBLISH,
    PERMISSION_CONTEST_RESULT_MANAGE,
    PERMISSION_CONTEST_SCORE_MANAGE,
    PERMISSION_CONTEST_END,
    PERMISSION_CONTEST_DELETE,
    PERMISSION_MISSION_VIEW,
    PERMISSION_MISSION_CREATE,
    PERMISSION_MISSION_PUBLISH,
    PERMISSION_MISSION_REWARD_MANAGE,
    PERMISSION_MISSION_EVIDENCE_REVIEW,
    PERMISSION_MISSION_DELETE,
    PERMISSION_SYSTEM_HEALTH_VIEW,
    PERMISSION_RUNTIME_LOGS_VIEW,
    PERMISSION_MAINTENANCE_MODE_MANAGE,
    PERMISSION_FEATURE_TOGGLE_MANAGE,
    PERMISSION_BACKUP_CREATE,
    PERMISSION_BACKUP_DOWNLOAD,
    PERMISSION_BACKUP_RESTORE,
    PERMISSION_INTEGRATION_HEALTH_VIEW,
    PERMISSION_WEBHOOK_MANAGE,
    PERMISSION_API_CREDENTIALS_MANAGE,
    PERMISSION_ADMIN_MANAGEMENT,
    PERMISSION_ADMIN_SHIFTS,
    PERMISSION_ANALYST_DASHBOARD,
    PERMISSION_ANNOUNCEMENTS,
    PERMISSION_AUDIT_LOGS,
    PERMISSION_AUTOMATIONS,
    PERMISSION_BACKUPS,
    PERMISSION_BROADCAST,
    PERMISSION_CAMPAIGNS,
    PERMISSION_CHANNEL_ATTRIBUTION,
    PERMISSION_CHANNEL_MANAGEMENT,
    PERMISSION_KPI_TRADER_MANAGE,
    PERMISSION_AI_COPILOT,
    PERMISSION_RISK_COACH,
    PERMISSION_PAPER_TRADING,
    PERMISSION_PROP_GUARDIAN,
    PERMISSION_PUBLISHER,
    PERMISSION_PARTNERS,
    PERMISSION_PUBLIC_PERFORMANCE,
    PERMISSION_CONTENT_FACTORY,
    PERMISSION_BUSINESS_INBOX,
    PERMISSION_DEVELOPER_API,
    PERMISSION_WORKSPACES,
    PERMISSION_OPERATIONS_GOVERNANCE,
    PERMISSION_KPI_TRADER_VIEW,
    PERMISSION_CONTEST_STATS,
    PERMISSION_CONTESTS,
    PERMISSION_CRM,
    PERMISSION_DASHBOARD,
    PERMISSION_DISCOUNTS,
    PERMISSION_EDUCATION,
    PERMISSION_EXPORT_CSV,
    PERMISSION_FAQ,
    PERMISSION_FEATURE_MANAGEMENT,
    PERMISSION_INCIDENTS,
    PERMISSION_LEADERBOARD,
    PERMISSION_MARKET_INTELLIGENCE,
    PERMISSION_MISSION_CONTROL,
    PERMISSION_MISSIONS,
    PERMISSION_PAID_EDUCATION,
    PERMISSION_PAYMENT_RECONCILIATION,
    PERMISSION_PAYMENTS,
    PERMISSION_PAYMENT_DASHBOARD_VIEW,
    PERMISSION_PAYMENT_TRANSACTIONS_VIEW,
    PERMISSION_PAYMENT_RECEIPTS_VIEW,
    PERMISSION_PAYMENT_RECEIPT_APPROVE,
    PERMISSION_PAYMENT_RECEIPT_REJECT,
    PERMISSION_PAYMENT_MANUAL_REVIEW,
    PERMISSION_PAYMENT_TXID_VIEW,
    PERMISSION_PAYMENT_TXID_VERIFY,
    PERMISSION_PAYMENT_METHOD_MANAGE,
    PERMISSION_PAYMENT_WALLET_MANAGE,
    PERMISSION_PAYMENT_HISTORY_EXPORT,
    PERMISSION_PAYMENT_REFUND_REQUEST,
    PERMISSION_PAYMENT_REFUND_APPROVE,
    PERMISSION_PAYMENT_VIP_ACTIVATE,
    PERMISSION_PAYMENT_VIP_EXTEND,
    PERMISSION_PORTFOLIO,
    PERMISSION_PROVIDER_HEALTH,
    PERMISSION_RENEWALS,
    PERMISSION_REWARD_POINTS,
    PERMISSION_REWARD_REQUESTS,
    PERMISSION_RISK_BOARDS,
    PERMISSION_RULES,
    PERMISSION_RUNTIME_SAFETY,
    PERMISSION_LABELS,
    PERMISSION_SHORT_LABELS,
    PERMISSION_SIGNAL_DELETE,
    PERMISSION_SIGNAL_EDIT,
    PERMISSION_SIGNAL_RESULTS,
    PERMISSION_SIGNAL_TEMPLATES,
    PERMISSION_SIGNALS,
    PERMISSION_SYSTEM_CONTROL,
    PERMISSION_TICKETS,
    PERMISSION_TRUST_CENTER,
    PERMISSION_TWO_STEP_APPROVALS,
    PERMISSION_USER_REWARDS,
    PERMISSION_USERS,
    PERMISSION_VIP_EXTENSION,
    PERMISSION_VIP_SETTINGS,
    PERMISSION_VIP_PLAN_VIEW,
    PERMISSION_VIP_PLAN_CREATE,
    PERMISSION_VIP_PLAN_EDIT,
    PERMISSION_VIP_PLAN_ACTIVATE,
    PERMISSION_VIP_PLAN_ARCHIVE,
    PERMISSION_VIP_PLAN_DELETE,
    PERMISSION_VIP_PLAN_ASSIGN_USERS,
    PERMISSION_CAPABILITIES,
    PERMISSION_RETENTION,
    PERMISSION_GROUPS,
    apply_admin_role_preset,
    delegated_admins,
    get_delegated_admin,
    normalize_admin_id,
    remove_delegated_admin,
    set_permissions,
    toggle_permission,
    upsert_delegated_admin,
)

from modules.admin_access import (
    has_permission as delegated_has_permission,
)

from modules.admin_access import (
    is_any_admin as db_is_any_admin,
)

from modules.admin_control_center import (
    CAPABILITY_LABELS,
    NOTIFICATION_KEYS,
    capability_status,
    capability_summary,
    close_league_season,
    control_summary,
    ensure_control_center,
    export_control_payload,
    feature_for_callback,
    feature_for_context,
    is_module_enabled,
    notification_preferences,
    pause_notifications,
    record_maintenance,
    set_control_value,
    set_notification_quiet_hours,
    set_notification_digest_time,
    set_notification_timezone,
    start_league_season,
    toggle_control_value,
    toggle_notification,
    trim_runtime_data,
)

from modules.admin_ui import (
    admin_ui_mode,
    callback_visible_in_mode,
    set_admin_ui_mode,
)

from modules.admin_control_center import (
    CATEGORIES as CONTROL_CATEGORIES,
)

from modules.admin_control_center import (
    FIELD_BY_KEY as CONTROL_FIELDS,
)

from modules.admin_control_center import (
    MODULE_BY_KEY as CONTROL_MODULES,
)

from modules.admin_control_center import (
    apply_preset as apply_control_preset,
)

from modules.admin_control_center import (
    category_modules as control_category_modules,
)

from modules.admin_control_center import (
    module_state as control_module_state,
    normalize_control_value,
)

from modules.admin_control_center import (
    reset_module as reset_control_module,
)

from modules.advanced_features import (
    ALERT_ASSETS,
    ALERT_LOCAL_ASSETS,
    active_ban,
    complete_price_alert_delivery,
    create_price_alert,
    delete_price_alert,
    find_registered_user,
    normalize_signal_message_channel_id,
    prepare_price_alert_deliveries,
    price_alert_history,
    random_reward_recipients,
    record_user_reward,
    register_signal_record,
    reset_signal_channel_stats,
    reset_signal_result,
    rewards_for_user,
    set_signal_message_channel_id,
    set_reward_points,
    set_user_ban,
    signal_channel_stats,
    signal_channel_stats_reset_at,
    signal_message_channel_id,
    toggle_price_alert,
    transactions_csv,
    unban_user,
    update_reward_status,
    user_price_alerts,
    user_segments,
)

from modules.analytics import admin_dashboard_snapshot, user_account_snapshot

from modules.business_dashboard import commercial_dashboard

from modules.announcements import ANNOUNCEMENT_TOPICS, announcement_history, announcement_summary, record_announcement

from modules.broadcast_queue import (
    broadcast_progress,
    cancel_broadcast,
    checkpoint_broadcast_result,
    claim_broadcast_batch,
    enqueue_broadcast,
    find_broadcast_job,
    finish_broadcast_batch,
    pause_broadcast,
    renew_broadcast_lease,
    resume_broadcast,
)

from modules.calculator import calculate_crypto_position_size, calculate_position_size

from modules.channel_insights import channel_analytics, record_channel_event, record_member_snapshot

from modules.channel_attribution import (
    channel_link_by_id,
    mark_public_channel_link_revoked,
    public_channel_attribution_summary,
    public_channel_link_report,
    record_public_channel_membership,
    register_public_channel_link,
)

from modules.channel_management import (
    claim_scheduled_signal,
    due_scheduled_signals,
    ensure_channel_management,
    get_channel_management,
    parse_force_join_channels,
    parse_schedule_time,
    renew_scheduled_signal_lease,
    required_join_channels,
    schedule_signal,
    scheduled_signal_rows,
    set_channel_option,
    set_force_join,
    set_force_join_channels,
    signal_age_minutes,
    signal_board_page,
    smart_pin_text,
    update_scheduled_signal,
)

from modules.contest import (
    add_candle_guess,
    add_chart_answer,
    add_news_direction_answer,
    add_price_guess,
    end_candle_contest,
    end_chart_contest,
    end_news_direction_contest,
    end_price_contest,
    get_open_candle_contest,
    get_open_chart_contest,
    get_open_news_direction_contest,
    get_open_price_contest,
    get_unsettled_price_contest,
    mark_deadline_notification_result,
    refresh_all_contests,
    start_candle_contest,
    start_chart_contest,
    start_news_direction_contest,
    start_price_contest,
)

from modules.crm_automation import (
    assign_crm_admin,
    claim_crm_automation_events,
    claim_first_entry_welcome,
    crm_activity_timeline,
    crm_automation_log_rows,
    crm_dashboard_snapshot,
    mark_crm_automation_event,
    set_crm_custom_field,
)

from modules.crm_engine import (
    CRM_STAGES,
    crm_pipeline_snapshot,
    due_crm_followups,
    mark_followup_notified,
    set_crm_stage,
)

from modules.crypto_prices import (
    CryptoQuote,
    compare_crypto_providers,
    fetch_crypto_market_leaders,
    fetch_crypto_quote,
    popular_crypto_assets,
    search_crypto,
)

from modules.automation_outbox import enqueue_automation_message

from modules.discount_campaigns import (
    calculate_discount_amount,
    campaign_report,
    claim_discount_reminder_events,
    generate_one_time_codes,
    mark_discount_reminder_event,
    parse_campaign_update_text,
    register_discount_distribution,
    settle_discount_for_order,
    update_discount_campaign,
)

from modules.campaign_studio import (
    CAMPAIGN_AUDIENCES,
    CAMPAIGN_CATEGORIES,
    activate_link_campaign,
    attach_campaign_discount,
    campaign_by_id,
    campaign_preview,
    campaign_studio_summary,
    create_marketing_campaign,
    marketing_campaign_report,
    record_campaign_touch,
    schedule_campaign,
    set_campaign_delivery,
    set_campaign_status,
)

from modules.economic_calendar import (
    CALENDAR_CURRENCIES,
    calendar_automation_snapshot,
    cache_calendar_events,
    calendar_settings,
    claim_auto_publication,
    claim_due_calendar_notifications,
    cycle_user_calendar_impact,
    cycle_user_calendar_reminder,
    cycle_user_calendar_timezone,
    fetch_economic_calendar,
    mark_auto_publication,
    mark_calendar_notification,
    render_calendar_alert,
    render_public_calendar,
    render_user_calendar,
    toggle_user_actual_alerts,
    toggle_user_calendar_alerts,
    toggle_user_calendar_currency,
    update_calendar_setting,
    user_calendar_preferences,
)

from modules.economic_calendar import (
    filter_events as filter_economic_events,
)

from modules.economic_calendar import (
    render_admin_event as render_admin_calendar_event,
)

from modules.economic_calendar import (
    render_selected_events as render_selected_calendar_events,
)

from modules.education import (
    create_lesson as create_education_lesson,
)

from modules.education import (
    delete_lesson as delete_education_lesson,
)

from modules.education import (
    add_lesson_attachment,
    append_lesson_text,
    duplicate_lesson,
    education_statistics,
    lesson_has_content,
    lesson_progress,
    mark_lesson_complete,
    rate_lesson,
    remove_lesson_attachment,
    set_lesson_status,
    visible_lessons,
)

from modules.education import (
    find_lesson as find_education_lesson,
)

from modules.education import (
    update_lesson as update_education_lesson,
)

from modules.incident_center import (
    claim_critical_notifications,
    incident_summary,
    maintain_incidents,
    mark_incident_notification,
    record_incident,
    update_incident_status,
)

from modules.growth_link_lab import growth_link_lab

from modules.iran_prices import IranMarketQuote, fetch_iran_market_snapshot

from modules.league import get_league, get_level

from modules.management_suite import (
    FINAL_SIGNAL_STATUSES,
    add_crm_note,
    approval_settings,
    approve_education_order,
    automation_settings,
    complete_crm_follow_up,
    create_backup,
    create_education_order,
    create_pending_approval,
    crm_summary,
    delete_signal_permanently,
    edit_signal,
    find_education_order,
    has_education_access,
    inactive_automation_events,
    is_admin_on_shift,
    issue_custom_discount,
    load_backup,
    mark_automation_log,
    mark_renewal_event,
    operation_requires_approval,
    pending_approvals,
    renewal_events,
    resolve_pending_approval,
    resolve_tracking_proposal,
    set_admin_shift,
    set_crm_follow_up,
    set_signal_lifecycle,
    set_signal_result_media,
    set_signal_result_media_deliveries,
    set_signal_metrics,
    signal_status_label,
    snooze_crm_follow_up,
    store_tracking_proposals,
    toggle_admin_shift,
    toggle_crm_tag,
    tracking_candidates,
    update_automation_setting,
)

from modules.market_catalog import asset_title, normalize_asset_symbol, popular_assets

from modules.market_data import fetch_ranges

from modules.market_intelligence import (
    api_states,
    build_market_snapshot,
    build_outlooks,
    create_briefing,
    ensure_market_intelligence,
    get_briefing,
    latest_snapshot,
    morning_generation_due,
    render_economy,
    render_energy,
    render_filings,
    render_morning_brief,
    render_news,
    render_outlook,
    render_selected_news,
    save_snapshot,
    scenario_performance,
    set_briefing_status,
    test_api_connections,
)

from modules.market_intelligence import (
    update_settings as update_market_intelligence_settings,
)

from modules.market_scope import (
    MARKET_CRYPTO,
    MARKET_FOREX,
    classify_market_symbol,
    market_label,
    normalize_market_category,
    signal_market_category,
)

from modules.market_sessions import SESSION_LABELS, session_performance

from modules.missions import (
    ALLOWED_EVENTS as MISSION_EVENTS,
)

from modules.missions import (
    create_mission as create_managed_mission,
)

from modules.missions import (
    delete_mission as delete_managed_mission,
)

from modules.missions import (
    duplicate_mission,
    find_mission,
    mission_available,
    mission_progress_snapshot,
    toggle_mission,
)

from modules.missions import (
    update_mission as update_managed_mission,
)

from modules.payment_verification import (
    normalize_network,
    normalize_txid,
    txid_used,
    verify_usdt_transaction,
    wallet_valid,
)

from modules.portfolio import (
    add_journal_entry,
    add_journal_admin_note,
    clear_watchlist,
    clear_watchlist_market,
    delete_journal_entry,
    ensure_signal_journal_entry,
    journal_csv,
    journal_csv_by_market,
    journal_entries,
    journal_entries_by_market,
    journal_stats,
    journal_stats_by_market,
    portfolio_admin_summary,
    remove_watchlist_symbol,
    set_watchlist_alerts,
    toggle_watchlist_symbol,
    update_journal_result,
    watchlist_by_market,
    watchlist_for_user,
)

from modules.prices import fetch_market_quote, fetch_price, fetch_prices, normalize_market_symbol, normalize_tracking_symbol, provider_names_for_symbols

from modules.privacy import (
    cancel_account_deletion,
    export_user_json,
    process_due_deletions,
    request_account_deletion,
    retention_cleanup,
)

from modules.retention_engine import (
    claim_due_retention_events,
    mark_retention_delivery,
    queue_retention_events,
    record_retention_conversion,
    retention_candidates,
    retention_message,
    retention_settings,
    retention_summary,
)

from modules.risk_exposure import exposure_snapshot, professional_exposure_boards

from modules.runtime_safety import publication_allowed, runtime_safety, set_runtime_mode

from modules.mission_control import mission_control_snapshot

from modules.payment_reconciliation import reconcile_order, reconciliation_summary

from modules.provider_health import provider_health_summary, record_provider_result, sanitize_provider_health

from modules.admin_today import admin_today_snapshot, toggle_admin_today_item

from modules.notification_router import route_notification, set_notification_filters

from modules.analyst_dashboard import analyst_dashboard, all_analyst_dashboards

from modules.kpi_trader import (
    QUALITY_CHECKS as KPI_QUALITY_CHECKS,
    adjust_trader_score as adjust_kpi_trader_score,
    claim_due_reminders as claim_kpi_due_reminders,
    create_task as create_kpi_task,
    kpi_settings,
    kpi_team_dashboard,
    kpi_trader_dashboard,
    list_tasks_for_trader,
    monthly_points_awarded as kpi_monthly_points_awarded,
    quality_gate_snapshot as kpi_quality_gate_snapshot,
    record_task_business_outcome as record_kpi_business_outcome,
    review_submission as review_kpi_submission,
    set_task_status as set_kpi_task_status,
    submission_by_id as kpi_submission_by_id,
    submit_task as submit_kpi_task,
    task_by_id as kpi_task_by_id,
    task_is_overdue as kpi_task_is_overdue,
    trader_task_submission,
    task_business_totals as kpi_task_business_totals,
    toggle_quality_check as toggle_kpi_quality_check,
    update_kpi_settings,
)

from modules.team_operations import (
    notification_intelligence,
    subscription_growth_center,
    team_operations_calendar,
    team_performance_dashboard,
)

from modules.signal_live_card import live_card_text

from modules.sales_growth import (
    active_vip_plans,
    create_public_discount,
    create_vip_plan,
    create_weekly_public_discount,
    crm_segment_snapshot,
    cycle_vip_plan_audience,
    delete_vip_plan,
    ensure_vip_plans,
    expire_public_discount,
    get_vip_plan,
    public_discount_codes,
    sales_funnel_snapshot,
    toggle_public_discount,
    toggle_vip_plan,
    toggle_vip_plan_highlight,
    update_vip_plan,
)

from modules.signal_engine import enrich_signal_payload, normalize_entries

from modules.signal_image import create_signal_image

from modules.signal_portal import (
    close_signal_cycle,
    current_signal_cycle,
    delete_signal_cycle,
    get_user_signal_choice,
    list_signal_cycles,
    release_reserved_signal_number,
    rename_signal_cycle,
    reserve_signal_identity,
    reset_signal_cycle,
    rollover_signal_cycle,
    set_user_signal_choice,
    signal_cycle_detail,
    signal_cycle_rows,
    signal_cycle_summary,
    signal_display_number,
    signal_portal_stats,
    start_signal_cycle,
    user_signal_status_text,
    user_visible_signals,
)

from modules.signal_reference import find_signal_by_delivery, parse_signal_reply_status, signal_reference

from modules.receipt_storage import read_receipt_bytes

from modules.rules import (
    accept_current_rules,
    current_rules,
    publish_rules,
    rules_acceptance_summary,
    rules_acceptance_history,
    set_rules_enabled,
    user_has_accepted_rules,
)

from modules.i18n import (
    normalize_language,
    set_user_language,
    tr,
    user_language,
)

from modules.signal_safety import (
    claim_expired_signal_approvals,
    create_signal_approval,
    evaluate_signal_safety,
    expire_due_signals,
    format_safety_report,
    mark_signal_approval_execution,
    mark_expired_signal_approval_notice,
    pending_signal_approvals,
    resolve_signal_approval,
)

from modules.signal_template_editor import (
    FIELD_LABELS as SIGNAL_TEMPLATE_FIELD_LABELS,
)

from modules.signal_template_editor import (
    TEMPLATE_FIELDS as SIGNAL_TEMPLATE_FIELDS,
)

from modules.signal_template_editor import (
    change_signal_template_font,
    ensure_signal_template_settings,
    move_signal_template_field,
    reset_signal_template_side,
    reset_signal_template_background,
    signal_template_background_info,
    signal_template_background_path,
    signal_template_layout,
    store_and_autodetect_signal_template_background,
)

from modules.signal_versioning import signal_version_history

from modules.stock_prices import StockQuote, fetch_stock_quote, popular_stocks, search_stocks

from modules.support import (
    add_internal_note,
    admin_tickets,
    append_ticket_message,
    assign_ticket,
    canned_replies,
    create_canned_reply,
    create_faq,
    create_ticket,
    delete_canned_reply,
    delete_faq,
    find_canned_reply,
    find_faq,
    find_ticket,
    internal_notes,
    record_faq_feedback,
    record_faq_view,
    search_faqs,
    set_ticket_priority,
    set_ticket_satisfaction,
    set_ticket_status,
    ticket_attachment_transport,
    toggle_canned_reply,
    toggle_faq,
    update_faq,
    user_tickets,
)

from modules.trust_center import build_trust_snapshot, refresh_trust_center

from modules.user_experience import search_internal

from modules.user_intelligence import (
    SEGMENT_LABELS,
    build_user_profile,
    full_user_export_zip,
    points_ledger_csv,
    rebuild_all_user_profiles,
    record_user_activity,
    user_activity_csv,
    user_master_csv,
)

from modules.vip import check_expired_vips, restore_vip_channel_access

from repositories import repository_metrics

from services.automation_delivery_service import deliver_automation_outbox

from services.campaign_delivery_service import dispatch_marketing_campaign

from services.campaign_scheduler_service import run_campaign_scheduler

from ui.button_factory import (
    InlineKeyboardButton,
    clone_button_with_callback,
    clone_button_with_text_and_callback,
    canonical_navigation_text,
    state_button,
    _telegram_request_with_button_fallback,
)

from ui.campaign_presenter import (
    campaign_audience_rows as present_campaign_audience_rows,
    campaign_category_rows as present_campaign_category_rows,
    campaign_detail_text as present_campaign_detail_text,
)

logger = logging.getLogger(__name__)

warnings.filterwarnings("ignore", message="If 'per_message=False'.*", category=PTBUserWarning)

(
    BUY_COUPON,
    BUY_RECEIPT,
    CALC_SYMBOL,
    CALC_BALANCE,
    CALC_RISK,
    CALC_ENTRY,
    CALC_SL,
    PRICE_GUESS,
    CANDLE_GUESS,
    SIG_SYMBOL,
    SIG_TYPE,
    SIG_ENTRY,
    SIG_TP,
    SIG_SL,
    SIG_RISK,
    SIG_TARGET,
    VIP_FIELD_VALUE,
    DISC_PERCENT,
    DISC_SEND_UID,
    DISC_SEND_PERCENT,
    LESSON_INPUT,
    PRICE_CONTEST_SYMBOL,
    PRICE_CONTEST_MEDIA,
    PRICE_CONTEST_DURATION,
    PRICE_CONTEST_FINAL,
    CHART_CONTEST_INPUT,
    CHART_CONTEST_FINAL,
    CANDLE_CONTEST_FINAL,
    MISSION_INPUT,
    VIP_EXT_UID,
    VIP_EXT_DAYS,
    CHART_CONTEST_DURATION,
    CANDLE_CONTEST_DURATION,
    MISSION_MANUAL_UID,
    MISSION_MANUAL_ID,
    TICKET_NEW_MESSAGE,
    TICKET_USER_REPLY,
    TICKET_ADMIN_REPLY,
    FAQ_ADD_QUESTION,
    FAQ_ADD_ANSWER,
    CONTEST_REWARD_INPUT,
    PRICE_ALERT_ASSET,
    PRICE_ALERT_CONDITION,
    PRICE_ALERT_VALUE,
    USDT_CONVERT_AMOUNT,
    ADMIN_USER_SEARCH,
    ADMIN_USER_POINTS,
    ADMIN_USER_BAN_REASON,
    BROADCAST_SEGMENT,
    BROADCAST_MESSAGE,
    DISC_RANDOM_PERCENT,
    DISC_RANDOM_COUNT,
    REWARD_POINTS_INPUT,
    ADMIN_ADD_ID,
    ADMIN_PRIVATE_CHANNEL_DAYS,
    CRM_NOTE_INPUT,
    CRM_TAG_INPUT,
    CRM_FOLLOWUP_INPUT,
    AUTOMATION_SETTING_INPUT,
    ADMIN_SHIFT_INPUT,
    SIGNAL_EDIT_INPUT,
    SIGNAL_METRICS_INPUT,
    EDUCATION_RECEIPT,
) = range(63)

SIG_SCHEDULE_TIME, FORCE_JOIN_LINK_INPUT, CRYPTO_SEARCH_INPUT, STOCK_SEARCH_INPUT = range(69, 73)

MARKET_SEARCH_INPUT = 73

ENTERPRISE_CONTROL_INPUT, TICKET_INTERNAL_NOTE_INPUT, TICKET_CANNED_REPLY_INPUT = range(73, 76)

FAQ_EDIT_INPUT, FAQ_SEARCH_INPUT = range(76, 78)

LESSON_EDIT_INPUT = 78

MISSION_EDIT_INPUT = 79

JOURNAL_RESULT_INPUT = 80

SIGNAL_CYCLE_NAME_INPUT = 81
SIGNAL_CYCLE_RENAME_INPUT = 82

# Stable high-number states for the R20 contest/calculator extensions.
CANDLE_CONTEST_QUESTION = 98310
NEWS_CONTEST_NAME = 98311
NEWS_CONTEST_RESULT = 98312
CALC_PROFILE_INPUT = 98320
CALC_BALANCE_CHOICE = 98321
CRM_MESSAGE_INPUT = 98330

# Optional chart image collected during the signal wizard.  A high, isolated
# state number avoids renumbering persistent ConversationHandler states.
SIG_CHART_IMAGE = 98301
SIGNAL_RESULT_MEDIA_INPUT = 98302
SIGNAL_CHANNEL_ID_INPUT = 98303

INTERNAL_SEARCH_INPUT = 84

VIP_PLAN_INPUT = 85

PUBLIC_DISCOUNT_INPUT = 86

VIP_PLAN_NAME_INPUT = 87

VIP_PLAN_PRICE_INPUT = 88

VIP_PLAN_DAYS_INPUT = 89

VIP_PLAN_AUDIENCE_INPUT = 90

VIP_PLAN_ORIGINAL_INPUT = 91

VIP_PLAN_LIMIT_INPUT = 92

VIP_PLAN_HIGHLIGHT_INPUT = 93

VIP_PLAN_FEATURES_INPUT = 94

VIP_PLAN_DESCRIPTION_INPUT = 95

BUY_TXID = 96

VIP_PLAN_WINDOW_INPUT = 96

PUBLIC_CODE_INPUT = 97

PUBLIC_PERCENT_INPUT = 98

PUBLIC_WINDOW_INPUT = 99

PUBLIC_MAX_USES_INPUT = 100

PUBLIC_USER_LIMIT_INPUT = 101

VIP_PLAN_EDIT_INPUT = 102

CRM_CUSTOM_FIELD_INPUT = 103

PUBLIC_CAMPAIGN_EDIT_INPUT = 104

PUBLIC_BATCH_INPUT = 105

PUBLIC_AFFILIATE_INPUT = 106

RULES_INPUT = 107

(
    CALC_MARKET,
    CALC_LEVERAGE,
    CALC_FEE,
    CALC_CROSS,
    SIG_MARKET,
    ANNOUNCE_DEST,
    ANNOUNCE_TOPIC,
    ANNOUNCE_CUSTOM_TITLE,
    ANNOUNCE_CONTENT,
    ANNOUNCE_CONFIRM,
) = range(107, 117)

(
    CAMPAIGN_NAME_INPUT,
    CAMPAIGN_CATEGORY_INPUT,
    CAMPAIGN_AUDIENCE_INPUT,
    CAMPAIGN_DISCOUNT_INPUT,
    CAMPAIGN_MESSAGE_INPUT,
    CAMPAIGN_DELIVERY_INPUT,
    CHANNEL_LINK_INPUT,
) = range(117, 124)

CAMPAIGN_SCHEDULE_INPUT = 124

CAMPAIGN_TRACKING_INPUT = 125

KPI_TASK_INPUT = 126

KPI_SUBMISSION_INPUT = 127

KPI_REJECTION_INPUT = 128

OWNER_KPI_SCORE_INPUT = 129

OWNER_KPI_LIMITS_INPUT = 130

KPI_BUSINESS_OUTCOME_INPUT = 131

JOURNAL_NEW_INPUT = 132

LESSON_MEDIA_INPUT = 133

JOURNAL_ADMIN_NOTE_INPUT = 81

PORTFOLIO_USER_INPUT = 82

PORTFOLIO_RESULT_INPUT = 83

from modules.platform_expansion import (
    behavioral_risk_report,
    classify_business_message,
    close_paper_trade,
    configure_prop_challenge,
    create_paper_account,
    create_partner,
    create_workspace,
    enqueue_publication,
    local_copilot_answer,
    open_paper_trade,
    paper_trade_action,
    paper_arena_snapshot,
    prop_guardian_snapshot,
    register_publisher_channel,
    register_webhook,
    render_content,
    local_market_intelligence,
    platform_dashboard,
    partner_dashboard,
    verified_public_performance,
)
from modules.platform_registry import platform_matrix

from modules.operations_governance import (
    approve_governance_request,
    claim_governance_digest,
    governance_monitoring_enabled,
    governance_notifications_enabled,
    apply_governance_request,
    create_governance_request,
    edit_governance_request,
    governance_control_risk,
    governance_dashboard,
    governance_request,
    governance_reset_risk,
    mark_governance_digest,
    reject_governance_request,
    retry_governance_request,
    run_automation_checks,
    set_governance_notification_snooze,
)

from modules.automated_market_scope import FOREX_USD_PAIRS
FOREX_SIGNAL_SYMBOLS = ["XAUUSD", *FOREX_USD_PAIRS, "XAGUSD", "US100"]

CRYPTO_SIGNAL_SYMBOLS = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "BNBUSDT", "ADAUSDT"]

SYMBOLS = [*FOREX_SIGNAL_SYMBOLS, *CRYPTO_SIGNAL_SYMBOLS]

_RUNTIME_BOT_USERNAME = SETTINGS.bot_username

CONTROL_OPERATION_LINKS: dict[str, tuple[str, str]] = {
    "edu": ("📚 مدیریت محتوای آموزش", "a_edu"),
    "missions": ("✅ مدیریت مأموریت‌ها", "a_missions"),
    "faq": ("❓ مدیریت سوالات", "a_faq"),
    "support": ("🎫 صندوق تیکت‌ها", "a_tickets"),
    "portal": ("📊 مدیریت پرتال سیگنال", "a_signal_results"),
    "watchlists": ("⭐ مدیریت واچ‌لیست‌ها", "a_portfolio"),
    "journal": ("📔 مدیریت ژورنال‌ها", "a_portfolio"),
    "signals": ("📡 مدیریت سیگنال‌ها", "a_signal_results"),
    "tracker": ("🛰 مدیریت کانال و ردیاب", "a_channel_center"),
    "channels": ("📺 مدیریت کانال", "a_channel_center"),
    "prices": ("💹 مدیریت اطلاعات بازار", "a_market_intel"),
    "crypto": ("🪙 مدیریت اطلاعات بازار", "a_market_intel"),
    "stocks": ("📈 مدیریت اطلاعات بازار", "a_market_intel"),
    "energy": ("🛢 مدیریت اطلاعات بازار", "a_market_intel"),
    "calendar": ("🗓 مدیریت تقویم و اخبار", "a_market_intel"),
    "news": ("📰 مدیریت اخبار و سناریو", "a_market_intel"),
    "league": ("🏆 مشاهده لیدربورد", "a_leaderboard"),
    "contests": ("🎯 مدیریت مسابقات", "a_contest"),
    "rewards": ("🎁 مدیریت جوایز", "a_user_rewards"),
    "referrals": ("👥 مدیریت کاربران", "a_users"),
    "account": ("👤 پرونده کاربران", "a_users"),
    "privacy": ("🔒 پرونده کاربران", "a_users"),
    "dashboard": ("📊 داشبورد واقعی", "a_dashboard"),
    "crm": ("🗂 مرکز CRM", "a_crm"),
    "broadcast": ("📣 ارسال همگانی", "a_broadcast"),
    "admins": ("👮 مدیریت ادمین‌ها", "a_admins"),
    "shifts": ("🕒 مدیریت شیفت‌ها", "a_shifts"),
    "automation": ("🤖 اتوماسیون مدیریتی", "a_automations"),
    "exports": ("📦 خروجی اطلاعات", "a_export_csv"),
    "audit": ("📜 مشاهده لاگ‌ها", "a_logs"),
    "health": ("🩺 اجرای عیب‌یابی", "ecc_diag"),
    "backup": ("💾 بکاپ و بازیابی", "a_backups"),
    "database": ("🧹 نگهداری دیتابیس", "ecc_maintenance"),
    "monitoring": ("🩺 مشاهده سلامت", "ecc_diag"),
    "security": ("👮 مدیریت دسترسی‌ها", "a_admins"),
    "runtime": ("🧹 نگهداری Runtime", "ecc_maintenance"),
    "copilot": ("🧠 داشبورد توسعه پلتفرم", "a_platform_expansion"),
    "risk_coach": ("🧠 داشبورد توسعه پلتفرم", "a_platform_expansion"),
    "paper_trading": ("🎮 داشبورد توسعه پلتفرم", "a_platform_expansion"),
    "prop_guardian": ("🛡 داشبورد توسعه پلتفرم", "a_platform_expansion"),
    "market_v2": ("🌐 داشبورد توسعه پلتفرم", "a_platform_expansion"),
    "publisher": ("📣 داشبورد توسعه پلتفرم", "a_platform_expansion"),
    "partners": ("🤝 داشبورد توسعه پلتفرم", "a_platform_expansion"),
    "performance": ("📊 داشبورد توسعه پلتفرم", "a_platform_expansion"),
    "content_factory": ("🏭 داشبورد توسعه پلتفرم", "a_platform_expansion"),
    "business_inbox": ("💼 داشبورد توسعه پلتفرم", "a_platform_expansion"),
    "miniapp_next": ("📱 داشبورد توسعه پلتفرم", "a_platform_expansion"),
    "developer_api": ("🔌 داشبورد توسعه پلتفرم", "a_platform_expansion"),
    "workspaces": ("🏢 داشبورد توسعه پلتفرم", "a_platform_expansion"),
    "governance": ("🧠 مرکز حاکمیت عملیات", "a_ops_governance"),
}

_ACCOUNT_ORDER_STATUS = {
    "pending": "⏳ در انتظار بررسی",
    "approving": "🔄 در حال تأیید",
    "approved": "✅ تأییدشده",
    "rejected": "❌ ردشده",
}

_CRM_CUSTOM_FIELD_LABELS = {
    "phone": "شماره تماس",
    "source": "منبع جذب",
    "company": "شرکت/مجموعه",
    "preferred_market": "بازار موردعلاقه",
    "contact_method": "روش تماس ترجیحی",
}

USER_FEATURE_GROUPS: dict[str, tuple[str, tuple[str, ...]]] = {
    "core": (
        "🧭 امکانات اصلی",
        ("subscriptions", "portal", "risk", "prices", "account", "rules"),
    ),
    "trading": (
        "📡 معامله‌گری",
        ("watchlists", "journal", "alerts", "crypto", "stocks", "energy"),
    ),
    "content": (
        "📚 محتوا و پشتیبانی",
        ("edu", "calendar", "news", "support", "faq"),
    ),
    "club": (
        "🏆 باشگاه کاربران",
        ("missions", "contests", "league", "rewards", "referrals", "privacy", "paper_trading"),
    ),
    "intelligence": (
        "🧠 هوش و کنترل شخصی",
        ("copilot", "risk_coach", "prop_guardian", "market_v2", "performance", "miniapp_next"),
    ),
}

USER_FEATURE_MODULE_KEYS = frozenset(
    module_key
    for _, module_keys in USER_FEATURE_GROUPS.values()
    for module_key in module_keys
)



def _language_for_user(user_id: int | str) -> str:
    """Return a stable user language without relying on feature import order."""
    return user_language(load_db(), user_id) or "fa"


APPROVAL_OPERATION_LABELS = {
    "restore_backup": "بازیابی بکاپ",
    "broadcast_all": "ارسال همگانی",
    "bulk_vip_extension": "تمدید گروهی VIP",
    "admin_remove": "حذف ادمین",
    "admin_all_permissions": "همه مجوزهای ادمین",
    "admin_role_preset": "تغییر نقش ادمین",
}
