from modules.signal_targets import TARGET_KEYS
"""Private Telegram mirror of the signal desk; no unsolicited signal pushes."""
from html import escape
from telegram import InlineKeyboardButton as B,InlineKeyboardMarkup
from core.async_runtime import run_blocking
from repositories.v2.live_signal_inbox import LiveSignalInbox,MARKETS,STRATEGIES
from modules.signal_execution import MODES,account_identity,account_key,mode_of
from services.live_signal_service import permitted,desk_snapshot,decide,paper_snapshot,reset_paper,control_paper,paper_accounts


async def live_signal_callback(update,context):
    q=update.callback_query;user=q.from_user.id
    try:await run_blocking(permitted,user,timeout=5)
    except PermissionError:
        await q.answer('دسترسی ندارید',show_alert=True);return
    await q.answer()
    parts=q.data.split(':');kind=parts[1];rows=[];text='سیگنال‌های زنده'
    iran_route='ir:h' if kind in {'m','s'} and parts[2]=='iran' else None
    if kind in {'v','d','p','x','u'}:
        old=await run_blocking(LiveSignalInbox().get,parts[2],timeout=5)
        if old and old['market']=='iran':iran_route='ir:v:'+old['id']
    if iran_route:
        from bot_runtime.iran_equity_desk import iran_equity_callback
        return await iran_equity_callback(update,context,route=iran_route,already_answered=True)
    cursor=None
    if kind in {'paths','pl','pc','pn','pt','pd'}:
        from bot_runtime.strategy_paths_panel import paths_panel
        return await paths_panel(q,context,parts,user)
    if kind in {'y','yb','yi','yf','ye'}:
        return await custom_strategy_panel(q,context,parts,user)
    if kind=='z':
        saved=context.user_data.get('live_signal_pages',{}).get(parts[2])
        if not saved:return
        m,e,cursor,*saved_mode=saved;parts=['ls','s',m,e,*(saved_mode or [])];kind='s'
    if kind=='b':
        from services.diagnostic_review_service import case_for_signal
        row=await run_blocking(LiveSignalInbox().get,parts[2],timeout=5)
        if not row:return
        key=await run_blocking(case_for_signal,user,row['id'],row['payload']['plan_hash'],timeout=5)
        kind='k';parts=['ls','k',key]
    if kind in {'p','x','u'}:
        key=parts[2];r=await run_blocking(LiveSignalInbox().get,key,timeout=5)
        if not r:return
        body={'action':{'p':'publish','x':'cancel','u':'cancel_publication'}[kind],'plan_hash':r['payload']['plan_hash']}
        if kind=='p':body['audience']='telegram_public' if parts[3]=='public' else 'telegram_private'
        try:await decide(user,key,body)
        except (ValueError,PermissionError) as exc:
            from core.error_explanations import admin_error_text
            await q.edit_message_text(admin_error_text(exc,source='live_signal'),reply_markup=InlineKeyboardMarkup([[B('سیگنال‌های زنده',callback_data='ls:h')]]));return
        kind='v'
    if kind in {'n','t'}:
        from services.desk_notification_service import notification_settings
        try:
            body={'interval_minutes':int(parts[2])} if kind=='t' else None
            d=await run_blocking(notification_settings,user,body,timeout=5)
        except ValueError:return
        interval=d['interval_minutes']
        text=f"🔔 یادآوری سیگنال‌های بررسی‌نشده\nفاصله: {str(interval)+' دقیقه' if interval else 'خاموش'}\nمنتظر تصمیم ادمین: {d['pending']}\nفقط یک پیام کوتاه؛ بازکردن سیگنال به معنی تصمیم‌گیری نیست.\nزمان دلخواه از تنظیمات همین بخش در مینی‌اپ قابل تعیین است."
        rows=[[B(f'{n} دقیقه',callback_data=f'ls:t:{n}') for n in (10,20,30)],
              [B('۶۰ دقیقه',callback_data='ls:t:60'),B('خاموش',callback_data='ls:t:0')],
              [B('برگشت',callback_data='ls:h')]]
    elif kind in {'c','k','j'}:
        from services.diagnostic_review_service import case_list,case_snapshot,review_decision
        if kind=='j':
            saved=context.user_data.get('diagnostic_case_snapshot')
            if not saved or saved['case']['id']!=parts[2]:return
            try:
                result=await review_decision(user,parts[2],{'action':parts[3],'case_hash':saved['case_hash']})
                text='تصمیم ثبت شد. '+('سیگنال تازه در پوشهٔ استراتژی قرار گرفت.' if result['signal_ids'] else 'سیگنال تازه‌ای ساخته نشد.')
            except (ValueError,RuntimeError):text='پرونده تغییر کرده یا بررسی داده کامل نشده است؛ پرونده را دوباره باز کنید.'
            rows=[[B('موارد نیازمند بررسی',callback_data='ls:c')],[B('سیگنال‌های زنده',callback_data='ls:h')]]
        elif kind=='c':
            d=await run_blocking(case_list,user,':'.join(parts[2:]) or None,timeout=5)
            text='موارد نیازمند بررسی\nپرونده را برای تصمیم یا اسکن دوباره انتخاب کنید.'
            rows=[[B(f"{r['symbol']} · {r['timeframe']} · {STRATEGIES.get(r['engine'],'دادهٔ بازار')}",callback_data='ls:k:'+r['id'])] for r in d['items']]
            if d['next_before']:rows.append([B('موارد قدیمی‌تر',callback_data='ls:c:'+d['next_before'])])
            if not rows:text+='\nمورد بازی ثبت نشده است.'
            rows.append([B('برگشت',callback_data='ls:h')])
        else:
            d=await run_blocking(case_snapshot,user,parts[2],timeout=5);r=d['case'];p=r['payload']
            context.user_data['diagnostic_case_snapshot']=d
            text=f"{r['symbol']} · {r['timeframe']}\n{p.get('title_fa','نیازمند بررسی')}\n{p.get('explanation_fa',p.get('reason',''))}\n\nاسکن دوباره فقط با ورود، استاپ و تارگت معتبر سیگنال می‌سازد؛ انتشار جداگانه است."
            prefix=f"ls:j:{r['id']}:"
            rows=[[B('بررسی شد؛ اسکن و ساخت سیگنال',callback_data=prefix+'rescan')],
                  [B('بررسی شد؛ بدون سیگنال',callback_data=prefix+'no_signal'),B('لغو بررسی',callback_data=prefix+'cancel')]]
            if d['revisions']:
                text+=f"\n{len(d['revisions'])} اصلاح کندل ثبت شده؛ نسخهٔ قبلی بایگانی می‌شود و پیشنهادهای وابسته نیازمند اسکن تازه خواهند شد."
                for rev in d['revisions'][:4]:
                    old,new=rev['payload']['old'],rev['payload']['new']
                    text+=f"\n{rev['timeframe']} · {rev['start_ms']}\nOHLCV: "+str([old[k] for k in ('open','high','low','close','volume')])+' → '+str([new[k] for k in ('open','high','low','close','volume')])
                rows.insert(0,[B('پذیرش اصلاح کندل و اسکن تازه',callback_data=prefix+'accept_rescan')])
            rows.append([B('برگشت',callback_data='ls:c')])
    elif kind=='o':
        d=await run_blocking(paper_accounts,user,timeout=15)
        text='حساب‌های آزمایشی مستقل · هر حالتِ هر استراتژی ۵۰۰۰ دلار · ریسک هر ورود ۱٪'
        rows=[[B(f"{STRATEGIES[x.get('strategy',account_identity(x['engine'])[0])]} · {MODES[x.get('execution_mode',account_identity(x['engine'])[1])]} · ${x['account']['payload']['balance']}",callback_data='ls:a:'+x['engine'])] for x in d['accounts']]
        rows.append([B('برگشت',callback_data='ls:h')])
    elif kind=='h':
        d=await run_blocking(desk_snapshot,user,timeout=5)
        text=f"📡 سیگنال‌های زنده · {d['unread']} جدید"
        rows=[[B(f"{m['label']} · {m['unread']}",callback_data=f"ls:m:{m['id']}")] for m in d['markets']]
        rows.append([B('حساب‌های آزمایشی استراتژی‌ها',callback_data='ls:o')])
        rows.extend(desk_settings_rows())
        rows.append([B('برگشت',callback_data='admin_home')])
    elif kind=='m':
        m=parts[2];d=await run_blocking(desk_snapshot,user,timeout=5);folder=next(x for x in d['markets'] if x['id']==m)
        text='سیگنال‌های زنده / '+folder['label']
        rows=[[B(f"{s['label']} · {s['unread']}",callback_data=f"ls:s:{m}:{s['id']}")] for s in folder['strategies']]
        rows.append([B('برگشت',callback_data='ls:h')])
    elif kind=='s':
        m,e=parts[2:4];before=cursor;mode=parts[4] if len(parts)>4 else None
        if mode is not None and mode not in MODES:return
        if mode is None:
            d=await run_blocking(desk_snapshot,user,timeout=5)
            folder=next(x for x in d['markets'] if x['id']==m)
            strategy=next(x for x in folder['strategies'] if x['id']==e)
            text=f"{MARKETS[m]} / {STRATEGIES[e]}\nنوع سیگنال را انتخاب کنید."
            rows=[[B(f"{x['label']} · {x['unread']}",callback_data=f"ls:s:{m}:{e}:{x['id']}")] for x in strategy['modes']]
            rows.append([B('برگشت',callback_data=f'ls:m:{m}')])
        else:
            d=await run_blocking(desk_snapshot,user,market=m,engine=e,before=before,execution_mode=mode,timeout=5)
            text=f"{MARKETS[m]} / {STRATEGIES[e]} / {MODES[mode]}\nسیگنال را برای مشاهدهٔ Entry، SL و TP انتخاب کنید."
            if not d['items']:text+='\nهنوز سیگنال واجد شرایط ثبت نشده است.'
            from modules.strategy_signal_format import priority_label
            rows=[[B(('⭐ ' if priority_label(r['payload']['plan']) else '')+f"{r['payload']['plan']['symbol']} · {r['payload']['plan']['direction']} · {r['payload']['plan']['timeframe']}",callback_data='ls:v:'+r['id'])] for r in d['items']]
            if d['next_before']:
                import uuid
                token=uuid.uuid4().hex[:8];pages=context.user_data.setdefault('live_signal_pages',{})
                if len(pages)>=20:pages.pop(next(iter(pages)))
                pages[token]=(m,e,d['next_before'],mode);rows.append([B('قدیمی‌تر',callback_data='ls:z:'+token)])
            rows.extend([[B('حساب آزمایشی و تاریخچه',callback_data=f'ls:a:{account_key(e,mode)}')],[B('برگشت',callback_data=f'ls:s:{m}:{e}')]])
    elif kind=='v':
        r=await run_blocking(LiveSignalInbox().get,parts[2],timeout=5)
        if not r:return
        p=r['payload']['plan'];labels={'PENDING':'منتظر بررسی','QUEUED':'در صف انتشار','PUBLISHED':'منتشرشده','CANCELLED':'لغوشده','EXPIRED':'ورود گذشته یا نامعتبر','NEEDS_REVIEW':'نیازمند بررسی داده'}
        from modules.strategy_signal_format import level_lines, priority_label
        text=f"{p['symbol']} · {p['direction']} · {p['timeframe']}\n{STRATEGIES[p['engine']]} / {MODES[mode_of(p)]}\n{labels.get(r['state'],r['state'])}\n\n"+'\n'.join(level_lines(p))
        from repositories.v2.strategy_paper import StrategyPaperRepository
        paper_status=await run_blocking(StrategyPaperRepository().for_signal,r['id'],timeout=5)
        paper_labels={'WAITING':'منتظر ورود','OPEN':'باز','CLOSED':'بسته‌شده','NEEDS_REVIEW':'نتیجه نامعلوم؛ بررسی داده','CANCELLED':'ورود لغوشده','PAUSED':'متوقف','RESET_ARCHIVED':'بایگانی دوره','UNAVAILABLE':'ثبت نشده'}
        text+=f"\nشناسه: {r['id'][:8]}\nآزمایش: {paper_labels.get(paper_status['state'],paper_status['state'])}"
        if paper_status.get('fill_price'):text+='\nورود ثبت‌شده: '+paper_status['fill_price']
        from modules.signal_forecast import lines as forecast_lines
        forecast=forecast_lines(p)
        if forecast:text+='\n\n'+'\n'.join(forecast)
        if priority_label(p):text+='\n\n⭐ '+priority_label(p)
        if r['payload']['kind']=='review':text+='\n\nقیمت مرجع تحلیلی؛ هنگام بررسی با بروکر تطبیق داده شود.'
        from modules.signal_plan_policy import entry_eligibility
        needs_rescan=not entry_eligibility(p)['allowed']
        if needs_rescan and r['state'] in {'PENDING','QUEUED'}:
            text+='\n\nاین پیشنهاد به بررسی مجدد نیاز دارد؛ انتشار آن غیرفعال است.'
        if r['state']=='PENDING':
            if not needs_rescan:rows.append([B('انتشار الان · عمومی',callback_data=f"ls:p:{r['id']}:public"),B('انتشار در VIP',callback_data=f"ls:p:{r['id']}:private")])
            rows.append([B('لغو سیگنال',callback_data='ls:x:'+r['id'])])
        elif r['state']=='QUEUED':rows=[[B('لغو انتشار',callback_data='ls:u:'+r['id']),B('لغو سیگنال',callback_data='ls:x:'+r['id'])]]
        for pub in r['payload'].get('publications',{}).values():
            if pub.get('number'):text+=f"\nشمارهٔ انتشار: {pub['number']}"
        if r['state'] in {'NEEDS_REVIEW','EXPIRED'}:
            rows.append([B('لغو سیگنال',callback_data='ls:x:'+r['id'])])
        if r['state'] in {'PENDING','NEEDS_REVIEW','EXPIRED'}:
            rows.append([B('بررسی دوباره و اسکن تازه',callback_data='ls:b:'+r['id'])])
        rows.append([B('تأییدهای همین سیگنال',callback_data='ls:d:'+r['id'])])
        rows.append([B('برگشت',callback_data=f"ls:s:{r['market']}:{r['engine']}:{mode_of(p)}")])
        await run_blocking(LiveSignalInbox().mark_read,[r['id']],user,timeout=5)
    elif kind=='d':
        from services.live_signal_service import signal_details
        d=await run_blocking(signal_details,user,parts[2],timeout=5)
        text=f"{d['symbol']} · {STRATEGIES[d['engine']]}\n"
        if d.get('execution_mode')=='MARKET':text+='ورود مارکت با قیمت زمان تحلیل است؛ تأییدهای زیر مربوط به محدودهٔ مرجع هستند.\n'
        if d['fvg'].get('midpoint'):text+=f"وسط FVG: {d['fvg']['midpoint']}\n"
        if d['entry_selection'].get('original_midpoint'):text+=f"وسط اصلی: {d['entry_selection']['original_midpoint']}\nآفست: {d['entry_selection'].get('actual_offset','0')}\n"
        if d['poc'].get('price'):text+=f"POC موج کامل: {d['poc']['price']} (برآورد حجم کندلی)\n"
        if d['indicator_votes']:text+='\n'.join(f"{name}: {'✓' if ok else '✕'}" for name,ok in d['indicator_votes'].items())+'\n'
        if d.get('stop_protection',{}).get('protective_swing'):
            text+=f"ساختار محافظ استاپ: {d['stop_protection']['protective_swing']}\nحاشیه ساختاری: {d['stop_protection'].get('buffer','—')}\n"
        pool=(d.get('liquidity_pool') or {}).get('selected') or {}
        if pool:
            text+=f"سطح نقدینگی: {pool['reference_price']}؛ سقف/کف تأییدشده: {pool['confirmed_touch_count']}\n"
            text+='این شمارش، حجم واقعی سفارش‌ها نیست.\n'
        inventory=(d.get('fvg_inventory') or {}).get('zones',[])
        if inventory:
            text+=f"شکاف‌های مستقل بررسی‌شده: {len(inventory)}؛ نواحی با هم ادغام نشده‌اند.\n"
        if d.get('exit_guidance',{}).get('state')=='ADMIN_REVIEW_PROPOSAL':
            advice=d['exit_guidance']
            text+='پیشنهاد مدیریت بعد از TP1؛ اجرا فقط با تصمیم ادمین.\n'
            if advice.get('proposed_stop'):text+=f"استاپ پیشنهادی: {advice['proposed_stop']}\n"
        text+='تأیید مکمل PO3 مستقل: '+('دارد' if d['goldbach'].get('confirmed') else 'ندارد')
        if d.get('confluence_priority',{}).get('confirmed'):
            text+='\n⭐ '+d['confluence_priority']['label_fa']
        for match in d.get('confluence_priority',{}).get('matches',[])[:3]:
            text+=f"\nDR Shift: {match['dr_shift']} · GB: {match['goldbach_price']}\nGolden: {match['golden_low']} — {match['golden_high']}"
        rows=[[B('برگشت به سیگنال',callback_data='ls:v:'+parts[2])]]
    elif kind in {'a','r','w'}:
        if kind=='w':
            if len(parts)!=6 or not parts[2].removesuffix('m').isdigit() or not 0<=int(parts[2].removesuffix('m'))<len(STRATEGIES) or parts[5] not in {'0','1'}:return
            e=account_key(list(STRATEGIES)[int(parts[2].removesuffix('m'))],'MARKET' if parts[2].endswith('m') else 'PENDING')
        else:e=parts[2]
        if kind=='w':
            try:await run_blocking(control_paper,user,e,{'run_id':parts[3],'revision':int(parts[4]),'enabled':parts[5]=='1'},timeout=5)
            except ValueError:pass
        if kind=='r':
            try:await run_blocking(reset_paper,user,e,{'run_id':parts[3]},timeout=5)
            except ValueError:pass
        d=await run_blocking(paper_snapshot,user,e,timeout=5);a=d['account'];p=a['payload'];s=d['stats']
        text=f"حساب آزمایشی / {STRATEGIES[account_identity(e)[0]]} / {MODES[account_identity(e)[1]]}\nشروع: {p['starting_balance']} دلار\nموجودی: {p['balance']} دلار\nسود/زیان محقق‌شده: {s['realized_usd']}\nسود/زیان باز: {s['unrealized_usd']}\nمعاملات بسته: {s['closed']}\nنرخ برد: {round(s['win_rate'],1) if s['win_rate'] is not None else '—'}\n\nشبیه‌سازی بر اساس R و قیمت‌های دریافت‌شده؛ کارمزد محاسبه نشده است."
        text+=f"\nریسک هر ورود: ۱٪ موجودی · ورود بعدی: ${s['next_trade_risk_usd']}\nریسک مجموع معاملات: ${s['open_risk_usd']}\nافت موجودی از سقف: ${s['balance_drawdown_usd']}\nورودهای جدید: {'فعال' if p.get('entries_enabled',True) else 'متوقف'}"
        if not s['equity_complete']:text+='\nمعاملهٔ حل‌نشده وجود دارد؛ سود/زیان کامل نیست.'
        text+=f"\n\nثبت خودکار مستقل از تأیید یا رد انتشار ادمین.\nسیگنال‌های ثبت‌شده: {s.get('total_signals',len(d['trades']))}"
        paper_labels={'WAITING':'منتظر ورود','OPEN':'معامله باز','CLOSED':'بسته‌شده','CANCELLED':'لغوشده','NEEDS_REVIEW':'نیازمند بررسی','RESET_ARCHIVED':'بایگانی','PAUSED':'توقف ورود آزمایشی'}
        publication_labels={'PENDING':'منتظر تصمیم ادمین','QUEUED':'در صف انتشار','PUBLISHED':'منتشرشده','CANCELLED':'عدم انتشار','EXPIRED':'مهلت انتشار گذشته','NEEDS_REVIEW':'نیازمند بررسی داده'}
        for t in d['trades'][:8]:
            plan=t['payload']['plan']
            text+=f"\n\n{plan['symbol']} · آزمون: {paper_labels.get(t['state'],'نامشخص')} · ${t['payload']['realized_usd']}\nانتشار: {publication_labels.get(t.get('publication_state'),'نامشخص')}\nEntry: {plan['entry']} · SL: {plan['stop']}"
            text+=' · '+ ' · '.join(f"{k.upper()}: {plan[k]}" for k in TARGET_KEYS if plan.get(k) is not None)
        text+='\n\nریست، تاریخچه را بایگانی می‌کند. تاریخچهٔ کامل و انتخاب پروفایل در مینی‌اپ / سیگنال‌های زنده است.'
        rows=[[B('ادامهٔ ورودهای جدید' if p.get('entries_enabled') is False else 'توقف ورودهای جدید',callback_data=f"ls:w:{str(list(STRATEGIES).index(account_identity(e)[0]))+('m' if account_identity(e)[1]=='MARKET' else '')}:{a['id']}:{p.get('control_revision',1)}:{int(p.get('entries_enabled') is False)}")],
              [B('ریست به ۵۰۰۰ دلار',callback_data=f"ls:r:{e}:{a['id']}")],[B('برگشت',callback_data='ls:o')]]
    else:return
    await q.edit_message_text(escape(text),parse_mode='HTML',reply_markup=InlineKeyboardMarkup(rows))
    remember_live_panel(context,user,q.message,kind,parts[2] if kind=='m' else None)


def remember_live_panel(context,user,message,kind,market=None,rows=None):
    if not message or kind not in {'root','h','m'}:return
    context.application.bot_data.setdefault('live_signal_panels',{})[str(user)]={
        'chat_id':message.chat_id,'message_id':message.message_id,'kind':kind,'market':market,
        'rows':rows,'last_counts':None}


async def refresh_live_panels(context):
    """Edit badges on an already open private menu; never send a new message."""
    import time
    data=context.application.bot_data
    if time.monotonic()<data.get('live_signal_panel_due',0):return
    data['live_signal_panel_due']=time.monotonic()+15
    panels=data.setdefault('live_signal_panels',{})
    for user,panel in list(panels.items())[:20]:
        try:
            d=await run_blocking(desk_snapshot,int(user),timeout=5)
            counts=tuple((m['id'],m['unread'],tuple(s['unread'] for s in m['strategies'])) for m in d['markets'])
            if counts==panel['last_counts']:continue
            if panel['kind']=='root':
                from bot_runtime.navigation import admin_menu
                rows=await run_blocking(admin_menu,int(user),timeout=5)
            elif panel['kind']=='h':
                rows=[[B(f"{m['label']} · {m['unread']}",callback_data=f"ls:m:{m['id']}")] for m in d['markets']]
                rows.append([B('حساب‌های آزمایشی استراتژی‌ها',callback_data='ls:o')])
                rows.extend(desk_settings_rows())
                rows.append([B('برگشت',callback_data='admin_home')])
            else:
                m=next(x for x in d['markets'] if x['id']==panel['market'])
                rows=[[B(f"{s['label']} · {s['unread']}",callback_data=f"ls:s:{m['id']}:{s['id']}")] for s in m['strategies']]
                rows.append([B('برگشت',callback_data='ls:h')])
            if panels.get(user) is not panel:continue
            if panel['kind']=='h':
                await context.bot.edit_message_text(chat_id=panel['chat_id'],message_id=panel['message_id'],
                    text=f"📡 سیگنال‌های زنده · {d['unread']} جدید",reply_markup=InlineKeyboardMarkup(rows))
            else:
                await context.bot.edit_message_reply_markup(chat_id=panel['chat_id'],message_id=panel['message_id'],reply_markup=InlineKeyboardMarkup(rows))
            panel['last_counts']=counts
        except Exception as exc:
            from telegram.error import BadRequest,NetworkError,RetryAfter
            if isinstance(exc,BadRequest) and 'not modified' in str(exc).lower():
                panel['last_counts']=counts
            elif not isinstance(exc,(NetworkError,RetryAfter)):
                panels.pop(user,None)


def desk_settings_rows():
    return [[B('مسیرها و مقایسهٔ استراتژی‌ها',callback_data='ls:paths')],[B('🔔 تنظیم یادآوری',callback_data='ls:n')],[B('موارد نیازمند بررسی',callback_data='ls:c')],
            [B('تنظیم استراتژی انتخابی',callback_data='ls:y')]]


async def custom_strategy_panel(q,context,parts,user):
    from services.custom_strategy_service import read_settings,save_settings
    from modules.custom_strategy import BASES,FILTERS
    from modules.indicator_suite import CATALOG
    d=await run_blocking(read_settings,user,timeout=5);c=d['settings'];kind=parts[1];note=''
    if kind!='y':
        try:
            if not parts[-1].isdigit() or int(parts[-1])!=d['revision']:raise ValueError('STALE')
            if kind=='ye':c['enabled']=not c['enabled']
            else:
                index=int(parts[2])
                if index<0:raise ValueError('INVALID')
                if kind=='yb':
                    c['base']=BASES[index]
                    if c['base']=='indicators' and not c['indicators']:c['indicators']=list(CATALOG)
                if kind=='yi':
                    name=list(CATALOG)[index]
                    c['indicators']=[x for x in c['indicators'] if x!=name] if name in c['indicators'] else [*c['indicators'],name]
                if kind=='yf':
                    name=FILTERS[index];c[name]=not c[name]
            await run_blocking(save_settings,user,{'revision':d['revision'],'settings':c},timeout=5)
        except (ValueError,IndexError):note='تنظیم عوض شده یا انتخاب معتبر نیست؛ حداقل یک اندیکاتور برای ورود اندیکاتوری لازم است.\n'
        d=await run_blocking(read_settings,user,timeout=5);c=d['settings']
    rev=d['revision']
    text=note+'استراتژی انتخابی\nهمهٔ تأییدهای روشن الزامی هستند. ورود، استاپ و تارگت از روش پایه می‌آیند؛ ترکیب، قیمت‌ها را میانگین نمی‌گیرد.\n'
    text+=f"حساب مستقل: ۵۰۰۰ دلار · ریسک هر ورود: ۱٪\nنسخهٔ تنظیمات: {rev}\nگلدن‌زون: {c['golden_low']} تا {c['golden_high']}\nتنظیم عددهای فیبو و دامنهٔ جابه‌جایی PO3 مستقل در مینی‌اپ است."
    rows=[[B('فعال ✅' if c['enabled'] else 'غیرفعال ⏸',callback_data=f'ls:ye:{rev}')]]
    rows.extend([[B(('✅ ' if c['base']==base else '')+'ورود: '+STRATEGIES[base],callback_data=f'ls:yb:{i}:{rev}')]
                 for i,base in enumerate(BASES)])
    labels={'require_fvg':'FVG','require_ob':'اوردر بلاک','require_poc':'POC','require_liquidity':'نقدینگی',
            'require_dmm':'سطوح PO3 مستقل','require_fibonacci':'فیبوناچی و گلدن‌زون'}
    buttons=[B(('✅ ' if c[k] else '▫️ ')+labels[k],callback_data=f'ls:yf:{i}:{rev}') for i,k in enumerate(FILTERS)]
    rows.extend([buttons[i:i+2] for i in range(0,len(buttons),2)])
    buttons=[B(('✅ ' if k in c['indicators'] else '▫️ ')+label,callback_data=f'ls:yi:{i}:{rev}') for i,(k,label) in enumerate(CATALOG.items())]
    rows.extend([buttons[i:i+2] for i in range(0,len(buttons),2)])
    rows.extend([[B('حساب، ریست و تاریخچه',callback_data='ls:a:custom')],[B('برگشت',callback_data='ls:h')]])
    await q.edit_message_text(escape(text),parse_mode='HTML',reply_markup=InlineKeyboardMarkup(rows))
