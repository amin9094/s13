"""Feature-owned Telegram handlers extracted from the v7 runtime: crm_content."""

from bot_runtime import shared as _shared
from modules.crm_navigation import crm_case_parent, select_crm_case

globals().update({name: value for name, value in vars(_shared).items() if not name.startswith('__')})

async def user_activity_guard(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    metric_increment("updates_total")
    if update.callback_query:
        metric_increment("callback_queries_total")
    elif update.effective_message:
        metric_increment("messages_total")
    user = update.effective_user
    if not user or (await run_blocking(_is_any_admin, user.id)):
        return
    action, source, metadata = _activity_descriptor(update)

    def mutate(db: dict[str, Any]) -> bool:
        uid = str(user.id)
        was_new = uid not in db.setdefault("users", {})
        record = register_user(db, user)
        record.setdefault("entered_bot_at", record.get("created_at") or utc_iso())
        record.setdefault("entry_user_id", uid)
        record_user_activity(db, user.id, action, source=source, metadata=metadata)
        return claim_first_entry_welcome(db, user.id, is_new_user=was_new)

    should_welcome = await async_with_db(mutate)
    if not should_welcome:
        return

    language_hint = str(getattr(user, "language_code", "") or "").lower()
    english = language_hint.startswith("en")
    text = (
        "👋 <b>Welcome to SENTINEL</b>\n\n"
        "Use the main menu to open live markets, the economic calendar, signals and education."
        if english
        else
        "👋 <b>به SENTINEL خوش آمدید</b>\n\n"
        "برای شروع می‌توانید قیمت بازار، تقویم اقتصادی، سیگنال‌ها و آموزش‌ها را از منوی اصلی ببینید."
    )
    label = "🏠 Start" if english else "🏠 شروع استفاده"
    try:
        await _telegram_request_with_button_fallback(
            context.bot.send_message,
            int(user.id),
            text,
            parse_mode=ParseMode.HTML,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(label, callback_data="home")]]),
        )
        await async_with_db(
            lambda db: mark_crm_automation_event(db, f"welcome:{user.id}", success=True)
        )
    except Exception as exc:
        await async_with_db(
            lambda db, error=exc.__class__.__name__: mark_crm_automation_event(
                db, f"welcome:{user.id}", success=False, detail=error
            )
        )
        logger.warning("Could not deliver one-time welcome to user %s: %s", user.id, exc.__class__.__name__)


async def banned_guard(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if not user or (await run_blocking(_is_any_admin, user.id)):
        return
    ban = active_ban(await async_snapshot(), user.id)
    if not ban:
        return
    language = (await run_blocking(_language_for_user, user.id))
    text = "🚫 Your access to the bot has been suspended." if language == "en" else "🚫 دسترسی شما به ربات مسدود شده است."
    if ban.get("reason"):
        text += f"\n{'Reason' if language == 'en' else 'دلیل'}: {esc(ban['reason'])}"
    if ban.get("expires_at"):
        text += f"\n{'Suspension ends' if language == 'en' else 'پایان محدودیت'}: {display_dt(ban['expires_at'])}"
    if update.callback_query:
        await update.callback_query.answer(
            "Your access is suspended." if language == "en" else "دسترسی شما مسدود است.",
            show_alert=True,
        )
    elif update.effective_message:
        await update.effective_message.reply_text(text, parse_mode=ParseMode.HTML)
    raise ApplicationHandlerStop


async def _user_has_required_membership(context: ContextTypes.DEFAULT_TYPE, user_id: int) -> bool:
    db = await async_snapshot()
    settings = get_channel_management(db, public_channel_id=SETTINGS.public_channel_id, private_channel_id=SETTINGS.private_channel_id).get(
        "force_join", {}
    )
    if not settings.get("enabled"):
        return True
    channels = required_join_channels(db, public_channel_id=SETTINGS.public_channel_id, private_channel_id=SETTINGS.private_channel_id)
    if not channels:
        logger.error("Force join is enabled without valid channels; access is denied for non-admin users")
        return False

    cache_seconds = max(15, min(int(settings.get("cache_seconds", 120) or 120), 3600))
    max_entries = max(1000, min(int(settings.get("cache_max_entries", 20000) or 20000), 100000))
    concurrency = max(1, min(int(settings.get("check_concurrency", 8) or 8), 20))
    failure_policy = str(settings.get("failure_policy") or "grace").strip().lower()
    if failure_policy not in {"open", "closed", "grace"}:
        failure_policy = "grace"

    channel_signature = ",".join(str(int(item["channel_id"])) for item in channels)
    cache_key = f"{user_id}:{int(bool(settings.get('require_all', True)))}:{failure_policy}:{channel_signature}"
    cache = context.application.bot_data.setdefault("force_join_cache", {})
    cached = cache.get(cache_key)
    if not isinstance(cached, dict):
        shared_cached = await shared_cache_get("force-join", cache_key)
        cached = shared_cached if isinstance(shared_cached, dict) else None
        if cached is not None:
            cache[cache_key] = cached
    now = utc_now()
    previous_verified = False
    if isinstance(cached, dict):
        checked_at = parse_dt(cached.get("checked_at"))
        previous_verified = bool(cached.get("member"))
        if checked_at and checked_at > now - timedelta(seconds=cache_seconds):
            return previous_verified

    semaphore = context.application.bot_data.get("force_join_semaphore")
    if not isinstance(semaphore, asyncio.Semaphore):
        semaphore = asyncio.Semaphore(concurrency)
        context.application.bot_data["force_join_semaphore"] = semaphore

    async def check(item: dict[str, Any]) -> tuple[int, bool | None]:
        channel_id = int(item["channel_id"])
        async with semaphore:
            try:
                member = await context.bot.get_chat_member(channel_id, user_id)
                status = str(member.status)
                allowed = status in {"creator", "owner", "administrator", "member"}
                if status == "restricted":
                    allowed = bool(getattr(member, "is_member", False))
                return channel_id, allowed
            except BadRequest as exc:
                detail = str(exc).lower()
                if any(token in detail for token in ("user not found", "participant_id_invalid", "member not found")):
                    return channel_id, False
                logger.warning("Could not verify mandatory channel %s membership: %s", channel_id, exc)
                return channel_id, None
            except TelegramError as exc:
                logger.warning("Temporary membership check failure for %s: %s", channel_id, exc)
                return channel_id, None

    results = await asyncio.gather(*(check(item) for item in channels))
    values = [value for _, value in results]
    known = [value for value in values if value is not None]
    has_unknown = len(known) != len(values)
    require_all = bool(settings.get("require_all", True))

    if require_all:
        if any(value is False for value in known):
            allowed = False
        elif has_unknown:
            allowed = failure_policy == "open" or (failure_policy == "grace" and previous_verified)
        else:
            allowed = bool(known) and all(known)
    else:
        if any(value is True for value in known):
            allowed = True
        elif has_unknown:
            allowed = failure_policy == "open" or (failure_policy == "grace" and previous_verified)
        else:
            allowed = False

    missing = [channel_id for channel_id, value in results if value is False]
    cache_payload = {
        "member": allowed,
        "missing": missing,
        "unknown": [channel_id for channel_id, value in results if value is None],
        "checked_at": utc_iso(now),
    }
    cache[cache_key] = cache_payload
    await shared_cache_set("force-join", cache_key, cache_payload, ttl_seconds=cache_seconds)
    if len(cache) > max_entries:
        ordered = sorted(
            cache.items(),
            key=lambda pair: parse_dt(pair[1].get("checked_at")) or datetime.min.replace(tzinfo=UTC),
        )
        for key, _ in ordered[: max(1, len(cache) - max_entries)]:
            cache.pop(key, None)

    def record(database: dict[str, Any]) -> None:
        for channel_id, value in results:
            record_channel_event(
                database,
                str(channel_id),
                "membership_check",
                success=value is not None,
                user_id=user_id,
                metadata={"result": value, "failure_policy": failure_policy},
            )
            if value is True:
                record_channel_event(database, str(channel_id), "membership_passed", user_id=user_id)
            elif value is False:
                record_channel_event(database, str(channel_id), "membership_failed", user_id=user_id)

    await async_with_db(record)
    return allowed


def _force_join_prompt(language: str = "fa") -> tuple[str, list[list[InlineKeyboardButton]]]:
    db = load_db()
    settings = get_channel_management(db, public_channel_id=SETTINGS.public_channel_id, private_channel_id=SETTINGS.private_channel_id).get(
        "force_join", {}
    )
    channels = required_join_channels(db, public_channel_id=SETTINGS.public_channel_id, private_channel_id=SETTINGS.private_channel_id)
    rows: list[list[InlineKeyboardButton]] = []
    for item in channels:
        link = str(item.get("invite_link") or "").strip()
        if link:
            rows.append(
                [
                    InlineKeyboardButton(
                        f"📢 Join {item['title']}" if language == "en" else f"📢 عضویت در {item['title']}",
                        url=link,
                    )
                ]
            )
    rows.append(
        [
            InlineKeyboardButton(
                "✅ I joined; verify membership" if language == "en" else "✅ عضو همه شدم؛ بررسی کن",
                callback_data="force_join_check",
            )
        ]
    )
    mode = (
        ("all required channels" if settings.get("require_all", True) else "at least one required channel")
        if language == "en"
        else ("همه کانال‌ها" if settings.get("require_all", True) else "حداقل یکی از کانال‌ها")
    )
    titles = "\n".join(f"• <b>{esc(item['title'])}</b>" for item in channels)
    return (
        (
            "🔒 <b>Required Channel Membership</b>\n\n"
            f"To use the bot, join <b>{mode}</b>:\n{titles}\n\n"
            "After joining, tap the verification button."
            if language == "en"
            else "🔒 <b>عضویت اجباری چندکاناله</b>\n\n"
            f"برای استفاده از امکانات ربات باید عضو <b>{mode}</b> باشید:\n{titles}\n\n"
            "بعد از عضویت دکمه بررسی را بزنید."
        ),
        rows,
    )


async def force_join_guard(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    chat = update.effective_chat
    if not user or not chat or chat.type != "private" or (await run_blocking(_is_any_admin, user.id)):
        return
    if update.callback_query and str(update.callback_query.data or "") == "force_join_check":
        return
    if update.callback_query and str(update.callback_query.data or "") == "rules_accept":
        return
    if update.effective_message and str(update.effective_message.text or "").startswith("/start"):
        return
    if await _user_has_required_membership(context, user.id):
        return
    await run_blocking(register_current_user, update)
    language = (await run_blocking(_language_for_user, user.id))
    text, rows = (await run_blocking(_force_join_prompt, language))
    if update.callback_query:
        await update.callback_query.answer(
            "Please join the required channel first." if language == "en" else "ابتدا عضو کانال شوید.",
            show_alert=True,
        )
        try:
            await edit(update.callback_query, text, rows)
        except TelegramError:
            pass
    elif update.effective_message:
        await reply(update, text, rows)
    raise ApplicationHandlerStop


async def force_join_check(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    await run_blocking(register_current_user, update)
    context.application.bot_data.pop("force_join_cache", None)
    if await _user_has_required_membership(context, query.from_user.id):
        await query.answer("Membership verified ✅" if language == "en" else "عضویت تأیید شد ✅", show_alert=True)
        await edit(
            query,
            "✅ Your membership was verified. You can now use the bot."
            if language == "en"
            else "✅ عضویت شما تأیید شد. اکنون می‌توانید از ربات استفاده کنید.",
            (await run_blocking(main_menu, query.from_user.id)),
        )
        return
    await query.answer(
        "Your membership has not been verified yet." if language == "en" else "هنوز عضویت شما تأیید نشده است.",
        show_alert=True,
    )
    text, rows = (await run_blocking(_force_join_prompt, language))
    await edit(query, text, rows)


async def a_users(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_USERS_VIEW):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    context.user_data["admin_user_search_mode"] = "users"
    await edit(query, "👥 آیدی عددی یا نام کاربری کاربر را وارد کنید:", back("admin_home"))
    return ADMIN_USER_SEARCH


async def a_crm(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CRM_VIEW):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    context.user_data["admin_user_search_mode"] = "crm"
    dashboard = await async_with_db(crm_dashboard_snapshot)
    lines = [
        "🗂 <b>مرکز CRM، فروش و اتوماسیون</b>",
        "",
        f"مخاطبان: <b>{int(dashboard.get('total', 0)):,}</b>",
        f"میانگین امتیاز Lead: <b>{float(dashboard.get('average_score', 0)):.1f}/100</b>",
        f"سرنخ داغ: <b>{int(dashboard.get('hot_leads', 0)):,}</b>",
        f"پیگیری فعال: <b>{int(dashboard.get('followups', 0)):,}</b> | عقب‌افتاده: <b>{int(dashboard.get('overdue_followups', 0)):,}</b>",
        "",
    ]
    stages = dashboard.get("stages", {})
    for stage, label in CRM_STAGES.items():
        lines.append(f"• {esc(label)}: <b>{int(stages.get(stage, 0)):,}</b>")
    automation = dashboard.get("automation", {})
    lines.extend(
        [
            "",
            f"اتوماسیون موفق: <b>{int(automation.get('sent', 0)):,}</b> | خطا: <b>{int(automation.get('failed', 0)):,}</b> | صف: <b>{int(automation.get('pending', 0)):,}</b>",
            "",
            "برای بازکردن پرونده، آیدی عددی یا نام کاربری کاربر را وارد کنید.",
        ]
    )
    await edit(
        query,
        "\n".join(lines),
        back("admin_cat:users"),
    )
    return ADMIN_USER_SEARCH


async def crm_dashboard_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CRM_VIEW):
        return
    query = update.callback_query
    await query.answer()
    dashboard = await async_with_db(crm_dashboard_snapshot)
    stages = dashboard.get("stages", {})
    lines = [
        "📊 <b>داشبورد عملیاتی CRM</b>",
        "",
        f"کل مخاطبان: <b>{int(dashboard.get('total', 0)):,}</b>",
        f"سرنخ داغ: <b>{int(dashboard.get('hot_leads', 0)):,}</b>",
        f"میانگین امتیاز: <b>{float(dashboard.get('average_score', 0)):.1f}</b>",
        f"پیگیری‌های عقب‌افتاده: <b>{int(dashboard.get('overdue_followups', 0)):,}</b>",
        "",
        "<b>مراحل فروش</b>",
    ]
    for stage, label in CRM_STAGES.items():
        lines.append(f"• {esc(label)}: <b>{int(stages.get(stage, 0)):,}</b>")
    personas = dashboard.get("personas", {})
    persona_labels = {
        "explorer": "کاوشگر",
        "engaged": "درگیر",
        "vip_prospect": "مستعد VIP",
        "paying": "پرداخت‌کننده",
        "advocate": "حامی برند",
        "at_risk": "در معرض ریزش",
        "dormant": "خوابیده",
        "support_sensitive": "نیازمند پشتیبانی",
    }
    lines.extend(
        [
            "",
            "<b>خوشه‌های رفتاری</b>",
            " | ".join(
                f"{label}: <b>{int(personas.get(code, 0))}</b>"
                for code, label in persona_labels.items()
                if int(personas.get(code, 0))
            )
            or "هنوز داده رفتاری کافی وجود ندارد.",
            f"قصد خرید بالا: <b>{int(dashboard.get('high_intent', 0))}</b> | ریسک ریزش بالا: <b>{int(dashboard.get('churn_risk', 0))}</b>",
        ]
    )
    assigned = dashboard.get("assigned", {})
    if assigned:
        lines.extend(["", "<b>تخصیص مدیران</b>"])
        for admin_id, count in sorted(assigned.items(), key=lambda item: item[1], reverse=True)[:15]:
            lines.append(f"• <code>{esc(admin_id)}</code>: <b>{int(count):,}</b> پرونده")
    rows = [
        [InlineKeyboardButton("🔄 بروزرسانی", callback_data="crm_dashboard")],
        [InlineKeyboardButton("🤖 اجرای اتوماسیون اکنون", callback_data="crm_automation_run")],
        [InlineKeyboardButton("📜 گزارش اتوماسیون", callback_data="crm_automation_log")],
        [InlineKeyboardButton("⬅️ CRM و خط فروش", callback_data="admin_cat:users")],
    ]
    from modules.crm_case import followups
    snapshot=await async_snapshot()
    rows[:0]=[[InlineKeyboardButton(label+' · '+str(followups(snapshot,key)['total']),callback_data='up:follows:'+key)] for key,label in [('open','کار باز'),('overdue','سررسیدشده'),('unnotified','اعلان‌نشده')]]
    refresh=dashboard.get('profile_refresh',{})
    lines.append(f"پروفایل محاسبه‌شده: {dashboard.get('profiles_calculated',0)} · در انتظار دسته‌بندی: {dashboard.get('unclassified',0)} · صف بروزرسانی: {refresh.get('dirty_backlog',0)}")
    await edit(query, "\n".join(lines), rows)


async def crm_automation_log_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CRM_VIEW):
        return
    query = update.callback_query
    await query.answer()
    rows_data = await async_with_db(lambda db: crm_automation_log_rows(db, limit=30))
    labels = {
        "welcome": "خوش‌آمدگویی",
        "abandoned_checkout": "خرید نیمه‌کاره",
        "churn_risk": "ریسک ریزش",
        "hot_lead": "سرنخ داغ",
        "high_value": "مشتری باارزش",
    }
    lines = ["📜 <b>گزارش اجرای اتوماسیون CRM</b>", ""]
    if not rows_data:
        lines.append("هنوز رویدادی ثبت نشده است.")
    for row in rows_data:
        status = {"sent": "✅", "failed": "❌", "pending": "⏳"}.get(str(row.get("status")), "▫️")
        lines.append(
            f"{status} {esc(labels.get(str(row.get('type')), str(row.get('type') or 'رویداد')))} | "
            f"کاربر <code>{esc(row.get('user_id') or '-')}</code> | تلاش {int(row.get('attempts', 0) or 0)}"
        )
        if row.get("detail"):
            lines.append(f"   {esc(row.get('detail'))}")
    await edit(
        query,
        "\n".join(lines)[:3900],
        [
            [InlineKeyboardButton("▶️ اجرای اکنون", callback_data="crm_automation_run")],
            [InlineKeyboardButton("⬅️ اتوماسیون مدیریتی", callback_data="admin_cat:automation")],
        ],
    )


async def crm_user_timeline(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CRM_VIEW):
        return
    query = update.callback_query
    uid = str(query.data or "").split(":", 1)[1]
    await query.answer()
    rows_data = await async_with_db(lambda db: crm_activity_timeline(db, uid, limit=40))
    lines = [f"🕘 <b>Timeline CRM کاربر</b> <code>{uid}</code>", ""]
    if not rows_data:
        lines.append("فعالیتی ثبت نشده است.")
    for row in rows_data:
        lines.append(
            f"• <b>{esc(row.get('label') or row.get('type'))}</b> — {display_dt(row.get('created_at'))}\n"
            f"  {esc(row.get('detail') or '-') }"
        )
    await edit(
        query,
        "\n".join(lines)[:3900],
        [[InlineKeyboardButton("↩️ پرونده CRM", callback_data=f"crm_open:{uid}")]],
    )


async def crm_assign_self_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CRM_PIPELINE_MANAGE):
        return
    query = update.callback_query
    uid = str(query.data or "").split(":", 1)[1]
    await async_with_db(lambda db: assign_crm_admin(db, uid, query.from_user.id,actor_id=query.from_user.id))
    await async_with_db(lambda db: audit(db, query.from_user.id, "crm_assign", uid))
    await query.answer("پرونده به شما تخصیص یافت")
    context.user_data["admin_user_uid"] = uid
    text, rows = (await run_blocking(_crm_view_payload, uid, parent_callback=crm_case_parent(context, uid), actor_id=update.effective_user.id))
    await edit(query, text, rows)


async def crm_assign_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CRM_PIPELINE_MANAGE):
        return
    query = update.callback_query
    uid = str(query.data or "").split(":", 1)[1]
    await query.answer()
    admin_ids = sorted(set((await run_blocking(_admin_ids_for_permission, PERMISSION_CRM))))
    rows: list[list[InlineKeyboardButton]] = []
    for index in range(0, len(admin_ids), 2):
        rows.append(
            [
                InlineKeyboardButton(
                    f"👮 {admin_id}",
                    callback_data=f"crm_assign:{uid}:{admin_id}",
                )
                for admin_id in admin_ids[index : index + 2]
            ]
        )
    rows.extend(
        [
            [InlineKeyboardButton("👤 تخصیص به من", callback_data=f"crm_assign:{uid}:{query.from_user.id}")],
            [InlineKeyboardButton("🧹 بدون مسئول", callback_data=f"crm_unassign:{uid}")],
            [InlineKeyboardButton("↩️ پرونده CRM", callback_data=f"crm_open:{uid}")],
        ]
    )
    await edit(query, f"👮 <b>انتخاب مسئول پرونده</b>\n\nکاربر: <code>{uid}</code>", rows)


async def crm_assign_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CRM_PIPELINE_MANAGE):
        return
    query = update.callback_query
    parts = str(query.data or "").split(":")
    uid = parts[1] if len(parts) > 1 else ""
    admin_id = None if parts[0] == "crm_unassign" else (parts[2] if len(parts) > 2 else None)
    if not uid.isdigit() or (admin_id is not None and not str(admin_id).isdigit()):
        await query.answer("شناسه نامعتبر است", show_alert=True)
        return
    await async_with_db(lambda db: assign_crm_admin(db, uid, admin_id,actor_id=query.from_user.id))
    await async_with_db(
        lambda db: audit(db, query.from_user.id, "crm_assign", f"{uid}:{admin_id or 'unassigned'}")
    )
    await query.answer("مسئول پرونده بروزرسانی شد")
    context.user_data["admin_user_uid"] = uid
    text, rows = (await run_blocking(_crm_view_payload, uid, parent_callback=crm_case_parent(context, uid), actor_id=update.effective_user.id))
    await edit(query, text, rows)


async def crm_custom_field_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_CRM_NOTES_MANAGE):
        return
    query = update.callback_query
    uid = str(query.data or "").split(":", 1)[1]
    await query.answer()
    rows = [
        [InlineKeyboardButton(label, callback_data=f"crm_field:{uid}:{key}")]
        for key, label in _CRM_CUSTOM_FIELD_LABELS.items()
    ]
    rows.append([InlineKeyboardButton("↩️ پرونده CRM", callback_data=f"crm_open:{uid}")])
    await edit(query, f"☎️ <b>اطلاعات تکمیلی مشتری</b>\n\nکاربر: <code>{uid}</code>", rows)


async def crm_custom_field_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CRM_NOTES_MANAGE):
        return ConversationHandler.END
    query = update.callback_query
    parts = str(query.data or "").split(":")
    uid = parts[1] if len(parts) > 1 else ""
    field = parts[2] if len(parts) > 2 else ""
    if not uid.isdigit() or field not in _CRM_CUSTOM_FIELD_LABELS:
        await query.answer("فیلد نامعتبر است", show_alert=True)
        return ConversationHandler.END
    context.user_data["admin_user_uid"] = uid
    context.user_data["crm_custom_field"] = field
    context.user_data["crm_field_uid"] = uid
    await query.answer()
    await edit(
        query,
        f"✏️ مقدار جدید <b>{esc(_CRM_CUSTOM_FIELD_LABELS[field])}</b> را وارد کنید.\n"
        "برای پاک‌کردن مقدار، یک خط تیره <code>-</code> بفرستید.",
        back(f"crm_field_menu:{uid}"),
    )
    return CRM_CUSTOM_FIELD_INPUT


async def crm_custom_field_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_CRM_NOTES_MANAGE):
        return ConversationHandler.END
    uid = str(context.user_data.get("crm_field_uid") or "")
    field = str(context.user_data.get("crm_custom_field") or "")
    value = (update.effective_message.text or "").strip()
    if value == "-":
        value = ""
    try:
        await async_with_db(
            lambda db: set_crm_custom_field(
                db, uid, field, value, admin_id=update.effective_user.id
            )
        )
        await async_with_db(
            lambda db: audit(db, update.effective_user.id, "crm_custom_field", f"{uid}:{field}")
        )
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return CRM_CUSTOM_FIELD_INPUT
    text, rows = (await run_blocking(_crm_view_payload, uid, parent_callback=crm_case_parent(context, uid), actor_id=update.effective_user.id))
    await reply(update, "✅ اطلاعات CRM بروزرسانی شد.\n\n" + text, rows)
    context.user_data.pop("crm_custom_field", None)
    context.user_data.pop("crm_field_uid", None)
    return ConversationHandler.END


async def a_portfolio(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_PORTFOLIO):
        return
    query = update.callback_query
    await query.answer()
    summary = portfolio_admin_summary(await async_snapshot())
    text = (
        "📔 <b>مرکز مدیریت ژورنال و واچ‌لیست</b>\n\n"
        f"کاربران دارای واچ‌لیست: <b>{summary['watchlist_users']:,}</b>\n"
        f"کل نمادهای ذخیره‌شده: <b>{summary['watchlist_assets']:,}</b>\n"
        f"کاربران دارای ژورنال: <b>{summary['journal_users']:,}</b>\n"
        f"کل رکوردهای ژورنال: <b>{summary['journal_entries']:,}</b>\n"
        f"رکوردهای باز: <b>{summary['open_journal_entries']:,}</b>\n\n"
        "برای مشاهده و مدیریت جزئیات، کاربر را انتخاب کنید."
    )
    rows = [
        [InlineKeyboardButton("🔎 انتخاب کاربر", callback_data="portfolio_user_search")],
        [
            InlineKeyboardButton("⭐ تنظیمات واچ‌لیست", callback_data="ecc_mod:watchlists"),
            InlineKeyboardButton("📔 تنظیمات ژورنال", callback_data="ecc_mod:journal"),
        ],
        [InlineKeyboardButton("↩️ کاربران و CRM", callback_data="admin_cat:users")],
    ]
    await edit(query, text, rows)


def _portfolio_user_text(db: dict[str, Any], uid: str) -> str:
    user = db.get("users", {}).get(uid, {}) if isinstance(db.get("users", {}), dict) else {}
    watchlist = watchlist_for_user(db, uid)
    entries = journal_entries(db, uid, limit=5000)
    stats = journal_stats(db, uid)
    notes = db.get("journal_admin_notes", {}).get(uid, [])
    symbols = "، ".join(str(item.get("symbol")) for item in watchlist[:30]) or "ندارد"
    return (
        "📔 <b>پرونده ژورنال و واچ‌لیست کاربر</b>\n\n"
        f"کاربر: <b>{esc(user.get('first_name') or '-')}</b> | <code>{uid}</code>\n"
        f"نام کاربری: @{esc(user.get('username') or '-')}\n\n"
        f"⭐ واچ‌لیست ({len(watchlist)}): <code>{esc(symbols)}</code>\n\n"
        f"📔 رکوردها: <b>{stats['total']}</b> | باز: <b>{stats['open']}</b> | بسته: <b>{stats['closed']}</b>\n"
        f"برد: <b>{stats['wins']}</b> | باخت: <b>{stats['losses']}</b> | نرخ برد: <b>{stats['win_rate']:.1f}٪</b>\n"
        f"P/L تجمعی: <b>{stats['pnl_sum']:+.2f}٪</b> | افت بیشینه: <b>{stats['max_drawdown']:.2f}٪</b>\n"
        f"یادداشت ادمین: <b>{len(notes)}</b>\n\n" + "\n".join("• " + _journal_entry_line(row) for row in entries[:12])
    )[:3900]


def _portfolio_user_rows(db: dict[str, Any], uid: str) -> list[list[InlineKeyboardButton]]:
    watchlist = watchlist_for_user(db, uid)
    entries = journal_entries(db, uid, limit=30)
    rows: list[list[InlineKeyboardButton]] = []
    for item in watchlist[:12]:
        symbol = str(item.get("symbol") or "")
        rows.append([InlineKeyboardButton(f"🗑 حذف {symbol} از واچ‌لیست", callback_data=f"portfolio_wremove:{uid}:{symbol}")])
    for item in entries[:12]:
        buttons = [InlineKeyboardButton(f"🗑 ژورنال #{item['id']}", callback_data=f"portfolio_jdelete:{uid}:{item['id']}")]
        if item.get("status") == "open":
            buttons.insert(0, InlineKeyboardButton(f"📈 نتیجه #{item['id']}", callback_data=f"portfolio_result:{uid}:{item['id']}"))
        rows.append(buttons)
    rows.extend(
        [
            [
                InlineKeyboardButton("📝 یادداشت خصوصی", callback_data=f"portfolio_note:{uid}"),
                InlineKeyboardButton("📦 خروجی CSV", callback_data=f"portfolio_export:{uid}"),
            ],
            [
                InlineKeyboardButton("🧹 پاک‌کردن واچ‌لیست", callback_data=f"portfolio_wclear:{uid}"),
                InlineKeyboardButton("🔄 بروزرسانی", callback_data=f"portfolio_user:{uid}"),
            ],
            [InlineKeyboardButton("↩️ مرکز ژورنال", callback_data="a_portfolio")],
        ]
    )
    return rows


async def portfolio_user_search_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_PORTFOLIO):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    await edit(query, "🔎 آیدی عددی یا نام کاربری کاربر را وارد کنید:", [[InlineKeyboardButton("↩️ بازگشت", callback_data="a_portfolio")]])
    return PORTFOLIO_USER_INPUT


async def portfolio_user_search_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_PORTFOLIO):
        return ConversationHandler.END
    try:
        uid, _ = find_registered_user((await async_snapshot()), update.effective_message.text or "")
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return PORTFOLIO_USER_INPUT
    db = await async_snapshot()
    await reply(update, _portfolio_user_text(db, uid), _portfolio_user_rows(db, uid))
    return ConversationHandler.END


async def portfolio_user_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_PORTFOLIO):
        return
    query = update.callback_query
    uid = str(query.data or "").split(":", 1)[1]
    db = await async_snapshot()
    if uid not in db.get("users", {}):
        await query.answer("کاربر پیدا نشد", show_alert=True)
        return
    await query.answer()
    await edit(query, _portfolio_user_text(db, uid), _portfolio_user_rows(db, uid))


async def portfolio_watchlist_remove(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_PORTFOLIO):
        return
    query = update.callback_query
    _, uid, symbol = str(query.data or "").split(":", 2)
    deleted = await async_with_db(lambda db: remove_watchlist_symbol(db, uid, symbol))
    if not deleted:
        await query.answer("نماد در واچ‌لیست نبود", show_alert=True)
        return
    await async_with_db(lambda db: audit(db, query.from_user.id, "portfolio_watchlist_remove", f"{uid}:{symbol}"))
    await query.answer("نماد حذف شد")
    db = await async_snapshot()
    await edit(query, _portfolio_user_text(db, uid), _portfolio_user_rows(db, uid))


async def portfolio_watchlist_clear(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_PORTFOLIO):
        return
    query = update.callback_query
    uid = str(query.data or "").split(":", 1)[1]
    count = await async_with_db(lambda db: clear_watchlist(db, uid))
    await async_with_db(lambda db: audit(db, query.from_user.id, "portfolio_watchlist_clear", f"{uid}:{count}"))
    await query.answer(f"{count} نماد حذف شد", show_alert=True)
    db = await async_snapshot()
    await edit(query, _portfolio_user_text(db, uid), _portfolio_user_rows(db, uid))


async def portfolio_journal_delete(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_PORTFOLIO):
        return
    query = update.callback_query
    _, uid, entry_id = str(query.data or "").split(":", 2)
    deleted = await async_with_db(lambda db: delete_journal_entry(db, uid, int(entry_id)))
    if deleted:
        await async_with_db(lambda db: audit(db, query.from_user.id, "portfolio_journal_delete", f"{uid}:{entry_id}"))
    await query.answer("رکورد حذف شد" if deleted else "رکورد پیدا نشد", show_alert=not deleted)
    db = await async_snapshot()
    await edit(query, _portfolio_user_text(db, uid), _portfolio_user_rows(db, uid))


async def portfolio_journal_export(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_PORTFOLIO):
        return
    query = update.callback_query
    uid = str(query.data or "").split(":", 1)[1]
    await query.answer("در حال ساخت خروجی…")
    file_obj = io.BytesIO(journal_csv((await async_snapshot()), uid))
    file_obj.name = f"trade-journal-{uid}.csv"
    await query.message.reply_document(file_obj, caption=f"📔 خروجی ژورنال کاربر <code>{uid}</code>", parse_mode=ParseMode.HTML)
    await async_with_db(lambda db: audit(db, query.from_user.id, "portfolio_journal_export", uid))


async def portfolio_note_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_PORTFOLIO):
        return ConversationHandler.END
    query = update.callback_query
    uid = str(query.data or "").split(":", 1)[1]
    context.user_data["portfolio_note_uid"] = uid
    await query.answer()
    await edit(query, "📝 یادداشت خصوصی ادمین را وارد کنید:", [[InlineKeyboardButton("↩️ انصراف", callback_data=f"portfolio_user:{uid}")]])
    return JOURNAL_ADMIN_NOTE_INPUT


async def portfolio_note_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_PORTFOLIO):
        return ConversationHandler.END
    uid = context.user_data.pop("portfolio_note_uid", None)
    if not uid:
        await reply(update, "❌ فرایند منقضی شده است.")
        return ConversationHandler.END
    try:
        note = await async_with_db(
            lambda db: add_journal_admin_note(db, uid, update.effective_user.id, update.effective_message.text or "")
        )
    except ValueError as exc:
        context.user_data["portfolio_note_uid"] = uid
        await reply(update, f"❌ {esc(exc)}")
        return JOURNAL_ADMIN_NOTE_INPUT
    await async_with_db(lambda db: audit(db, update.effective_user.id, "portfolio_admin_note", f"{uid}:{note['id']}"))
    db = await async_snapshot()
    await reply(update, "✅ یادداشت ثبت شد.\n\n" + _portfolio_user_text(db, uid), _portfolio_user_rows(db, uid))
    return ConversationHandler.END


async def portfolio_result_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_PORTFOLIO):
        return ConversationHandler.END
    query = update.callback_query
    _, uid, entry_id = str(query.data or "").split(":", 2)
    context.user_data["portfolio_result"] = (uid, int(entry_id))
    await query.answer()
    await edit(
        query,
        "📈 نتیجه را با قالب <code>درصد | قیمت خروج | مبلغ | یادداشت</code> وارد کنید. برای مقدار نامشخص <code>-</code> بفرستید.",
        [[InlineKeyboardButton("↩️ انصراف", callback_data=f"portfolio_user:{uid}")]],
    )
    return PORTFOLIO_RESULT_INPUT


async def portfolio_result_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_PORTFOLIO):
        return ConversationHandler.END
    target = context.user_data.get("portfolio_result")
    parts = [part.strip() for part in (update.effective_message.text or "").split("|", 3)]
    if not target or len(parts) != 4:
        await reply(update, "❌ قالب نامعتبر است.")
        return PORTFOLIO_RESULT_INPUT
    uid, entry_id = target
    try:
        pnl = float(parts[0].replace(",", ""))
        exit_price = None if parts[1] in {"", "-"} else float(parts[1].replace(",", ""))
        amount = None if parts[2] in {"", "-"} else float(parts[2].replace(",", ""))
        row = await async_with_db(
            lambda db: update_journal_result(db, uid, entry_id, pnl_percent=pnl, exit_price=exit_price, pnl_amount=amount, note=parts[3])
        )
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return PORTFOLIO_RESULT_INPUT
    context.user_data.pop("portfolio_result", None)
    await async_with_db(lambda db: audit(db, update.effective_user.id, "portfolio_result_update", f"{uid}:{entry_id}:{row['pnl_percent']}"))
    db = await async_snapshot()
    await reply(update, "✅ نتیجه ژورنال بروزرسانی شد.\n\n" + _portfolio_user_text(db, uid), _portfolio_user_rows(db, uid))
    return ConversationHandler.END


def _admin_user_profile_text(db: dict[str, Any], uid: str, user: dict[str, Any]) -> str:
    profile = build_user_profile(db, uid)
    points = int(profile.get("points_current", 0))
    vip = db.get("vip_users", {}).get(uid)
    vip_active = is_vip(db, uid)
    ban = active_ban(db, uid)
    vip_suffix = f" تا {display_dt(vip.get('expires_at'))}" if vip_active and vip else ""
    return (
        "👤 <b>پروفایل کامل کاربر</b>\n\n"
        f"🆔 <code>{uid}</code>\n"
        f"نام: {esc(user.get('first_name') or '-')} {esc(user.get('last_name') or '')}\n"
        f"نام کاربری: @{esc(user.get('username') or '-')}\n"
        f"🏷 دسته: <b>{esc(profile.get('primary_category_label') or 'کاربر عادی')}</b>\n"
        f"⭐ مانده: <b>{points:,}</b> | دریافتی: <b>{int(profile.get('points_received', 0)):,}</b>"
        f" | خرج‌شده: <b>{int(profile.get('points_spent', 0)):,}</b>\n"
        f"💎 VIP: <b>{'فعال' if vip_active else 'غیرفعال'}</b>{vip_suffix}\n"
        f"🧾 خرید اشتراک: <b>{int(profile.get('vip_purchase_count', 0))}</b>"
        f" | تمدید: <b>{int(profile.get('vip_renewal_count', 0))}</b>"
        f" | هزینه: <b>{int(profile.get('vip_spend', 0)):,}</b> تومان\n"
        f"🎓 خرید آموزش: <b>{int(profile.get('education_purchase_count', 0))}</b>\n"
        f"🎫 تیکت‌ها: <b>{int(profile.get('ticket_count', 0))}</b>\n"
        f"🎁 جوایز: <b>{int(profile.get('reward_count', 0))}</b>\n"
        f"📊 کل فعالیت: <b>{int(profile.get('activity_summary', {}).get('total', 0)):,}</b>\n"
        f"🚫 وضعیت مسدودی: <b>{'مسدود' if ban else 'آزاد'}</b>\n"
        f"آخرین فعالیت: {display_dt(profile.get('activity_summary', {}).get('last_at') or user.get('last_seen_at'))}"
    )


async def admin_user_search(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    mode = str(context.user_data.get("admin_user_search_mode") or "users")
    permission = PERMISSION_CRM_VIEW if mode == "crm" else PERMISSION_USERS_VIEW
    if not await require_admin(update, permission):
        return ConversationHandler.END
    try:
        uid, user = find_registered_user((await async_snapshot()), update.effective_message.text or "")
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return ADMIN_USER_SEARCH
    context.user_data["admin_user_uid"] = uid
    db = await async_snapshot()
    if mode == "crm":
        select_crm_case(context, uid, "a_crm")
        text, rows = (await run_blocking(_crm_view_payload, uid, parent_callback=crm_case_parent(context, uid), actor_id=update.effective_user.id))
        await reply(update, text, rows)
        return ConversationHandler.END
    rows = [
        [
            InlineKeyboardButton("➕ افزایش امتیاز", callback_data="admin_user_points:add"),
            InlineKeyboardButton("➖ کاهش امتیاز", callback_data="admin_user_points:sub"),
        ],
        [
            InlineKeyboardButton("🚫 مسدودی ۷ روزه", callback_data="admin_user_ban:7"),
            InlineKeyboardButton("⛔ مسدودی دائم", callback_data="admin_user_ban:perm"),
        ],
        [
            InlineKeyboardButton("✅ رفع مسدودی", callback_data="admin_user_unban"),
            InlineKeyboardButton("🎁 مشاهده جوایز", callback_data=f"a_user_rewards:{uid}"),
        ],
        [InlineKeyboardButton("🗂 مشاهده CRM کامل", callback_data=f"crm_open:{uid}")],
        [InlineKeyboardButton("➕ افزودن به کانال خصوصی", callback_data="admin_private_add")],
        [InlineKeyboardButton("➖ حذف از کانال خصوصی", callback_data="admin_private_remove")],
        [InlineKeyboardButton("🔎 جستجوی کاربر دیگر", callback_data="a_users"), InlineKeyboardButton("🔙 پنل", callback_data="admin_home")],
    ]
    await reply(update, _admin_user_profile_text(db, uid, user), rows)
    return ConversationHandler.END


async def admin_user_points_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_USERS):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    uid = context.user_data.get("admin_user_uid")
    if not uid:
        await query.answer("ابتدا کاربر را جستجو کنید", show_alert=True)
        return ConversationHandler.END
    context.user_data["admin_points_mode"] = query.data.split(":", 1)[1]
    await edit(query, "مقدار و دلیل را به شکل زیر بفرستید:\n<code>50 | جایزه فعالیت</code>", back("a_users"))
    return ADMIN_USER_POINTS


async def admin_user_points_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_USERS):
        return ConversationHandler.END
    try:
        amount_text, reason = [part.strip() for part in (update.effective_message.text or "").split("|", 1)]
        amount = int(amount_text.replace(",", ""))
        if amount <= 0 or amount > 1_000_000:
            raise ValueError("مقدار باید بین ۱ تا ۱٬۰۰۰٬۰۰۰ باشد")
        uid = str(context.user_data["admin_user_uid"])
        mode = context.user_data.get("admin_points_mode")
        signed = amount if mode == "add" else -amount
        total = await async_with_db(lambda db: add_points(db, uid, signed, f"admin:{update.effective_user.id}:{reason}"))
        await async_with_db(lambda db: audit(db, update.effective_user.id, "user_points_change", f"{uid}:{signed}:{reason}"))
    except (ValueError, KeyError) as exc:
        await reply(update, f"❌ {esc(exc)}")
        return ADMIN_USER_POINTS
    await reply(update, f"✅ امتیاز کاربر <code>{uid}</code> تغییر کرد. موجودی جدید: <b>{total}</b>", back("admin_home"))
    return ConversationHandler.END


async def admin_user_ban_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_USER_BAN_MANAGE):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    uid = context.user_data.get("admin_user_uid")
    if not uid:
        await query.answer("ابتدا کاربر را جستجو کنید", show_alert=True)
        return ConversationHandler.END
    value = query.data.split(":", 1)[1]
    context.user_data["admin_ban_days"] = None if value == "perm" else int(value)
    await edit(query, "دلیل مسدودی را بنویسید:", back("a_users"))
    return ADMIN_USER_BAN_REASON


async def admin_user_ban_reason(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_USER_BAN_MANAGE):
        return ConversationHandler.END
    uid = str(context.user_data.get("admin_user_uid") or "")
    ban_days = context.user_data.get("admin_ban_days")
    reason = (update.effective_message.text or "").strip()
    try:
        row = await async_with_db(
            lambda db: set_user_ban(db, uid, days=ban_days, reason=reason, admin_id=update.effective_user.id)
        )
        await async_with_db(lambda db: audit(db, update.effective_user.id, "user_ban", f"{uid}:{row.get('expires_at') or 'permanent'}"))
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return ADMIN_USER_BAN_REASON
    await reply(update, f"✅ کاربر <code>{uid}</code> مسدود شد.", back("admin_home"))
    return ConversationHandler.END


async def admin_user_unban(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_USER_BAN_MANAGE):
        return
    query = update.callback_query
    await query.answer()
    uid = context.user_data.get("admin_user_uid")
    if not uid:
        await query.answer("ابتدا کاربر را جستجو کنید", show_alert=True)
        return
    ok = await async_with_db(lambda db: unban_user(db, uid))
    await async_with_db(lambda db: audit(db, query.from_user.id, "user_unban", str(uid)))
    await query.answer("رفع مسدودی انجام شد" if ok else "کاربر مسدود نبود", show_alert=True)
    await edit(query, "✅ عملیات انجام شد.", back("admin_home"))


async def admin_private_add_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_USER_VIP_ASSIGN):
        return ConversationHandler.END
    query = update.callback_query
    uid = context.user_data.get("admin_user_uid")
    if not uid:
        await query.answer("ابتدا کاربر را جستجو کنید", show_alert=True)
        return ConversationHandler.END
    await query.answer()
    await edit(
        query,
        "مدت دسترسی کاربر به کانال خصوصی را به روز وارد کنید:\nمثال: <code>30</code>\n\nحداقل ۱ روز و حداکثر ۳۶۵۰ روز.",
        back("a_users"),
    )
    return ADMIN_PRIVATE_CHANNEL_DAYS


async def admin_private_add_days(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_USER_VIP_ASSIGN):
        return ConversationHandler.END
    uid = str(context.user_data.get("admin_user_uid") or "")
    try:
        days = parse_positive_int(update.effective_message.text or "")
        if days > 3650:
            raise ValueError("مدت دسترسی نمی‌تواند بیشتر از ۳۶۵۰ روز باشد")
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}")
        return ADMIN_PRIVATE_CHANNEL_DAYS

    snapshot = await async_snapshot()
    if uid not in snapshot.get("users", {}) and uid not in snapshot.get("vip_users", {}):
        await reply(update, "❌ کاربر در دیتابیس پیدا نشد.", back("a_users"))
        return ConversationHandler.END

    expiry = projected_vip_expiry(snapshot, uid, days)
    invite_link: str | None = None
    try:
        invite_link = await restore_vip_channel_access(context.bot, int(uid), utc_iso(expiry))
    except TelegramError:
        logger.exception("Could not prepare private-channel access for %s", uid)
        await reply(
            update,
            "❌ ساخت لینک یک‌بارمصرف یا آماده‌سازی دسترسی کانال ناموفق بود. دسترسی ادمین ربات در کانال را بررسی کنید.",
            back("a_users"),
        )
        return ConversationHandler.END

    def commit_access(db: dict[str, Any]) -> dict[str, Any] | None:
        if uid not in db.get("users", {}) and uid not in db.get("vip_users", {}):
            return None
        record = activate_vip(db, uid, days, invite_link=invite_link, fixed_expires_at=expiry)
        audit(db, update.effective_user.id, "private_channel_add", f"{uid}/{days}d")
        return record

    try:
        record = await async_with_db(commit_access)
    except Exception:
        logger.exception("Could not commit private-channel access for %s", uid)
        record = None

    if not record:
        try:
            if invite_link:
                await context.bot.revoke_chat_invite_link(
                    chat_id=SETTINGS.private_channel_id,
                    invite_link=invite_link,
                )
        except TelegramError:
            logger.warning("Could not revoke unused private-channel invite for %s", uid)
        await reply(update, "❌ ثبت نهایی دسترسی انجام نشد.", back("a_users"))
        return ConversationHandler.END

    notification_sent = True
    try:
        await _telegram_request_with_button_fallback(
            context.bot.send_message,
            int(uid),
            "✅ دسترسی شما به کانال خصوصی فعال شد.\n"
            f"⏳ پایان دسترسی: {display_dt(record['expires_at'])}\n"
            "🔗 لینک یک‌بارمصرف ورود:\n"
            f"{invite_link}",
        )
    except TelegramError:
        notification_sent = False
        logger.info("Could not send private-channel invite to %s", uid)

    delivery_note = "لینک برای کاربر ارسال شد." if notification_sent else "ارسال پیام به کاربر ناموفق بود؛ لینک را دستی برای او بفرستید."
    await reply(
        update,
        f"✅ دسترسی کاربر <code>{uid}</code> تا {display_dt(record['expires_at'])} فعال شد.\n"
        f"{delivery_note}\n\n🔗 <code>{esc(invite_link)}</code>",
        back("a_users"),
    )
    return ConversationHandler.END


async def admin_private_remove(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_USER_VIP_ASSIGN):
        return
    query = update.callback_query
    uid = str(context.user_data.get("admin_user_uid") or "")
    if not uid:
        await query.answer("ابتدا کاربر را جستجو کنید", show_alert=True)
        return
    await query.answer()

    current = (await async_snapshot()).get("vip_users", {}).get(uid, {})
    invite_link = str(current.get("invite_link") or "")
    if invite_link:
        try:
            await context.bot.revoke_chat_invite_link(
                chat_id=SETTINGS.private_channel_id,
                invite_link=invite_link,
            )
        except TelegramError:
            logger.info("Stored invite for %s was already invalid or could not be revoked", uid)

    def queue_removal(db: dict[str, Any]) -> None:
        record = db.setdefault("vip_users", {}).setdefault(uid, {})
        record.update(
            {
                "status": "expired",
                "expires_at": utc_iso(),
                "invite_link": None,
                "updated_at": utc_iso(),
                "channel_removed_at": None,
                "channel_removal_status": "pending",
                "channel_removal_phase": "ban",
                "channel_removal_attempts": 0,
                "channel_removal_next_retry_at": None,
                "channel_removal_last_error": None,
            }
        )
        audit(db, query.from_user.id, "private_channel_remove", uid)

    await async_with_db(queue_removal)
    await check_expired_vips(context)
    result = (await async_snapshot()).get("vip_users", {}).get(uid, {})
    if result.get("channel_removed_at"):
        await edit(query, f"✅ کاربر <code>{uid}</code> از کانال خصوصی حذف شد.", back("a_users"))
    else:
        await edit(
            query,
            f"⚠️ حذف کاربر <code>{uid}</code> ثبت شد، اما تلگرام فعلاً عملیات را کامل نکرد. ربات به‌صورت خودکار دوباره تلاش می‌کند.",
            back("a_users"),
        )


def _broadcast_body_and_options(raw: str) -> tuple[str, str | None, list[dict[str, str]]]:
    lines = str(raw or "").splitlines()
    scheduled_for: str | None = None
    buttons: list[dict[str, str]] = []
    if lines:
        matched = re.fullmatch(r"\s*@(?:schedule|زمان)\s+(.+?)\s*", lines[0], flags=re.IGNORECASE)
        if matched:
            scheduled_for = parse_schedule_time(matched.group(1), timezone=SETTINGS.timezone).isoformat()
            lines = lines[1:]
    body_lines: list[str] = []
    for line in lines:
        matched = re.fullmatch(r"\s*\[\[(.{1,64})\|((?:https?://|tg://).+?)\]\]\s*", line)
        if matched:
            buttons.append({"label": matched.group(1).strip(), "url": matched.group(2).strip()})
        else:
            body_lines.append(line)
    return "\n".join(body_lines).strip(), scheduled_for, buttons[:8]


def _broadcast_payloads_from_message(message: Any) -> tuple[list[dict[str, Any]], str | None]:
    raw = str(message.text or message.caption or "")
    body, scheduled_for, buttons = _broadcast_body_and_options(raw)
    if message.photo:
        return [{"type": "photo", "file_id": message.photo[-1].file_id, "caption": body, "buttons": buttons}], scheduled_for
    if message.video:
        return [{"type": "video", "file_id": message.video.file_id, "caption": body, "buttons": buttons}], scheduled_for
    if message.document:
        return [{"type": "document", "file_id": message.document.file_id, "caption": body, "buttons": buttons}], scheduled_for
    if message.audio:
        return [{"type": "audio", "file_id": message.audio.file_id, "caption": body, "buttons": buttons}], scheduled_for
    if message.voice:
        return [{"type": "voice", "file_id": message.voice.file_id, "caption": body, "buttons": buttons}], scheduled_for
    if not body:
        raise ValueError("متن یا رسانه‌ای برای ارسال پیدا نشد")
    variants = [part.strip() for part in re.split(r"\n\s*---AB---\s*\n", body, maxsplit=1)]
    return [{"type": "text", "text": part, "buttons": buttons} for part in variants if part], scheduled_for


def _broadcast_markup(content: dict[str, Any]) -> InlineKeyboardMarkup | None:
    buttons = content.get("buttons", [])
    rows = [
        [InlineKeyboardButton(str(item.get("label") or "لینک"), url=str(item.get("url") or ""))]
        for item in buttons
        if isinstance(item, dict) and str(item.get("url") or "").startswith(("https://", "http://", "tg://"))
    ]
    return InlineKeyboardMarkup(rows) if rows else None


async def _send_broadcast_content(bot: Any, user_id: int, content: dict[str, Any]) -> None:
    kind = str(content.get("type") or "text")
    markup = _broadcast_markup(content)
    common = {"reply_markup": markup} if markup else {}
    if kind == "text":
        await _telegram_request_with_button_fallback(bot.send_message, user_id, str(content.get("text") or ""), **common)
        return
    method = {
        "photo": bot.send_photo,
        "video": bot.send_video,
        "document": bot.send_document,
        "audio": bot.send_audio,
        "voice": bot.send_voice,
    }.get(kind)
    if method is None:
        raise ValueError("نوع پیام همگانی ناشناخته است")
    local_path = str(content.get("file_path") or "").strip()
    if local_path:
        from modules.broadcast_queue import trusted_local_media_path
        safe_path = trusted_local_media_path(local_path)
        with open(safe_path, "rb") as media_handle:
            kwargs = {kind: media_handle, "caption": str(content.get("caption") or ""), **common}
            await _telegram_request_with_button_fallback(method, user_id, **kwargs)
        return
    kwargs = {kind: str(content.get("file_id") or ""), "caption": str(content.get("caption") or ""), **common}
    await _telegram_request_with_button_fallback(method, user_id, **kwargs)


async def a_broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_BROADCAST):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    rows = [
        [InlineKeyboardButton("📣 اعلان کانال عمومی/خصوصی", callback_data="a_announcement")],
        [InlineKeyboardButton("📊 صف و وضعیت ارسال‌ها", callback_data="broadcast_queue_panel")],
        [InlineKeyboardButton("همه کاربران", callback_data="bcast_segment:all")],
        [
            InlineKeyboardButton("کاربران عادی", callback_data="bcast_segment:normal"),
            InlineKeyboardButton("VIPها", callback_data="bcast_segment:vip"),
        ],
        [
            InlineKeyboardButton("غیرفعال‌های ۳۰ روزه", callback_data="bcast_segment:inactive"),
            InlineKeyboardButton("برندگان", callback_data="bcast_segment:winners"),
        ],
        back("admin_home")[0],
    ]
    await edit(query, "📣 گروه دریافت‌کننده را انتخاب کنید:", rows)
    return BROADCAST_SEGMENT


async def broadcast_segment(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_BROADCAST):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    segment = query.data.split(":", 1)[1]
    context.user_data["broadcast_segment"] = segment
    count = len(user_segments((await async_snapshot()), segment))
    await edit(
        query,
        f"پیام متنی، عکس، ویدئو، فایل، صدا یا Voice را بفرستید. دریافت‌کنندگان: <b>{count}</b>\n\n"
        "زمان‌بندی اختیاری در خط اول: <code>@زمان 2026-06-28 09:30</code>\n"
        "دکمه URL در خط جدا: <code>[[عنوان|https://example.com]]</code>\n"
        "A/B متنی: دو نسخه را با خط <code>---AB---</code> جدا کنید.",
        back("admin_home"),
    )
    return BROADCAST_MESSAGE


async def broadcast_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_BROADCAST):
        return ConversationHandler.END
    segment = context.user_data.get("broadcast_segment", "all")
    recipients = user_segments((await async_snapshot()), segment)
    settings = control_module_state((await async_snapshot()), "broadcast")
    try:
        payloads, scheduled_for = _broadcast_payloads_from_message(update.effective_message)
        if any(payload.get("type") != "text" for payload in payloads) and not bool(settings.get("media", True)):
            raise ValueError("ارسال رسانه‌ای توسط مدیریت غیرفعال است")
        if any(payload.get("buttons") for payload in payloads) and not bool(settings.get("buttons", True)):
            raise ValueError("دکمه‌های پیام همگانی غیرفعال‌اند")
        if scheduled_for and not bool(settings.get("scheduled", True)):
            raise ValueError("زمان‌بندی ارسال همگانی غیرفعال است")
        if len(payloads) > 1 and not bool(settings.get("ab_test", True)):
            raise ValueError("A/B Test توسط مدیریت غیرفعال است")
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}", back("a_broadcast"))
        return BROADCAST_MESSAGE

    if segment == "all" and operation_requires_approval(await async_snapshot(),"broadcast_all"):
        approval = await async_with_db(lambda db:create_pending_approval(
            db,"broadcast_all",{"payloads":payloads,"scheduled_for":scheduled_for},update.effective_user.id,
            description=f"ارسال همگانی برای {len(recipients)} کاربر؛ {len(payloads)} نسخهٔ محتوا"))
        await _notify_pending_approval(context,approval)
        await reply(update,"🔐 ارسال هنوز وارد صف نشده است؛ در انتظار تأیید ادمین اصلی.",back("a_approvals"))
        return ConversationHandler.END
    jobs: list[dict[str, Any]] = []
    if len(payloads) == 1:
        jobs.append(
            await async_with_db(
                lambda db: enqueue_broadcast(
                    db,
                    admin_id=update.effective_user.id,
                    segment=segment,
                    recipients=recipients,
                    content=payloads[0],
                    scheduled_for=scheduled_for,
                )
            )
        )
    else:
        groups = (recipients[::2], recipients[1::2])
        for index, payload in enumerate(payloads[:2]):
            jobs.append(
                await async_with_db(
                    lambda db, idx=index, item=payload: enqueue_broadcast(
                        db,
                        admin_id=update.effective_user.id,
                        segment=f"{segment}:{'A' if idx == 0 else 'B'}",
                        recipients=groups[idx],
                        content=item,
                        scheduled_for=scheduled_for,
                        variant="A" if idx == 0 else "B",
                    )
                )
            )
    await async_with_db(
        lambda db: audit(
            db,
            update.effective_user.id,
            "broadcast_queued",
            f"{','.join(str(job['id']) for job in jobs)}:{segment}:{len(recipients)}",
        )
    )
    ids = "، ".join(f"<code>{job['id']}</code>" for job in jobs)
    schedule_text = f"\\nزمان اجرا: <b>{display_dt(scheduled_for)}</b>" if scheduled_for else ""
    await reply(
        update,
        f"✅ ارسال وارد صف پایدار شد.\\nشناسه: {ids}\\nدریافت‌کننده: <b>{len(recipients)}</b>{schedule_text}\\n"
        "ارسال پس از Restart نیز ادامه پیدا می‌کند.",
        [[InlineKeyboardButton("📊 مشاهده وضعیت صف", callback_data="broadcast_queue_panel")], back("admin_home")[0]],
    )
    return ConversationHandler.END


async def broadcast_queue_panel(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    *,
    answer_callback: bool = True,
) -> None:
    if not await require_admin(update, PERMISSION_BROADCAST):
        return
    query = update.callback_query
    if answer_callback:
        await query.answer()
    jobs = [row for row in reversed((await async_snapshot()).get("broadcast_queue", [])) if isinstance(row, dict)][:15]
    lines = ["📣 <b>صف پایدار ارسال همگانی</b>", ""]
    rows: list[list[InlineKeyboardButton]] = []
    for job in jobs:
        progress = broadcast_progress(job)
        lines.append(
            f"<code>{progress['id']}</code> | {esc(progress['status'])} | {esc((job.get('content') or {}).get('type') or 'text')} | "
            f"{progress['sent']}/{progress['total']} | خطا {progress['failed']} | {progress['percent']}٪"
            + (f" | زمان {display_dt(job.get('scheduled_for'))}" if job.get("scheduled_for") else "")
        )
        if progress["status"] not in {"completed", "cancelled"}:
            action = "resume" if progress["status"] == "paused" else "pause"
            action_label = "▶️ ادامه" if action == "resume" else "⏸ توقف"
            rows.append(
                [
                    InlineKeyboardButton(action_label, callback_data=f"broadcast_job_{action}:{job['id']}"),
                    InlineKeyboardButton("❌ لغو", callback_data=f"broadcast_job_cancel:{job['id']}"),
                ]
            )
    if not jobs:
        lines.append("هنوز ارسال صف‌شده‌ای وجود ندارد.")
    rows.append([InlineKeyboardButton("🔄 تازه‌سازی", callback_data="broadcast_queue_panel"), *back("a_broadcast")[0]])
    await edit(query, "\n".join(lines), rows)


async def broadcast_job_control(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_BROADCAST):
        return
    query = update.callback_query
    action, job_id = query.data.split(":", 1)
    if action.endswith("cancel"):
        changed = await async_with_db(lambda db: cancel_broadcast(db, job_id))
    elif action.endswith("pause"):
        changed = await async_with_db(lambda db: pause_broadcast(db, job_id))
    else:
        changed = await async_with_db(lambda db: resume_broadcast(db, job_id))
    await query.answer("انجام شد" if changed else "وضعیت قابل تغییر نیست", show_alert=not changed)
    await broadcast_queue_panel(update, context, answer_callback=False)


async def broadcast_queue_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    settings = control_module_state(await async_snapshot(), "broadcast")
    batch_size = max(1, min(100, int(settings.get("batch_size", SETTINGS.broadcast_batch_size) or SETTINGS.broadcast_batch_size)))
    rate = max(1, min(30, int(settings.get("rate_per_second", 20) or 20)))
    batch = await async_with_db(lambda db: claim_broadcast_batch(db, batch_size, personal_only=not is_module_enabled(db, "broadcast")))
    if not batch:
        return

    lease_lost = asyncio.Event()

    async def renew_loop() -> None:
        while True:
            await asyncio.sleep(30)
            renewed = await async_with_db(lambda db: renew_broadcast_lease(db, batch["id"], batch["lease_token"], lease_seconds=120))
            if not renewed:
                lease_lost.set()
                logger.error("Lost broadcast lease for %s", batch["id"])
                return

    renew_task = asyncio.create_task(renew_loop(), name=f"broadcast-lease:{batch['id']}")
    try:
        for item in batch["items"]:
            if lease_lost.is_set():
                break
            uid = str(item["user_id"])
            from modules.broadcast_queue import authorize_broadcast_recipient
            can_send=await async_with_db(lambda db,u=uid:authorize_broadcast_recipient(db,batch['id'],batch['lease_token'],u))
            attempt = int(item.get("attempt", 1))
            result: dict[str, Any]
            try:
                event = batch.get("notification_event") or {}
                allowed = can_send
                if event:
                    from modules.notification_router import should_notify
                    snapshot = await async_snapshot()
                    allowed = allowed and should_notify(snapshot, uid, event["kind"], market=event.get("market"), symbol=event.get("symbol"))
                    if event.get("signal_id"):
                        allowed = allowed and _find_user_visible_signal(snapshot, int(uid), int(event["signal_id"])) is not None
                if allowed:
                    await _send_broadcast_content(
                        context.bot,
                        int(uid),
                        batch.get("content") or {"type": "text", "text": batch.get("message", "")},
                    )
                result = {"user_id": uid, "attempt": attempt, "status": "sent" if allowed else 'cancelled'}
            except Forbidden as exc:
                result = {"user_id": uid, "attempt": attempt, "status": "blocked", "error": str(exc)}
            except RetryAfter as exc:
                retry_after = getattr(exc, "retry_after", 1)
                seconds = retry_after.total_seconds() if hasattr(retry_after, "total_seconds") else float(retry_after)
                result = {
                    "user_id": uid,
                    "attempt": attempt,
                    "status": "retry",
                    "error": f"retry_after:{seconds}",
                    "retry_after_seconds": seconds,
                }
                await asyncio.sleep(min(5.0, max(0.1, seconds)))
            except TelegramError as exc:
                ambiguous=exc.__class__.__name__ in {'TimedOut','NetworkError'} and bool(batch.get('contact_budget'))
                result = {"user_id": uid, "attempt": attempt, "status": 'uncertain' if ambiguous else "retry", "error": exc.__class__.__name__}
            checkpointed = await async_with_db(
                lambda db, delivery=result: checkpoint_broadcast_result(
                    db,
                    batch["id"],
                    batch["lease_token"],
                    delivery,
                )
            )
            if checkpointed is None:
                lease_lost.set()
                logger.error("Lost broadcast lease while checkpointing %s", batch["id"])
                break
            await asyncio.sleep(1 / rate)
    finally:
        renew_task.cancel()
        try:
            await renew_task
        except asyncio.CancelledError:
            pass

    if lease_lost.is_set():
        return
    completed = await async_with_db(lambda db: finish_broadcast_batch(db, batch["id"], batch["lease_token"]))
    if completed and completed.get("status") == "completed" and not completed.get("completion_notified"):
        progress = broadcast_progress(completed)
        try:
            await _telegram_request_with_button_fallback(
                context.bot.send_message,
                int(completed["admin_id"]),
                f"✅ ارسال <code>{completed['id']}</code> تمام شد.\n"
                f"موفق: <b>{progress['sent']}</b> | ناموفق: <b>{progress['failed']}</b> | مسدود: <b>{progress['blocked']}</b>",
                parse_mode=ParseMode.HTML,
            )
            await async_with_db(lambda db: find_broadcast_job(db, completed["id"]).update({"completion_notified": True}))
        except TelegramError:
            logger.warning("Could not notify broadcast owner for %s", completed["id"])


async def a_export_csv(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, (PERMISSION_CRM_EXPORT, PERMISSION_EXPORT_CSV)):
        return
    query = update.callback_query
    await query.answer()
    full_access = (await run_blocking(_has_admin_permission, query.from_user.id, PERMISSION_EXPORT_CSV))
    rows = back("admin_cat:users")
    await edit(
        query,
        "📊 <b>دسترسی خروجی اطلاعات</b>\n\n"
        "دانلود هر فایل مستقیماً در دستهٔ «CRM و خط فروش» قرار دارد.\n\n"
        + ("دسترسی کامل خروجی فعال است؛ بسته جامع، گردش امتیاز و تراکنش‌ها قابل دریافت است."
           if full_access else "دسترسی CRM Export فعال است؛ فقط خلاصه کاربران و فعالیت‌های CRM قابل دریافت است."),
        rows,
    )


async def _send_export_document(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
    *,
    filename: str,
    content: bytes,
    caption: str,
    audit_action: str,
    permission: str | tuple[str, ...] = PERMISSION_EXPORT_CSV,
) -> None:
    if not await require_admin(update, permission):
        return
    query = update.callback_query
    await query.answer("در حال ساخت فایل…")
    document = io.BytesIO(content)
    document.name = filename
    await context.bot.send_document(query.from_user.id, document, caption=caption)
    await async_with_db(lambda db: audit(db, query.from_user.id, audit_action, filename))


async def admin_export_full(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_EXPORT_CSV):
        return
    stamp = datetime.now(UTC).strftime("%Y%m%d-%H%M")
    content = await async_with_db(full_user_export_zip)
    await _send_export_document(
        update,
        context,
        filename=f"sentinel-user-database-{stamp}.zip",
        content=content,
        caption="📦 خروجی کامل و دسته‌بندی‌شده اطلاعات کاربران",
        audit_action="export_user_database_zip",
    )


async def admin_export_users(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, (PERMISSION_CRM_EXPORT, PERMISSION_EXPORT_CSV)):
        return
    content = await async_with_db(user_master_csv)
    await _send_export_document(
        update,
        context,
        filename="sentinel-users-master.csv",
        content=content,
        caption="👥 خلاصه کامل کاربران و دسته‌بندی‌ها",
        audit_action="export_users_master_csv",
        permission=(PERMISSION_CRM_EXPORT, PERMISSION_EXPORT_CSV),
    )


async def admin_export_activity(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, (PERMISSION_CRM_EXPORT, PERMISSION_EXPORT_CSV)):
        return
    await _send_export_document(
        update,
        context,
        filename="sentinel-user-activity.csv",
        content=user_activity_csv(await async_snapshot()),
        caption="📋 تاریخچه فعالیت‌های کاربران",
        audit_action="export_user_activity_csv",
        permission=(PERMISSION_CRM_EXPORT, PERMISSION_EXPORT_CSV),
    )


async def admin_export_points(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_EXPORT_CSV):
        return
    await _send_export_document(
        update,
        context,
        filename="sentinel-points-ledger.csv",
        content=points_ledger_csv(await async_snapshot()),
        caption="⭐ دفتر کل امتیازهای دریافتی و خرج‌شده",
        audit_action="export_points_ledger_csv",
    )


async def admin_export_transactions(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_EXPORT_CSV):
        return
    await _send_export_document(
        update,
        context,
        filename="sentinel-transactions.csv",
        content=transactions_csv(await async_snapshot()),
        caption="💳 خروجی تراکنش‌ها و جوایز",
        audit_action="export_transactions_csv",
    )


def _feature_group_rows(db: dict[str, Any], group_key: str = "") -> list[list[InlineKeyboardButton]]:
    buttons = []
    seen = set()
    for key, (_, modules) in USER_FEATURE_GROUPS.items():
        for module_key in modules:
            if module_key in seen or module_key not in CONTROL_MODULES: continue
            seen.add(module_key)
            buttons.append(state_button(CONTROL_MODULES[module_key].label, is_module_enabled(db, module_key),
                                        callback_data=f"feature_toggle:{key}:{module_key}"))
    rows = [buttons[index:index+2] for index in range(0, len(buttons), 2)]
    rows.append([InlineKeyboardButton("⬅️ ادمین و امنیت", callback_data="admin_cat:system")])
    return rows


async def feature_management_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_FEATURE_TOGGLE_MANAGE): return
    query = update.callback_query
    await query.answer()
    await edit(query, "🎛 <b>مدیریت امکانات کاربری</b>\n\nهر دکمه وضعیت همان قابلیت را تغییر می‌دهد. همهٔ امکانات اینجا مستقیم قابل انتخاب‌اند.",
               _feature_group_rows(await async_snapshot()))


async def feature_group_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await feature_management_view(update, context)


async def feature_toggle_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_FEATURE_TOGGLE_MANAGE):
        return
    query = update.callback_query
    _, group_key, module_key = str(query.data).split(":", 2)
    if group_key not in USER_FEATURE_GROUPS or module_key not in USER_FEATURE_GROUPS[group_key][1]:
        await query.answer("قابلیت انتخاب‌شده معتبر نیست.", show_alert=True)
        return
    enabled = await async_with_db(
        lambda db: toggle_control_value(db, module_key, "enabled", query.from_user.id)
    )
    await async_with_db(
        lambda db: audit(
            db,
            query.from_user.id,
            "user_feature_toggle",
            f"{module_key}:{'enabled' if enabled else 'disabled'}",
        )
    )
    await query.answer("قابلیت فعال شد." if enabled else "قابلیت غیرفعال شد.", show_alert=True)
    await edit(
        query,
        "🎛 <b>مدیریت امکانات کاربری</b>\n\n"
        "✅ فعال است  •  ⛔️ غیرفعال است\n"
        "با لمس هر گزینه، وضعیت همان قابلیت فوراً تغییر می‌کند.",
        _feature_group_rows(await async_snapshot(), group_key),
    )


async def rules_admin_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_RULES):
        return
    query = update.callback_query
    await query.answer()
    db = await async_snapshot()
    fa_state = current_rules(db, "fa")
    en_state = current_rules(db, "en")
    fa_summary = rules_acceptance_summary(db, "fa")
    en_summary = rules_acceptance_summary(db, "en")
    enabled = bool(fa_state.get("enabled", True))
    await edit(
        query,
        "📜 <b>قوانین دوزبانه SENTINEL</b>\n\n"
        f"وضعیت الزام: <b>{'فعال' if enabled else 'غیرفعال'}</b>\n\n"
        f"🇮🇷 فارسی · نسخه <b>{int(fa_state.get('version', 0) or 0)}</b>\n"
        f"پذیرفته: <b>{fa_summary['accepted']}</b> | در انتظار: <b>{fa_summary['pending']}</b>\n"
        f"آخرین ویرایش: <b>{display_dt(fa_state.get('updated_at')) if fa_state.get('updated_at') else '—'}</b>\n\n"
        f"🇬🇧 English · Version <b>{int(en_state.get('version', 0) or 0)}</b>\n"
        f"Accepted: <b>{en_summary['accepted']}</b> | Pending: <b>{en_summary['pending']}</b>\n"
        f"Last update: <b>{display_dt(en_state.get('updated_at')) if en_state.get('updated_at') else '—'}</b>\n\n"
        "نسخه‌های دو زبان مستقل‌اند و کاربر فقط قوانین زبان انتخابی خودش را تأیید می‌کند.",
        [
            [
                InlineKeyboardButton("📝 قوانین فارسی", callback_data="rules_edit:fa"),
                InlineKeyboardButton("📝 English rules", callback_data="rules_edit:en"),
            ],
            [
                InlineKeyboardButton("👁 پیش‌نمایش فارسی", callback_data="rules_preview:fa"),
                InlineKeyboardButton("👁 English preview", callback_data="rules_preview:en"),
            ],
            [
                state_button(
                    "الزام پذیرش قوانین",
                    enabled,
                    callback_data="rules_toggle",
                    enabled_label="فعال",
                    disabled_label="غیرفعال",
                )
            ],
            back("admin_cat:users")[0],
        ],
    )


async def rules_edit_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_RULES):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    language = normalize_language(str(query.data or "").split(":", 1)[-1])
    context.user_data["rules_language"] = language
    await edit(
        query,
        (
            "📝 <b>Publish new English rules</b>\n\nSend the rules as text or upload a UTF-8 "
            "<code>.txt</code>/<code>.md</code> file. Maximum: 32,000 characters."
            if language == "en"
            else "📝 <b>انتشار نسخه جدید قوانین فارسی</b>\n\n"
            "متن قوانین را مستقیماً ارسال کنید یا یک فایل UTF-8 با پسوند <code>.txt</code> یا "
            "<code>.md</code> بفرستید.\nحداکثر اندازه متن: ۳۲٬۰۰۰ نویسه."
        ),
        back("a_rules"),
    )
    return RULES_INPUT


async def rules_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_RULES):
        return ConversationHandler.END
    message = update.effective_message
    language = normalize_language(context.user_data.get("rules_language") or "fa")
    raw_text = str(message.text or "")
    if message.document:
        name = str(message.document.file_name or "").lower()
        if not name.endswith((".txt", ".md")):
            await reply(update, "❌ فقط فایل TXT یا Markdown پذیرفته می‌شود.", back("a_rules"))
            return RULES_INPUT
        if int(message.document.file_size or 0) > 131_072:
            await reply(update, "❌ حجم فایل قوانین بیش از حد مجاز است.", back("a_rules"))
            return RULES_INPUT
        try:
            telegram_file = await context.bot.get_file(message.document.file_id)
            payload = await telegram_file.download_as_bytearray()
            raw_text = bytes(payload).decode("utf-8-sig")
        except (TelegramError, UnicodeDecodeError):
            await reply(update, "❌ فایل باید متنی و با کدگذاری UTF-8 باشد.", back("a_rules"))
            return RULES_INPUT
    try:
        state = await async_with_db(
            lambda db: publish_rules(db, raw_text, update.effective_user.id, language)
        )
        await async_with_db(
            lambda db: set_control_value(db, "rules", "enabled", True, update.effective_user.id)
        )
        await async_with_db(
            lambda db: audit(
                db,
                update.effective_user.id,
                "rules_publish",
                f"language:{language}:version:{state['version']}",
            )
        )
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}", back("a_rules"))
        return RULES_INPUT
    await reply(
        update,
        (
            f"✅ English rules version <b>{int(state['version'])}</b> was published.\n"
            "English users must accept this version before continuing."
            if language == "en"
            else f"✅ نسخه <b>{int(state['version'])}</b> قوانین فارسی منتشر شد.\n"
            "از این لحظه کاربران فارسی‌زبان پیش از ورود باید نسخه جدید را تأیید کنند."
        ),
        [[InlineKeyboardButton("📜 مدیریت قوانین", callback_data="a_rules")]],
    )
    return ConversationHandler.END


async def rules_toggle_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_RULES):
        return
    query = update.callback_query
    db = await async_snapshot()
    enabled = not bool(current_rules(db).get("enabled", True))

    def mutate(database: dict[str, Any]) -> None:
        set_rules_enabled(database, enabled, query.from_user.id)
        set_control_value(database, "rules", "enabled", enabled, query.from_user.id)
        audit(database, query.from_user.id, "rules_toggle", "enabled" if enabled else "disabled")

    await async_with_db(mutate)
    await rules_admin_view(update, context)


async def rules_preview_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_RULES):
        return
    query = update.callback_query
    await query.answer()
    language = normalize_language(str(query.data or "").split(":", 1)[-1])
    await _send_rules_prompt(update, context, admin_preview=True, language=language)


def _delegated_admin_text(uid: str, row: dict[str, Any]) -> str:
    permissions = set(row.get("permissions", []))
    role = row.get("role_preset_label") or "سفارشی"
    status = "فعال" if row.get("active", True) and str(row.get("approval_status") or "approved") == "approved" else "در انتظار تأیید یا غیرفعال"
    return ("👮 <b>دسترسی‌های ادمین</b>\n\n"
            f"ادمین: <code>{esc(uid)}</code>\nنقش: <b>{esc(role)}</b>\n"
            f"وضعیت ادمین: <b>{status}</b>\n"
            f"دسترسی انتخاب‌شده: <b>{len(permissions)} از {len(ALL_PERMISSIONS)-len(OWNER_ONLY_PERMISSIONS)}</b>\n\n"
            "هر دسترسی دکمهٔ مستقل دارد؛ سبز فعال و قرمز غیرفعال است.\n"
            "برای ادامهٔ فهرست از صفحهٔ بعد استفاده کنید. تأیید دوم فقط با ادمین اصلی است.")


def _delegated_admin_rows(uid: str, row: dict[str, Any], page: int = 0) -> list[list[InlineKeyboardButton]]:
    from ui.button_factory import state_button
    from modules.admin_permission_ui import PAGE_SIZE, PERMISSIONS, clamp_permission_page, permission_token
    page = clamp_permission_page(page)
    permissions = set(row.get("permissions", []))
    buttons = []
    for permission in PERMISSIONS[page*PAGE_SIZE:(page+1)*PAGE_SIZE]:
        enabled = permission in permissions
        label = PERMISSION_SHORT_LABELS[permission]
        if permission == PERMISSION_TWO_STEP_APPROVALS:
            label = "مشاهدهٔ درخواست تأیید"
        buttons.append(state_button(label, enabled,
            callback_data=f"ap_set:{uid}:{permission_token(permission)}:{int(not enabled)}:{page}",
            enabled_label="فعال", disabled_label="غیرفعال"))
    rows = [buttons[index:index+2] for index in range(0,len(buttons),2)]
    paging = []
    if page:
        paging.append(InlineKeyboardButton("⬅️ صفحه قبل",callback_data=f"admin_manage:{uid}:{page-1}"))
    if (page+1)*PAGE_SIZE < len(PERMISSIONS):
        paging.append(InlineKeyboardButton("صفحه بعد ➡️",callback_data=f"admin_manage:{uid}:{page+1}"))
    if paging: rows.append(paging)
    if page == 0:
        roles = [InlineKeyboardButton(f"🎭 {spec.get('label',key)}",callback_data=f"admin_role:{uid}:{key}") for key,spec in ADMIN_ROLE_PRESETS.items()]
        rows.extend(roles[index:index+2] for index in range(0,len(roles),2))
    rows += [[InlineKeyboardButton("✅ فعال‌سازی همه",callback_data=f"admin_perm_all:{uid}:on"),InlineKeyboardButton("🚫 لغو همه",callback_data=f"admin_perm_all:{uid}:off")],
             [InlineKeyboardButton("🗑 حذف ادمین",callback_data=f"admin_remove:{uid}"),InlineKeyboardButton("⬅️ فهرست ادمین‌ها",callback_data="a_admins")]]
    return rows


def _delegated_admin_group_rows(uid, row, group_key):
    # Old messages remain usable; permission groups no longer open a submenu.
    from modules.admin_permission_ui import permission_page
    values = PERMISSION_GROUPS.get(group_key, ("", ()))[1]
    return _delegated_admin_rows(uid,row,permission_page(values[0]) if values else 0)



def _delegated_admin_self_edit_error(actor_id: int | str, target_id: int | str) -> str | None:
    if is_admin(actor_id):
        return None
    try:
        if int(actor_id) == int(target_id):
            return "ادمین واگذارشده نمی‌تواند دسترسی‌های خودش را تغییر دهد."
    except (TypeError, ValueError):
        return "آیدی ادمین معتبر نیست."
    return None


async def a_admins(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_ADMIN_MANAGEMENT):
        return
    query = update.callback_query
    await query.answer()
    admins = delegated_admins(await async_snapshot())
    rows: list[list[InlineKeyboardButton]] = [[InlineKeyboardButton("➕ افزودن ادمین با آیدی عددی", callback_data="admin_add")]]
    for uid, row in sorted(admins.items(), key=lambda item: int(item[0])):
        count = len(set(row.get("permissions", [])))
        rows.append([InlineKeyboardButton(f"👤 {uid} | {count}/{len(ALL_PERMISSIONS) - len(OWNER_ONLY_PERMISSIONS)} دسترسی", callback_data=f"admin_manage:{uid}")])
    rows.append(back("admin_home")[0])
    text = (
        "👮 <b>مدیریت ادمین‌ها و دسترسی‌ها</b>\n\n"
        "ادمین‌های اصلی از متغیر <code>ADMIN_IDS</code> خوانده می‌شوند و از این قسمت حذف نمی‌شوند.\n"
        "برای هر ادمین می‌توانید تمام بخش‌های پنل را جداگانه فعال یا غیرفعال کنید. "
        "مجوز «مدیریت ادمین‌ها» به فرد اجازه می‌دهد برای سایر افراد ادمین بسازد و دسترسی تعیین کند."
    )
    if not admins:
        text += "\n\nهنوز ادمین واگذارشده‌ای ثبت نشده است."
    await edit(query, text, rows)


async def admin_add_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_ADMIN_MANAGEMENT):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    await edit(
        query,
        "آیدی عددی تلگرام فرد را وارد کنید.\n\nنمونه: <code>123456789</code>\nفرد می‌تواند با دستور <code>/id</code> آیدی خود را ببیند.",
        back("a_admins"),
    )
    return ADMIN_ADD_ID


async def admin_add_id_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, PERMISSION_ADMIN_MANAGEMENT):
        return ConversationHandler.END
    raw = _ascii_digits(update.effective_message.text or "").strip()
    if not raw.isdigit():
        await reply(update, "❌ آیدی باید فقط شامل عدد باشد. دوباره وارد کنید:", back("a_admins"))
        return ADMIN_ADD_ID
    try:
        uid = normalize_admin_id(raw)
        error = _delegated_admin_self_edit_error(update.effective_user.id, uid)
        if error:
            raise ValueError(error)
        row = await async_with_db(lambda db: upsert_delegated_admin(db, uid, [], update.effective_user.id))
        await async_with_db(lambda db: audit(db, update.effective_user.id, "delegated_admin_add", uid))
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}", back("a_admins"))
        return ADMIN_ADD_ID
    await reply(
        update,
        _delegated_admin_text(uid, row) + "\n\nاکنون دسترسی‌های موردنظر را فعال کنید.",
        _delegated_admin_rows(uid, row),
    )
    return ConversationHandler.END


async def admin_manage(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_ADMIN_MANAGEMENT):
        return
    query = update.callback_query
    await query.answer()
    parts = str(query.data).split(":")
    uid = parts[1]
    page = int(parts[2]) if len(parts)>2 and parts[2].isdigit() else 0
    context.user_data["admin_permissions_page"] = page
    error = _delegated_admin_self_edit_error(query.from_user.id, uid)
    if error:
        await query.answer(error, show_alert=True)
        return
    row = get_delegated_admin((await async_snapshot()), uid)
    if not row:
        await edit(query, "❌ این ادمین پیدا نشد.", back("a_admins"))
        return
    await edit(query, _delegated_admin_text(uid, row), _delegated_admin_rows(uid, row, page))


async def admin_permission_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_ADMIN_MANAGEMENT):
        return
    query = update.callback_query
    _, uid, permission = query.data.split(":", 2)
    error = _delegated_admin_self_edit_error(query.from_user.id, uid)
    if error:
        await query.answer(error, show_alert=True)
        return
    try:
        row = await async_with_db(lambda db: toggle_permission(db, uid, permission, query.from_user.id))
        await async_with_db(lambda db: audit(db, query.from_user.id, "delegated_admin_permission", f"{uid}:{permission}"))
    except (ValueError, PermissionError) as exc:
        await query.answer(str(exc), show_alert=True)
        return
    enabled = permission in set(row.get("permissions", []))
    await query.answer(
        f"{PERMISSION_SHORT_LABELS.get(permission, permission)} {'فعال شد ✅' if enabled else 'غیرفعال شد ⛔'}",
        show_alert=True,
    )
    from modules.admin_permission_ui import permission_page
    await edit(query, _delegated_admin_text(uid,row), _delegated_admin_rows(uid,row,permission_page(permission)))


async def admin_permission_set(update, context):
    if not await require_admin(update, PERMISSION_ADMIN_MANAGEMENT):
        return
    from modules.admin_access import set_permission_state
    from modules.admin_permission_ui import TOKEN_TO_PERMISSION
    query = update.callback_query
    _,uid,token,desired,page = str(query.data).split(":")
    error = _delegated_admin_self_edit_error(query.from_user.id,uid)
    permission = TOKEN_TO_PERMISSION.get(token)
    if error or not permission or desired not in {"0","1"}:
        await query.answer(error or "مجوز نامعتبر است.",show_alert=True); return
    try:
        def mutate(db):
            row = set_permission_state(db,uid,permission,desired=="1",query.from_user.id)
            audit(db,query.from_user.id,"delegated_admin_permission",f"{uid}:{permission}:{desired}")
            return row
        row = await async_with_db(mutate)
    except (ValueError,PermissionError) as exc:
        await query.answer(str(exc),show_alert=True); return
    await query.answer("دسترسی ذخیره شد.")
    await edit(query,_delegated_admin_text(uid,row),_delegated_admin_rows(uid,row,int(page)))


async def admin_permission_group(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_ADMIN_MANAGEMENT):
        return
    query = update.callback_query
    await query.answer()
    _, uid, group_key = str(query.data).split(":", 2)
    error = _delegated_admin_self_edit_error(query.from_user.id, uid)
    if error:
        await query.answer(error, show_alert=True)
        return
    row = get_delegated_admin((await async_snapshot()), uid)
    group = PERMISSION_GROUPS.get(group_key)
    if not row or not group:
        await query.answer("ادمین یا گروه دسترسی پیدا نشد.", show_alert=True)
        return
    await edit(query, _delegated_admin_text(uid,row), _delegated_admin_group_rows(uid,row,group_key))


async def admin_role_preset_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_ADMIN_MANAGEMENT):
        return
    query = update.callback_query
    _, uid, preset = str(query.data or "").split(":", 2)
    error = _delegated_admin_self_edit_error(query.from_user.id, uid)
    if error:
        await query.answer(error, show_alert=True)
        return
    spec = ADMIN_ROLE_PRESETS.get(preset)
    if spec is None:
        await query.answer("نقش انتخاب‌شده معتبر نیست.", show_alert=True)
        return
    if operation_requires_approval((await async_snapshot()), "admin_role_preset"):
        approval = await async_with_db(
            lambda db: create_pending_approval(
                db,
                "admin_role_preset",
                {"uid": uid, "preset": preset},
                query.from_user.id,
                description=f"اعمال نقش {spec.get('label', preset)} برای ادمین {uid}",
            )
        )
        await _notify_pending_approval(context, approval)
        await query.answer("درخواست نقش برای تأیید دوم ارسال شد.", show_alert=True)
        return
    try:
        row = await async_with_db(
            lambda db: apply_admin_role_preset(db, uid, preset, query.from_user.id)
        )
        await async_with_db(
            lambda db: audit(db, query.from_user.id, "delegated_admin_role_preset", f"{uid}:{preset}")
        )
    except (ValueError, PermissionError) as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer(f"نقش {spec.get('label', preset)} اعمال شد ✅", show_alert=True)
    await edit(
        query,
        _delegated_admin_text(uid, row)
        + f"\n\n<b>شرح نقش:</b> {esc(spec.get('description') or '')}",
        _delegated_admin_rows(uid, row),
    )


async def admin_permissions_all(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_ADMIN_MANAGEMENT):
        return
    query = update.callback_query
    await query.answer()
    _, uid, mode = query.data.split(":", 2)
    error = _delegated_admin_self_edit_error(query.from_user.id, uid)
    if error:
        await query.answer(error, show_alert=True)
        return
    if operation_requires_approval((await async_snapshot()), "admin_all_permissions"):
        row = await async_with_db(
            lambda db: create_pending_approval(
                db,
                "admin_all_permissions",
                {"uid": uid, "mode": mode},
                query.from_user.id,
                description=f"{'اعطای همه دسترسی‌ها به' if mode == 'on' else 'لغو همه دسترسی‌های'} ادمین {uid}",
            )
        )
        await _notify_pending_approval(context, row)
        await edit(query, "🔐 تغییر همه مجوزها برای تأیید ادمین دوم ارسال شد.", back("a_admins"))
        return
    permissions = ALL_PERMISSIONS if mode == "on" else ()
    try:
        row = await async_with_db(lambda db: set_permissions(db, uid, permissions, query.from_user.id))
        await async_with_db(lambda db: audit(db, query.from_user.id, "delegated_admin_permissions_all", f"{uid}:{mode}"))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await edit(query, _delegated_admin_text(uid, row), _delegated_admin_rows(uid, row))


async def admin_remove(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_ADMIN_MANAGEMENT):
        return
    query = update.callback_query
    await query.answer()
    uid = query.data.split(":", 1)[1]
    error = _delegated_admin_self_edit_error(query.from_user.id, uid)
    if error:
        await query.answer(error, show_alert=True)
        return
    if operation_requires_approval((await async_snapshot()), "admin_remove"):
        row = await async_with_db(
            lambda db: create_pending_approval(
                db,
                "admin_remove",
                {"uid": uid},
                query.from_user.id,
                description=f"حذف کامل دسترسی ادمین {uid}",
            )
        )
        await _notify_pending_approval(context, row)
        await edit(query, "🔐 حذف ادمین برای تأیید ادمین دوم ارسال شد.", back("a_admins"))
        return
    try:
        removed = await async_with_db(lambda db: remove_delegated_admin(db, uid))
        if removed:
            await async_with_db(lambda db: audit(db, query.from_user.id, "delegated_admin_remove", uid))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await edit(query, "✅ دسترسی ادمین به‌طور کامل حذف شد." if removed else "❌ ادمین پیدا نشد.", back("a_admins"))


async def admin_home(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, allow_limited=True):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    await edit(query, (await run_blocking(admin_home_text, query.from_user.id)), (await run_blocking(admin_menu, query.from_user.id)))
    from bot_runtime.live_signal_desk import remember_live_panel
    remember_live_panel(context,query.from_user.id,query.message,'root')
    return ConversationHandler.END


async def admin_ui_mode_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, allow_limited=True):
        return ConversationHandler.END
    query = update.callback_query
    mode = str(query.data or "").split(":", 1)[1]
    try:
        await async_with_db(
            lambda db: set_admin_ui_mode(db, query.from_user.id, mode)
        )
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return ConversationHandler.END
    await query.answer(
        "حالت ساده فعال شد" if mode == "basic" else "حالت حرفه‌ای فعال شد"
    )
    await edit(
        query,
        (await run_blocking(admin_home_text, query.from_user.id)),
        (await run_blocking(admin_menu, query.from_user.id)),
    )
    return ConversationHandler.END


async def admin_navigation(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if not await require_admin(update, allow_limited=True):
        return ConversationHandler.END
    query = update.callback_query
    await query.answer()
    category = str(query.data or "").split(":", 1)[1] if ":" in str(query.data or "") else ""
    category = _admin_canonical_category(category)
    granted = (await run_blocking(_admin_granted_permissions, query.from_user.id))
    items = _admin_items_by_callback()
    if not any(_admin_item_allowed(key, query.from_user.id, granted, items) for key in _admin_navigation_categories().get(category, {}).get("callbacks", [])):
        await query.answer("به این مرکز دسترسی ندارید.", show_alert=True)
        return ConversationHandler.END
    await edit(
        query,
        (await run_blocking(admin_category_text, category, query.from_user.id)),
        (await run_blocking(admin_category_menu, category, query.from_user.id)),
    )
    return ConversationHandler.END


async def a_pending(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, (PERMISSION_PAYMENTS, PERMISSION_PAYMENT_DASHBOARD_VIEW, PERMISSION_PAYMENT_TRANSACTIONS_VIEW, PERMISSION_PAYMENT_RECEIPTS_VIEW, PERMISSION_PAYMENT_MANUAL_REVIEW)):
        return
    query = update.callback_query
    await query.answer()
    try:
        page = int(query.data.split(":", 1)[1]) if ":" in query.data else 0
    except (TypeError, ValueError):
        page = 0
    page = max(0, page)
    from services.experience_state import pending_orders
    rows_all = await run_blocking(pending_orders)
    page_size = 10
    max_page = max(0, (len(rows_all) - 1) // page_size)
    page = min(page, max_page)
    pending = rows_all[page * page_size : (page + 1) * page_size]
    if not pending:
        await edit(query, "📥 سفارش معلقی وجود ندارد.", back("admin_home"))
        return
    rows: list[list[InlineKeyboardButton]] = []
    for order in pending:
        state = "🔄" if order.get("status") == "approving" else "📄"
        rows.append(
            [
                InlineKeyboardButton(
                    f"{state} {order.get('order_id')} | {int(order.get('price', 0) or 0):,}",
                    callback_data=f"pending_detail:{order.get('order_id')}:{page}",
                )
            ]
        )
    nav: list[InlineKeyboardButton] = []
    if page > 0:
        nav.append(InlineKeyboardButton("◀️ قبلی", callback_data=f"a_pending:{page - 1}"))
    if page < max_page:
        nav.append(InlineKeyboardButton("بعدی ▶️", callback_data=f"a_pending:{page + 1}"))
    if nav:
        rows.append(nav)
    rows += back("admin_home")
    await edit(
        query,
        f"📥 <b>پرداخت‌های در حال بررسی</b>\nتعداد کل: {len(rows_all)}\nصفحه {page + 1} از {max_page + 1}",
        rows,
    )


async def pending_detail(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, (PERMISSION_PAYMENTS, PERMISSION_PAYMENT_DASHBOARD_VIEW, PERMISSION_PAYMENT_TRANSACTIONS_VIEW, PERMISSION_PAYMENT_RECEIPTS_VIEW, PERMISSION_PAYMENT_MANUAL_REVIEW)):
        return
    query = update.callback_query
    await query.answer()
    parts = query.data.split(":")
    order_id = parts[1] if len(parts) > 1 else ""
    try:
        page = int(parts[2]) if len(parts) > 2 else 0
    except ValueError:
        page = 0
    from services.vip_order_projection import project_normalized_order_to_legacy
    order = await run_blocking(project_normalized_order_to_legacy, order_id)
    order = order or find_vip_order((await async_snapshot()), order_id)
    if not order:
        await query.answer("سفارش پیدا نشد.", show_alert=True)
        return
    caption = _order_caption(order)
    markup = _order_keyboard(order, page=page)
    try:
        receipt_file = _order_receipt_file(order)
        if order.get("receipt_file_id"):
            await _telegram_request_with_button_fallback(
                context.bot.send_photo,
                chat_id=query.message.chat.id,
                photo=order["receipt_file_id"],
                caption=caption,
                parse_mode=ParseMode.HTML,
                reply_markup=markup,
            )
        elif receipt_file:
            await _telegram_request_with_button_fallback(
                context.bot.send_photo,
                chat_id=query.message.chat.id,
                photo=receipt_file,
                caption=caption,
                parse_mode=ParseMode.HTML,
                reply_markup=markup,
            )
        else:
            await _telegram_request_with_button_fallback(
                context.bot.send_message,
                chat_id=query.message.chat.id,
                text=caption + "\n\nℹ️ این سفارش بدون رسید ثبت شده است.",
                parse_mode=ParseMode.HTML,
                reply_markup=markup,
            )
    except TelegramError:
        logger.exception("Could not display pending order %s", order_id)
        await query.answer("نمایش جزئیات ناموفق بود؛ لاگ سرور را بررسی کنید.", show_alert=True)


def _dashboard_rows(user_id: int | str, current_page: str) -> list[list[InlineKeyboardButton]]:
    labels = [
        ("overview", "📊 خلاصه"),
        ("business", "🏢 تجاری"),
        ("sales", "💰 فروش"),
        ("users", "👥 کاربران"),
        ("support", "🎫 پشتیبانی"),
        ("signals", "📡 سیگنال"),
        ("system", "⚙️ سیستم"),
    ]
    buttons = [
        InlineKeyboardButton(("✅ " if page == current_page else "") + label, callback_data=f"a_dash:{page}") for page, label in labels
    ]
    rows = [buttons[index : index + 2] for index in range(0, len(buttons), 2)]
    actions: list[InlineKeyboardButton] = []
    if _has_admin_permission(user_id, PERMISSION_PAYMENTS):
        actions.append(InlineKeyboardButton("📥 پرداخت‌های معلق", callback_data="a_pending"))
    if _has_admin_permission(user_id, PERMISSION_TICKETS):
        actions.append(InlineKeyboardButton("🎫 تیکت‌های باز", callback_data="a_tickets"))
    if actions:
        rows.append(actions[:2])
    actions = []
    if _has_admin_permission(user_id, PERMISSION_PAID_EDUCATION):
        actions.append(InlineKeyboardButton("🎓 پرداخت آموزش", callback_data="a_edu_orders"))
    if _has_admin_permission(user_id, PERMISSION_CRM):
        actions.append(InlineKeyboardButton("🗂 CRM", callback_data="a_crm"))
    if actions:
        rows.append(actions[:2])
    if _has_admin_permission(user_id, PERMISSION_DASHBOARD):
        rows.append([InlineKeyboardButton("📈 مشاهده قیف فروش", callback_data="a_sales_funnel"), InlineKeyboardButton("🔎 مرکز شفافیت", callback_data="a_trust_center")])
    if _has_admin_permission(user_id, PERMISSION_SIGNAL_RESULTS):
        rows.append([InlineKeyboardButton("🛡 تابلو ریسک", callback_data="sig_exposure"), InlineKeyboardButton("🕒 سشن‌ها", callback_data="sig_sessions")])
    if _has_admin_permission(user_id, PERMISSION_SYSTEM_CONTROL):
        rows.append([InlineKeyboardButton("🚨 رخدادها", callback_data="a_incidents"), InlineKeyboardButton("🧩 قابلیت‌ها", callback_data="a_capabilities")])
    rows.append(
        [
            InlineKeyboardButton("🔄 تازه‌سازی", callback_data=f"a_dash:{current_page}"),
            InlineKeyboardButton("🔙 پنل مدیریت", callback_data="admin_home"),
        ]
    )
    return rows


def _dashboard_text(snapshot: dict[str, Any], page: str) -> str:
    users = snapshot["users"]
    vip = snapshot["vip"]
    sales = snapshot["sales"]
    support = snapshot["support"]
    signals = snapshot["signals"]
    engagement = snapshot["engagement"]
    system = snapshot["system"]

    if page == "business":
        board = snapshot.get("commercial", {})
        revenue = board.get("revenue", {})
        commercial_vip = board.get("vip", {})
        growth = board.get("growth", {})
        campaigns = board.get("campaigns", {})
        crm = board.get("crm", {})
        direction = "رشد" if float(revenue.get("change_percent", 0) or 0) >= 0 else "کاهش"
        lines = [
            "🏢 <b>داشبورد تجاری SENTINEL</b>",
            "نمای مدیریتی ۳۰ روز اخیر در مقایسه با ۳۰ روز قبل",
            "",
            "<b>💰 درآمد و فروش</b>",
            f"درآمد: <b>{int(revenue.get('current', 0)):,} تومان</b>",
            f"{direction}: <b>{float(revenue.get('change_percent', 0)):+.1f}٪</b>",
            f"سفارش: <b>{int(revenue.get('orders', 0)):,}</b> | میانگین سفارش: <b>{int(revenue.get('average_order_value', 0)):,}</b>",
            f"ARPU ثبت‌شده: <b>{int(revenue.get('arpu', 0)):,} تومان</b>",
            "",
            "<b>💎 VIP</b>",
            f"فعال: <b>{int(commercial_vip.get('active', 0)):,}</b> | رو به انقضا: <b>{int(commercial_vip.get('expiring_7d', 0)):,}</b>",
            f"خریدار ۳۰ روز: <b>{int(commercial_vip.get('buyers_30d', 0)):,}</b> | تبدیل ورودی جدید: <b>{float(commercial_vip.get('conversion_30d', 0)):.1f}٪</b>",
            "",
            "<b>🚀 رشد و کمپین لینک‌محور</b>",
            f"کمپین فعال: <b>{int(campaigns.get('active', 0)):,}</b> | لینک: <b>{int(growth.get('links', 0)):,}</b>",
            f"ورود منتسب: <b>{int(growth.get('joins', 0)):,}</b> | خرید منتسب: <b>{int(growth.get('attributed_orders', 0)):,}</b>",
            f"درآمد منتسب: <b>{int(growth.get('attributed_revenue', 0)):,}</b> | هزینه: <b>{int(growth.get('cost', 0)):,}</b>",
            f"ROAS: <b>{float(growth.get('roas', 0)):.2f}x</b> | ROI: <b>{float(growth.get('roi', 0)):.1f}٪</b> | CAC: <b>{float(growth.get('cac', 0)):,.0f}</b>",
            "",
            "<b>🧠 رفتار مشتری</b>",
            f"درگیر: <b>{int(crm.get('engaged', 0)):,}</b> | قصد خرید بالا: <b>{int(crm.get('high_intent', 0)):,}</b> | ریسک ریزش: <b>{int(crm.get('at_risk', 0)):,}</b>",
        ]
        return "\n".join(lines)

    if page == "sales":
        return (
            "💰 <b>داشبورد فروش و درآمد</b>\n\n"
            "<b>درآمد کل VIP + آموزش</b>\n"
            f"امروز: <b>{sales['total']['today']:,} تومان</b> ({sales['total']['today_count']} پرداخت)\n"
            f"۷ روز: <b>{sales['total']['days_7']:,} تومان</b> ({sales['total']['days_7_count']} پرداخت)\n"
            f"۳۰ روز: <b>{sales['total']['days_30']:,} تومان</b> ({sales['total']['days_30_count']} پرداخت)\n"
            f"کل دوره: <b>{sales['total']['all']:,} تومان</b> ({sales['total']['all_count']} پرداخت)\n\n"
            "<b>تفکیک درآمد</b>\n"
            f"💎 VIP در ۳۰ روز: <b>{sales['vip']['days_30']:,} تومان</b>\n"
            f"🎓 آموزش در ۳۰ روز: <b>{sales['education']['days_30']:,} تومان</b>\n"
            f"📥 سفارش VIP معلق: <b>{vip['pending_orders']}</b>\n"
            f"🎓 پرداخت آموزش معلق: <b>{sales['pending_education']}</b>\n\n"
            "<b>شاخص‌های فروش</b>\n"
            f"نرخ تبدیل به خریدار VIP: <b>{users['conversion_rate']:.1f}٪</b>\n"
            f"نرخ خریدار تکراری: <b>{users['renewal_rate']:.1f}٪</b>\n"
            f"خریداران VIP یکتا: <b>{users['unique_vip_buyers']}</b>\n"
            f"خریداران تکراری: <b>{users['repeat_vip_buyers']}</b>"
        )

    if page == "users":
        total = max(1, int(users["total"]))
        segments = users.get("segments", {})
        return (
            "👥 <b>داشبورد کاربران</b>\n\n"
            f"کل کاربران: <b>{users['total']:,}</b>\n"
            f"کاربر جدید امروز: <b>{users['new_today']}</b>\n"
            f"کاربر جدید ۷ روز: <b>{users['new_7d']}</b>\n"
            f"کاربر جدید ۳۰ روز: <b>{users['new_30d']}</b>\n\n"
            "<b>فعالیت کاربران</b>\n"
            f"فعال در ۲۴ ساعت: <b>{users['active_24h']}</b> ({users['active_24h'] / total * 100:.1f}٪)\n"
            f"فعال در ۷ روز: <b>{users['active_7d']}</b> ({users['active_7d'] / total * 100:.1f}٪)\n"
            f"فعال در ۳۰ روز: <b>{users['active_30d']}</b> ({users['active_30d'] / total * 100:.1f}٪)\n\n"
            "<b>اشتراک و وضعیت</b>\n"
            f"VIP فعال: <b>{vip['active']}</b>\n"
            f"منقضی‌شونده تا ۷ روز: <b>{vip['expiring_7d']}</b>\n"
            f"VIP منقضی: <b>{vip['expired']}</b>\n"
            f"کاربران مسدود: <b>{users['banned']}</b>\n\n"
            "<b>دسته‌بندی مشتریان</b>\n"
            f"خریدار بار اول: <b>{int(segments.get('first_buyer', 0))}</b>\n"
            f"خریدار تکراری: <b>{int(segments.get('repeat_buyer', 0))}</b>\n"
            f"مشتری وفادار: <b>{int(segments.get('loyal_buyer', 0))}</b>\n"
            f"مشتری باارزش: <b>{int(segments.get('high_value', 0))}</b>\n"
            f"خرج‌کننده امتیاز: <b>{int(segments.get('points_spender', 0))}</b>\n"
            f"کاربر غیرفعال: <b>{int(segments.get('inactive_user', 0))}</b>"
        )

    if page == "support":
        return (
            "🎫 <b>داشبورد پشتیبانی و تعامل</b>\n\n"
            f"تیکت باز: <b>{support['open']}</b>\n"
            f"تیکت بدون رسیدگی بیش از ۲۴ ساعت: <b>{support['stale_24h']}</b>\n"
            f"تیکت بسته‌شده در ۷ روز: <b>{support['closed_7d']}</b>\n"
            f"کل تیکت‌ها: <b>{support['total']}</b>\n"
            f"درخواست جایزه معلق: <b>{support['pending_rewards']}</b>\n\n"
            "<b>تعامل کاربران</b>\n"
            f"هشدار قیمت فعال: <b>{engagement['active_price_alerts']}</b>\n"
            f"مأموریت تکمیل‌شده: <b>{engagement['completed_missions']}</b>\n"
            f"جوایز تحویل‌شده: <b>{engagement['delivered_rewards']}</b>\n"
            f"کمپین‌های ۷ روز اخیر: <b>{engagement['broadcasts_7d']}</b>\n"
            f"ارسال موفق کمپین: <b>{engagement['broadcast_sent_7d']}</b>\n"
            f"ارسال ناموفق کمپین: <b>{engagement['broadcast_failed_7d']}</b>"
        )

    if page == "signals":
        safety = snapshot.get("signal_safety", {})
        return (
            "📡 <b>داشبورد عملکرد سیگنال‌ها</b>\n\n"
            f"کل سیگنال‌ها: <b>{signals['total']}</b>\n"
            f"سیگنال فعال: <b>{signals['active']}</b>\n"
            f"سیگنال نهایی‌شده: <b>{signals['final']}</b>\n"
            f"برد محاسبه‌شده: <b>{signals['wins']}</b>\n"
            f"باخت محاسبه‌شده: <b>{signals['losses']}</b>\n"
            f"نرخ برد: <b>{signals['win_rate']:.1f}٪</b>\n"
            f"مجموع سود/زیان ثبت‌شده: <b>{signals['profit_percent_sum']:+.2f}٪</b>\n\n"
            "<b>🛡 کنترل انتشار</b>\n"
            f"تأیید مالک: <b>{'فعال' if safety.get('owner_approval') else 'غیرفعال'}</b> | "
            f"در انتظار: <b>{int(safety.get('pending_approvals', 0))}</b>\n"
            f"سقف ریسک: <b>{float(safety.get('max_risk_percent', 0) or 0):g}٪</b> | "
            "R/R اجباری: <b>غیرفعال</b>\n"
            f"ریسک باز کل: <b>{float(snapshot.get('exposure', {}).get('total_open_risk', 0) or 0):.2f}٪</b> | "
            f"سیگنال باز: <b>{int(snapshot.get('exposure', {}).get('open_count', 0) or 0)}</b>\n\n"
            "ℹ️ نرخ برد فقط از سیگنال‌هایی محاسبه می‌شود که نتیجه قابل تشخیص دارند."
        )

    if page == "system":
        storage = snapshot.get("storage", {})
        storage_label = {
            "postgresql": "PostgreSQL پایدار",
            "sqlite-volume": "SQLite روی Volume",
            "sqlite-ephemeral": "SQLite موقت",
        }.get(str(storage.get("backend") or ""), str(storage.get("backend") or "نامشخص"))
        return (
            "⚙️ <b>داشبورد سلامت سیستم</b>\n\n"
            f"نسخه ساختار دیتابیس: <b>{system['database_schema']}</b>\n"
            f"ذخیره‌سازی: <b>{esc(storage_label)}</b> | "
            f"وضعیت: <b>{'پایدار' if storage.get('persistent') else 'ناپایدار'}</b>\n"
            f"ادمین محدود فعال: <b>{system['delegated_admins']}</b>\n"
            f"فعالیت ادمین در ۲۴ ساعت: <b>{system['admin_logs_24h']}</b>\n"
            f"آخرین فعالیت مدیریتی: <b>{display_dt(system.get('latest_admin_activity_at'))}</b>\n"
            f"آخرین ارسال همگانی: <b>{display_dt(engagement.get('latest_broadcast_at'))}</b>\n\n"
            f"درس‌ها: <b>{sales['lessons_total']}</b> | پولی: <b>{sales['paid_lessons']}</b>\n"
            f"کد تخفیف فعال: <b>{snapshot['discounts']['active']}</b>\n"
            f"بکاپ موجود: <b>{snapshot['backups']['count']}</b>\n"
            f"آخرین بکاپ: <b>{display_dt(snapshot['backups'].get('latest_at'))}</b>\n"
            f"قابلیت متصل: <b>{int(snapshot.get('capabilities', {}).get('connected', 0) or 0)}</b> | "
            f"آزمایشی/نیازمند تنظیم: <b>{int(snapshot.get('capabilities', {}).get('experimental', 0) or 0) + int(snapshot.get('capabilities', {}).get('configuration_required', 0) or 0)}</b>"
        )

    return (
        "📊 <b>داشبورد مدیریت واقعی</b>\n"
        f"آخرین بروزرسانی: <b>{display_dt(snapshot.get('generated_at'))}</b>\n\n"
        "<b>💰 وضعیت مالی</b>\n"
        f"درآمد امروز: <b>{sales['total']['today']:,} تومان</b>\n"
        f"درآمد ۳۰ روز: <b>{sales['total']['days_30']:,} تومان</b>\n"
        f"پرداخت معلق: <b>{vip['pending_orders'] + sales['pending_education']}</b>\n\n"
        "<b>👥 کاربران و VIP</b>\n"
        f"کل کاربران: <b>{users['total']:,}</b> | جدید امروز: <b>{users['new_today']}</b>\n"
        f"فعال ۲۴ ساعت: <b>{users['active_24h']}</b> | فعال ۷ روز: <b>{users['active_7d']}</b>\n"
        f"VIP فعال: <b>{vip['active']}</b> | رو به انقضا: <b>{vip['expiring_7d']}</b>\n"
        f"نرخ تبدیل VIP: <b>{users['conversion_rate']:.1f}٪</b>\n\n"
        "<b>🚨 مرکز اقدام</b>\n"
        f"تیکت باز: <b>{support['open']}</b> | معوق بالای ۲۴ ساعت: <b>{support['stale_24h']}</b>\n"
        f"درخواست جایزه: <b>{support['pending_rewards']}</b>\n"
        "<b>📡 عملکرد سیگنال</b>\n"
        f"فعال: <b>{signals['active']}</b> | نهایی: <b>{signals['final']}</b> | نرخ برد: <b>{signals['win_rate']:.1f}٪</b>"
    )



__feature_exports__ = ('admin_permission_set', 'user_activity_guard', 'banned_guard', '_user_has_required_membership', '_force_join_prompt', 'force_join_guard', 'force_join_check', 'a_users', 'a_crm', 'crm_dashboard_view', 'crm_automation_log_view', 'crm_user_timeline', 'crm_assign_self_handler', 'crm_assign_menu', 'crm_assign_handler', 'crm_custom_field_menu', 'crm_custom_field_start', 'crm_custom_field_input', 'a_portfolio', '_portfolio_user_text', '_portfolio_user_rows', 'portfolio_user_search_start', 'portfolio_user_search_input', 'portfolio_user_view', 'portfolio_watchlist_remove', 'portfolio_watchlist_clear', 'portfolio_journal_delete', 'portfolio_journal_export', 'portfolio_note_start', 'portfolio_note_input', 'portfolio_result_start', 'portfolio_result_input', '_admin_user_profile_text', 'admin_user_search', 'admin_user_points_start', 'admin_user_points_input', 'admin_user_ban_start', 'admin_user_ban_reason', 'admin_user_unban', 'admin_private_add_start', 'admin_private_add_days', 'admin_private_remove', '_broadcast_body_and_options', '_broadcast_payloads_from_message', '_broadcast_markup', '_send_broadcast_content', 'a_broadcast', 'broadcast_segment', 'broadcast_message', 'broadcast_queue_panel', 'broadcast_job_control', 'broadcast_queue_job', 'a_export_csv', '_send_export_document', 'admin_export_full', 'admin_export_users', 'admin_export_activity', 'admin_export_points', 'admin_export_transactions', '_feature_group_rows', 'feature_management_view', 'feature_group_view', 'feature_toggle_handler', 'rules_admin_view', 'rules_edit_start', 'rules_input', 'rules_toggle_handler', 'rules_preview_handler', '_delegated_admin_text', '_delegated_admin_rows', '_delegated_admin_group_rows', '_delegated_admin_self_edit_error', 'a_admins', 'admin_add_start', 'admin_add_id_input', 'admin_manage', 'admin_permission_toggle', 'admin_permission_group', 'admin_role_preset_handler', 'admin_permissions_all', 'admin_remove', 'admin_home', 'admin_ui_mode_handler', 'admin_navigation', 'a_pending', 'pending_detail', '_dashboard_rows', '_dashboard_text')
