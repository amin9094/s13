"""Integrated review tools inside existing module cards; no new top-level menu."""
from __future__ import annotations
from datetime import datetime
from zoneinfo import ZoneInfo

from bot_runtime.navigation import edit,reply,require_admin
from bot_runtime.shared import ConversationHandler,CallbackQueryHandler,MessageHandler,CommandHandler,filters,InlineKeyboardButton
from core.async_db import async_snapshot,async_with_db
from core.utils import esc,utc_iso
from modules.admin_access import PERMISSION_CONTEST_RESULT_MANAGE,PERMISSION_CONTEST_PUBLISH,PERMISSION_EDUCATION_EDIT
from modules.admin_access import PERMISSION_CRM_VIEW

INPUT='REVIEW45_INPUT'
KIND={'p':'price','c':'chart','k':'candle','n':'news_direction'}
FIELD={'ref':'reference_name','time':'observation_at','tick':'price_tick','limit':'max_participants','group':'eligible_group','ties':'tie_handling','prize':'prize_by_rank','solution':'solution'}
PROMPTS={'ref':'نام مرجع نتیجه را بنویسید؛ مثلاً نام منبع و نوع قیمت.',
         'time':'زمان مشاهدهٔ نتیجه را به وقت تهران وارد کنید: 2026-10-20 18:30',
         'tick':'کوچک‌ترین گام مجاز قیمت را وارد کنید؛ مثلاً 0.01',
         'limit':'سقف شرکت‌کننده را وارد کنید؛ صفر یعنی بدون سقف.',
         'group':'گروه شرکت: همه، اشتراک، بدون اشتراک، معرفی، یا فهرست آیدی‌ها با ویرگول.',
         'ties':'قانون تساوی را بنویسید: مشترک یا زودتر',
         'prize':'هر خط: رتبه، امتیاز، روز اشتراک، درصد کوپن\nمثال: 1، 10، 2، 0\nحداکثر سه رتبه؛ درصد کوپن ۰، ۱۰، ۲۰، ۳۰، ۴۰ یا ۵۰.',
         'solution':'توضیح آموزشی نتیجه را بنویسید؛ پاسخ‌ها و جایزهٔ ثبت‌شده تغییر نمی‌کنند.'}


async def show_contest_proposal(update,context,kind,value,*,expected_id=None):
    from modules.contest_policy import propose_result
    proposal=await async_with_db(lambda db:propose_result(db,update.effective_user.id,kind,value,expected_id=expected_id))
    lines=['🔎 نتیجهٔ موقت؛ هنوز جایزه پرداخت نشده',f"مسابقه: {esc(proposal['contest_id'])}",f"نتیجه: {esc(proposal['value'])}"]
    lines += [f"رتبه {r['rank']} · کاربر {esc(r['uid'])} · اختلاف {esc(r['difference'])}" for r in proposal['preview'][:10]]
    rows=[[InlineKeyboardButton('✅ تأیید نتیجه و پرداخت جایزه',callback_data='up:final:'+proposal['id'])],
          [InlineKeyboardButton('بازگشت بدون نهایی‌سازی',callback_data='a_contest')]]
    if update.callback_query:await edit(update.callback_query,'\n'.join(lines),rows)
    else:await reply(update,'\n'.join(lines),rows)
    return ConversationHandler.END


async def _contest_card(update,context,short):
    from modules.contest_policy import latest,health
    db=await async_snapshot();kind=KIND[short];contest=latest(db,kind)
    if not contest:
        await edit(update.callback_query,'مسابقه‌ای ثبت نشده است.',[[InlineKeyboardButton('بازگشت',callback_data='a_contest')]])
        return ConversationHandler.END
    stats=health(db,kind);cid=contest['id']
    lines=['🏆 تنظیمات و سلامت مسابقه',f"شناسه: {esc(cid)}",f"وضعیت: {esc(contest['status'])}",
           f"پاسخ‌ها: {len(contest.get('participants',contest.get('answers',{})))}",
           f"مرجع: {esc(contest.get('reference_name','ثبت دستی ادمین'))}",
           f"قانون تساوی: {'زودتر' if contest.get('tie_handling')=='earliest' else 'مشترک'}",
           f"پاسخ‌های ردشده: {sum(stats.get('rejected_answers',{}).values())}",
           f"خطاهای نهایی‌سازی: {stats.get('finalization_failures',0)}",
           f"اجزای جایزهٔ ثبت‌شده: {stats.get('delivered_prize_components',0)} · برندگان جایزه: {stats.get('awarded_users',0)}",
           'پس از اولین پاسخ، قوانین ورود و جوایز قفل می‌شوند.']
    rows=[]
    fields=('ref','time','tick','limit','group','ties','prize') if contest.get('status')=='active' else ('solution',) if contest.get('status')=='closed' else ()
    labels={'ref':'مرجع نتیجه','time':'زمان نتیجه','tick':'گام قیمت','limit':'سقف شرکت','group':'گروه مجاز','ties':'تساوی','prize':'جوایز رتبه‌ها','solution':'توضیح آموزشی'}
    for field in fields:rows.append([InlineKeyboardButton('✏️ '+labels[field],callback_data=f'up:field:{short}:{cid}:{field}')])
    if contest.get('status')=='closed':rows.append([InlineKeyboardButton('📚 ساخت پیش‌نویس درس از نتیجه',callback_data=f'up:lesson:{short}:{cid}')])
    rows.append([InlineKeyboardButton('بازگشت',callback_data='a_contest')])
    await edit(update.callback_query,'\n'.join(lines),rows)
    return ConversationHandler.END


async def callback(update,context):
    q=update.callback_query;parts=q.data.split(':');op=parts[1]
    if op in {'learn','topic','quiz','qa'}:
        return await learning_callback(update,context,parts)
    permission=PERMISSION_CRM_VIEW if op in {'case','claim','follows'} else PERMISSION_EDUCATION_EDIT if op=='learncfg' else PERMISSION_CONTEST_PUBLISH if op=='field' and parts[-1]!='solution' else PERMISSION_CONTEST_RESULT_MANAGE
    if not await require_admin(update,permission):return ConversationHandler.END
    await q.answer()
    try:
        if op=='follows':
            from modules.crm_case import followups
            cursor=''
            if len(parts)>3:
                saved=context.user_data.get('review45_followup_cursors',{}).get(parts[3])
                if not saved or saved['mode']!=parts[2]:raise ValueError('صفحه منقضی شده؛ دوباره باز کنید')
                cursor=saved['after']
            data=followups(await async_snapshot(),parts[2],after=cursor)
            rows=[[InlineKeyboardButton(item['user_id']+' · '+str(item['at'])[:16],callback_data='crm_open:'+item['user_id'])] for item in data['items']]
            if data['next_after']:
                from uuid import uuid4
                token=uuid4().hex[:10];saved=context.user_data.setdefault('review45_followup_cursors',{})
                if len(saved)>30:saved.clear()
                saved[token]={'mode':parts[2],'after':data['next_after']}
                rows.append([InlineKeyboardButton('صفحهٔ بعد',callback_data=f'up:follows:{parts[2]}:{token}')])
            await edit(q,f"پیگیری‌ها: {data['total']}\nنمایش تا ۴۰ مورد در این صفحه.",rows+[[InlineKeyboardButton('CRM',callback_data='crm_dashboard')]])
            return ConversationHandler.END
        if op=='claim':
            from modules.crm_case import claim_case
            await async_with_db(lambda db:claim_case(db,q.from_user.id,parts[2],int(parts[3])))
            op='case'
        if op=='case':
            from modules.crm_case import case_summary
            data=await async_with_db(lambda db:case_summary(db,parts[2]));profile=data['profile']
            lines=['🗂 پروندهٔ یکپارچهٔ کاربر '+esc(data['user_id']),
                   'مسئول: '+esc(profile.get('assigned_admin') or 'تعیین نشده'),
                   'مرحله: '+esc(profile.get('stage_label','')),
                   'دلیل: '+esc('دستی' if profile.get('stage_reason',{}).get('manual') else 'رفتار و خرید ثبت‌شده'),
                   f"آخرین فعالیت: {profile.get('recency_days')} روز" if profile.get('recency_known') else 'آخرین فعالیت: ثبت نشده']
            reason=profile.get('stage_reason',{})
            lines.append(f"مبنای دسته‌بندی: {reason.get('approved_purchases',0)} خرید تأییدشده · {reason.get('recorded_actions',0)} اقدام ثبت‌شده")
            rows=[]
            for section in data['sections'].values():
                lines.append(section['label']+': '+str(section['total']))
                for item in section['items']:
                    rows.append([InlineKeyboardButton(section['label']+' · '+item['id']+' · '+str(item['status']),callback_data=item['callback'])])
            for item in data['education']:
                lines.append('آموزش: '+esc(item['title'])+(' · قبول' if item['passed'] else ' · مطالعه‌شده' if item['studied'] else ' · در مسیر'))
            for item in data['contests']:lines.append('مسابقه: '+esc(item['id'])+' · '+esc(item['status']))
            for item in data['contacts']:lines.append('تماس: '+esc(item['kind'])+' · '+esc(item['status']))
            rows += [[InlineKeyboardButton('پذیرش مسئولیت پرونده',callback_data=f"up:claim:{data['user_id']}:{profile.get('owner_revision',1)}")],
                     [InlineKeyboardButton('بازگشت به همان کاربر',callback_data='crm_open:'+data['user_id'])]]
            await edit(q,'\n'.join(lines)[:3900],rows)
            return ConversationHandler.END
        if op=='learncfg':
            from modules.education import find_lesson
            lesson=find_lesson(await async_snapshot(),parts[2])
            if not lesson:raise ValueError('درس پیدا نشد')
            context.user_data['review45_form']={'kind':'learning','id':parts[2],'field':parts[3],'revision':lesson['content_revision']}
            prompt='آیدی پیش‌نیازها را با ویرگول بفرستید؛ صفر یعنی بدون پیش‌نیاز.' if parts[3]=='prereq' else 'هر خط یک سؤال:\nسؤال | گزینه اول | گزینه دوم | شماره گزینه درست\nمثال: استاپ چیست؟ | حد سود | حد ضرر | 2\nشماره از ۱ شروع می‌شود؛ صفر یعنی حذف آزمون.'
            await edit(q,prompt,[[InlineKeyboardButton('بازگشت بدون ذخیره',callback_data='lesson_manage:'+parts[2])]])
            return INPUT
        if op=='c':return await _contest_card(update,context,parts[2])
        if op=='final':
            from modules.contest_policy import finalize_result
            try:
                row=await async_with_db(lambda db:finalize_result(db,q.from_user.id,parts[2]))
            except (ValueError,PermissionError):
                def failure(db):
                    from modules.contest_policy import current
                    p=db.get('contest_result_proposals',{}).get(parts[2],{})
                    contest=current(db,p.get('kind'))
                    if contest and contest['id']==p.get('contest_id'):
                        health=contest.setdefault('health_counters',{})
                        health['finalization_failures']=health.get('finalization_failures',0)+1
                await async_with_db(failure)
                raise
            await edit(q,'✅ نتیجه نهایی شد؛ جوایز در حساب کاربران ثبت و اعلان‌ها وارد صف شدند.',[[InlineKeyboardButton('مسابقات',callback_data='a_contest')]])
            return ConversationHandler.END
        if op=='lesson':
            from modules.contest_policy import solution_lesson
            lesson=await async_with_db(lambda db:solution_lesson(db,q.from_user.id,KIND[parts[2]],parts[3]))
            await edit(q,'📚 پیش‌نویس درس ساخته شد؛ انتشار جداگانه است.',[[InlineKeyboardButton('بررسی درس',callback_data=f"lesson_manage:{lesson['id']}")]])
            return ConversationHandler.END
        if op=='field':
            from modules.contest_policy import latest
            contest=latest(await async_snapshot(),KIND[parts[2]])
            if not contest or contest['id']!=parts[3]:raise ValueError('مسابقه تغییر کرده است')
            context.user_data['review45_form']={'kind':KIND[parts[2]],'short':parts[2],'id':parts[3],
                 'field':parts[4],'revision':int(contest.get('rules_revision',1))}
            await edit(q,PROMPTS[parts[4]],[[InlineKeyboardButton('بازگشت بدون ذخیره',callback_data='up:c:'+parts[2])]])
            return INPUT
    except (ValueError,KeyError,PermissionError) as exc:
        await edit(q,'❌ '+esc(str(exc)),[[InlineKeyboardButton('مسابقات',callback_data='a_contest')]])
    return ConversationHandler.END


async def input_value(update,context):
    form=context.user_data.get('review45_form')
    if not form:return ConversationHandler.END
    permission=PERMISSION_EDUCATION_EDIT if form['kind']=='learning' else PERMISSION_CONTEST_RESULT_MANAGE if form['field']=='solution' else PERMISSION_CONTEST_PUBLISH
    if not await require_admin(update,permission):return ConversationHandler.END
    text=str(update.effective_message.text or '').strip().translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩','01234567890123456789'))
    try:
        field=form['field'];value=text;extra={}
        if form['kind']=='learning':
            def save(db):
                from modules.education import find_lesson,update_lesson
                lesson=find_lesson(db,form['id'])
                if not lesson or lesson['content_revision']!=form['revision']:raise ValueError('درس تغییر کرده؛ دوباره باز کنید')
                if field=='prereq':
                    value=[] if text=='0' else [p.strip() for p in text.replace('،',',').split(',')]
                    return update_lesson(db,form['id'],prerequisite_ids=value)
                quiz=[]
                if text!='0':
                    for line in text.splitlines():
                        parts=[p.strip() for p in line.split('|')]
                        if len(parts)<4:raise ValueError('متن سؤال، دست‌کم دو گزینه و شمارهٔ پاسخ لازم است')
                        quiz.append({'question':parts[0],'options':parts[1:-1],'correct':int(parts[-1])-1})
                return update_lesson(db,form['id'],quiz=quiz)
            await async_with_db(save)
            context.user_data.pop('review45_form',None)
            await reply(update,'✅ تنظیمات آموزشی ذخیره شد.',[[InlineKeyboardButton('بازگشت به درس',callback_data='lesson_manage:'+form['id'])]])
            return ConversationHandler.END
        if field=='solution':
            from modules.contest_policy import solution_lesson
            await async_with_db(lambda db:solution_lesson(db,update.effective_user.id,form['kind'],form['id'],text))
        else:
            if field=='limit':value=int(text)
            elif field=='time':value=utc_iso(datetime.strptime(text,'%Y-%m-%d %H:%M').replace(tzinfo=ZoneInfo('Asia/Tehran')))
            elif field=='group':
                value={'همه':'everyone','اشتراک':'vip','بدون اشتراک':'nonvip','معرفی':'referral'}.get(text,'selected')
                if value=='selected':
                    ids=[part.strip() for part in text.replace('،',',').split(',')]
                    if not ids or not all(uid.isdigit() for uid in ids):raise ValueError('فهرست آیدی‌ها نامعتبر است')
                    extra={'allowed_user_ids':ids}
            elif field=='ties':
                if text not in {'مشترک','زودتر'}:raise ValueError('مشترک یا زودتر را بنویسید')
                value='shared' if text=='مشترک' else 'earliest'
            elif field=='prize':
                value={}
                for line in text.splitlines():
                    rank,points,days,coupon=[int(p.strip()) for p in line.replace('،',',').split(',')]
                    value[str(rank)]={'points':points,'vip_days':days,'coupon_percent':coupon}
            from modules.contest_policy import update_policy
            await async_with_db(lambda db:update_policy(db,update.effective_user.id,form['kind'],{FIELD[field]:value,**extra},
                                  expected_id=form['id'],expected_revision=form['revision']))
        context.user_data.pop('review45_form',None)
        await reply(update,'✅ ذخیره شد.',[[InlineKeyboardButton('بازگشت به همان مسابقه',callback_data='up:c:'+form['short'])]])
        return ConversationHandler.END
    except (ValueError,PermissionError) as exc:
        back='lesson_manage:'+form['id'] if form['kind']=='learning' else 'up:c:'+form['short']
        await reply(update,'❌ '+esc(str(exc)),[[InlineKeyboardButton('بازگشت بدون ذخیره',callback_data=back)]])
        return INPUT


async def learning_callback(update,context,parts):
    q=update.callback_query;uid=q.from_user.id;op=parts[1]
    await q.answer()
    try:
        from modules.learning_path import recommendations,lesson_for_user,require_access,assess
        db=await async_snapshot()
        from modules.admin_control_center import is_module_enabled
        if not is_module_enabled(db,'edu'):raise ValueError('این بخش در دسترس نیست')
        if op in {'learn','topic'}:
            if op=='topic':
                topic={'risk':'ریسک','structure':'ساختار','fvg':'FVG'}[parts[2]]
                def select(current):
                    topics=current.setdefault('education_learning_state',{}).setdefault(str(uid),{}).setdefault('topics',[])
                    if topic in topics:topics.remove(topic)
                    else:topics.append(topic)
                await async_with_db(select);db=await async_snapshot()
            data=recommendations(db,uid)
            rows=[]
            if data['last_lesson_id']:rows.append([InlineKeyboardButton('▶️ ادامهٔ آخرین درس',callback_data='lesson:'+data['last_lesson_id'])])
            for item in data['items']:rows.append([InlineKeyboardButton('📖 '+item['title'][:45],callback_data=f"lesson:{item['lesson_id']}")])
            rows += [[InlineKeyboardButton(('✅ ' if topic in data['topics'] else '▫️ ')+topic,callback_data='up:topic:'+key)] for key,topic in [('risk','ریسک'),('structure','ساختار'),('fvg','FVG')]]
            rows.append([InlineKeyboardButton('آموزش',callback_data='u_edu')])
            text='📚 مسیر یادگیری شما\nموضوع‌های دلخواه را انتخاب کنید. پیشنهادها از انتخاب شما و اقدام‌های ثبت‌شده می‌آیند.'
            for item in data['items'][:5]:text+='\n'+esc(item['title']+' — '+item['reason'])
            await edit(q,text,rows);return ConversationHandler.END
        if op=='quiz':
            from uuid import uuid4
            lesson=lesson_for_user(db,uid,parts[2]);require_access(db,uid,lesson)
            if not all(db.get('education_progress',{}).get(str(uid),{}).get(str(k),{}).get('passed') for k in lesson.get('prerequisite_ids',[])):
                raise ValueError('ابتدا پیش‌نیازها را با موفقیت بگذرانید')
            context.user_data['review45_quiz']={'lesson_id':str(parts[2]),'revision':lesson['content_revision'],'nonce':uuid4().hex[:12],'answers':[]}
        session=context.user_data.get('review45_quiz')
        if not session:raise ValueError('آزمون منقضی شده؛ دوباره شروع کنید')
        lesson=lesson_for_user(db,uid,session['lesson_id']);require_access(db,uid,lesson)
        if lesson['content_revision']!=session['revision']:raise ValueError('نسخهٔ درس تغییر کرده است')
        if op=='qa':
            if parts[2]!=session['nonce'] or int(parts[3])!=len(session['answers']):raise ValueError('این دکمه مربوط به سؤال فعلی نیست')
            choice=int(parts[4]);question=lesson['quiz'][len(session['answers'])]
            if not 0<=choice<len(question['options']):raise ValueError('پاسخ نامعتبر است')
            session['answers'].append(choice)
        index=len(session['answers']);quiz=lesson.get('quiz',[])
        if index>=len(quiz):
            result=await async_with_db(lambda current:assess(current,uid,session['lesson_id'],list(session['answers'])))
            context.user_data.pop('review45_quiz',None)
            await edit(q,f"{'✅ قبولی ثبت شد' if result['passed'] else 'برای قبولی همهٔ پاسخ‌ها باید درست باشند'}\nامتیاز: {result['score']:.0f}٪",
                       [[InlineKeyboardButton('بازگشت به درس',callback_data='lesson:'+session['lesson_id'])]])
        else:
            question=quiz[index]
            rows=[[InlineKeyboardButton(text[:60],callback_data=f"up:qa:{session['nonce']}:{index}:{n}")] for n,text in enumerate(question['options'])]
            rows.append([InlineKeyboardButton('بازگشت به درس',callback_data='lesson:'+session['lesson_id'])])
            await edit(q,f"سؤال {index+1} از {len(quiz)}\n"+esc(question['question']),rows)
    except (ValueError,KeyError,IndexError) as exc:
        await edit(q,'❌ '+esc(str(exc)),[[InlineKeyboardButton('آموزش',callback_data='u_edu')]])
    return ConversationHandler.END


def conversation():
    return ConversationHandler(entry_points=[CallbackQueryHandler(callback,pattern=r'^up:')],
        states={INPUT:[MessageHandler(filters.TEXT & ~filters.COMMAND,input_value)]},
        fallbacks=[CallbackQueryHandler(callback,pattern=r'^up:')],allow_reentry=True,
        per_message=False,name='review45_conversation',persistent=True)
