"""Feature-owned Telegram handlers extracted from the v7 runtime: market_data."""

from bot_runtime import shared as _shared
globals().update({name: value for name, value in vars(_shared).items() if not name.startswith('__')})

async def u_price(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    rows = [
        [InlineKeyboardButton("💱 Forex, metals & CFD" if language == "en" else "💱 فارکس، طلا و CFD", callback_data="price_forex", style="primary")],
        [InlineKeyboardButton("🪙 Crypto market" if language == "en" else "🪙 بازار کریپتو", callback_data="crypto_menu")],
        [InlineKeyboardButton("🔎 Search all markets" if language == "en" else "🔎 جستجوی همه بازارها", callback_data="market_search")],
        [InlineKeyboardButton("🇮🇷 Iran market" if language == "en" else "🇮🇷 بازار ایران", callback_data="iran_prices")],
        [
            InlineKeyboardButton("📈 Stocks" if language == "en" else "📈 سهام", callback_data="stock_menu"),
            InlineKeyboardButton("🛢 Energy" if language == "en" else "🛢 نفت و انرژی", callback_data="price_energy"),
        ],
        [
            InlineKeyboardButton("🔔 Price alerts" if language == "en" else "🔔 هشدار قیمت", callback_data="price_alerts"),
            InlineKeyboardButton("🪙 USDT converter" if language == "en" else "🪙 تبدیل تتر", callback_data="usdt_convert"),
        ],
        [InlineKeyboardButton("↩️ Main menu" if language == "en" else "↩️ منوی اصلی", callback_data="home", style="primary")],
    ]
    text = (
        "💹 <b>Market prices</b>\nChoose a market. Quotes use provider consensus when multiple valid sources are available."
        if language == "en"
        else "💹 <b>قیمت‌ها بر اساس بازار</b>\nبازار را انتخاب کنید. در صورت دسترسی، قیمت از اجماع چند منبع معتبر محاسبه می‌شود."
    )
    await edit(query, text, rows)


async def price_forex_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    rows = [
        [InlineKeyboardButton("🥇 XAUUSD", callback_data="price:XAUUSD"), InlineKeyboardButton("🥈 XAGUSD", callback_data="price:XAGUSD")],
        [InlineKeyboardButton("EUR/USD", callback_data="price:EURUSD"), InlineKeyboardButton("GBP/USD", callback_data="price:GBPUSD")],
        [InlineKeyboardButton("USD/JPY", callback_data="price:USDJPY"), InlineKeyboardButton("US100", callback_data="price:US100")],
        [InlineKeyboardButton("🔎 Custom symbol" if language == "en" else "🔎 نماد دلخواه", callback_data="market_search")],
        [InlineKeyboardButton("🔙 Price categories" if language == "en" else "🔙 دسته‌بندی قیمت‌ها", callback_data="u_price")],
    ]
    await edit(
        query,
        "💱 <b>Forex, metals & CFD</b>\nChoose a symbol:" if language == "en" else "💱 <b>فارکس، فلزات و CFD</b>\nیک نماد را انتخاب کنید:",
        rows,
    )


async def price_fetch(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    symbol = query.data.split(":", 1)[1]
    language = (await run_blocking(_language_for_user, query.from_user.id))
    if not (await run_blocking(rate_limit_allow, query.from_user.id, f"price:{symbol}", 3)):
        await query.answer("Please wait a few seconds." if language == "en" else "لطفاً چند ثانیه صبر کنید.", show_alert=False)
        return
    await query.answer("Loading…" if language == "en" else "در حال دریافت…")
    try:
        quote = await fetch_market_quote(symbol, force=True)
        text = _market_quote_text(quote, language)
    except ValueError as exc:
        text = f"❌ {esc(exc)}"
    except Exception:
        logger.exception("Price fetch failed for %s", symbol)
        text = "❌ The quote is unavailable. Try again shortly." if language == "en" else "❌ دریافت قیمت ممکن نشد. کمی بعد دوباره تلاش کنید."
    await edit(
        query,
        text,
        [
            [
                InlineKeyboardButton("🔄 Refresh" if language == "en" else "🔄 تازه‌سازی", callback_data=f"price:{symbol}"),
                InlineKeyboardButton("🔙 Back" if language == "en" else "🔙 بازگشت", callback_data="u_price"),
            ]
        ],
    )


def _market_quote_text(quote: Any, language: str = "fa") -> str:
    language = normalize_language(language)
    decimals = 2 if quote.price >= 100 else 5 if quote.price >= 1 else 8
    if language == "en":
        lines = [
            f"💹 <b>{esc(quote.title)}</b>",
            f"Symbol: <code>{esc(quote.symbol)}</code>",
            "",
            f"💰 Price: <code>{quote.price:,.{decimals}f}</code>",
        ]
        if quote.change_percent is not None:
            icon = "🟢" if quote.change_percent >= 0 else "🔴"
            lines.append(f"📊 Change: {icon} <b>{quote.change_percent:+.2f}%</b>")
        if quote.bid is not None or quote.ask is not None:
            bid = f"{quote.bid:,.{decimals}f}" if quote.bid is not None else "—"
            ask = f"{quote.ask:,.{decimals}f}" if quote.ask is not None else "—"
            lines.append(f"🔻 Bid: <code>{bid}</code> | 🔺 Ask: <code>{ask}</code>")
        lines.extend(
            [
                "",
                f"📡 Sources: <code>{esc(quote.source)}</code>",
                f"🧭 Valid providers: <b>{int(getattr(quote, 'provider_count', 1))}</b> | Dispersion: <b>{float(getattr(quote, 'dispersion_bps', 0)):.1f} bps</b>",
                f"🛡 Confidence: <b>{float(quote.confidence) * 100:.0f}%</b>",
                f"🕒 Updated: <code>{esc(display_dt(quote.updated_at.isoformat()))}</code>",
            ]
        )
        if quote.stale:
            lines.append("⚠️ This is stale or last-known-good data.")
        return "\n".join(lines)
    lines = [
        f"💹 <b>{esc(quote.title)}</b>",
        f"نماد: <code>{esc(quote.symbol)}</code>",
        "",
        f"💰 قیمت: <code>{quote.price:,.{decimals}f}</code>",
    ]
    if quote.change_percent is not None:
        icon = "🟢" if quote.change_percent >= 0 else "🔴"
        lines.append(f"📊 تغییر: {icon} <b>{quote.change_percent:+.2f}%</b>")
    if quote.bid is not None or quote.ask is not None:
        bid = f"{quote.bid:,.{decimals}f}" if quote.bid is not None else "—"
        ask = f"{quote.ask:,.{decimals}f}" if quote.ask is not None else "—"
        lines.append(f"🔻 Bid: <code>{bid}</code> | 🔺 Ask: <code>{ask}</code>")
    if quote.open_price is not None:
        lines.append(f"🔓 بازشدن: <code>{quote.open_price:,.{decimals}f}</code>")
    if quote.high is not None or quote.low is not None:
        high = f"{quote.high:,.{decimals}f}" if quote.high is not None else "—"
        low = f"{quote.low:,.{decimals}f}" if quote.low is not None else "—"
        lines.append(f"⬆️ سقف: <code>{high}</code> | ⬇️ کف: <code>{low}</code>")
    lines.extend(
        [
            "",
            f"📡 منابع: <code>{esc(quote.source)}</code>",
            f"🧭 منبع معتبر: <b>{int(getattr(quote, 'provider_count', 1))}</b> | پراکندگی: <b>{float(getattr(quote, 'dispersion_bps', 0)):.1f} bps</b>",
            f"🛡 اطمینان: <b>{float(quote.confidence) * 100:.0f}٪</b>",
            f"🕒 بروزرسانی: <code>{esc(display_dt(quote.updated_at.isoformat()))}</code>",
        ]
    )
    if quote.stale:
        lines.append("⚠️ داده کش‌شده یا با تأخیر است.")
    return "\n".join(lines)


async def market_search_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    examples = "XAUUSD، EURUSD، BTCUSD، US100، WTI، AAPL"
    await edit(
        query,
        (
            "🔎 <b>Search all markets</b>\n\nEnter a market symbol. Examples:\n"
            f"<code>{examples}</code>\n\nForex, crypto, indices, metals, energy, commodities and stocks are supported."
            if language == "en"
            else "🔎 <b>جستجوی کامل بازار</b>\n\nنماد بازار را وارد کنید. نمونه‌ها:\n"
            f"<code>{examples}</code>\n\nفارکس، رمزارز، شاخص، فلز، انرژی، کالا و سهام پشتیبانی می‌شوند."
        ),
        [[InlineKeyboardButton("🔙 Market" if language == "en" else "🔙 بازار", callback_data="u_price")]],
    )
    return MARKET_SEARCH_INPUT


async def market_search_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    user_id = update.effective_user.id
    language = (await run_blocking(_language_for_user, user_id))
    if not (await run_blocking(rate_limit_allow, user_id, "market_search", 2)):
        await reply(update, "⏳ Please wait a few seconds." if language == "en" else "⏳ لطفاً چند ثانیه صبر کنید.", back("u_price"))
        return MARKET_SEARCH_INPUT
    raw = update.effective_message.text or ""
    try:
        symbol = normalize_market_symbol(raw)
        quote = await fetch_market_quote(symbol)
    except (ValueError, RuntimeError) as exc:
        await reply(
            update,
            (
                f"❌ {esc(exc)}\n\nTry an English symbol such as <code>EURUSD</code> or <code>BTCUSD</code>."
                if language == "en"
                else f"❌ {esc(exc)}\n\nنماد انگلیسی را امتحان کنید؛ مثل <code>EURUSD</code> یا <code>BTCUSD</code>."
            ),
            [
                [
                    InlineKeyboardButton("🔁 Search again" if language == "en" else "🔁 جستجوی دوباره", callback_data="market_search"),
                    InlineKeyboardButton("🔙 Market" if language == "en" else "🔙 بازار", callback_data="u_price"),
                ]
            ],
        )
        return MARKET_SEARCH_INPUT
    except Exception:
        logger.exception("Generic market search failed for %r", raw)
        await reply(update, "❌ The quote is unavailable." if language == "en" else "❌ دریافت قیمت ممکن نشد.", back("u_price"))
        return ConversationHandler.END
    ALERT_ASSETS.setdefault(quote.symbol, quote.title)
    await reply(
        update,
        _market_quote_text(quote, language),
        [
            [InlineKeyboardButton("🔔 Create alert" if language == "en" else "🔔 ساخت هشدار برای این نماد", callback_data="price_alert_new")],
            [
                InlineKeyboardButton("🔁 Search another" if language == "en" else "🔁 جستجوی نماد دیگر", callback_data="market_search"),
                InlineKeyboardButton("🔙 Market" if language == "en" else "🔙 بازار", callback_data="u_price"),
            ],
        ],
    )
    return ConversationHandler.END


def _format_crypto_price(value: float | None) -> str:
    if value is None:
        return "—"
    if value >= 1_000:
        return f"${value:,.2f}"
    if value >= 1:
        return f"${value:,.4f}"
    if value >= 0.01:
        return f"${value:,.6f}"
    return f"${value:,.10f}".rstrip("0").rstrip(".")


def _format_compact_usd(value: float | None) -> str:
    if value is None:
        return "—"
    for suffix, divisor in (("T", 1_000_000_000_000), ("B", 1_000_000_000), ("M", 1_000_000), ("K", 1_000)):
        if abs(value) >= divisor:
            return f"${value / divisor:,.2f}{suffix}"
    return f"${value:,.2f}"


def _crypto_quote_text(quote: CryptoQuote, language: str = "fa") -> str:
    change = quote.change_24h
    if change is None:
        change_text = "—"
    else:
        icon = "🟢" if change >= 0 else "🔴"
        change_text = f"{icon} <b>{change:+.2f}%</b>"
    rank = f"#{quote.market_cap_rank}" if quote.market_cap_rank else "—"
    return "\n".join(
        (
        [
            f"🪙 <b>{esc(quote.name)} ({esc(quote.symbol)})</b>",
            "",
            f"💵 Price: <code>{esc(_format_crypto_price(quote.price_usd))}</code>",
            f"📊 24h change: {change_text}",
            f"⬆️ 24h high: <code>{esc(_format_crypto_price(quote.high_24h))}</code>",
            f"⬇️ 24h low: <code>{esc(_format_crypto_price(quote.low_24h))}</code>",
            f"💧 24h volume: <code>{esc(_format_compact_usd(quote.volume_24h))}</code>",
            f"🏦 Market cap: <code>{esc(_format_compact_usd(quote.market_cap))}</code>",
            f"🏅 Market rank: <b>{esc(rank)}</b>",
            "",
            f"🕒 Updated: <b>{esc(display_dt(quote.updated_at.isoformat()))}</b>",
            f"📡 Source: <code>{esc(quote.source)}</code>",
            f"🧾 Provider ID: <code>{esc(quote.provider_asset_id or quote.coin_id)}</code>",
            f"💱 Quote currency: <b>{esc(quote.quote_currency)}</b>  •  Identity: <b>{'Verified' if quote.identity_verified else 'Review required'}</b>",
            "<i>Quotes are informational and may differ slightly from your exchange.</i>",
        ]
        if language == "en"
        else [
            f"🪙 <b>{esc(quote.name)} ({esc(quote.symbol)})</b>",
            "",
            f"💵 قیمت: <code>{esc(_format_crypto_price(quote.price_usd))}</code>",
            f"📊 تغییر ۲۴ ساعت: {change_text}",
            f"⬆️ سقف ۲۴ ساعت: <code>{esc(_format_crypto_price(quote.high_24h))}</code>",
            f"⬇️ کف ۲۴ ساعت: <code>{esc(_format_crypto_price(quote.low_24h))}</code>",
            f"💧 حجم ۲۴ ساعت: <code>{esc(_format_compact_usd(quote.volume_24h))}</code>",
            f"🏦 ارزش بازار: <code>{esc(_format_compact_usd(quote.market_cap))}</code>",
            f"🏅 رتبه بازار: <b>{esc(rank)}</b>",
            "",
            f"🕒 به‌روزرسانی: <b>{esc(display_dt(quote.updated_at.isoformat()))}</b>",
            f"📡 منبع: <code>{esc(quote.source)}</code>",
            f"🧾 شناسه منبع: <code>{esc(quote.provider_asset_id or quote.coin_id)}</code>",
            f"💱 ارز مظنه: <b>{esc(quote.quote_currency)}</b>  •  هویت: <b>{'تأییدشده' if quote.identity_verified else 'نیازمند بررسی'}</b>",
            "<i>قیمت‌ها صرفاً اطلاع‌رسانی هستند و ممکن است با صرافی شما اختلاف جزئی داشته باشند.</i>",
        ])
    )


def _remember_crypto_callback(context: ContextTypes.DEFAULT_TYPE, coin_id: str) -> str:
    """Keep Telegram callback payloads short even for long provider identifiers."""
    mapping = context.user_data.setdefault("crypto_callback_ids", {})
    reverse = context.user_data.setdefault("crypto_callback_reverse", {})
    existing = reverse.get(coin_id)
    if existing and mapping.get(existing) == coin_id:
        return str(existing)
    token = uuid.uuid5(uuid.NAMESPACE_URL, f"sentinel:crypto:{coin_id}").hex[:12]
    mapping[token] = coin_id
    reverse[coin_id] = token
    if len(mapping) > 250:
        keep = list(mapping)[-200:]
        context.user_data["crypto_callback_ids"] = {key: mapping[key] for key in keep}
        context.user_data["crypto_callback_reverse"] = {
            value: key for key, value in context.user_data["crypto_callback_ids"].items()
        }
    return token


def _resolve_crypto_callback(context: ContextTypes.DEFAULT_TYPE, value: str) -> str:
    return str(context.user_data.get("crypto_callback_ids", {}).get(value) or value)


def _crypto_quote_rows(
    context: ContextTypes.DEFAULT_TYPE,
    coin_id: str,
    language: str = "fa",
) -> list[list[InlineKeyboardButton]]:
    token = _remember_crypto_callback(context, coin_id)
    return [
        [
            InlineKeyboardButton(
                "⚖️ Compare providers" if language == "en" else "⚖️ مقایسه منابع",
                callback_data=f"crypto_compare:{token}",
            )
        ],
        [
            InlineKeyboardButton("🔄 Refresh" if language == "en" else "🔄 تازه‌سازی", callback_data=f"crypto_refresh:{token}"),
            InlineKeyboardButton("🔍 Search crypto" if language == "en" else "🔍 جستجوی ارز", callback_data="crypto_search"),
        ],
        [InlineKeyboardButton("🪙 Crypto market" if language == "en" else "🪙 ارزهای دیجیتال", callback_data="crypto_menu"), InlineKeyboardButton("🔙 Market" if language == "en" else "🔙 بازار", callback_data="u_price")],
    ]


async def crypto_provider_compare(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    value = str(query.data or "").split(":", 1)[1]
    coin_id = _resolve_crypto_callback(context, value)
    if not (await run_blocking(rate_limit_allow, query.from_user.id, f"crypto_compare:{coin_id}", 3)):
        await query.answer("Please wait a moment." if language == "en" else "چند لحظه صبر کنید.", show_alert=True)
        return
    await query.answer("Comparing providers…" if language == "en" else "در حال مقایسه منابع…")
    try:
        result = await compare_crypto_providers(coin_id)
    except (ValueError, RuntimeError) as exc:
        await edit(
            query,
            (f"❌ Price comparison failed.\n\n{esc(exc)}" if language == "en" else f"❌ مقایسه قیمت ممکن نشد.\n\n{esc(exc)}"),
            _crypto_quote_rows(context, coin_id, language),
        )
        return
    lines = [
        f"⚖️ <b>{'Provider comparison' if language == 'en' else 'مقایسه قیمت'} {esc(result['symbol'])}</b>",
        "",
    ]
    for quote in result["quotes"]:
        lines.append(
            f"• <b>{esc(quote.source)}</b>: "
            f"<code>{esc(_format_crypto_price(quote.price_usd))}</code> "
            f"{esc(quote.quote_currency)}"
        )
    lines.extend(
        [
            "",
            f"{'Maximum provider spread' if language == 'en' else 'اختلاف بیشینه منابع'}: <b>{float(result['spread_percent']):.4f}%</b>",
            f"{'Valid providers' if language == 'en' else 'تعداد منابع معتبر'}: <b>{int(result['provider_count'])}</b>",
            "",
            (
                "<i>USD and USDT are normalized for display. This does not replace your exchange quote.</i>"
                if language == "en"
                else "<i>USDT و USD برای مقایسه نمایشی کنار هم قرار گرفته‌اند؛ این بخش جایگزین قیمت صرافی شما نیست.</i>"
            ),
        ]
    )
    await edit(query, "\n".join(lines), _crypto_quote_rows(context, coin_id, language))


async def crypto_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    popular = popular_crypto_assets()
    rows = [
        [
            InlineKeyboardButton(
                f"{popular[index].symbol}",
                callback_data=f"crypto_coin:{_remember_crypto_callback(context, popular[index].coin_id)}",
            ),
            InlineKeyboardButton(
                f"{popular[index + 1].symbol}",
                callback_data=f"crypto_coin:{_remember_crypto_callback(context, popular[index + 1].coin_id)}",
            ),
        ]
        for index in range(0, min(len(popular), 8), 2)
    ]
    rows.insert(0, [InlineKeyboardButton("🔍 Search name or symbol" if language == "en" else "🔍 جستجوی نام یا نماد ارز", callback_data="crypto_search")])
    rows.insert(1, [InlineKeyboardButton("🏆 Market leaders" if language == "en" else "🏆 برترین ارزهای بازار", callback_data="crypto_top")])
    rows.append([InlineKeyboardButton("🔙 Market prices" if language == "en" else "🔙 بازگشت به قیمت بازار", callback_data="u_price")])
    await edit(
        query,
        (
            "🪙 <b>Crypto price center</b>\n\n"
            "Search any asset name, symbol or provider ID. SENTINEL checks the full CoinGecko catalog and active Binance markets.\n"
            "Examples: <code>Bitcoin</code>, <code>BTC</code> or <code>bitcoin</code>."
            if language == "en"
            else "🪙 <b>مرکز قیمت ارزهای دیجیتال</b>\n\n"
            "نام، نماد یا شناسه هر ارز را جستجو کنید؛ فهرست کامل CoinGecko و بازارهای فعال Binance بررسی می‌شوند.\n"
            "مثال: <code>Bitcoin</code>، <code>BTC</code> یا <code>بیت کوین</code>."
        ),
        rows,
    )


async def crypto_market_leaders_view(
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    if not (await run_blocking(rate_limit_allow, query.from_user.id, "crypto_top", 3)):
        await query.answer("Please wait a few seconds." if language == "en" else "لطفاً چند ثانیه صبر کنید.", show_alert=False)
        return
    force = str(query.data or "").endswith(":refresh")
    await query.answer("Loading market…" if language == "en" else "در حال دریافت بازار…")
    try:
        quotes = await fetch_crypto_market_leaders(limit=12, force=force)
    except Exception:
        logger.exception("Crypto market leaders failed")
        await edit(
            query,
            (
                "❌ The market overview is unavailable. Direct crypto search is still available."
                if language == "en"
                else "❌ دریافت نمای کلی بازار ممکن نشد. جستجوی مستقیم ارز همچنان در دسترس است."
            ),
            [
                [InlineKeyboardButton("🔍 Search crypto" if language == "en" else "🔍 جستجوی ارز", callback_data="crypto_search")],
                [InlineKeyboardButton("🔄 Try again" if language == "en" else "🔄 تلاش دوباره", callback_data="crypto_top:refresh")],
                [InlineKeyboardButton("↩️ Back" if language == "en" else "↩️ بازگشت", callback_data="crypto_menu")],
            ],
        )
        return
    lines = ["🏆 <b>Crypto market leaders</b>" if language == "en" else "🏆 <b>برترین ارزهای بازار</b>", ""]
    rows: list[list[InlineKeyboardButton]] = []
    for quote in quotes:
        change = "—" if quote.change_24h is None else f"{quote.change_24h:+.2f}%"
        lines.append(
            f"<b>#{quote.market_cap_rank or '—'} {esc(quote.symbol)}</b> "
            f"<code>{esc(_format_crypto_price(quote.price_usd))}</code> • {esc(change)}"
        )
        token = _remember_crypto_callback(context, quote.coin_id)
        rows.append(
            [
                InlineKeyboardButton(
                    f"{quote.symbol} • {'Details' if language == 'en' else 'جزئیات'}",
                    callback_data=f"crypto_coin:{token}",
                )
            ]
        )
    rows.extend(
        [
            [InlineKeyboardButton("🔄 Refresh market" if language == "en" else "🔄 تازه‌سازی بازار", callback_data="crypto_top:refresh")],
            [InlineKeyboardButton("🔍 Search all assets" if language == "en" else "🔍 جستجوی همه ارزها", callback_data="crypto_search")],
            [InlineKeyboardButton("↩️ Back" if language == "en" else "↩️ بازگشت", callback_data="crypto_menu")],
        ]
    )
    await edit(query, "\n".join(lines), rows)


async def crypto_search_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    await edit(
        query,
        (
            "🔍 <b>Search all crypto assets</b>\n\n"
            "Send an asset name, symbol or provider ID. Active results are paginated.\n"
            "Examples: <code>ETH</code>, <code>Solana</code> or <code>ethereum</code>."
            if language == "en"
            else "🔍 <b>جستجوی کامل ارز دیجیتال</b>\n\n"
            "نام، نماد یا شناسه ارز را بفرستید. نتایج همه ارزهای فعال صفحه‌بندی می‌شوند.\n"
            "مثال: <code>ETH</code>، <code>Solana</code> یا <code>اتریوم</code>."
        ),
        [[InlineKeyboardButton("🔙 Back" if language == "en" else "🔙 بازگشت", callback_data="crypto_menu")]],
    )
    return CRYPTO_SEARCH_INPUT


def _crypto_search_page_rows(
    context: ContextTypes.DEFAULT_TYPE,
    *,
    page: int,
    page_size: int = 8,
    language: str = "fa",
) -> tuple[list[list[InlineKeyboardButton]], int, int]:
    results = list(context.user_data.get("crypto_search_results") or [])
    total = len(results)
    pages = max(1, (total + page_size - 1) // page_size)
    page = max(0, min(int(page), pages - 1))
    start = page * page_size
    rows: list[list[InlineKeyboardButton]] = []
    for item in results[start : start + page_size]:
        coin_id = str(item.get("coin_id") or "")
        token = _remember_crypto_callback(context, coin_id)
        rank = f" #{item.get('market_cap_rank')}" if item.get("market_cap_rank") else ""
        source = " • BN" if str(item.get("source") or "").lower() == "binance" else ""
        label = f"{item.get('name')} ({item.get('symbol')}){rank}{source}"
        rows.append([InlineKeyboardButton(label[:60], callback_data=f"crypto_pick:{token}")])
    if pages > 1:
        navigation: list[InlineKeyboardButton] = []
        if page > 0:
            navigation.append(InlineKeyboardButton("◀️ Previous" if language == "en" else "◀️ قبلی", callback_data=f"crypto_page:{page - 1}"))
        navigation.append(InlineKeyboardButton(f"{page + 1}/{pages}", callback_data="crypto_page:noop"))
        if page + 1 < pages:
            navigation.append(InlineKeyboardButton("Next ▶️" if language == "en" else "بعدی ▶️", callback_data=f"crypto_page:{page + 1}"))
        rows.append(navigation)
    rows.append(
        [
            InlineKeyboardButton("🔁 Search again" if language == "en" else "🔁 جستجوی دوباره", callback_data="crypto_search"),
            InlineKeyboardButton("🔙 Back" if language == "en" else "🔙 بازگشت", callback_data="crypto_menu"),
        ]
    )
    return rows, page, pages


async def crypto_search_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    user_id = update.effective_user.id
    language = (await run_blocking(_language_for_user, user_id))
    if not (await run_blocking(rate_limit_allow, user_id, "crypto_search", 2)):
        await reply(
            update,
            "⏳ Please wait a few seconds and search again." if language == "en" else "⏳ لطفاً چند ثانیه صبر کنید و دوباره جستجو کنید.",
            [[InlineKeyboardButton("↩️ Back" if language == "en" else "↩️ بازگشت", callback_data="crypto_menu")]],
        )
        return CRYPTO_SEARCH_INPUT
    query_text = update.effective_message.text or ""
    try:
        results = await search_crypto(query_text, limit=40)
    except ValueError as exc:
        await reply(update, f"❌ {esc(exc)}", [[InlineKeyboardButton("🔁 Search again" if language == "en" else "🔁 جستجوی دوباره", callback_data="crypto_search")]])
        return CRYPTO_SEARCH_INPUT
    except Exception:
        logger.exception("Crypto search failed for %r", query_text)
        await reply(
            update,
            "❌ Crypto search is temporarily unavailable." if language == "en" else "❌ سرویس جستجوی ارز دیجیتال موقتاً در دسترس نیست.",
            [[InlineKeyboardButton("↩️ Back" if language == "en" else "↩️ بازگشت", callback_data="crypto_menu")]],
        )
        return ConversationHandler.END

    if not results:
        await reply(
            update,
            (
                "🔎 No result was found. Try an English symbol such as <code>BTC</code> or <code>LINK</code>."
                if language == "en"
                else "🔎 نتیجه‌ای پیدا نشد. نماد انگلیسی ارز را امتحان کنید؛ مانند <code>BTC</code> یا <code>LINK</code>."
            ),
            [
                [
                    InlineKeyboardButton("🔁 Search again" if language == "en" else "🔁 جستجوی دوباره", callback_data="crypto_search"),
                    InlineKeyboardButton("🔙 Back" if language == "en" else "🔙 بازگشت", callback_data="crypto_menu"),
                ]
            ],
        )
        return CRYPTO_SEARCH_INPUT

    context.user_data["crypto_search_query"] = query_text.strip()
    context.user_data["crypto_search_results"] = [
        {
            "coin_id": item.coin_id,
            "name": item.name,
            "symbol": item.symbol,
            "market_cap_rank": item.market_cap_rank,
            "source": item.source,
        }
        for item in results
    ]
    rows, page, pages = _crypto_search_page_rows(context, page=0, language=language)
    await reply(
        update,
        (
            f"🔍 Results for <b>{esc(query_text.strip())}</b>\n"
            f"<b>{len(results)}</b> results • page <b>{page + 1}/{pages}</b>:"
            if language == "en"
            else f"🔍 نتایج برای <b>{esc(query_text.strip())}</b>\n"
            f"<b>{len(results)}</b> نتیجه • صفحه <b>{page + 1}/{pages}</b>:"
        ),
        rows,
    )
    return CRYPTO_SEARCH_INPUT


async def crypto_search_page(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    value = str(query.data).split(":", 1)[1]
    if value == "noop":
        await query.answer()
        return CRYPTO_SEARCH_INPUT
    rows, page, pages = _crypto_search_page_rows(context, page=int(value), language=language)
    search_text = str(context.user_data.get("crypto_search_query") or "")
    await query.answer()
    await edit(
        query,
        (
            f"🔍 Results for <b>{esc(search_text)}</b>\n"
            f"<b>{len(context.user_data.get('crypto_search_results') or [])}</b> results • page <b>{page + 1}/{pages}</b>:"
            if language == "en"
            else f"🔍 نتایج برای <b>{esc(search_text)}</b>\n"
            f"<b>{len(context.user_data.get('crypto_search_results') or [])}</b> نتیجه • صفحه <b>{page + 1}/{pages}</b>:"
        ),
        rows,
    )
    return CRYPTO_SEARCH_INPUT


async def _show_crypto_quote(
    query,
    context: ContextTypes.DEFAULT_TYPE,
    coin_id: str,
    *,
    force: bool = False,
) -> None:
    language = (await run_blocking(_language_for_user, query.from_user.id))
    if not (await run_blocking(rate_limit_allow, query.from_user.id, f"crypto_quote:{coin_id}", 2)):
        await query.answer("Please wait a few seconds." if language == "en" else "لطفاً چند ثانیه صبر کنید.", show_alert=False)
        return
    await query.answer("Loading quote…" if language == "en" else "در حال دریافت قیمت…")
    try:
        quote = await fetch_crypto_quote(coin_id, force=force)
        text = _crypto_quote_text(quote, language)
        rows = _crypto_quote_rows(context, quote.coin_id, language)
    except ValueError as exc:
        text = f"❌ {esc(exc)}"
        rows = [
            [
                InlineKeyboardButton("🔍 Search again" if language == "en" else "🔍 جستجوی دوباره", callback_data="crypto_search"),
                InlineKeyboardButton("🔙 Back" if language == "en" else "🔙 بازگشت", callback_data="crypto_menu"),
            ]
        ]
    except Exception:
        logger.exception("Crypto quote failed for %s", coin_id)
        text = "❌ This crypto quote is unavailable. Try again shortly." if language == "en" else "❌ دریافت قیمت این ارز ممکن نشد. کمی بعد دوباره تلاش کنید."
        rows = [
            [
                InlineKeyboardButton(
                    "🔄 Try again" if language == "en" else "🔄 تلاش دوباره",
                    callback_data=f"crypto_refresh:{_remember_crypto_callback(context, coin_id)}",
                ),
                InlineKeyboardButton("🔙 Back" if language == "en" else "🔙 بازگشت", callback_data="crypto_menu"),
            ]
        ]
    await edit(query, text, rows)


async def crypto_search_pick(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    coin_id = _resolve_crypto_callback(context, query.data.split(":", 1)[1])
    await _show_crypto_quote(query, context, coin_id)
    return ConversationHandler.END


async def crypto_coin_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    coin_id = _resolve_crypto_callback(context, query.data.split(":", 1)[1])
    await _show_crypto_quote(
        query,
        context,
        coin_id,
        force=query.data.startswith("crypto_refresh:"),
    )


def _stock_quote_text(quote: StockQuote, language: str = "fa") -> str:
    language = normalize_language(language)
    change = quote.change_percent
    if change is None:
        change_text = "—"
    else:
        icon = "🟢" if change >= 0 else "🔴"
        change_text = f"{icon} <b>{change:+.2f}%</b>"
    volume = f"{quote.volume:,}" if quote.volume is not None else "—"
    if language == "en":
        return "\n".join(
            [
                f"📈 <b>{esc(quote.symbol)}</b>",
                "",
                f"💵 Price: <code>${quote.price:,.4f}</code>" if quote.price is not None else "💵 Price: —",
                f"📊 Change: {change_text}",
                f"🔓 Open: <code>${quote.open:,.4f}</code>" if quote.open is not None else "🔓 Open: —",
                f"⬆️ High: <code>${quote.high:,.4f}</code>" if quote.high is not None else "⬆️ High: —",
                f"⬇️ Low: <code>${quote.low:,.4f}</code>" if quote.low is not None else "⬇️ Low: —",
                f"⏮ Previous close: <code>${quote.previous_close:,.4f}</code>" if quote.previous_close is not None else "⏮ Previous close: —",
                f"📦 Volume: <code>{volume}</code>",
                f"📅 Latest trading day: <b>{esc(quote.latest_trading_day or '—')}</b>",
                "",
                f"📡 Source: <code>{esc(quote.source)}</code>",
                "<i>Free-tier market data may be delayed.</i>",
            ]
        )
    return "\n".join(
        [
            f"📈 <b>{esc(quote.symbol)}</b>",
            "",
            f"💵 قیمت: <code>${quote.price:,.4f}</code>" if quote.price is not None else "💵 قیمت: —",
            f"📊 تغییر: {change_text}",
            f"🔓 بازشدن: <code>${quote.open:,.4f}</code>" if quote.open is not None else "🔓 بازشدن: —",
            f"⬆️ سقف: <code>${quote.high:,.4f}</code>" if quote.high is not None else "⬆️ سقف: —",
            f"⬇️ کف: <code>${quote.low:,.4f}</code>" if quote.low is not None else "⬇️ کف: —",
            f"⏮ بسته‌شدن قبلی: <code>${quote.previous_close:,.4f}</code>" if quote.previous_close is not None else "⏮ بسته‌شدن قبلی: —",
            f"📦 حجم: <code>{volume}</code>",
            f"📅 آخرین روز معاملاتی: <b>{esc(quote.latest_trading_day or '—')}</b>",
            "",
            f"📡 منبع: <code>{esc(quote.source)}</code>",
            "<i>ممکن است داده پلن رایگان با تأخیر نمایش داده شود.</i>",
        ]
    )


def _stock_quote_rows(symbol: str, language: str = "fa") -> list[list[InlineKeyboardButton]]:
    language = normalize_language(language)
    return [
        [
            InlineKeyboardButton("🔄 Refresh" if language == "en" else "🔄 تازه‌سازی", callback_data=f"stock_refresh:{symbol}"),
            InlineKeyboardButton("🔍 Stock search" if language == "en" else "🔍 جستجوی سهام", callback_data="stock_search"),
        ],
        [
            InlineKeyboardButton("📈 Popular stocks" if language == "en" else "📈 سهام محبوب", callback_data="stock_menu"),
            InlineKeyboardButton("🔙 Markets" if language == "en" else "🔙 بازار", callback_data="u_price"),
        ],
    ]


async def stock_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    popular = popular_stocks()
    rows: list[list[InlineKeyboardButton]] = [[InlineKeyboardButton("🔍 Search company or ticker" if language == "en" else "🔍 جستجوی شرکت یا نماد", callback_data="stock_search")]]
    for index in range(0, len(popular), 2):
        pair = popular[index : index + 2]
        rows.append([InlineKeyboardButton(symbol, callback_data=f"stock_quote:{symbol}") for symbol, _ in pair])
    rows.append([InlineKeyboardButton("🔙 Back to market prices" if language == "en" else "🔙 بازگشت به قیمت بازار", callback_data="u_price")])
    await edit(
        query,
        "📈 <b>Global stock prices</b>\n\nSearch by ticker or company name; for example <code>AAPL</code>, <code>Microsoft</code> or <code>NVIDIA</code>." if language == "en" else "📈 <b>قیمت سهام جهانی</b>\n\nنماد یا نام شرکت را جستجو کنید؛ مثال: <code>AAPL</code>، <code>Microsoft</code> یا <code>NVIDIA</code>.",
        rows,
    )


async def stock_search_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    language = (await run_blocking(_language_for_user, query.from_user.id))
    await edit(
        query,
        "🔍 <b>Stock search</b>\n\nSend a company name or market ticker." if language == "en" else "🔍 <b>جستجوی سهام</b>\n\nنام شرکت یا نماد بورسی را ارسال کنید.",
        [[InlineKeyboardButton("🔙 Back" if language == "en" else "🔙 بازگشت", callback_data="stock_menu")]],
    )
    return STOCK_SEARCH_INPUT


async def stock_search_input(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    user_id = update.effective_user.id
    language = (await run_blocking(_language_for_user, user_id))
    if not (await run_blocking(rate_limit_allow, user_id, "stock_search", 5)):
        await reply(update, "⏳ Please wait a few seconds." if language == "en" else "⏳ لطفاً چند ثانیه صبر کنید.", [[InlineKeyboardButton("🔙 Back" if language == "en" else "🔙 بازگشت", callback_data="stock_menu")]])
        return STOCK_SEARCH_INPUT
    term = update.effective_message.text or ""
    try:
        results = await search_stocks(term, limit=8)
    except (ValueError, RuntimeError) as exc:
        await reply(update, f"❌ {esc(exc)}", [[InlineKeyboardButton("🔁 Search again" if language == "en" else "🔁 جستجوی دوباره", callback_data="stock_search")]])
        return STOCK_SEARCH_INPUT
    except Exception:
        logger.exception("Stock search failed for %r", term)
        await reply(update, "❌ Stock search is temporarily unavailable." if language == "en" else "❌ دریافت نتیجه جستجوی سهام ممکن نشد.", [[InlineKeyboardButton("🔙 Back" if language == "en" else "🔙 بازگشت", callback_data="stock_menu")]])
        return ConversationHandler.END
    if not results:
        await reply(
            update,
            "🔎 No results found. Try the company ticker." if language == "en" else "🔎 نتیجه‌ای پیدا نشد. نماد انگلیسی شرکت را امتحان کنید.",
            [
                [
                    InlineKeyboardButton("🔁 Search again" if language == "en" else "🔁 جستجوی دوباره", callback_data="stock_search"),
                    InlineKeyboardButton("🔙 Back" if language == "en" else "🔙 بازگشت", callback_data="stock_menu"),
                ]
            ],
        )
        return STOCK_SEARCH_INPUT
    rows = []
    for item in results:
        suffix = f" | {item.region}" if item.region else ""
        rows.append([InlineKeyboardButton(f"{item.symbol} — {item.name}{suffix}"[:62], callback_data=f"stock_pick:{item.symbol}")])
    rows.append(
        [
            InlineKeyboardButton("🔁 Search again" if language == "en" else "🔁 جستجوی دوباره", callback_data="stock_search"),
            InlineKeyboardButton("🔙 Back" if language == "en" else "🔙 بازگشت", callback_data="stock_menu"),
        ]
    )
    await reply(update, f"🔍 Results for <b>{esc(term.strip())}</b>:" if language == "en" else f"🔍 نتایج برای <b>{esc(term.strip())}</b>:", rows)
    return STOCK_SEARCH_INPUT


async def _show_stock_quote(query, symbol: str, *, force: bool = False) -> None:
    language = (await run_blocking(_language_for_user, query.from_user.id))
    if not (await run_blocking(rate_limit_allow, query.from_user.id, f"stock_quote:{symbol}", 5)):
        await query.answer("Please wait a few seconds." if language == "en" else "لطفاً چند ثانیه صبر کنید.", show_alert=False)
        return
    await query.answer("Fetching price…" if language == "en" else "در حال دریافت قیمت…")
    try:
        quote = await fetch_stock_quote(symbol, force=force)
        text = _stock_quote_text(quote, language)
        rows = _stock_quote_rows(quote.symbol, language)
    except (ValueError, RuntimeError) as exc:
        text = f"❌ {esc(exc)}"
        rows = [
            [
                InlineKeyboardButton("🔍 Search again" if language == "en" else "🔍 جستجوی دوباره", callback_data="stock_search"),
                InlineKeyboardButton("🔙 Back" if language == "en" else "🔙 بازگشت", callback_data="stock_menu"),
            ]
        ]
    except Exception:
        logger.exception("Stock quote failed for %s", symbol)
        text = "❌ This stock price is temporarily unavailable." if language == "en" else "❌ دریافت قیمت این سهم ممکن نشد."
        rows = [
            [
                InlineKeyboardButton("🔄 Try again" if language == "en" else "🔄 تلاش دوباره", callback_data=f"stock_refresh:{symbol}"),
                InlineKeyboardButton("🔙 Back" if language == "en" else "🔙 بازگشت", callback_data="stock_menu"),
            ]
        ]
    await edit(query, text, rows)


async def stock_search_pick(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    symbol = query.data.split(":", 1)[1]
    await _show_stock_quote(query, symbol)
    return ConversationHandler.END


async def stock_quote_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    symbol = query.data.split(":", 1)[1]
    await _show_stock_quote(query, symbol, force=query.data.startswith("stock_refresh:"))


def _format_iran_quote(icon: str, quote: IranMarketQuote, language: str = "fa") -> str:
    language = normalize_language(language)
    change = ""
    if quote.change_percent is not None:
        arrow = "🟢" if quote.change_percent >= 0 else "🔴"
        change = f"  {arrow} <b>{quote.change_percent:+.2f}%</b>"
    estimate = (" <i>(estimated)</i>" if language == "en" else " <i>(برآوردی)</i>") if quote.estimated else ""
    english_titles = {
        "USD": "Free-market USD",
        "USDT_IRT": "Tether",
        "IR_GOLD_18K": "18K gold",
        "IR_GOLD_24K": "24K gold",
        "IR_GOLD_MESGHAL": "Gold mesghal",
        "IR_COIN_EMAMI": "Emami coin",
        "IR_COIN_BAHAR": "Bahar Azadi coin",
        "IR_COIN_HALF": "Half coin",
        "IR_COIN_QUARTER": "Quarter coin",
        "IR_COIN_GRAMI": "Gram coin",
        "EUR": "Euro",
        "GBP": "British pound",
        "AED": "UAE dirham",
        "TRY": "Turkish lira",
    }
    title = english_titles.get(str(quote.symbol), quote.title) if language == "en" else quote.title
    unit = "IRT" if language == "en" else quote.unit
    return f"{icon} <b>{esc(title)}</b>: <code>{quote.price:,.0f}</code> {esc(unit)}{change}{estimate}"


async def iran_prices(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    if not (await run_blocking(rate_limit_allow, query.from_user.id, "iran_prices", 4)):
        await query.answer("Please wait a few seconds." if language == "en" else "لطفاً چند ثانیه صبر کنید.", show_alert=False)
        return
    await query.answer("Fetching Iranian market prices…" if language == "en" else "در حال دریافت قیمت‌های ایران…")
    force = str(query.data or "") == "iran_prices_refresh"
    try:
        snapshot = await fetch_iran_market_snapshot(force=force)
        updated = display_dt(snapshot.fetched_at)
        icons = {
            "USD": "💵",
            "USDT_IRT": "🪙",
            "IR_GOLD_18K": "🥇",
            "IR_GOLD_24K": "🏅",
            "IR_GOLD_MESGHAL": "⚖️",
            "IR_COIN_EMAMI": "🪙",
            "IR_COIN_BAHAR": "🪙",
            "IR_COIN_HALF": "🪙",
            "IR_COIN_QUARTER": "🪙",
            "IR_COIN_GRAMI": "🪙",
            "EUR": "🇪🇺",
            "GBP": "🇬🇧",
            "AED": "🇦🇪",
            "TRY": "🇹🇷",
        }
        lines = ["🇮🇷 <b>Iranian market prices</b>" if language == "en" else "🇮🇷 <b>قیمت کامل بازار ایران</b>", ""]
        lines.extend(_format_iran_quote(icons.get(item.symbol, "•"), item, language) for item in snapshot.all_quotes)
        lines.extend(
            [
                "",
                f"🕒 Last update: <b>{esc(updated)}</b>" if language == "en" else f"🕒 آخرین به‌روزرسانی: <b>{esc(updated)}</b>",
                f"📡 Source: <code>{esc(' | '.join(snapshot.sources))}</code>" if language == "en" else f"📡 منبع: <code>{esc(' | '.join(snapshot.sources))}</code>",
            ]
        )
        if snapshot.stale:
            lines.append("⚠️ The live provider is unavailable; cached prices are shown." if language == "en" else "⚠️ سرویس زنده موقتاً قطع است؛ آخرین قیمت ذخیره‌شده نمایش داده می‌شود.")
        if snapshot.dollar.estimated or snapshot.gold18.estimated:
            lines.append("ℹ️ Estimated values are calculated from Iranian Tether and global ounce prices." if language == "en" else "ℹ️ موارد برآوردی از قیمت زنده تتر ایران و انس جهانی محاسبه شده‌اند.")
        lines.append("<i>Prices are informational and may differ from executable market quotes.</i>" if language == "en" else "<i>قیمت‌ها صرفاً اطلاع‌رسانی هستند و ممکن است با بازار لحظه‌ای اختلاف داشته باشند.</i>")
        text = "\n".join(lines)
    except Exception:
        logger.exception("Iran market prices failed")
        text = "❌ Iranian USD, Tether and gold prices are temporarily unavailable." if language == "en" else "❌ دریافت قیمت دلار، تتر و طلای ایران ممکن نشد. کمی بعد دوباره تلاش کنید."
    await edit(
        query,
        text,
        [
            [
                InlineKeyboardButton("🔄 Refresh" if language == "en" else "🔄 تازه‌سازی", callback_data="iran_prices_refresh"),
                InlineKeyboardButton("🔙 Back" if language == "en" else "🔙 بازگشت", callback_data="u_price"),
            ]
        ],
    )


async def _market_snapshot_for_display(*, force: bool = False) -> dict[str, Any]:
    previous = await async_with_db(lambda db: latest_snapshot(db))
    try:
        snapshot = await build_market_snapshot(force=force)
        if isinstance(previous, dict) and previous:
            stale_sources: list[str] = []
            for key in ("calendar", "news", "quotes", "fred", "world_bank", "energy", "filings"):
                current = snapshot.get(key)
                old_value = previous.get(key)
                if not current and old_value:
                    snapshot[key] = old_value
                    stale_sources.append(key)
            if stale_sources:
                snapshot["stale_sources"] = stale_sources
                snapshot["outlooks"] = build_outlooks(snapshot)
        await async_with_db(lambda db: save_snapshot(db, snapshot))
        return snapshot
    except Exception:
        logger.exception("Market intelligence collection failed")
        return previous


def _calendar_user_rows(period: str, prefs: dict[str, Any], language: str = "fa") -> list[list[InlineKeyboardButton]]:
    language = normalize_language(language)
    currencies = {str(item).upper() for item in prefs.get("currencies", [])}
    impact_labels = ({"high": "High only", "medium": "High & medium", "low": "All events"} if language == "en" else {"high": "فقط مهم", "medium": "مهم و متوسط", "low": "همه خبرها"})
    rows: list[list[InlineKeyboardButton]] = [
        [
            InlineKeyboardButton("Today" if language == "en" else "امروز", callback_data="u_calendar:today"),
            InlineKeyboardButton("Tomorrow" if language == "en" else "فردا", callback_data="u_calendar:tomorrow"),
            InlineKeyboardButton("7 days" if language == "en" else "۷ روز", callback_data="u_calendar:week"),
        ],
        [
            InlineKeyboardButton(
                f"Impact: {impact_labels.get(str(prefs.get('min_impact') or 'high'), 'High')}" if language == "en" else f"اهمیت: {impact_labels.get(str(prefs.get('min_impact') or 'high'), 'مهم')}",
                callback_data=f"cal_pref_impact:{period}",
            ),
            InlineKeyboardButton(
                f"Reminders: {'On' if prefs.get('enabled', True) else 'Off'}" if language == "en" else f"یادآوری: {'روشن' if prefs.get('enabled', True) else 'خاموش'}",
                callback_data=f"cal_pref_alert:{period}",
            ),
        ],
        [
            InlineKeyboardButton(
                f"Actual result: {'On' if prefs.get('actual_alerts', True) else 'Off'}" if language == "en" else f"نتیجه Actual: {'روشن' if prefs.get('actual_alerts', True) else 'خاموش'}",
                callback_data=f"cal_pref_actual:{period}",
            ),
            InlineKeyboardButton(
                f"{int(prefs.get('reminder_minutes', 30) or 30)} minutes before" if language == "en" else f"{int(prefs.get('reminder_minutes', 30) or 30)} دقیقه قبل",
                callback_data=f"cal_pref_reminder:{period}",
            ),
        ],
        [
            InlineKeyboardButton(
                f"🕒 {prefs.get('timezone') or SETTINGS.timezone}",
                callback_data=f"cal_pref_timezone:{period}",
            )
        ],
    ]
    currency_buttons = [
        InlineKeyboardButton(
            f"{'✅' if code in currencies else '▫️'} {code}",
            callback_data=f"cal_pref_currency:{code}:{period}",
        )
        for code in CALENDAR_CURRENCIES
    ]
    for index in range(0, len(currency_buttons), 3):
        rows.append(currency_buttons[index : index + 3])
    rows.append(
        [
            InlineKeyboardButton("🔄 Refresh" if language == "en" else "🔄 تازه‌سازی", callback_data=f"u_calendar_refresh:{period}"),
            InlineKeyboardButton("↩️ Live market desk" if language == "en" else "↩️ میز بازار زنده", callback_data="home", style="primary"),
        ]
    )
    return rows


async def user_economic_calendar(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    data = str(query.data or "")
    force = data.startswith("u_calendar_refresh:")
    period = data.rsplit(":", 1)[-1] if ":" in data else "today"
    if period not in {"today", "tomorrow", "week"}:
        period = "today"
    if not (await run_blocking(rate_limit_allow, query.from_user.id, "economic_calendar", 5)):
        await query.answer("Please wait a few seconds." if language == "en" else "لطفاً چند ثانیه صبر کنید.")
        return
    await query.answer("Fetching calendar…" if language == "en" else "در حال دریافت تقویم…")
    snapshot = await _market_snapshot_for_display(force=force)
    events = snapshot.get("calendar", []) if isinstance(snapshot, dict) else []
    prefs = await async_with_db(lambda db: user_calendar_preferences(db, query.from_user.id))
    if not isinstance(events, list) or not events:
        await edit(
            query,
            "⚠️ The economic calendar is temporarily unavailable. The latest valid data will appear after connectivity is restored." if language == "en" else "⚠️ تقویم اقتصادی موقتاً در دسترس نیست. آخرین داده معتبر پس از برقراری اتصال نمایش داده می‌شود.",
            _calendar_user_rows(period, prefs, language),
        )
        return
    currencies = {str(item).upper() for item in prefs.get("currencies", [])}
    text = render_user_calendar(
        events,
        period=period,
        min_impact=str(prefs.get("min_impact") or "high"),
        currencies=currencies or None,
        timezone=str(prefs.get("timezone") or SETTINGS.timezone),
        language=language,
    )
    await edit(query, text, _calendar_user_rows(period, prefs, language))


async def calendar_user_preference_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    parts = str(query.data or "").split(":")
    action = parts[0]
    period = parts[-1] if parts[-1] in {"today", "tomorrow", "week"} else "today"
    try:
        if action == "cal_pref_impact":
            prefs = await async_with_db(lambda db: cycle_user_calendar_impact(db, query.from_user.id))
        elif action == "cal_pref_alert":
            prefs = await async_with_db(lambda db: toggle_user_calendar_alerts(db, query.from_user.id))
        elif action == "cal_pref_actual":
            prefs = await async_with_db(lambda db: toggle_user_actual_alerts(db, query.from_user.id))
        elif action == "cal_pref_reminder":
            prefs = await async_with_db(lambda db: cycle_user_calendar_reminder(db, query.from_user.id))
        elif action == "cal_pref_timezone":
            prefs = await async_with_db(lambda db: cycle_user_calendar_timezone(db, query.from_user.id))
        else:
            currency = parts[1] if len(parts) > 2 else ""
            prefs = await async_with_db(lambda db: toggle_user_calendar_currency(db, query.from_user.id, currency))
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await query.answer("Preference saved" if language == "en" else "تنظیم ذخیره شد")
    snapshot = await _market_snapshot_for_display(force=False)
    events = snapshot.get("calendar", []) if isinstance(snapshot, dict) else []
    currencies = {str(item).upper() for item in prefs.get("currencies", [])}
    text = render_user_calendar(
        events if isinstance(events, list) else [],
        period=period,
        min_impact=str(prefs.get("min_impact") or "high"),
        currencies=currencies or None,
        timezone=str(prefs.get("timezone") or SETTINGS.timezone),
        language=language,
    )
    await edit(query, text, _calendar_user_rows(period, prefs, language))


def _calendar_admin_rows(context: ContextTypes.DEFAULT_TYPE) -> list[list[InlineKeyboardButton]]:
    events = context.user_data.get("mi_calendar_events", [])
    selected = set(context.user_data.get("mi_calendar_selected", set()))
    period = str(context.user_data.get("mi_calendar_period") or "today")
    include_analysis = bool(context.user_data.get("mi_calendar_analysis", False))
    rows: list[list[InlineKeyboardButton]] = [
        [
            InlineKeyboardButton("امروز", callback_data="mi_calendar_period:today"),
            InlineKeyboardButton("فردا", callback_data="mi_calendar_period:tomorrow"),
            InlineKeyboardButton("۷ روز", callback_data="mi_calendar_period:week"),
        ]
    ]
    for index, event in enumerate(events[:18]):
        mark = "☑️" if index in selected else "⬜️"
        title = str(event.get("title_fa") or event.get("title") or "خبر")[:28]
        currency = str(event.get("currency") or "")
        rows.append(
            [
                InlineKeyboardButton(f"{mark} {currency} | {title}", callback_data=f"mi_calendar_toggle:{index}"),
                InlineKeyboardButton("جزئیات", callback_data=f"mi_calendar_detail:{index}"),
            ]
        )
    rows.extend(
        [
            [
                state_button(
                    "تحلیل در پیام",
                    bool(include_analysis),
                    callback_data="mi_calendar_analysis_toggle",
                ),
                InlineKeyboardButton("🔄 بروزرسانی", callback_data=f"mi_admin_calendar_refresh:{period}"),
            ],
            [
                InlineKeyboardButton("📢 ارسال عمومی", callback_data="mi_calendar_send:public"),
                InlineKeyboardButton("🔒 ارسال VIP", callback_data="mi_calendar_send:private"),
            ],
            [InlineKeyboardButton("📣 ارسال هر دو", callback_data="mi_calendar_send:both")],
            [InlineKeyboardButton("⚙️ اتوماسیون و یادآوری تقویم", callback_data="mi_calendar_automation")],
            [InlineKeyboardButton("🔙 مرکز اخبار", callback_data="a_market_intel")],
        ]
    )
    return rows


def _calendar_admin_text(context: ContextTypes.DEFAULT_TYPE) -> str:
    events = context.user_data.get("mi_calendar_events", [])
    selected = set(context.user_data.get("mi_calendar_selected", set()))
    period = str(context.user_data.get("mi_calendar_period") or "today")
    labels = {"today": "امروز", "tomorrow": "فردا", "week": "هفت روز آینده"}
    lines = [
        f"🗓 <b>تقویم اقتصادی {labels.get(period, 'امروز')}</b>",
        "",
        f"خبرهای مهم/متوسط: <b>{len(events)}</b>",
        f"انتخاب‌شده برای انتشار: <b>{len(selected)}</b>",
        "",
        "روی هر خبر تیک بزنید؛ جزئیات، Forecast/Previous/Actual و تحلیل اثر فقط در این پنل دیده می‌شود.",
    ]
    return "\n".join(lines)


async def market_admin_calendar(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    data = str(query.data or "")
    force = data.startswith("mi_admin_calendar_refresh:")
    period = data.split(":", 1)[1] if ":" in data else str(context.user_data.get("mi_calendar_period") or "today")
    if period not in {"today", "tomorrow", "week"}:
        period = "today"
    await query.answer("در حال دریافت تقویم…")
    snapshot = await _market_snapshot_for_display(force=force)
    raw_events = snapshot.get("calendar", []) if isinstance(snapshot, dict) else []
    events = filter_economic_events(raw_events if isinstance(raw_events, list) else [], period=period, min_impact="medium")
    context.user_data["mi_calendar_events"] = events[:30]
    context.user_data["mi_calendar_selected"] = set()
    context.user_data["mi_calendar_period"] = period
    context.user_data.setdefault("mi_calendar_analysis", False)
    await edit(query, _calendar_admin_text(context), _calendar_admin_rows(context))


async def market_admin_calendar_period(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await market_admin_calendar(update, context)


async def market_admin_calendar_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    index = int(str(query.data).split(":", 1)[1])
    events = context.user_data.get("mi_calendar_events", [])
    if not isinstance(events, list) or not (0 <= index < len(events)):
        await query.answer("فهرست منقضی شده؛ دوباره بروزرسانی کنید.", show_alert=True)
        return
    selected = set(context.user_data.get("mi_calendar_selected", set()))
    if index in selected:
        selected.remove(index)
    else:
        selected.add(index)
    context.user_data["mi_calendar_selected"] = selected
    await query.answer("انتخاب شد")
    await edit(query, _calendar_admin_text(context), _calendar_admin_rows(context))


async def market_admin_calendar_detail(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    index = int(str(query.data).split(":", 1)[1])
    events = context.user_data.get("mi_calendar_events", [])
    if not isinstance(events, list) or not (0 <= index < len(events)):
        await query.answer("فهرست منقضی شده است.", show_alert=True)
        return
    await query.answer()
    await edit(
        query,
        render_admin_calendar_event(events[index]),
        [
            [
                InlineKeyboardButton(
                    "🔙 فهرست تقویم", callback_data=f"mi_calendar_back:{context.user_data.get('mi_calendar_period', 'today')}"
                )
            ]
        ],
    )


async def market_admin_calendar_analysis_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    context.user_data["mi_calendar_analysis"] = not bool(context.user_data.get("mi_calendar_analysis", False))
    await query.answer("تنظیم شد")
    await edit(query, _calendar_admin_text(context), _calendar_admin_rows(context))


async def market_admin_calendar_send(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    destination = str(query.data).split(":", 1)[1]
    events = context.user_data.get("mi_calendar_events", [])
    selected = sorted(set(context.user_data.get("mi_calendar_selected", set())))
    if not isinstance(events, list) or not selected:
        await query.answer("حداقل یک خبر را انتخاب کنید.", show_alert=True)
        return
    text = render_selected_calendar_events(
        events,
        selected,
        include_analysis=bool(context.user_data.get("mi_calendar_analysis", False)),
    )
    await query.answer("در حال انتشار…")
    message_ids: list[int] = []
    errors: list[str] = []
    for channel_id in _market_explicit_channels(destination):
        try:
            for chunk in chunk_text(text, 3900):
                message = await _telegram_request_with_button_fallback(
                    context.bot.send_message,
                    chat_id=channel_id,
                    text=chunk,
                    parse_mode=ParseMode.HTML,
                    disable_web_page_preview=True,
                )
                message_ids.append(int(message.message_id))
        except TelegramError as exc:
            errors.append(f"{channel_id}:{exc.__class__.__name__}")

    def _record(db: dict[str, Any]) -> None:
        root = ensure_market_intelligence(db)
        rows = root.setdefault("calendar_publications", [])
        rows.append(
            {
                "created_at": datetime.now(UTC).isoformat(),
                "created_by": str(query.from_user.id),
                "destination": destination,
                "event_ids": [str(events[i].get("id") or "") for i in selected if 0 <= i < len(events)],
                "include_analysis": bool(context.user_data.get("mi_calendar_analysis", False)),
                "message_ids": message_ids,
                "errors": errors,
            }
        )
        root["calendar_publications"] = rows[-300:]
        audit(db, query.from_user.id, "economic_calendar_publish", f"{destination}:{len(selected)}")

    await async_with_db(_record)
    if message_ids:
        context.user_data["mi_calendar_selected"] = set()
        warning = f"\n⚠️ خطای بخشی: <code>{esc(', '.join(errors))}</code>" if errors else ""
        await edit(
            query,
            f"✅ {len(selected)} خبر تقویم منتشر شد.{warning}",
            [[InlineKeyboardButton("🔙 مرکز اخبار", callback_data="a_market_intel")]],
        )
    else:
        await edit(
            query, f"❌ انتشار انجام نشد: <code>{esc(', '.join(errors) or 'کانال تنظیم نشده')}</code>", _calendar_admin_rows(context)
        )


def _calendar_automation_text(snapshot: dict[str, Any]) -> str:
    settings = snapshot.get("settings", {})
    notifications = snapshot.get("notifications", {})
    last = snapshot.get("last_auto_publication", {})
    impact_labels = {"high": "فقط مهم", "medium": "مهم و متوسط", "low": "همه"}
    destination_labels = {"public": "عمومی", "private": "VIP", "both": "هر دو"}
    return (
        "⚙️ <b>اتوماسیون تقویم اقتصادی</b>\n\n"
        f"سیستم تقویم: {'✅' if settings.get('enabled') else '❌'}\n"
        f"یادآوری کاربران: {'✅' if settings.get('alerts_enabled') else '❌'}\n"
        f"اعلان نتیجه Actual: {'✅' if settings.get('actual_alerts_enabled') else '❌'}\n"
        f"انتشار خودکار روزانه: {'✅' if settings.get('auto_publish_enabled') else '❌'}\n"
        f"زمان انتشار: <code>{esc(settings.get('auto_publish_time') or '07:30')}</code> ({esc(SETTINGS.timezone)})\n"
        f"مقصد: <b>{destination_labels.get(str(settings.get('auto_publish_destination')), 'عمومی')}</b>\n"
        f"حداقل اهمیت انتشار: <b>{impact_labels.get(str(settings.get('auto_publish_min_impact')), 'فقط مهم')}</b>\n"
        f"ارزهای انتشار: <code>{esc(','.join(settings.get('auto_publish_currencies', [])) or 'همه')}</code>\n\n"
        f"مشترکان یادآوری: <b>{int(snapshot.get('subscribers', 0)):,}</b>\n"
        f"ارسال موفق: <b>{int(notifications.get('sent', 0)):,}</b> | "
        f"ناموفق: <b>{int(notifications.get('failed', 0)):,}</b> | "
        f"در صف: <b>{int(notifications.get('pending', 0)):,}</b>\n"
        f"آخرین انتشار خودکار: <code>{esc(last.get('date') or '-')}</code> / {esc(last.get('status') or '-')}"
    )


def _calendar_automation_rows(settings: dict[str, Any]) -> list[list[InlineKeyboardButton]]:
    return [
        [
            state_button("تقویم اقتصادی", bool(settings.get("enabled")), callback_data="cal_admin_toggle:enabled"),
            state_button("یادآوری خبر", bool(settings.get("alerts_enabled")), callback_data="cal_admin_toggle:alerts_enabled"),
        ],
        [
            state_button("اعلان Actual", bool(settings.get("actual_alerts_enabled")), callback_data="cal_admin_toggle:actual_alerts_enabled"),
            state_button("انتشار خودکار", bool(settings.get("auto_publish_enabled")), callback_data="cal_admin_toggle:auto_publish_enabled"),
        ],
        [
            InlineKeyboardButton("🕒 تغییر ساعت", callback_data="cal_admin_cycle:time"),
            InlineKeyboardButton("📣 تغییر مقصد", callback_data="cal_admin_cycle:destination"),
        ],
        [
            InlineKeyboardButton("🔴 تغییر اهمیت", callback_data="cal_admin_cycle:impact"),
            InlineKeyboardButton("💱 تغییر ارزها", callback_data="cal_admin_cycle:currencies"),
        ],
        [InlineKeyboardButton("▶️ اجرای بررسی اکنون", callback_data="cal_admin_run_now")],
        [InlineKeyboardButton("🔙 تقویم اقتصادی", callback_data="mi_admin_calendar")],
    ]


async def calendar_automation_panel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    await query.answer()
    snapshot = await async_with_db(calendar_automation_snapshot)
    await edit(query, _calendar_automation_text(snapshot), _calendar_automation_rows(snapshot.get("settings", {})))


async def calendar_admin_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    key = str(query.data or "").split(":", 1)[1]
    current = bool(calendar_settings(await async_snapshot()).get(key))
    await async_with_db(lambda db: update_calendar_setting(db, key, not current))
    await async_with_db(lambda db: audit(db, query.from_user.id, "calendar_automation_toggle", f"{key}:{not current}"))
    await query.answer("تنظیم شد")
    snapshot = await async_with_db(calendar_automation_snapshot)
    await edit(query, _calendar_automation_text(snapshot), _calendar_automation_rows(snapshot.get("settings", {})))


async def calendar_admin_cycle(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    action = str(query.data or "").split(":", 1)[1]
    settings = calendar_settings(await async_snapshot())
    if action == "time":
        options = ["07:30", "08:00", "09:00", "12:00", "18:00"]
        current = str(settings.get("auto_publish_time") or "07:30")
        value = options[(options.index(current) + 1) % len(options)] if current in options else options[0]
        key = "auto_publish_time"
    elif action == "destination":
        options = ["public", "private", "both"]
        current = str(settings.get("auto_publish_destination") or "public")
        value = options[(options.index(current) + 1) % len(options)] if current in options else options[0]
        key = "auto_publish_destination"
    elif action == "impact":
        options = ["high", "medium", "low"]
        current = str(settings.get("auto_publish_min_impact") or "high")
        value = options[(options.index(current) + 1) % len(options)] if current in options else options[0]
        key = "auto_publish_min_impact"
    else:
        options = [
            ["USD", "EUR", "GBP"],
            ["USD"],
            ["USD", "EUR", "GBP", "JPY", "CAD", "AUD", "NZD", "CHF"],
            [],
        ]
        current = sorted(settings.get("auto_publish_currencies", []))
        normalized = [sorted(item) for item in options]
        value = options[(normalized.index(current) + 1) % len(options)] if current in normalized else options[0]
        key = "auto_publish_currencies"
    await async_with_db(lambda db: update_calendar_setting(db, key, value))
    await async_with_db(lambda db: audit(db, query.from_user.id, "calendar_automation_setting", f"{key}:{value}"))
    await query.answer("تنظیم شد")
    snapshot = await async_with_db(calendar_automation_snapshot)
    await edit(query, _calendar_automation_text(snapshot), _calendar_automation_rows(snapshot.get("settings", {})))


async def economic_calendar_automation_job(context: ContextTypes.DEFAULT_TYPE) -> dict[str, int]:
    counts = {"reminders": 0, "actuals": 0, "published": 0, "failed": 0}
    try:
        events = await fetch_economic_calendar(force=False)
    except Exception:
        logger.exception("Economic calendar automation fetch failed")
        return counts
    await async_with_db(lambda db: cache_calendar_events(db, events))
    notifications = await async_with_db(lambda db: claim_due_calendar_notifications(db, events))
    for item in notifications:
        uid = str(item.get("user_id") or "")
        if not uid.isdigit():
            await async_with_db(
                lambda db, key=item["key"]: mark_calendar_notification(
                    db, key, success=False, detail="invalid_user_id"
                )
            )
            counts["failed"] += 1
            continue
        try:
            allowed = await async_with_db(
                lambda db, user_id=uid, event=dict(item.get("event") or {}): route_notification(
                    db,
                    user_id,
                    "high_impact" if str(event.get("impact") or "").lower() in {"high", "3"} else "calendar",
                    market=str(event.get("market") or ""),
                    symbol=str(event.get("currency") or ""),
                )
            )
            if not allowed:
                await async_with_db(
                    lambda db, key=item["key"]: mark_calendar_notification(
                        db, key, success=True, detail="user_preferences_blocked"
                    )
                )
                continue
            await _telegram_request_with_button_fallback(
                context.bot.send_message,
                int(uid),
                render_calendar_alert(
                    dict(item.get("event") or {}),
                    kind=str(item.get("kind") or "reminder"),
                    reminder_minutes=int(item.get("reminder_minutes", 0) or 0),
                    timezone=str(item.get("timezone") or SETTINGS.timezone),
                ),
                parse_mode=ParseMode.HTML,
                reply_markup=InlineKeyboardMarkup(
                    [[InlineKeyboardButton("🗓 مشاهده تقویم", callback_data="u_calendar:today")]]
                ),
            )
            await async_with_db(lambda db, key=item["key"]: mark_calendar_notification(db, key, success=True))
            if item.get("kind") == "actual":
                counts["actuals"] += 1
            else:
                counts["reminders"] += 1
        except Exception as exc:
            logger.warning(
                "Economic calendar delivery failed for user %s: %s",
                uid,
                exc.__class__.__name__,
            )
            await async_with_db(
                lambda db, key=item["key"], error=exc.__class__.__name__: mark_calendar_notification(
                    db, key, success=False, detail=error
                )
            )
            counts["failed"] += 1
    publication = await async_with_db(lambda db: claim_auto_publication(db, events))
    if publication is not None:
        selected = list(publication.get("events") or [])
        if not selected:
            await async_with_db(lambda db: mark_auto_publication(db, success=True, detail="no_matching_events"))
        else:
            text = render_selected_calendar_events(selected, list(range(len(selected))), include_analysis=False)
            message_ids: list[int] = []
            errors: list[str] = []
            for channel_id in _market_explicit_channels(str(publication.get("destination") or "public")):
                try:
                    for chunk in chunk_text(text, 3900):
                        message = await _telegram_request_with_button_fallback(
                            context.bot.send_message,
                            chat_id=channel_id,
                            text=chunk,
                            parse_mode=ParseMode.HTML,
                            disable_web_page_preview=True,
                        )
                        message_ids.append(int(message.message_id))
                except TelegramError as exc:
                    errors.append(f"{channel_id}:{exc.__class__.__name__}")
            await async_with_db(
                lambda db: mark_auto_publication(
                    db,
                    success=bool(message_ids),
                    detail=",".join(errors),
                    message_ids=message_ids,
                )
            )
            counts["published"] += int(bool(message_ids))
            counts["failed"] += int(not message_ids)
    return counts


async def calendar_admin_run_now(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    await query.answer("در حال بررسی…")
    counts = await economic_calendar_automation_job(context)
    snapshot = await async_with_db(calendar_automation_snapshot)
    text = _calendar_automation_text(snapshot) + (
        f"\n\nاجرای دستی: یادآوری <b>{counts['reminders']}</b> | "
        f"Actual <b>{counts['actuals']}</b> | انتشار <b>{counts['published']}</b> | "
        f"خطا <b>{counts['failed']}</b>"
    )
    await edit(query, text, _calendar_automation_rows(snapshot.get("settings", {})))


def _market_user_rows() -> list[list[InlineKeyboardButton]]:
    return [
        [
            InlineKeyboardButton("🛢 قیمت نفت و انرژی", callback_data="price_energy"),
            InlineKeyboardButton("📈 قیمت سهام", callback_data="stock_menu"),
        ],
        [InlineKeyboardButton("🔄 بروزرسانی", callback_data="mi_refresh"), InlineKeyboardButton("🔙 خانه", callback_data="home")],
    ]


async def u_market_intel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    # Legacy entry point: keep old buttons alive but route users to the new,
    # public-safe economic calendar instead of exposing provider news details.
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    if not (await run_blocking(rate_limit_allow, query.from_user.id, "economic_calendar", 5)):
        await query.answer("Please wait a few seconds." if language == "en" else "لطفاً چند ثانیه صبر کنید.")
        return
    await query.answer("Fetching today's key events…" if language == "en" else "در حال دریافت خبرهای مهم امروز…")
    snapshot = await _market_snapshot_for_display(force=str(query.data or "") == "mi_refresh")
    events = snapshot.get("calendar", []) if isinstance(snapshot, dict) else []
    if not isinstance(events, list) or not events:
        await edit(query, "⚠️ The economic calendar is temporarily unavailable." if language == "en" else "⚠️ تقویم اقتصادی موقتاً در دسترس نیست.", _calendar_user_rows("today", {}, language))
        return
    await edit(query, render_public_calendar(events, period="today", language=language), _calendar_user_rows("today", {}, language))


async def market_energy_price(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    language = (await run_blocking(_language_for_user, query.from_user.id))
    if not (await run_blocking(rate_limit_allow, query.from_user.id, "market_energy", 8)):
        await query.answer("Please wait a few seconds." if language == "en" else "لطفاً چند ثانیه صبر کنید.", show_alert=False)
        return
    await query.answer("Fetching energy prices…" if language == "en" else "در حال دریافت قیمت نفت…")
    snapshot = await _market_snapshot_for_display(force=False)
    text = render_energy(snapshot) if snapshot and language != "en" else (
        "🛢 <b>Energy market</b>\n\nLive provider data is available in the Mini App; use Refresh to request the latest snapshot."
        if snapshot and language == "en"
        else ("⚠️ Energy market data is unavailable." if language == "en" else "⚠️ داده نفت و انرژی در دسترس نیست.")
    )
    await edit(
        query,
        text,
        [
            [
                InlineKeyboardButton("🔄 Refresh" if language == "en" else "🔄 بروزرسانی", callback_data="price_energy"),
                InlineKeyboardButton("🔙 Market prices" if language == "en" else "🔙 قیمت بازار", callback_data="u_price"),
            ]
        ],
    )


async def market_intel_view(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    await query.answer("در حال آماده‌سازی…")
    key = query.data.split(":", 1)[1]
    snapshot = await _market_snapshot_for_display(force=False)
    renderers = {
        "gold": lambda value: render_outlook(value, "gold"),
        "eurusd": lambda value: render_outlook(value, "eurusd"),
        "news": render_news,
        "economy": render_economy,
        "energy": render_energy,
        "filings": render_filings,
    }
    renderer = renderers.get(key)
    text = renderer(snapshot) if renderer and snapshot else "⚠️ داده این بخش در دسترس نیست."
    await edit(
        query,
        text,
        [
            [
                InlineKeyboardButton("🔄 بروزرسانی", callback_data=f"mi_view:{key}"),
                InlineKeyboardButton("🔙 مرکز ادمین", callback_data="a_market_intel"),
            ]
        ],
    )


async def market_latest_brief(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    query = update.callback_query
    await query.answer("گزارش‌های کامل پس از تأیید ادمین در کانال منتشر می‌شوند.", show_alert=True)


def _market_admin_panel_text(root: dict[str, Any]) -> str:
    settings = root.get("settings", {}) if isinstance(root.get("settings"), dict) else {}
    latest_pending = None
    for row in reversed(root.get("briefings", [])):
        if isinstance(row, dict) and row.get("status") == "pending":
            latest_pending = row
            break
    destination_labels = {"public": "کانال عمومی", "private": "کانال VIP", "both": "هر دو کانال"}
    states = api_states()
    ready_count = sum(1 for state in states if state.configured)
    lines = [
        "📰 <b>مرکز اخبار، اقتصاد و تحلیل بازار</b>",
        "",
        f"🤖 تولید خودکار صبحگاهی: {'✅ روشن' if settings.get('auto_generate', True) else '❌ خاموش'}",
        f"🕒 زمان تولید: <b>{esc(settings.get('morning_time') or '07:30')}</b> ({esc(SETTINGS.timezone)})",
        f"📣 مقصد انتشار پس از تأیید: <b>{destination_labels.get(str(settings.get('destination')), 'کانال عمومی')}</b>",
        f"🔌 منابع آماده: <b>{ready_count}/{len(states)}</b>",
        f"⏳ گزارش در انتظار تأیید: <b>{'#' + str(latest_pending.get('id')) if latest_pending else 'ندارد'}</b>",
        "",
        "گزارش صبحگاهی هیچ‌وقت بدون تأیید ادمین در کانال منتشر نمی‌شود.",
    ]
    return "\n".join(lines)


def _market_admin_rows(root: dict[str, Any]) -> list[list[InlineKeyboardButton]]:
    settings = root.get("settings", {}) if isinstance(root.get("settings"), dict) else {}
    latest_pending = next(
        (row for row in reversed(root.get("briefings", [])) if isinstance(row, dict) and row.get("status") == "pending"),
        None,
    )
    destination_labels = {"public": "عمومی", "private": "VIP", "both": "هر دو"}
    rows = [
        [
            InlineKeyboardButton("🗓 تقویم اقتصادی", callback_data="mi_admin_calendar"),
            InlineKeyboardButton("📰 خبرهای تحلیلی", callback_data="mi_admin_news"),
        ],
        [InlineKeyboardButton("🧠 ساخت گزارش صبحگاهی", callback_data="mi_admin_generate")],
        [
            InlineKeyboardButton("🥇 سناریوی طلا", callback_data="mi_admin_scenario:gold"),
            InlineKeyboardButton("💶 سناریوی EUR/USD", callback_data="mi_admin_scenario:eurusd"),
        ],
        [
            InlineKeyboardButton("🌍 جزئیات اقتصاد", callback_data="mi_view:economy"),
            InlineKeyboardButton("🏢 گزارش‌های SEC", callback_data="mi_view:filings"),
        ],
    ]
    if latest_pending:
        rows.append(
            [
                InlineKeyboardButton(
                    f"✅ بررسی گزارش #{latest_pending.get('id')}", callback_data=f"mi_admin_review:{latest_pending.get('id')}"
                )
            ]
        )
    rows.extend(
        [
            [
                state_button(
                    "گزارش صبحگاهی",
                    bool(settings.get("auto_generate", True)),
                    callback_data="mi_admin_toggle:auto_generate",
                ),
                InlineKeyboardButton(
                    f"مقصد: {destination_labels.get(str(settings.get('destination')), 'عمومی')}",
                    callback_data="mi_admin_destination",
                ),
            ],
            [
                InlineKeyboardButton("07:00", callback_data="mi_admin_time:0700"),
                InlineKeyboardButton("07:30", callback_data="mi_admin_time:0730"),
                InlineKeyboardButton("08:00", callback_data="mi_admin_time:0800"),
                InlineKeyboardButton("08:30", callback_data="mi_admin_time:0830"),
            ],
            [
                InlineKeyboardButton("📐 ارزیابی سناریوها", callback_data="mi_scenario_performance"),
                InlineKeyboardButton("🔌 وضعیت APIها", callback_data="mi_admin_apis"),
            ],
            [InlineKeyboardButton("🔙 پنل ادمین", callback_data="admin_home")],
        ]
    )
    return rows


async def a_market_intel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    await query.answer()
    root = await async_with_db(lambda db: dict(ensure_market_intelligence(db)))
    await edit(query, _market_admin_panel_text(root), _market_admin_rows(root))


def _market_explicit_channels(destination: str) -> list[int]:
    channels: list[int] = []
    if destination in {"public", "both"} and SETTINGS.public_channel_id:
        channels.append(int(SETTINGS.public_channel_id))
    if destination in {"private", "both"} and SETTINGS.private_channel_id:
        channels.append(int(SETTINGS.private_channel_id))
    return channels


async def _publish_market_text(bot, text: str, destination: str) -> tuple[list[int], list[str]]:
    message_ids: list[int] = []
    errors: list[str] = []
    for channel_id in _market_explicit_channels(destination):
        try:
            for part in chunk_text(text, 3900):
                message = await _telegram_request_with_button_fallback(
                    bot.send_message,
                    channel_id,
                    part,
                    parse_mode=ParseMode.HTML,
                    disable_web_page_preview=True,
                )
                message_ids.append(int(message.message_id))
        except TelegramError as exc:
            errors.append(f"{channel_id}:{exc.__class__.__name__}")
    return message_ids, errors


def _market_news_selection_text(snapshot: dict[str, Any], selected: set[int]) -> str:
    news = snapshot.get("news", []) if isinstance(snapshot.get("news"), list) else []
    lines = ["📰 <b>انتخاب خبرهای مهم برای انتشار</b>", "", "روی شماره هر خبر بزنید تا تیک بخورد:", ""]
    if not news:
        lines.append("⚠️ خبری در Snapshot فعلی وجود ندارد.")
    for index, item in enumerate(news[:12]):
        icon = "✅" if index in selected else "▫️"
        lines.append(f"{icon} <b>{index + 1}.</b> {esc(str(item.get('title') or 'بدون عنوان')[:230])}")
    lines.extend(["", f"انتخاب‌شده: <b>{len(selected)}</b>"])
    return "\n".join(lines)


def _market_news_selection_rows(count: int, selected: set[int]) -> list[list[InlineKeyboardButton]]:
    buttons = [
        InlineKeyboardButton(f"{'✅' if index in selected else '▫️'} {index + 1}", callback_data=f"mi_news_toggle:{index}")
        for index in range(min(12, count))
    ]
    rows = [buttons[index : index + 4] for index in range(0, len(buttons), 4)]
    rows.extend(
        [
            [
                InlineKeyboardButton("📢 ارسال عمومی", callback_data="mi_news_send:public"),
                InlineKeyboardButton("🔒 ارسال VIP", callback_data="mi_news_send:private"),
            ],
            [InlineKeyboardButton("📡 ارسال هر دو", callback_data="mi_news_send:both")],
            [
                InlineKeyboardButton("🔄 دریافت خبر تازه", callback_data="mi_admin_news_refresh"),
                InlineKeyboardButton("🔙 مرکز اخبار", callback_data="a_market_intel"),
            ],
        ]
    )
    return rows


async def market_admin_news(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    force = str(query.data or "") == "mi_admin_news_refresh"
    await query.answer("در حال دریافت خبرها…")
    snapshot = await _market_snapshot_for_display(force=force)
    context.user_data["mi_news_selected"] = set()
    context.user_data["mi_news_snapshot"] = snapshot or {}
    news = snapshot.get("news", []) if isinstance(snapshot, dict) and isinstance(snapshot.get("news"), list) else []
    await edit(query, _market_news_selection_text(snapshot or {}, set()), _market_news_selection_rows(len(news), set()))


async def market_admin_news_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    index = int(query.data.split(":", 1)[1])
    selected = context.user_data.setdefault("mi_news_selected", set())
    if not isinstance(selected, set):
        selected = set()
        context.user_data["mi_news_selected"] = selected
    if index in selected:
        selected.remove(index)
    else:
        selected.add(index)
    await query.answer("انتخاب بروزرسانی شد")
    snapshot = context.user_data.get("mi_news_snapshot")
    if not isinstance(snapshot, dict):
        snapshot = await async_with_db(lambda db: latest_snapshot(db))
    news = snapshot.get("news", []) if isinstance(snapshot.get("news"), list) else []
    selected.intersection_update(range(len(news)))
    await edit(query, _market_news_selection_text(snapshot, selected), _market_news_selection_rows(len(news), selected))


async def market_admin_news_send(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    destination = query.data.split(":", 1)[1]
    selected = context.user_data.get("mi_news_selected", set())
    if not isinstance(selected, set) or not selected:
        await query.answer("حداقل یک خبر را انتخاب کنید.", show_alert=True)
        return
    snapshot = context.user_data.get("mi_news_snapshot")
    if not isinstance(snapshot, dict):
        snapshot = await async_with_db(lambda db: latest_snapshot(db))
    text = render_selected_news(snapshot, sorted(selected))
    await query.answer("در حال انتشار…")
    message_ids, errors = await _publish_market_text(context.bot, text, destination)
    await async_with_db(
        lambda db: audit(
            db,
            query.from_user.id,
            "market_selected_news_publish",
            f"{destination}:{','.join(str(index) for index in sorted(selected))}:{len(message_ids)}",
        )
    )
    if message_ids:
        context.user_data["mi_news_selected"] = set()
        context.user_data.pop("mi_news_snapshot", None)
        warning = f"\n⚠️ خطای بخشی: <code>{esc(', '.join(errors))}</code>" if errors else ""
        await edit(
            query,
            f"✅ {len(selected)} خبر منتخب منتشر شد.{warning}",
            [[InlineKeyboardButton("🔙 مرکز اخبار", callback_data="a_market_intel")]],
        )
    else:
        await edit(
            query,
            f"❌ انتشار انجام نشد: <code>{esc(', '.join(errors) or 'کانال تنظیم نشده')}</code>",
            [[InlineKeyboardButton("🔙 انتخاب خبرها", callback_data="mi_admin_news")]],
        )


def _market_scenario_rows(asset: str) -> list[list[InlineKeyboardButton]]:
    return [
        [
            InlineKeyboardButton("📢 ارسال عمومی", callback_data=f"mi_scenario_send:{asset}:public"),
            InlineKeyboardButton("🔒 ارسال VIP", callback_data=f"mi_scenario_send:{asset}:private"),
        ],
        [InlineKeyboardButton("📡 ارسال هر دو", callback_data=f"mi_scenario_send:{asset}:both")],
        [
            InlineKeyboardButton("🔄 بروزرسانی", callback_data=f"mi_admin_scenario:{asset}"),
            InlineKeyboardButton("🔙 مرکز اخبار", callback_data="a_market_intel"),
        ],
    ]


async def market_admin_scenario(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    asset = query.data.split(":", 1)[1]
    if asset not in {"gold", "eurusd"}:
        await query.answer("سناریو نامعتبر است.", show_alert=True)
        return
    await query.answer("در حال ساخت سناریو…")
    snapshot = await _market_snapshot_for_display(force=False)
    text = render_outlook(snapshot, asset) if snapshot else "⚠️ داده کافی برای سناریو وجود ندارد."
    await edit(query, text, _market_scenario_rows(asset))


async def market_admin_scenario_send(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    _, asset, destination = query.data.split(":", 2)
    if asset not in {"gold", "eurusd"} or destination not in {"public", "private", "both"}:
        await query.answer("درخواست نامعتبر است.", show_alert=True)
        return
    snapshot = await async_with_db(lambda db: latest_snapshot(db))
    if not snapshot:
        snapshot = await _market_snapshot_for_display(force=True)
    text = render_outlook(snapshot, asset) if snapshot else "⚠️ داده کافی برای سناریو وجود ندارد."
    await query.answer("در حال انتشار…")
    message_ids, errors = await _publish_market_text(context.bot, text, destination)
    await async_with_db(lambda db: audit(db, query.from_user.id, "market_scenario_publish", f"{asset}:{destination}:{len(message_ids)}"))
    if message_ids:
        warning = f"\n⚠️ خطای بخشی: <code>{esc(', '.join(errors))}</code>" if errors else ""
        await edit(
            query,
            f"✅ سناریوی {'طلا' if asset == 'gold' else 'EUR/USD'} منتشر شد.{warning}",
            [[InlineKeyboardButton("🔙 مرکز اخبار", callback_data="a_market_intel")]],
        )
    else:
        await edit(query, f"❌ انتشار انجام نشد: <code>{esc(', '.join(errors) or 'کانال تنظیم نشده')}</code>", _market_scenario_rows(asset))


def _market_review_rows(briefing_id: int) -> list[list[InlineKeyboardButton]]:
    return [
        [
            InlineKeyboardButton("✅ تأیید و انتشار", callback_data=f"mi_admin_approve:{briefing_id}"),
            InlineKeyboardButton("❌ رد گزارش", callback_data=f"mi_admin_reject:{briefing_id}"),
        ],
        [InlineKeyboardButton("🔄 تولید مجدد", callback_data=f"mi_admin_regenerate:{briefing_id}")],
        [InlineKeyboardButton("🔙 مرکز اخبار", callback_data="a_market_intel")],
    ]


async def _create_market_briefing(*, created_by: str, force: bool) -> dict[str, Any]:
    snapshot = await build_market_snapshot(force=force)
    text = render_morning_brief(snapshot)
    return await async_with_db(lambda db: create_briefing(db, snapshot, text, created_by=created_by))


async def market_admin_generate(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    await query.answer("در حال دریافت خبرها و داده‌ها…")
    try:
        row = await _create_market_briefing(created_by=str(query.from_user.id), force=True)
        await async_with_db(lambda db: audit(db, query.from_user.id, "market_brief_generate", str(row.get("id"))))
        preview = chunk_text(str(row.get("text") or ""), 3000)[0]
        await edit(query, f"📝 <b>پیش‌نویس گزارش #{row.get('id')}</b>\n\n{preview}", _market_review_rows(int(row["id"])))
    except Exception as exc:
        logger.exception("Could not generate market briefing")
        await edit(
            query,
            f"❌ ساخت گزارش انجام نشد: <code>{esc(str(exc)[:300])}</code>",
            [[InlineKeyboardButton("🔙 بازگشت", callback_data="a_market_intel")]],
        )


async def market_admin_review(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    await query.answer()
    briefing_id = int(query.data.split(":", 1)[1])
    row = await async_with_db(lambda db: dict(get_briefing(db, briefing_id) or {}))
    if not row:
        await edit(query, "❌ گزارش موردنظر پیدا نشد.", [[InlineKeyboardButton("🔙 مرکز اخبار", callback_data="a_market_intel")]])
        return
    status = esc(row.get("status") or "—")
    preview = chunk_text(str(row.get("text") or ""), 3000)[0]
    await edit(query, f"📝 <b>گزارش #{briefing_id}</b> — وضعیت: <b>{status}</b>\n\n{preview}", _market_review_rows(briefing_id))


def _market_destination_channels(settings: dict[str, Any]) -> list[int]:
    destination = str(settings.get("destination") or "public")
    channels: list[int] = []
    if destination in {"public", "both"}:
        channels.append(SETTINGS.public_channel_id)
    if destination in {"private", "both"}:
        channels.append(SETTINGS.private_channel_id)
    return [channel_id for channel_id in channels if channel_id]


async def market_admin_approve(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    await query.answer("در حال انتشار…")
    briefing_id = int(query.data.split(":", 1)[1])
    row, settings = await async_with_db(
        lambda db: (
            dict(get_briefing(db, briefing_id) or {}),
            dict(ensure_market_intelligence(db).get("settings", {})),
        )
    )
    if not row:
        await edit(query, "❌ گزارش موردنظر پیدا نشد.", [[InlineKeyboardButton("🔙 مرکز اخبار", callback_data="a_market_intel")]])
        return
    if row.get("status") == "published":
        await edit(query, "ℹ️ این گزارش قبلاً منتشر شده است.", [[InlineKeyboardButton("🔙 مرکز اخبار", callback_data="a_market_intel")]])
        return
    message_ids: list[int] = []
    errors: list[str] = []
    for channel_id in _market_destination_channels(settings):
        try:
            for chunk in chunk_text(str(row.get("text") or ""), 3900):
                message = await _telegram_request_with_button_fallback(
                    context.bot.send_message,
                    chat_id=channel_id,
                    text=chunk,
                    parse_mode=ParseMode.HTML,
                    disable_web_page_preview=True,
                )
                message_ids.append(int(message.message_id))
        except TelegramError as exc:
            errors.append(f"{channel_id}:{exc.__class__.__name__}")
            logger.warning("Could not publish market briefing %s to %s", briefing_id, channel_id)
    status = "published" if message_ids else "failed"
    await async_with_db(
        lambda db: (
            set_briefing_status(
                db,
                briefing_id,
                status,
                reviewer=query.from_user.id,
                message_ids=message_ids,
                error=",".join(errors),
            ),
            audit(db, query.from_user.id, "market_brief_publish", f"{briefing_id}:{status}"),
        )
    )
    if status == "published":
        warning = f"\n⚠️ خطای بخشی: <code>{esc(', '.join(errors))}</code>" if errors else ""
        await edit(
            query,
            f"✅ گزارش #{briefing_id} در کانال منتشر شد.{warning}",
            [[InlineKeyboardButton("🔙 مرکز اخبار", callback_data="a_market_intel")]],
        )
    else:
        await edit(query, f"❌ انتشار کامل نشد. خطا: <code>{esc(', '.join(errors) or 'unknown')}</code>", _market_review_rows(briefing_id))


async def market_admin_reject(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    await query.answer("رد شد")
    briefing_id = int(query.data.split(":", 1)[1])
    try:
        await async_with_db(
            lambda db: (
                set_briefing_status(db, briefing_id, "rejected", reviewer=query.from_user.id),
                audit(db, query.from_user.id, "market_brief_reject", str(briefing_id)),
            )
        )
    except ValueError as exc:
        await query.answer(str(exc), show_alert=True)
        return
    await edit(
        query,
        f"❌ گزارش #{briefing_id} رد شد و در کانال منتشر نمی‌شود.",
        [[InlineKeyboardButton("🔙 مرکز اخبار", callback_data="a_market_intel")]],
    )


async def market_admin_regenerate(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    old_id = int(query.data.split(":", 1)[1])
    await query.answer("در حال تولید مجدد…")
    try:
        row = await _create_market_briefing(created_by=str(query.from_user.id), force=True)
        await async_with_db(
            lambda db: (
                set_briefing_status(db, old_id, "rejected", reviewer=query.from_user.id),
                audit(db, query.from_user.id, "market_brief_regenerate", f"{old_id}->{row.get('id')}"),
            )
        )
        preview = chunk_text(str(row.get("text") or ""), 3000)[0]
        await edit(
            query,
            f"🔄 <b>نسخه جدید گزارش #{row.get('id')}</b>\n\n{preview}",
            _market_review_rows(int(row["id"])),
        )
    except Exception as exc:
        logger.exception("Could not regenerate market briefing")
        await edit(
            query,
            f"❌ تولید مجدد ناموفق بود: <code>{esc(str(exc)[:300])}</code>",
            [[InlineKeyboardButton("🔙 بازگشت", callback_data="a_market_intel")]],
        )


async def market_admin_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    key = query.data.split(":", 1)[1]
    if key != "auto_generate":
        await query.answer("گزینه نامعتبر است.", show_alert=True)
        return
    await async_with_db(
        lambda db: update_market_intelligence_settings(
            db,
            auto_generate=not bool(ensure_market_intelligence(db).get("settings", {}).get("auto_generate", True)),
        )
    )
    await query.answer("تنظیم شد")
    root = await async_with_db(lambda db: dict(ensure_market_intelligence(db)))
    await edit(query, _market_admin_panel_text(root), _market_admin_rows(root))


async def market_admin_destination(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    order = ["public", "private", "both"]
    current = await async_with_db(lambda db: str(ensure_market_intelligence(db).get("settings", {}).get("destination") or "public"))
    next_value = order[(order.index(current) + 1) % len(order)] if current in order else "public"
    await async_with_db(lambda db: update_market_intelligence_settings(db, destination=next_value))
    await query.answer("مقصد تغییر کرد")
    root = await async_with_db(lambda db: dict(ensure_market_intelligence(db)))
    await edit(query, _market_admin_panel_text(root), _market_admin_rows(root))


async def market_admin_time(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    raw = query.data.split(":", 1)[1]
    value = f"{raw[:2]}:{raw[2:]}"
    await async_with_db(lambda db: update_market_intelligence_settings(db, morning_time=value))
    await query.answer(f"زمان روی {value} تنظیم شد")
    root = await async_with_db(lambda db: dict(ensure_market_intelligence(db)))
    await edit(query, _market_admin_panel_text(root), _market_admin_rows(root))


async def market_scenario_performance(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    await query.answer()
    stats = scenario_performance(await async_snapshot())
    lines = [
        "📐 <b>ارزیابی خارج از نمونه سناریوها</b>",
        "",
        "پیش‌بینی‌ها پس از افق ۲۴ ساعته با قیمت واقعی مقایسه و با Brier Score ارزیابی می‌شوند.",
        "",
    ]
    for asset in ("XAU/USD", "EUR/USD"):
        row = stats.get(asset, {}) if isinstance(stats, dict) else {}
        samples = int(row.get("samples", 0) or 0) if isinstance(row, dict) else 0
        accuracy = row.get("accuracy") if isinstance(row, dict) else None
        brier = row.get("average_brier") if isinstance(row, dict) else None
        lines.append(
            f"<b>{asset}</b> — نمونه: <b>{samples}</b> | "
            f"دقت جهت: <b>{accuracy if accuracy is not None else '—'}٪</b> | "
            f"Brier: <code>{brier if brier is not None else '—'}</code>"
        )
    lines.extend(["", "پس از حداقل ۱۰ نمونه، احتمال‌ها خودکار به سمت عملکرد واقعی کالیبره می‌شوند."])
    await edit(
        query,
        "\n".join(lines),
        [
            [
                InlineKeyboardButton("🔄 تازه‌سازی", callback_data="mi_scenario_performance"),
                InlineKeyboardButton("🔙 مرکز اخبار", callback_data="a_market_intel"),
            ]
        ],
    )


async def market_admin_apis(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if not await require_admin(update, PERMISSION_MARKET_INTELLIGENCE):
        return
    query = update.callback_query
    await query.answer("در حال تست واقعی اتصال‌ها…")
    results = await test_api_connections()
    icons = {"ok": "✅", "empty": "⚠️", "missing": "⚪️", "error": "❌"}
    lines = ["🔌 <b>تست واقعی APIها</b>", ""]
    for row in results:
        lines.append(f"{icons.get(str(row.get('status')), '⚠️')} <b>{esc(row.get('name') or 'API')}</b> — {esc(row.get('detail') or '—')}")
    lines.extend(
        [
            "",
            "نام‌های جایگزین Variable نیز پشتیبانی می‌شوند؛ مقدار کلید را بدون فاصله و بدون عبارت KEY= وارد کنید.",
            "تقویم اقتصادی و World Bank بدون کلید کار می‌کنند.",
        ]
    )
    await edit(
        query,
        "\n".join(lines),
        [
            [
                InlineKeyboardButton("🔄 تست دوباره", callback_data="mi_admin_apis"),
                InlineKeyboardButton("🔙 مرکز اخبار", callback_data="a_market_intel"),
            ]
        ],
    )


async def _notify_market_briefing_admins(bot, row: dict[str, Any]) -> None:
    preview = chunk_text(str(row.get("text") or ""), 2800)[0]
    text = f"🌅 <b>گزارش صبحگاهی #{row.get('id')} آماده تأیید است</b>\n\n{preview}"
    markup = InlineKeyboardMarkup(_market_review_rows(int(row["id"])))
    for admin_id in (await run_blocking(_admin_ids_for_permission, PERMISSION_MARKET_INTELLIGENCE)):
        try:
            await _telegram_request_with_button_fallback(
                bot.send_message, admin_id, text, parse_mode=ParseMode.HTML, disable_web_page_preview=True, reply_markup=markup
            )
        except TelegramError:
            logger.warning("Could not notify market intelligence admin %s", admin_id)


async def market_scenario_evaluation_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    root = (await async_snapshot()).get("market_intelligence", {})
    if not isinstance(root, dict) or not root.get("settings", {}).get("enabled", True):
        return
    snapshot = await build_market_snapshot(force=True)
    await async_with_db(lambda db: save_snapshot(db, snapshot))


async def market_morning_job(context: ContextTypes.DEFAULT_TYPE) -> None:
    local_now = datetime.now(ZoneInfo(SETTINGS.timezone))
    if not await async_with_db(lambda db: morning_generation_due(db, local_now)):
        return
    try:
        row = await _create_market_briefing(created_by="scheduler", force=True)
        await _notify_market_briefing_admins(context.bot, row)
    except Exception:
        logger.exception("Morning market briefing generation failed")



__feature_exports__ = ('u_price', 'price_forex_menu', 'price_fetch', '_market_quote_text', 'market_search_start', 'market_search_input', '_format_crypto_price', '_format_compact_usd', '_crypto_quote_text', '_remember_crypto_callback', '_resolve_crypto_callback', '_crypto_quote_rows', 'crypto_provider_compare', 'crypto_menu', 'crypto_market_leaders_view', 'crypto_search_start', '_crypto_search_page_rows', 'crypto_search_input', 'crypto_search_page', '_show_crypto_quote', 'crypto_search_pick', 'crypto_coin_view', '_stock_quote_text', '_stock_quote_rows', 'stock_menu', 'stock_search_start', 'stock_search_input', '_show_stock_quote', 'stock_search_pick', 'stock_quote_view', '_format_iran_quote', 'iran_prices', '_market_snapshot_for_display', '_calendar_user_rows', 'user_economic_calendar', 'calendar_user_preference_handler', '_calendar_admin_rows', '_calendar_admin_text', 'market_admin_calendar', 'market_admin_calendar_period', 'market_admin_calendar_toggle', 'market_admin_calendar_detail', 'market_admin_calendar_analysis_toggle', 'market_admin_calendar_send', '_calendar_automation_text', '_calendar_automation_rows', 'calendar_automation_panel', 'calendar_admin_toggle', 'calendar_admin_cycle', 'economic_calendar_automation_job', 'calendar_admin_run_now', '_market_user_rows', 'u_market_intel', 'market_energy_price', 'market_intel_view', 'market_latest_brief', '_market_admin_panel_text', '_market_admin_rows', 'a_market_intel', '_market_explicit_channels', '_publish_market_text', '_market_news_selection_text', '_market_news_selection_rows', 'market_admin_news', 'market_admin_news_toggle', 'market_admin_news_send', '_market_scenario_rows', 'market_admin_scenario', 'market_admin_scenario_send', '_market_review_rows', '_create_market_briefing', 'market_admin_generate', 'market_admin_review', '_market_destination_channels', 'market_admin_approve', 'market_admin_reject', 'market_admin_regenerate', 'market_admin_toggle', 'market_admin_destination', 'market_admin_time', 'market_scenario_performance', 'market_admin_apis', '_notify_market_briefing_admins', 'market_scenario_evaluation_job', 'market_morning_job')
