"""One-question-at-a-time admin flows; drafts survive restarts."""
from bot_runtime import shared as _shared
globals().update({name:value for name,value in vars(_shared).items() if not name.startswith('__')})
from modules import admin_creation as _creation
from bot_runtime.shared import async_with_db, async_snapshot, InlineKeyboardButton, esc, utc_iso, ConversationHandler
from bot_runtime.navigation import edit, reply
from modules.crm_navigation import crm_case_parent
from modules.admin_access import has_permission
from bot_runtime.admin_operations import _lesson_attachment_from_message

CREATION_INPUT='CREATION_INPUT'


async def creation_screen(update, context, key):
    actor=update.effective_user.id
    def prepare(db):
        row=_creation.get_draft(db,actor,key)
        summary=_creation.review(db,actor,key) if row['step']=='review' else None
        return dict(row),summary,dict(db.get('users',{}).get(str(row.get('selected_user')),{}))
    row,summary,recipient=await async_with_db(prepare)
    context.user_data['creation_draft_id']=key
    rows=[];title=_creation.KINDS[row['kind']]
    metadata=f"\nسازنده: {esc(row['actor'])} | ویرایش: {esc(row['updated_at'][:16])}"
    if row['status']=='published':
        text='✅ ثبت شد. این عملیات با کلیک دوباره تکرار نمی‌شود.'
        rows=[[InlineKeyboardButton('ساخت مورد دیگر',callback_data='a_create')]]
    elif summary is not None:
        text=f'<b>{esc(title)} — پیش‌نمایش</b>\n\n'+'\n'.join(f'{esc(k)}: <b>{esc(v)}</b>' for k,v in summary)
        if row['kind']=='milestone':text+='\n\nپاداش فقط پس از بررسی شرایط در سرور صادر می‌شود.'
        text+='\n\nتا تأیید شما هیچ موردی فعال نمی‌شود.'
        rows=[[InlineKeyboardButton('✅ تأیید و انتشار',callback_data=f"cw:publish:{key}:{row['revision']}")],
              [InlineKeyboardButton('✏️ ویرایش یک مورد',callback_data=f'cw:edit:{key}')]]
    else:
        field=row.get('editing') or _creation.fields(row)[int(row['step'])]
        question,choices=_creation.FIELDS[field]
        if field=='claim' and row.get('selected_user'):
            question='این جایزه را به همین کاربر انتخاب‌شده بدهیم؟'
            choices=(('🎁 به همین کاربر انتخاب‌شده بده','assign'),)
        if field in {'value','second','third'}:
            v=row['values'];unit='درصد' if row['kind']=='discount' and v['discount_type']=='percentage' else 'تومان' if row['kind']=='discount' else 'روز VIP' if v.get('reward_type')=='vip_days' and row['kind'] in {'reward','milestone','mission','contest'} else 'درصد کوپن' if v.get('reward_type')=='discount_coupon' and row['kind'] in {'reward','milestone','mission','contest'} else 'امتیاز'
            question=f'چند {unit}؟'
            if field in {'second','third'}:question=('رتبه دوم: ' if field=='second' else 'رتبه سوم: ')+question
        if field=='limit' and row['kind']=='mission':question='حداکثر چند بار این مأموریت جایزه بدهد؟'
        text=f'<b>{esc(title)}</b>\nمرحله {int(row["step"])+1} از {len(_creation.fields(row))}\n\n{esc(question)}'
        for label,value in choices:
            index=next(i for i,choice in enumerate(_creation.FIELDS[field][1]) if choice[1]==value)
            if field=='reward_type' and (row['kind'] in {'mission','contest'} and value=='custom' or row['kind']=='milestone' and value=='combined'):continue
            rows.append([InlineKeyboardButton(label,callback_data=f'cw:answer:{key}:{field}:{index}')])
        if field=='content':
            text+=f"\nفایل‌های دریافت‌شده: {len(row.get('attachments',[]))}"
            rows.append([InlineKeyboardButton('ادامه',callback_data=f'cw:content_done:{key}')])
    if row.get('selected_user'):
        uid=row['selected_user'];name=' '.join(str(recipient.get(k) or '') for k in ('first_name','last_name')).strip()
        text=f"👤 گیرنده: <b>{esc(name or recipient.get('username') or 'کاربر')}</b> | <code>{esc(uid)}</code>\n\n"+text
    if row['status']=='draft':
        rows += [[InlineKeyboardButton('⬅️ برگشت',callback_data=f'cw:back:{key}'),InlineKeyboardButton('💾 ذخیره پیش‌نویس',callback_data=f'cw:save:{key}')],
                 [InlineKeyboardButton('❌ لغو',callback_data=f'cw:cancel:{key}')]]
    if row.get('return_callback'):
        rows.append([InlineKeyboardButton('👤 بازگشت به پرونده همین کاربر',callback_data=row['return_callback'])])
    if update.callback_query:await edit(update.callback_query,(text+metadata)[:3900],rows)
    else:await reply(update,(text+metadata)[:3900],rows)
    return CREATION_INPUT if row['status']=='draft' else ConversationHandler.END


async def creation_callback(update,context):
    q=update.callback_query;await q.answer();actor=q.from_user.id
    try:
        data=str(q.data);parts=data.split(':')
        if data=='a_create':
            context.user_data.pop('creation_draft_id',None)
            db=await async_snapshot();rows=[]
            for kind,title in _creation.KINDS.items():
                try:_creation.require(db, actor, kind)
                except PermissionError:continue
                rows.append([InlineKeyboardButton(title,callback_data=f'cw:mode:{kind}')])
            if not rows:raise PermissionError('مجوز ساخت ندارید.')
            rows += [[InlineKeyboardButton('💾 پیش‌نویس‌های من',callback_data='cw:drafts')], [InlineKeyboardButton('پنل مدیریت',callback_data='admin_home')]]
            await edit(q,'➕ <b>چه چیزی می‌خواهید بسازید؟</b>\nهر بار فقط یک سؤال؛ پاسخ‌ها خودکار ذخیره می‌شوند.',rows)
            return CREATION_INPUT
        action=parts[1]
        if action=='mode':
            context.user_data.pop('creation_draft_id',None)
            kind=parts[2];db=await async_snapshot();_creation.require(db,actor,kind)
            rows=[[InlineKeyboardButton('قدم‌به‌قدم — پیشنهادی',callback_data=f'cw:new:{kind}:guided')],
                  [InlineKeyboardButton('⚡ ساخت سریع',callback_data=f'cw:new:{kind}:quick')]]
            rows += [[InlineKeyboardButton(label,callback_data=f'cw:template:{key}')] for key,(label,k,_) in _creation.TEMPLATES.items() if k==kind]
            if kind=='points':rows.append([InlineKeyboardButton('📜 تاریخچه امتیاز',callback_data='cw:history:0')])
            rows.append([InlineKeyboardButton('⬅️ برگشت',callback_data='a_create')])
            await edit(q,'روش ساخت را انتخاب کنید. ساخت سریع و الگو نیز قبل از انتشار پیش‌نمایش دارند.',rows)
            return CREATION_INPUT
        if action=='history':
            db=await async_snapshot();_creation.require(db,actor,'points')
            page=max(0,int(parts[2]));history=list(reversed(db.get('point_history',[])))
            lines=['📜 <b>تاریخچه امتیاز</b>']
            for event in history[page*10:page*10+10]:
                lines.append(f"کاربر {esc(event.get('user_id'))} | {int(event.get('amount',0)):+d} | {esc(event.get('reason',''))}\n{esc(event.get('created_at',''))} | ادمین: {esc(event.get('actor','system'))}")
            rows=[]
            if page:rows.append([InlineKeyboardButton('قبلی',callback_data=f'cw:history:{page-1}')])
            if (page+1)*10<len(history):rows.append([InlineKeyboardButton('بعدی',callback_data=f'cw:history:{page+1}')])
            rows.append([InlineKeyboardButton('⬅️ مدیریت امتیاز',callback_data='cw:mode:points')])
            context.user_data.pop('creation_draft_id',None)
            await edit(q,'\n\n'.join(lines)[:3900],rows)
            return ConversationHandler.END
        if action in {'new','template','user'}:
            if action=='template':
                template=parts[2];kind=_creation.TEMPLATES[template][1];mode='template';user=None
            else:kind=parts[2];mode=parts[3] if action=='new' else 'guided';template='';user=parts[3] if action=='user' else None
            def create(db):
                row=_creation.create_draft(db,actor,kind,mode=mode,template=template,selected_user=user)
                if user:
                    parent=crm_case_parent(context,user)
                    callback=f'crm_open:{user}'
                    pieces=parent.split(':')
                    if pieces[0] in {'crm_pipeline_stage','crm_segment'}:
                        callback+=':'+('p' if pieces[0]=='crm_pipeline_stage' else 's')+':'+':'.join(pieces[1:])
                    elif pieces[0]=='funnel_users':callback+=':f:'+':'.join(pieces[1:])
                    db['admin_creation_drafts'][row['id']]['return_callback']=callback
                return row
            row=await async_with_db(create)
            return await creation_screen(update,context,row['id'])
        if action=='drafts':
            context.user_data.pop('creation_draft_id',None)
            db=await async_snapshot();rows=[]
            items=[r for r in db.get('admin_creation_drafts',{}).values() if r['actor']==str(actor) and r['status']=='draft']
            page=int(parts[2]) if len(parts)>2 else 0
            for row in sorted(items,key=lambda r:r['updated_at'],reverse=True)[page*8:page*8+8]:
                rows.append([InlineKeyboardButton(f"{_creation.KINDS[row['kind']]} | {row['values'].get('title','')}"[:60],callback_data=f"cw:resume:{row['id']}")])
            if (page+1)*8<len(items):rows.append([InlineKeyboardButton('صفحه بعد',callback_data=f'cw:drafts:{page+1}')])
            rows.append([InlineKeyboardButton('مرکز ساخت',callback_data='a_create')])
            await edit(q,'💾 <b>پیش‌نویس‌های شما</b>\nبرای ادامه یکی را انتخاب کنید.',rows);return CREATION_INPUT
        key=parts[2]
        if action=='back':
            row=await async_with_db(lambda db:dict(_creation.get_draft(db,actor,key)))
            if row['step']==0 and not row.get('editing'):
                context.user_data.pop('creation_draft_id',None)
                await edit(q,'پاسخ‌های شما ذخیره شده‌اند.',[[InlineKeyboardButton('ادامه همین پیش‌نویس',callback_data=f'cw:resume:{key}')],[InlineKeyboardButton('👤 پرونده همین کاربر' if row.get('return_callback') else 'مرکز ساخت',callback_data=row.get('return_callback') or 'a_create')]])
                return ConversationHandler.END
        if action=='publish':
            draft=await async_with_db(lambda db:dict(_creation.get_draft(db,actor,key)))
            result=await async_with_db(lambda db:_creation.publish(db,actor,key,int(parts[3])))
            context.user_data.pop('creation_draft_id',None)
            await edit(q,'✅ با موفقیت ثبت شد.\n'+('کد: <code>'+esc(result['code'])+'</code>' if result.get('code') else ''),[[InlineKeyboardButton('👤 پرونده همین کاربر' if draft.get('return_callback') else 'مرکز ساخت',callback_data=draft.get('return_callback') or 'a_create')]])
            return ConversationHandler.END
        if action=='edit':
            row=await async_with_db(lambda db:dict(_creation.get_draft(db,actor,key)))
            rows=[[InlineKeyboardButton(_creation.FIELDS[f][0].split('؟')[0][:55],callback_data=f'cw:field:{key}:{f}')] for f in _creation.fields(row)]
            if row['kind']=='discount':rows.append([InlineKeyboardButton('⚙️ ترکیب تخفیف‌ها',callback_data=f'cw:field:{key}:stackable')])
            rows.append([InlineKeyboardButton('⬅️ پیش‌نمایش',callback_data=f'cw:review:{key}')])
            await edit(q,'فقط موردی که می‌خواهید تغییر کند را انتخاب کنید.',rows);return CREATION_INPUT
        def mutate(db):
            row=_creation.get_draft(db,actor,key)
            if row['status']!='draft':raise ValueError('پیش‌نویس قبلاً نهایی شده است.')
            order=_creation.fields(row)
            if action=='answer':
                field=parts[3];expected=row.get('editing') or (order[int(row['step'])] if row['step']!='review' else '')
                if field!=expected:raise ValueError('این دکمه مربوط به مرحله قبلی است؛ از صفحه فعلی ادامه دهید.')
                choices=_creation.FIELDS[field][1];index=int(parts[4])
                if not 0<=index<len(choices):raise ValueError('گزینه نامعتبر است.')
                _creation.answer(db,actor,key,field,choices[index][1])
            elif action=='field':
                field=parts[3]
                if field not in order+['stackable']:raise ValueError('فیلد نامعتبر است.')
                row['editing']=field;row['step']=order.index(field) if field in order else 0
            elif action=='back':
                row['step']='review' if row.get('editing') else len(order)-1 if row['step']=='review' else max(0,int(row['step'])-1)
                row['editing']=None
            elif action=='review':row['step']='review';row['editing']=None
            elif action=='content_done':
                if not row.get('attachments') and not row['values'].get('content'):raise ValueError('ابتدا محتوا بفرستید.')
                _creation.answer(db,actor,key,'content',row['values'].get('content') or '-')
            elif action=='cancel_confirm':row['status']='cancelled'
            elif action not in {'save','cancel','resume'}:raise ValueError('دستور نامعتبر است.')
            row['updated_at']=utc_iso()
            return dict(row)
        row=await async_with_db(mutate)
        if action=='cancel' and (row['answered'] or row.get('attachments')):
            await edit(q,'پیش‌نویس حذف شود؟',[[InlineKeyboardButton('بله، لغو کن',callback_data=f'cw:cancel_confirm:{key}')],[InlineKeyboardButton('ادامه ویرایش',callback_data=f'cw:resume:{key}')]])
            return CREATION_INPUT
        if action in {'save','cancel_confirm'} or action=='cancel':
            if action=='cancel':await async_with_db(lambda db:_creation.get_draft(db,actor,key).update(status='cancelled'))
            context.user_data.pop('creation_draft_id',None)
            await edit(q,'💾 پیش‌نویس ذخیره شد.' if action=='save' else 'لغو شد.',[[InlineKeyboardButton('👤 پرونده همین کاربر' if row.get('return_callback') else 'مرکز ساخت',callback_data=row.get('return_callback') or 'a_create')]])
            return ConversationHandler.END
        return await creation_screen(update,context,key)
    except (ValueError,PermissionError,KeyError,IndexError) as exc:
        await edit(q,esc(str(exc)),[[InlineKeyboardButton('پیش‌نویس‌های من',callback_data='cw:drafts')],[InlineKeyboardButton('مرکز ساخت',callback_data='a_create')]])
        return CREATION_INPUT


async def creation_message(update,context):
    key=context.user_data.get('creation_draft_id');actor=update.effective_user.id
    if not key:
        await reply(update,'از مرکز ساخت، نوع آیتم را انتخاب کنید.',[[InlineKeyboardButton('مرکز ساخت',callback_data='a_create')]])
        return CREATION_INPUT
    try:
        row=await async_with_db(lambda db:dict(_creation.get_draft(db,actor,key)))
        if row['step']=='review':return await creation_screen(update,context,key)
        field=row.get('editing') or _creation.fields(row)[int(row['step'])]
        if field=='content':
            message=update.effective_message
            attachment=_lesson_attachment_from_message(message)
            text=str(message.text or '')
            if not attachment and text.startswith(('https://','http://')):attachment={'type':'link','url':text}
            def content(db):
                draft=_creation.get_draft(db,actor,key)
                if draft['status']!='draft':raise ValueError('پیش‌نویس نهایی شده است.')
                kind=attachment['type'] if attachment else 'text'
                if not has_permission(db,actor,f'education.create_{"image" if kind=="photo" else "document" if kind=="pdf" else kind}'):
                    raise PermissionError('مجوز این نوع محتوا را ندارید.')
                if getattr(message,'media_group_id',None) and not has_permission(db,actor,'education.create_media_group'):
                    raise PermissionError('مجوز آلبوم لازم است.')
                if attachment:
                    from modules.education import normalize_attachment
                    if len(draft['attachments'])>=20:raise ValueError('حداکثر ۲۰ فایل مجاز است.')
                    attachment['media_group_id']=str(getattr(message,'media_group_id','') or '')
                    normalized=normalize_attachment(attachment)
                    if not any(a['id']==normalized['id'] for a in draft['attachments']):draft['attachments'].append(normalized)
                elif text:draft['values']['content']=(str(draft['values'].get('content',''))+'\n'+text).strip()[:100000]
                else:raise ValueError('این نوع پیام پشتیبانی نمی‌شود.')
                draft['revision']+=1;draft['updated_at']=utc_iso()
            await async_with_db(content)
            if getattr(message,'media_group_id',None):return CREATION_INPUT
        else:await async_with_db(lambda db:_creation.answer(db,actor,key,field,str(update.effective_message.text or '')))
        return await creation_screen(update,context,key)
    except (ValueError,PermissionError) as exc:
        await reply(update,esc(str(exc)),[[InlineKeyboardButton('ادامه',callback_data=f'cw:resume:{key}')]])
        return CREATION_INPUT

__feature_exports__=('creation_screen','creation_callback','creation_message')
