from __future__ import annotations

import copy
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Generic, TypeVar

from core.db import (
    query_db_records,
    read_db_record,
    read_db_section,
    upsert_db_record,
    with_db_section,
)

T = TypeVar("T")

_METRIC_LOCK = threading.RLock()
_METRICS: dict[str, dict[str, float]] = {}


def _observe(section: str, operation: str, started: float) -> None:
    elapsed = max(0.0, time.perf_counter() - started)
    key = f"{section}:{operation}"
    with _METRIC_LOCK:
        row = _METRICS.setdefault(key, {"count": 0.0, "seconds": 0.0, "max_seconds": 0.0})
        row["count"] += 1
        row["seconds"] += elapsed
        row["max_seconds"] = max(row["max_seconds"], elapsed)


def repository_metrics() -> dict[str, dict[str, float]]:
    with _METRIC_LOCK:
        return copy.deepcopy(_METRICS)


@dataclass(slots=True)
class ListSectionRepository(Generic[T]):
    section: str
    id_field: str = "id"

    def all(self) -> list[T]:
        started = time.perf_counter()
        try:
            value = read_db_section(self.section)
            if not isinstance(value, list):
                raise TypeError(f"section {self.section} must be a list")
            return copy.deepcopy(value)
        finally:
            _observe(self.section, "all", started)

    def find(self, record_id: int | str) -> T | None:
        target = str(record_id)
        started = time.perf_counter()
        try:
            for row in self.all():
                if isinstance(row, dict) and str(row.get(self.id_field)) == target:
                    return copy.deepcopy(row)
            return None
        finally:
            _observe(self.section, "find", started)

    def recent(self, *, limit: int = 100) -> list[T]:
        started = time.perf_counter()
        try:
            return query_db_records(self.section, limit=limit, newest_first=True)
        finally:
            _observe(self.section, "recent_rows", started)

    def by_user(self, user_id: int | str, *, limit: int = 100) -> list[T]:
        started = time.perf_counter()
        try:
            return query_db_records(
                self.section,
                user_id=user_id,
                limit=limit,
                newest_first=True,
            )
        finally:
            _observe(self.section, "by_user_rows", started)

    def by_status(self, status: str, *, limit: int = 100) -> list[T]:
        started = time.perf_counter()
        try:
            return query_db_records(
                self.section,
                status=status,
                limit=limit,
                newest_first=True,
            )
        finally:
            _observe(self.section, "by_status_rows", started)

    def filter(self, predicate: Callable[[T], bool], *, limit: int | None = None) -> list[T]:
        started = time.perf_counter()
        try:
            output: list[T] = []
            for row in self.all():
                if predicate(row):
                    output.append(row)
                    if limit is not None and len(output) >= max(0, int(limit)):
                        break
            return output
        finally:
            _observe(self.section, "filter", started)

    def append(self, row: T) -> T:
        started = time.perf_counter()
        try:
            def mutate(items: Any) -> T:
                if not isinstance(items, list):
                    raise TypeError(f"section {self.section} must be a list")
                items.append(copy.deepcopy(row))
                return copy.deepcopy(row)

            return with_db_section(self.section, mutate)
        finally:
            _observe(self.section, "append", started)

    def update(self, record_id: int | str, mutator: Callable[[dict[str, Any]], T]) -> T:
        target = str(record_id)
        started = time.perf_counter()
        try:
            def mutate(items: Any) -> T:
                if not isinstance(items, list):
                    raise TypeError(f"section {self.section} must be a list")
                for row in items:
                    if isinstance(row, dict) and str(row.get(self.id_field)) == target:
                        return mutator(row)
                raise KeyError(record_id)

            return with_db_section(self.section, mutate)
        finally:
            _observe(self.section, "update", started)

    def remove(self, record_id: int | str) -> dict[str, Any] | None:
        target = str(record_id)
        started = time.perf_counter()
        try:
            def mutate(items: Any) -> dict[str, Any] | None:
                if not isinstance(items, list):
                    raise TypeError(f"section {self.section} must be a list")
                for index, row in enumerate(items):
                    if isinstance(row, dict) and str(row.get(self.id_field)) == target:
                        removed = items.pop(index)
                        return copy.deepcopy(removed)
                return None

            return with_db_section(self.section, mutate)
        finally:
            _observe(self.section, "remove", started)


@dataclass(slots=True)
class DictSectionRepository(Generic[T]):
    section: str

    def all(self) -> dict[str, T]:
        started = time.perf_counter()
        try:
            value = read_db_section(self.section)
            if not isinstance(value, dict):
                raise TypeError(f"section {self.section} must be a dictionary")
            return copy.deepcopy(value)
        finally:
            _observe(self.section, "all", started)

    def get(self, key: int | str, default: T | None = None) -> T | None:
        started = time.perf_counter()
        try:
            value = read_db_record(self.section, key)
            return copy.deepcopy(default if value is None else value)
        finally:
            _observe(self.section, "get", started)

    def set(self, key: int | str, value: T) -> T:
        started = time.perf_counter()
        try:
            return upsert_db_record(self.section, key, value)
        finally:
            _observe(self.section, "set", started)

    def update(self, key: int | str, mutator: Callable[[Any], T], *, default_factory: Callable[[], Any] = dict) -> T:
        target = str(key)
        started = time.perf_counter()
        try:
            def mutate(items: Any) -> T:
                if not isinstance(items, dict):
                    raise TypeError(f"section {self.section} must be a dictionary")
                current = items.setdefault(target, default_factory())
                return mutator(current)

            return with_db_section(self.section, mutate)
        finally:
            _observe(self.section, "update", started)

    def remove(self, key: int | str) -> T | None:
        target = str(key)
        started = time.perf_counter()
        try:
            def mutate(items: Any) -> T | None:
                if not isinstance(items, dict):
                    raise TypeError(f"section {self.section} must be a dictionary")
                value = items.pop(target, None)
                return copy.deepcopy(value)

            return with_db_section(self.section, mutate)
        finally:
            _observe(self.section, "remove", started)
