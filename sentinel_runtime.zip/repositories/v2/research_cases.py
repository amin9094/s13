"""Immutable bounded research inputs, separate from live and paper decisions."""
import time
from core.storage.engine import normalized_engine
from modules.research_context import encode
from repositories.v2.common import json_dump,json_load,content_hash
from repositories.v2.live_signal_inbox import page_cursor


class ResearchCases:
    def __init__(self,engine=None):self.engine=engine or normalized_engine()

    def capture(self,context,result,*,quote_epoch=None):
        observations=[]
        if len(context.closed)>=105:
            from modules.indicator_suite import indicators,agreement
            stats=indicators(context.closed)
            for direction in ('BUY','SELL'):
                _,votes=agreement(stats,direction,context.indicator_selection)
                observations.append({'direction':direction,'votes':votes,'failed':[k for k,v in votes.items() if not v]})
        candidates=[]
        for row in result.get('results',[]):
            plan=row.get('plan') or row.get('draft_plan')
            if plan:candidates.append((plan['setup_id'],plan))
        # A diagnostic capture is never enrolled or published. Retain only a
        # bounded recent sample of explicitly rejected engine observations.
        diagnostics=[r for r in result.get('results',[]) if not (r.get('plan') or r.get('draft_plan')) and r.get('reason')][:8]
        diagnostics += [{'engine':'indicators','state':'DIAGNOSTIC_ONLY','reason':'NEAR_AGREEMENT_NOT_A_VALID_ENTRY','observation':r}
                        for r in observations if r['votes'] and len(r['failed'])<=1 and not candidates]
        if not candidates and not diagnostics:return {'state':'NO_LOCKED_PROPOSAL'}
        bundle=encode(context)
        keys=sorted({x[0] for x in candidates}) or ['diagnostic:'+content_hash({'symbol':context.candles[-1].symbol,'timeframe':context.candles[-1].timeframe,
            'last_closed_source_id':context.closed[-1].source_id,'rows':diagnostics,'parameters':bundle['input']['parameters'],
            'engine_profiles':bundle['input']['engine_parameters'],'selection':context.indicator_selection})]
        with self.engine.transaction(read_only=True) as c:
            existing=c.execute('SELECT source_key,case_id FROM s9_research_links WHERE source_key IN ('+','.join('?' for _ in keys)+')',keys).fetchall()  # nosec B608 -- bound placeholders only
        if len(existing)==len(keys):return {'state':'ALREADY_RECORDED','case_id':existing[0]['case_id']}
        from modules.research_regime import classify
        body={'bundle':bundle,'original_results':result,'quote_epoch':quote_epoch,
              'kind':'PROPOSAL' if candidates else 'DIAGNOSTIC_ONLY','regime':classify(context.closed),
              'indicator_observations':observations,'near_misses':diagnostics}
        text=json_dump(body);size=len(text.encode('utf-8'))
        if size>24_000_000:return {'state':'INPUT_SIZE_LIMIT','bytes':size}
        identifier=content_hash(body)[:32];last=context.candles[-1]
        with self.engine.transaction() as c:
            if self.engine.dialect.name=='postgres':c.execute('SELECT pg_advisory_xact_lock(719084412)')
            used=c.execute('SELECT COALESCE(SUM(LENGTH(payload)),0) AS n FROM s9_research_cases').fetchone()['n']
            if not candidates and used+size>40_000_000:return {'state':'DIAGNOSTIC_STORAGE_BUDGET_REACHED'}
            if used+size>400_000_000:return {'state':'RESEARCH_STORAGE_BUDGET_REACHED'}
            c.execute('INSERT INTO s9_research_cases(id,symbol,timeframe,created_ms,payload) VALUES(?,?,?,?,?) ON CONFLICT DO NOTHING',
                (identifier,last.symbol,last.timeframe,context.cutoff_ms,text))
            for key in keys:c.execute('INSERT INTO s9_research_links(source_key,case_id) VALUES(?,?) ON CONFLICT DO NOTHING',(key,identifier))
        return {'state':'RECORDED','case_id':identifier,'input_hash':content_hash(bundle)}

    def get(self,key):
        with self.engine.transaction(read_only=True) as c:r=c.execute('SELECT * FROM s9_research_cases WHERE id=?',(key,)).fetchone()
        if not r:return None
        payload=json_load(r['payload'])
        if content_hash(payload)[:32]!=r['id']:raise ValueError('RESEARCH_INPUT_HASH_MISMATCH')
        return {**r,'payload':payload}

    def page(self,before=None):
        stamp,key=page_cursor(before)
        with self.engine.transaction(read_only=True) as c:rows=c.execute('SELECT id,symbol,timeframe,created_ms FROM s9_research_cases WHERE created_ms<? OR (created_ms=? AND id<?) ORDER BY created_ms DESC,id DESC LIMIT 40',(stamp,stamp,key)).fetchall()
        return {'items':rows,'next_before':f"{rows[-1]['created_ms']}:{rows[-1]['id']}" if len(rows)==40 else None}
