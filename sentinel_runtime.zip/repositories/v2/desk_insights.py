"""Bounded private conflict lookup and measured discovery counters."""
import time
from uuid import uuid4
from repositories.v2.common import json_dump, json_load


def annotate_relations(inbox, items):
    if not items:
        return
    from repositories.v2.live_signal_inbox import global_inbox_scope
    from modules.desk_presentation import presentation_group
    symbols = sorted({r['payload']['plan']['symbol'] for r in items})
    scope, values = global_inbox_scope(inbox.engine, 'i.')
    field = "CAST(i.payload AS JSONB)->'plan'->>'symbol'" if inbox.engine.dialect.name == 'postgres' else "json_extract(i.payload,'$.plan.symbol')"
    query = ("SELECT i.id,i.created_ms,i.state,i.payload FROM s9_signal_inbox i WHERE " + scope  # nosec B608  # fixed JSON expression; symbols/timestamps are bound
             + " AND i.state IN ('PENDING','QUEUED','PUBLISHED') AND " + field + " IN ("
             + ','.join('?' for _ in symbols) + ") AND i.created_ms BETWEEN ? AND ? ORDER BY i.created_ms DESC,i.id DESC LIMIT 1001")  # nosec B608 -- fixed expressions, bound symbols
    with inbox.engine.transaction(read_only=True) as c:
        matches = c.execute(query, (*values, *symbols, min(r['created_ms'] for r in items)-3600000,
                                    max(r['created_ms'] for r in items)+3600000)).fetchall()
    candidates = [(r, json_load(r['payload'])['plan']) for r in matches[:1000]]
    for row in items:
        plan = row['payload']['plan']; group = presentation_group(plan)
        neighbors = [(r, p) for r, p in candidates if r['id'] != row['id'] and p['symbol'] == plan['symbol']
                     and abs(r['created_ms']-row['created_ms']) <= 3600000]
        row['relations'] = {
            'conflicts': [{'id': r['id'], 'engine': p['engine'], 'direction': p['direction'],
                           'timeframe': p['timeframe'], 'entry': p['entry'], 'stop': p['stop']}
                          for r, p in neighbors if p['direction'] != plan['direction']][:20],
            'display_group': group,
            'similar_count': sum(presentation_group(p) == group for _, p in neighbors),
            'truncated': len(matches) > 1000, 'automatic_cancellation': False}


def record_scan(engine, symbol, timeframe, result, *, operation_id=None):
    stamp = int(time.time()*1000)
    groups = {}
    for row in result.get('results', []):
        name = row.get('engine', 'market_data')
        counts = groups.setdefault(name, {'evaluated': 0, 'ready': 0, 'review': 0, 'rejected': 0})
        counts['evaluated'] += 1
        counts['ready' if row.get('plan') else 'review' if row.get('draft_plan') or row.get('state') == 'NEEDS_REVIEW' else 'rejected'] += 1
    from core.logging_context import correlation_id
    key = operation_id or uuid4().hex
    with engine.transaction() as c:
        c.execute('INSERT INTO s9_scan_observations VALUES(?,?,?,?,?) ON CONFLICT DO NOTHING',
                  (key, symbol, timeframe, stamp, json_dump({'engines': groups, 'state': result.get('state'),'operation_id':correlation_id() or key})))
        c.execute('DELETE FROM s9_scan_observations WHERE at_ms<?', (stamp-30*86400000,))
    return key


def funnel(engine):
    now = int(time.time()*1000); groups = {}; observed = None
    with engine.transaction(read_only=True, repeatable_read=True) as c:
        cursor = (-1, '')
        while True:
            rows = c.execute('SELECT * FROM s9_scan_observations WHERE at_ms>=? AND (at_ms>? OR (at_ms=? AND id>?)) ORDER BY at_ms,id LIMIT 200',
                             (now-86400000, cursor[0], cursor[0], cursor[1])).fetchall()
            for row in rows:
                observed = min(observed, row['at_ms']) if observed is not None else row['at_ms']
                for name, counts in json_load(row['payload'])['engines'].items():
                    target = groups.setdefault(name, {k: 0 for k in ('evaluated', 'ready', 'review', 'rejected')})
                    for k in target:
                        target[k] += counts.get(k, 0)
            if len(rows) < 200:
                break
            cursor = (rows[-1]['at_ms'], rows[-1]['id'])
        from repositories.v2.live_signal_inbox import global_inbox_scope
        scope, values = global_inbox_scope(engine, 'i.')
        query = 'SELECT i.engine,i.state,COUNT(*) AS n FROM s9_signal_inbox i WHERE '+scope+" AND i.state!='STAGING' GROUP BY i.engine,i.state"  # nosec B608 -- fixed scope
        states = c.execute(query, values).fetchall()
        trades = c.execute('SELECT r.engine,t.state,COUNT(*) AS n FROM s9_strategy_paper_trades t JOIN s9_strategy_paper_runs r ON r.id=t.run_id WHERE r.active=1 GROUP BY r.engine,t.state').fetchall()
    return {'observed_ms': now, 'scans_since_ms': observed,
            'scan_coverage': 'MEASURED_LAST_24H' if observed is not None else 'NOT_RECORDED',
            'scans': groups or None, 'inbox_states': states, 'active_paper_states': trades,
            'counts_are_cumulative_stages': False, 'historic_scan_count': None}
