"""Immutable, idempotent facts shared by desk, publication and paper ledgers."""
from repositories.v2.common import json_dump,json_load,content_hash


def record(c,signal_id,kind,at_ms,detail=None,*,key=None):
    if type(at_ms) is not int or at_ms<0:raise ValueError('SIGNAL_EVENT_TIME_INVALID')
    detail=detail or {}
    identity=content_hash([signal_id,kind,key if key is not None else [at_ms,detail]])[:32]
    from core.logging_context import operation_id
    detail={**detail,'operation_id':operation_id('signal:'+str(signal_id))}
    c.execute('''INSERT INTO s9_signal_timeline(id,signal_id,kind,at_ms,payload)
        VALUES(?,?,?,?,?) ON CONFLICT(id) DO NOTHING''',(identity,signal_id,kind,at_ms,json_dump(detail)))


def page(c,signal_id,*,after_ms=0,limit=200):
    return [{**r,'payload':json_load(r['payload'])} for r in c.execute(
        'SELECT * FROM s9_signal_timeline WHERE signal_id=? AND at_ms>=? ORDER BY at_ms,id LIMIT ?',
        (signal_id,after_ms,max(1,min(500,limit)))).fetchall()]


def timing(c,row,paper=None):
    events=page(c,row['id']);first={}
    for e in events:first.setdefault(e['kind'],e['at_ms'])
    read=c.execute('SELECT MIN(read_ms) AS stamp FROM s9_signal_reads WHERE signal_id=?',(row['id'],)).fetchone()
    stamps={'staged_ms':row['created_ms'],'available_ms':first.get('AVAILABLE'),
            'quote_received_ms':first.get('DATA_QUOTE'),'analysis_ready_ms':first.get('ANALYSIS_READY'),
            'first_seen_ms':read['stamp'] if read else None,'decision_ms':first.get('REVIEW_DECISION'),
            'published_ms':first.get('PUBLISHED'),'paper_entry_ms':(paper or {}).get('entered_ms'),
            'first_zone_touch_ms':first.get('FIRST_ZONE_TOUCH')}
    def difference(a,b):
        x,y=stamps.get(a),stamps.get(b)
        return x-y if x is not None and y is not None and x>=y else None
    return {**stamps,'quote_to_available_ms':difference('available_ms','quote_received_ms'),
            'available_to_seen_ms':difference('first_seen_ms','available_ms'),
            'available_to_entry_ms':difference('paper_entry_ms','available_ms'),
            'events':events,'is_price_arrival_prediction':False}
