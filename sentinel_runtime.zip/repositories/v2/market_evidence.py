from __future__ import annotations

import time
from hashlib import sha256
from core.storage.engine import normalized_engine
from modules.canonical_market import Candle
from repositories.v2.common import json_dump, json_load




class MarketEvidenceRepository:
    def __init__(self, engine=None):
        self.engine = engine or normalized_engine()

    def save_candles(self, rows):
        if not rows:
            return 0
        grouped = {}
        for row in rows:
            grouped.setdefault((row.symbol, row.provider, row.timeframe), []).append(row)
        correction = False
        pending_writes = []
        with self.engine.transaction() as cursor:
            for key, group in sorted(grouped.items()):
                if self.engine.dialect.name == "postgres":
                    # Serialize matching markets without holding a session lease.
                    cursor.execute("SELECT pg_advisory_xact_lock(hashtextextended(?,0))", ("sentinel-candles:" + ":".join(key),))
                existing_rows = cursor.execute(
                    "SELECT start_ms,payload FROM s9_candles WHERE symbol=? AND provider=? AND timeframe=? AND start_ms>=? AND start_ms<=?",
                    (*key, min(row.start_ms for row in group), max(row.start_ms for row in group)),
                ).fetchall()
                existing = {row["start_ms"]: Candle.from_dict(json_load(row["payload"])) for row in existing_rows}
                writes = []
                for row in group:
                    old = existing.get(row.start_ms)
                    if old:
                        if (old.venue, old.product, old.volume_kind, old.alignment_offset_ms) != (row.venue, row.product, row.volume_kind, row.alignment_offset_ms):
                            raise ValueError("CANDLE_PROVENANCE_CHANGE_REQUIRES_REVIEW")
                        if old.is_closed:
                            if not row.is_closed or row.available_ms < old.available_ms:
                                raise ValueError("CLOSED_CANDLE_REOPEN_OR_STALE_REVISION_REQUIRES_REVIEW")
                            if (old.open, old.high, old.low, old.close, old.volume) != (row.open, row.high, row.low, row.close, row.volume):
                                # Record both versions before rejecting this batch. The
                                # original evidence stays unchanged until an explicit,
                                # audited administrator decision accepts the revision.
                                self._record_revision(cursor, old, row)
                                correction = True
                                continue
                            continue
                        if row.available_ms < old.available_ms:
                            continue
                    writes.append((row.symbol, row.provider, row.timeframe, row.start_ms, row.end_ms, json_dump(row.as_dict())))
                if writes:
                    pending_writes.extend(writes)
            if not correction and pending_writes:
                cursor.executemany(
                    """INSERT INTO s9_candles(symbol,provider,timeframe,start_ms,end_ms,payload)
                    VALUES(?,?,?,?,?,?) ON CONFLICT(symbol,provider,timeframe,start_ms) DO UPDATE SET
                    end_ms=excluded.end_ms,payload=excluded.payload""", pending_writes,
                )
            cutoff = max(row.available_ms for row in rows) - 180 * 86400000
            cursor.execute("DELETE FROM s9_candles WHERE end_ms < ?", (cutoff,))
        if correction:
            raise ValueError("CLOSED_CANDLE_CORRECTION_REQUIRES_REVIEW")
        return len(rows)

    def candles(self, symbol, provider, timeframe, *, before_ms=None, limit=500):
        with self.engine.transaction(read_only=True) as cursor:
            records = cursor.execute(
                """SELECT payload FROM s9_candles WHERE symbol=? AND provider=? AND timeframe=?
              AND start_ms < ? ORDER BY start_ms DESC LIMIT ?""",
                (symbol, provider, timeframe, before_ms or 9223372036854775807, max(1, min(int(limit), 5000))),
            ).fetchall()
        return [Candle.from_dict(json_load(row["payload"])) for row in reversed(records)]

    @staticmethod
    def _revision_key(old, new):
        fields = ('symbol','provider','venue','product','timeframe','start_ms','end_ms',
                  'open','high','low','close','volume','volume_kind','alignment_offset_ms')
        identity = [[b.as_dict().get(k) for k in fields] for b in (old,new)]
        return sha256(json_dump(identity).encode()).hexdigest()[:32]

    def _record_revision(self, cursor, old, new):
        key = self._revision_key(old,new)
        cursor.execute("""UPDATE s9_candle_revisions SET state='SUPERSEDED' WHERE symbol=? AND provider=?
            AND timeframe=? AND start_ms=? AND state='PENDING' AND id!=?""",
            (new.symbol,new.provider,new.timeframe,new.start_ms,key))
        cursor.execute("""INSERT INTO s9_candle_revisions(id,symbol,provider,timeframe,start_ms,state,observed_ms,payload)
            VALUES(?,?,?,?,?,'PENDING',?,?) ON CONFLICT(id) DO UPDATE SET state='PENDING',observed_ms=excluded.observed_ms WHERE s9_candle_revisions.state='SUPERSEDED'""",
            (key,new.symbol,new.provider,new.timeframe,new.start_ms,int(time.time()*1000),
             json_dump({'old':old.as_dict(),'new':new.as_dict()})))

    def pending_revisions(self, symbol, provider=None, timeframe=None):
        with self.engine.transaction(read_only=True) as c:
            rows=c.execute("""SELECT * FROM s9_candle_revisions WHERE symbol=? AND state='PENDING'
                AND (?='' OR provider=?) AND (?='' OR timeframe=?) ORDER BY start_ms,id LIMIT 2000""",
                (symbol,provider or '',provider or '',timeframe or '',timeframe or '')).fetchall()
        return [{**r,'payload':json_load(r['payload'])} for r in rows]

    def accept_revisions(self, identifiers, *, actor):
        if not identifiers or len(identifiers)>2000 or len(set(identifiers))!=len(identifiers):
            raise ValueError('CANDLE_REVISION_SELECTION_INVALID')
        families=set()
        with self.engine.atomic() as c:
            # Same lock order as writers: family first, then individual rows.
            if self.engine.dialect.name=='postgres':
                lock_families=set()
                for key in sorted(identifiers):
                    r=c.execute('SELECT symbol,provider,timeframe FROM s9_candle_revisions WHERE id=?',(key,)).fetchone()
                    if not r:raise ValueError('CANDLE_REVISION_CHANGED')
                    lock_families.add((r['symbol'],r['provider'],r['timeframe']))
                for family in sorted(lock_families):
                    c.execute('SELECT pg_advisory_xact_lock(hashtextextended(?,0))',('sentinel-candles:'+':'.join(family),))
            for key in sorted(identifiers):
                sql='SELECT * FROM s9_candle_revisions WHERE id=?'
                if self.engine.dialect.name=='postgres':sql+=' FOR UPDATE'
                r=c.execute(sql,(key,)).fetchone()
                if not r or r['state']!='PENDING':raise ValueError('CANDLE_REVISION_CHANGED')
                p=json_load(r['payload']);old=Candle.from_dict(p['old']);new=Candle.from_dict(p['new'])
                family=(r['symbol'],r['provider'],r['timeframe'])
                stored=c.execute('SELECT payload FROM s9_candles WHERE symbol=? AND provider=? AND timeframe=? AND start_ms=?',
                    (*family,r['start_ms'])).fetchone()
                if not stored or Candle.from_dict(json_load(stored['payload']))!=old:
                    raise ValueError('CANDLE_REVISION_BASE_CHANGED')
                c.execute('UPDATE s9_candles SET end_ms=?,payload=? WHERE symbol=? AND provider=? AND timeframe=? AND start_ms=?',
                    (new.end_ms,json_dump(new.as_dict()),*family,new.start_ms))
                # Both exact versions remain archived permanently in this row.
                p['decision']={'actor':str(actor),'accepted_ms':int(time.time()*1000)}
                c.execute("UPDATE s9_candle_revisions SET state='ACCEPTED',payload=? WHERE id=? AND state='PENDING'",
                    (json_dump(p),key))
                families.add(family)
        return sorted(families)
