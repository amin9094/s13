"""Per-strategy $5000 simulations with entry-time 1% risk and audited controls."""
from copy import deepcopy
from repositories.v2 import paper_statistics
import csv
import io
import re
import time
import uuid
from decimal import Decimal as D
from core.storage.engine import normalized_engine
from repositories.v2.common import json_dump,json_load,utc_iso
from repositories.v2.live_signal_inbox import STRATEGIES,page_cursor
from modules.strategy_paper import advance,close_manually,open_market
from modules.signal_execution import account_identity,account_key,mode_of

STARTING_BALANCE=D(5000)
RISK_POLICY='ONE_PERCENT_ENTRY_BALANCE_V2'


class StrategyPaperRepository:
    def __init__(self,engine=None):self.engine=engine or normalized_engine()

    def _lock(self,c,run_id):
        query=('SELECT * FROM s9_strategy_paper_runs WHERE id=? FOR UPDATE'
               if self.engine.dialect.name=='postgres' else 'SELECT * FROM s9_strategy_paper_runs WHERE id=?')
        r=c.execute(query,(run_id,)).fetchone()
        return {**r,'payload':json_load(r['payload'])} if r else None

    def _save_run(self,c,run,p):
        c.execute('UPDATE s9_strategy_paper_runs SET payload=?,revision=revision+1 WHERE id=?',
                  (json_dump(p),run['id']))
        run['payload']=p;run['revision']+=1

    def _upgrade(self,c,run):
        """Add capital once; do not rewrite historical P/L or existing open sizes."""
        p=run['payload']
        if not run['active'] or p.get('risk_policy')==RISK_POLICY:return run
        original=D(p['starting_balance']);addition=max(D(0),STARTING_BALANCE-original)
        p.update(starting_balance=str(original+addition),balance=str(D(p['balance'])+addition),
                 risk_percent='1',risk_policy=RISK_POLICY,entries_enabled=p.get('entries_enabled',True),control_revision=1)
        p['peak_balance']=str(max(D(p['balance']),D(p.get('peak_balance',str(original)))+addition))
        p.setdefault('max_balance_drawdown_usd','0')
        p.setdefault('audit',[]).append({'type':'CAPITAL_AND_RISK_UPGRADE','at_ms':int(time.time()*1000),
                    'capital_added_usd':str(addition),'previous_starting_balance':str(original),
                    'actor':'SYSTEM_USER_REQUEST','open_sizes_preserved':True})
        self._save_run(c,run,p)
        return run

    @staticmethod
    def _book_values(p,delta):
        balance=D(p['balance'])+delta
        peak=max(D(p.get('peak_balance',p['starting_balance'])),balance)
        p.update(balance=str(balance),peak_balance=str(peak),
                 max_balance_drawdown_usd=str(max(D(p.get('max_balance_drawdown_usd','0')),peak-balance)))
        return p

    def _book(self,c,run,delta):
        self._save_run(c,run,self._book_values(run['payload'],delta))

    def ensure(self,engine):
        base,mode=account_identity(engine)
        with self.engine.transaction() as c:
            identifier=uuid.uuid4().hex;now=int(time.time()*1000)
            payload={'starting_balance':'5000','balance':'5000','risk_percent':'1','profile_id':None,
                     'strategy':base,'execution_mode':mode,
                     'risk_policy':RISK_POLICY,'entries_enabled':True,'control_revision':1,'audit':[],
                     'peak_balance':'5000','max_balance_drawdown_usd':'0',
                     'currency':'USD','model':'R_NORMALIZED_VIRTUAL_USD','fees_included':False,
                     'participation_policy':'ALL_VALID_SIGNALS_INDEPENDENT_OF_PUBLICATION',
                     'partials':'HALF_REMAINING_AT_TP_LAST_CLOSES_ALL','reset_actor':None}
            c.execute('''INSERT INTO s9_strategy_paper_runs(id,engine,active,created_ms,payload)
                VALUES(?,?,1,?,?) ON CONFLICT DO NOTHING''',(identifier,engine,now,json_dump(payload)))
            r=c.execute('SELECT id FROM s9_strategy_paper_runs WHERE engine=? AND active=1',(engine,)).fetchone()
            run=self._upgrade(c,self._lock(c,r['id']))
        return run

    def active(self,engine):
        account_identity(engine)
        with self.engine.transaction(read_only=True) as c:
            row=c.execute('SELECT * FROM s9_strategy_paper_runs WHERE engine=? AND active=1',(engine,)).fetchone()
        if row:
            run={**row,'payload':json_load(row['payload'])}
            if run['payload'].get('risk_policy')==RISK_POLICY:return run
        return self.ensure(engine)

    def enroll(self,inbox,baseline):
        mode=mode_of(inbox['payload']['plan']);key=account_key(inbox['engine'],mode)
        run=self.active(key)
        with self.engine.transaction() as c:
            run=self._lock(c,run['id'])
            if not run['active']:return {'state':'ACCOUNT_CHANGED'}
            existing=c.execute('SELECT id,run_id,state FROM s9_strategy_paper_trades WHERE signal_id=?',(inbox['id'],)).fetchone()
            if existing:return {'state':'ALREADY_RECORDED','trade_id':existing['id'],'run_id':existing['run_id'],'trade_state':existing['state']}
            profile=inbox['payload'].get('profile_id')
            if not profile:return {'state':'PROFILE_UNCLASSIFIED'}
            # Every valid signal participates. Frozen per-trade profile IDs
            # retain separate statistics without resetting capital or changing
            # the account's original profile/configuration.
            if run['payload'].get('profile_id') is None:
                run['payload']['profile_id']='MARKET_ANALYSIS_PROFILES' if mode=='MARKET' else 'CUSTOM_CONFIGURATIONS' if inbox['engine']=='custom' else profile
                c.execute('UPDATE s9_strategy_paper_runs SET payload=?,revision=revision+1 WHERE id=?',
                          (json_dump(run['payload']),run['id']))
            plan=inbox['payload']['plan'];balance=D(run['payload']['balance'])
            bid,ask=D(baseline['bid']),D(baseline['ask'])
            if not bid.is_finite() or not ask.is_finite() or bid<=0 or ask<bid:
                raise ValueError('PAPER_QUOTE_INVALID')
            if mode=='MARKET':
                now=int(time.time()*1000)
                if not 0<=now-baseline['event_ms']<=5000 or not 0<=now-baseline['received_ms']<=5000:
                    raise ValueError('PAPER_MARKET_CURRENT_QUOTE_REQUIRED')
            above=(plan['direction']=='BUY') != (plan['submodel']=='range_breakout')
            if mode=='PENDING' and not (bid>D(plan['zone_high']) if above else ask<D(plan['zone_low'])):
                # An already visited zone cannot be armed for a second touch.
                raise ValueError('PAPER_ORIGINAL_ZONE_NOT_AHEAD_AT_ARMING')
            estimate=max(D(0),balance)/100
            state='WAITING' if run['payload'].get('entries_enabled',True) else 'PAUSED'
            identifier=uuid.uuid4().hex
            p={'plan':plan,'signal_id':inbox['id'],'run_id':run['id'],'state':state,'execution_mode':mode,
               'profile_id':inbox['payload'].get('profile_id'),'risk_usd':'0','estimated_risk_usd':str(estimate),
               'risk_percent':'1','sizing_policy':RISK_POLICY,'armed_ms':int(time.time()*1000),
               'realized_usd':'0','unrealized_usd':'0','remaining':'1','targets_hit':[], 'events':[],
               'epoch':baseline['epoch'],'last_tick_id':baseline['id'],
               'last_quote':{k:baseline[k] for k in ('bid','ask','event_ms','received_ms')},
               'last_received_ms':baseline['received_ms'],'last_event_ms':baseline['event_ms'],
               'source_kind':inbox['payload']['kind'],'source_quality': 'INDICATIVE' if inbox['payload']['kind']=='review' else 'NATIVE_BOOK',
               'participation_policy':'ALL_VALID_SIGNALS_INDEPENDENT_OF_PUBLICATION',
               'fees_included':False,'cost_model':run['payload'].get('cost_models',{}).get(plan['symbol'])}
            linked=c.execute('SELECT r.payload FROM s9_research_links l JOIN s9_research_cases r ON r.id=l.case_id WHERE l.source_key=?',(plan.get('setup_id',''),)).fetchone()
            p['market_regime']=json_load(linked['payload']).get('regime') if linked else None
            from modules.research_context import implementation_hash
            p['implementation_hash']=implementation_hash()
            if state=='PAUSED':p.update(reason='ADMIN_ENTRIES_PAUSED_NO_RETROACTIVE_FILL')
            elif mode=='MARKET':
                p=open_market(p,baseline,balance);state=p['state']
                if D(p['realized_usd']):self._book(c,run,D(p['realized_usd']))
            c.execute('''INSERT INTO s9_strategy_paper_trades(id,run_id,signal_id,state,created_ms,payload)
                VALUES(?,?,?,?,?,?) ON CONFLICT(signal_id) DO NOTHING''',
                (identifier,run['id'],inbox['id'],state,int(time.time()*1000),json_dump(p)))
            if c.rowcount:paper_statistics.changed(c,run['id'],None,p)
            from repositories.v2.signal_timeline import record
            record(c,inbox['id'],'DATA_QUOTE',baseline['received_ms'],{'event_ms':baseline['event_ms']},key='arming')
            return {'state':'RECORDED','trade_id':identifier,'run_id':run['id'],'trade_state':state,
                    'profile_id':profile,'cohort_policy':'FROZEN_PROFILE_PER_TRADE'}

    def active_trades(self, *, after=None, limit=1000):
        stamp,key=page_cursor(after) if after else (0,'')
        with self.engine.transaction(read_only=True) as c:
            rows=c.execute("""SELECT * FROM s9_strategy_paper_trades WHERE state IN ('WAITING','OPEN')
                AND (created_ms>? OR (created_ms=? AND id>?)) ORDER BY created_ms,id LIMIT ?""",
                (stamp,stamp,key,max(1,min(1000,int(limit))))).fetchall()
        return [{**r,'payload':json_load(r['payload'])} for r in rows]

    def tracking_batch(self, *, limit=100):
        with self.engine.transaction(read_only=True) as c:
            row=c.execute("SELECT value FROM v8_meta WHERE key='strategy_paper_tracking_cursor'").fetchone()
        cursor=json_load(row['value'],{}) if row else {}
        rows=self.active_trades(after=cursor.get('after'),limit=limit)
        return rows or self.active_trades(limit=limit)

    def advance_tracking_cursor(self, trade):
        with self.engine.transaction() as c:
            c.execute('''INSERT INTO v8_meta(key,value,updated_at) VALUES(?,?,?)
                ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at''',
                ('strategy_paper_tracking_cursor',json_dump({'after':f"{trade['created_ms']}:{trade['id']}"}),utc_iso()))

    def tick(self,identifier,tick):
        return self.tick_batch(identifier,[tick])

    def tick_batch(self,identifier,ticks):
        if len(ticks)>2000:raise ValueError('PAPER_BATCH_TOO_LARGE')
        if not ticks:return
        with self.engine.transaction() as c:
            initial=c.execute('SELECT run_id FROM s9_strategy_paper_trades WHERE id=?',(identifier,)).fetchone()
            if not initial:return
            run=self._upgrade(c,self._lock(c,initial['run_id']))
            row=c.execute('SELECT * FROM s9_strategy_paper_trades WHERE id=?',(identifier,)).fetchone()
            if not run['active'] or row['state'] not in {'WAITING','OPEN'}:return
            p=json_load(row['payload']);original=deepcopy(p)
            from repositories.v2.signal_timeline import record
            for tick in ticks:
                if p['state'] not in {'WAITING','OPEN'}:break
                if p['state']=='WAITING':p['entry_balance_usd']=run['payload']['balance']
                event_count=len(p['events']);p,delta=advance(p,tick)
                for event in p['events'][event_count:]:
                    if event['type']!='COST':record(c,row['signal_id'],'PAPER_'+event['type'],event['at_ms'],event)
                self._book_values(run['payload'],delta)
            c.execute('UPDATE s9_strategy_paper_trades SET state=?,payload=?,revision=revision+1 WHERE id=? AND revision=?',
                      (p['state'],json_dump(p),identifier,row['revision']))
            if c.rowcount!=1:raise ValueError('PAPER_CONCURRENT_TICK')
            paper_statistics.changed(c,run['id'],original,p)
            self._save_run(c,run,run['payload'])

    def suspend(self,identifier,reason):
        with self.engine.transaction() as c:
            row=c.execute('SELECT run_id,state,payload FROM s9_strategy_paper_trades WHERE id=?',(identifier,)).fetchone()
            if row:
                self._lock(c,row['run_id'])
                row=c.execute('SELECT run_id,state,payload FROM s9_strategy_paper_trades WHERE id=?',(identifier,)).fetchone()
                p=json_load(row['payload']);original=deepcopy(p);p.update(state='NEEDS_REVIEW',reason=reason)
                c.execute("UPDATE s9_strategy_paper_trades SET state='NEEDS_REVIEW',payload=?,revision=revision+1 WHERE id=? AND state IN ('WAITING','OPEN')",(json_dump(p),identifier))
                if c.rowcount:paper_statistics.changed(c,row['run_id'],original,p)

    def cancel_waiting(self,signal_id,*,reason):
        """Technical invalidation only; an editorial rejection is independent."""
        with self.engine.transaction() as c:
            row=c.execute('SELECT run_id,state,payload FROM s9_strategy_paper_trades WHERE signal_id=?',(signal_id,)).fetchone()
            if row:
                self._lock(c,row['run_id'])
                row=c.execute('SELECT run_id,state,payload FROM s9_strategy_paper_trades WHERE signal_id=?',(signal_id,)).fetchone()
                p=json_load(row['payload']);original=deepcopy(p);p.update(state='CANCELLED',reason=reason)
                c.execute("UPDATE s9_strategy_paper_trades SET state='CANCELLED',payload=?,revision=revision+1 WHERE signal_id=? AND state='WAITING'",(json_dump(p),signal_id))
                if c.rowcount:paper_statistics.changed(c,row['run_id'],original,p)

    def reset(self,engine,*,actor,expected_run_id,risk_percent=None,profile_id=None):
        risk=D(str(risk_percent)) if risk_percent is not None else None
        if risk is not None and (not risk.is_finite() or risk!=1):raise ValueError('PAPER_RISK_MUST_BE_ONE_PERCENT')
        base,mode=account_identity(engine)
        with self.engine.transaction() as c:
            old=self._lock(c,expected_run_id)
            if not old or not old['active'] or old['engine']!=engine:raise ValueError('PAPER_RESET_ALREADY_APPLIED')
            rp=old['payload']
            profile_id=profile_id if profile_id is not None else rp.get('profile_id')
            rp.update(archived_ms=int(time.time()*1000),reset_actor=str(actor))
            c.execute('UPDATE s9_strategy_paper_runs SET active=0,payload=?,revision=revision+1 WHERE id=?',(json_dump(rp),old['id']))
            rows=c.execute("SELECT id,payload FROM s9_strategy_paper_trades WHERE run_id=? AND state IN ('WAITING','OPEN','NEEDS_REVIEW')",(old['id'],)).fetchall()
            for row in rows:
                p=json_load(row['payload']);original=deepcopy(p);p.update(state='RESET_ARCHIVED',reason='RESET_WITHOUT_ASSUMED_EXIT')
                c.execute("UPDATE s9_strategy_paper_trades SET state='RESET_ARCHIVED',payload=?,revision=revision+1 WHERE id=?",(json_dump(p),row['id']))
                paper_statistics.changed(c,old['id'],original,p)
            identifier=uuid.uuid4().hex
            p={**rp,'starting_balance':'5000','balance':'5000','risk_percent':'1','risk_policy':RISK_POLICY,
               'peak_balance':'5000','max_balance_drawdown_usd':'0','audit':[], 'control_revision':1,'profile_id':profile_id,
               'previous_run_id':old['id'],'reset_actor':str(actor),
               'participation_policy':'ALL_VALID_SIGNALS_INDEPENDENT_OF_PUBLICATION'}
            p.pop('archived_ms',None)
            c.execute('INSERT INTO s9_strategy_paper_runs(id,engine,active,created_ms,payload) VALUES(?,?,1,?,?)',
                      (identifier,engine,int(time.time()*1000),json_dump(p)))
        return {'run_id':identifier,'balance':'5000','history_preserved':True}

    def control(self,engine,*,actor,expected_run_id,expected_revision,enabled):
        account_identity(engine)
        if type(enabled) is not bool:raise ValueError('PAPER_CONTROL_INVALID')
        with self.engine.transaction() as c:
            run=self._lock(c,expected_run_id)
            if not run or not run['active'] or run['engine']!=engine or run['payload'].get('control_revision',1)!=expected_revision:
                raise ValueError('PAPER_ACCOUNT_CHANGED')
            p=run['payload'];p['entries_enabled']=enabled;p['control_revision']=expected_revision+1
            p.setdefault('audit',[]).append({'type':'RESUME_ENTRIES' if enabled else 'PAUSE_ENTRIES',
                                            'actor':str(actor),'at_ms':int(time.time()*1000)})
            if not enabled:
                rows=c.execute("SELECT id,payload FROM s9_strategy_paper_trades WHERE run_id=? AND state='WAITING'",(run['id'],)).fetchall()
                for row in rows:
                    t=json_load(row['payload']);original=deepcopy(t);t.update(state='PAUSED',reason='ADMIN_ENTRIES_PAUSED_NO_RETROACTIVE_FILL')
                    t['events'].append({'type':'ADMIN_PAUSE','actor':str(actor),'at_ms':int(time.time()*1000)})
                    c.execute("UPDATE s9_strategy_paper_trades SET state='PAUSED',payload=?,revision=revision+1 WHERE id=?",(json_dump(t),row['id']))
                    paper_statistics.changed(c,run['id'],original,t)
            self._save_run(c,run,p)
        return {'run_id':run['id'],'entries_enabled':enabled,'revision':p['control_revision']}

    def trade(self,identifier):
        with self.engine.transaction(read_only=True) as c:
            r=c.execute('SELECT * FROM s9_strategy_paper_trades WHERE id=?',(identifier,)).fetchone()
        return {**r,'payload':json_load(r['payload'])} if r else None

    def configure_costs(self,engine,*,actor,run_id,revision,symbol,specification):
        from modules.paper_costs import parse
        from modules.automated_market_scope import require_global_symbol
        if type(revision) is not int or revision<1 or not isinstance(run_id,str) or not re.fullmatch('[a-f0-9]{32}',run_id):raise ValueError('PAPER_COST_SPEC_INVALID')
        account_identity(engine);require_global_symbol(symbol);spec=parse(specification)
        with self.engine.transaction() as c:
            run=self._lock(c,run_id)
            if not run or not run['active'] or run['engine']!=engine or run['payload'].get('control_revision',1)!=revision:raise ValueError('PAPER_ACCOUNT_CHANGED')
            p=run['payload'];p.setdefault('cost_models',{})[symbol]=spec;p['control_revision']=revision+1
            p.setdefault('audit',[]).append({'type':'COST_SPECIFICATION_FUTURE_SIGNALS','actor':str(actor),'at_ms':int(time.time()*1000),'symbol':symbol,'specification':spec})
            self._save_run(c,run,p)
        return {'revision':p['control_revision'],'future_signals_only':True}

    def for_signal(self,signal_id):
        with self.engine.transaction(read_only=True) as c:
            r=c.execute('SELECT * FROM s9_strategy_paper_trades WHERE signal_id=?',(signal_id,)).fetchone()
        if not r:return {'state':'UNAVAILABLE'}
        p=json_load(r['payload'])
        return {'state':r['state'],'id':r['id'],'revision':r['revision'],**{k:p.get(k) for k in ('entered_ms','closed_ms','fill_price','realized_usd','unrealized_usd','remaining','reason','last_event_ms','last_quote','excursions')},'events':p.get('events',[])}

    def manage_trade(self,engine,identifier,*,actor,expected_run_id,expected_revision,action,ticks=None):
        account_identity(engine)
        if action not in {'cancel_waiting','close'}:raise ValueError('PAPER_ACTION_INVALID')
        with self.engine.transaction() as c:
            run=self._lock(c,expected_run_id)
            row=c.execute('SELECT * FROM s9_strategy_paper_trades WHERE id=?',(identifier,)).fetchone()
            if (not run or not run['active'] or run['engine']!=engine or not row
                or row['run_id']!=run['id']):raise ValueError('PAPER_TRADE_CHANGED')
            p=json_load(row['payload']);original=deepcopy(p);delta=D(0)
            if p.get('management_revision',1)!=expected_revision:raise ValueError('PAPER_TRADE_CHANGED')
            if action=='cancel_waiting':
                if row['state']!='WAITING':raise ValueError('PAPER_TRADE_NOT_WAITING')
                p.update(state='CANCELLED',reason='ADMIN_PAPER_CANCEL')
                p['events'].append({'type':'ADMIN_PAPER_CANCEL','actor':str(actor),'at_ms':int(time.time()*1000)})
            else:
                if row['state']!='OPEN':raise ValueError('PAPER_TRADE_NOT_OPEN')
                now=int(time.time()*1000)
                if (not ticks or not 0<=now-ticks[-1]['event_ms']<=5000
                    or not 0<=now-ticks[-1]['received_ms']<=5000):
                    raise ValueError('PAPER_MANUAL_CLOSE_FRESH_QUOTE_REQUIRED')
                index=next((i for i,t in enumerate(ticks) if t['id']==p['last_tick_id']),None)
                if index is None or len(ticks)-index>2000:raise ValueError('PAPER_REPLAY_WINDOW_MISSING')
                # Replay first, atomically; never close through an unobserved gap.
                for tick in ticks[index+1:]:
                    p,change=advance(p,tick);self._book(c,run,change)
                if p['state']=='NEEDS_REVIEW':raise ValueError('PAPER_MANUAL_CLOSE_UNPROVEN')
                if p['state']=='OPEN':
                    p,change=close_manually(p,ticks[-1],actor);self._book(c,run,change)
                elif p['state']!='CLOSED':raise ValueError('PAPER_MANUAL_CLOSE_UNPROVEN')
            p['management_revision']=expected_revision+1
            c.execute('UPDATE s9_strategy_paper_trades SET state=?,payload=?,revision=revision+1 WHERE id=?',
                      (p['state'],json_dump(p),identifier))
            paper_statistics.changed(c,run['id'],original,p)
            run['payload'].setdefault('audit',[]).append({'type':'TRADE_'+action.upper(),'trade_id':identifier,
                    'actor':str(actor),'at_ms':int(time.time()*1000)})
            from repositories.v2.signal_timeline import record
            for event in p['events'][len(original['events']):]:
                if event['type']!='COST':record(c,row['signal_id'],'PAPER_'+event['type'],event['at_ms'],event)
            self._book(c,run,delta)
        return {'id':identifier,'state':p['state'],'realized_usd':p['realized_usd']}

    def iter_csv(self,engine,*,run_id):
        account_identity(engine)
        out=io.StringIO();writer=csv.writer(out)
        writer.writerow(['id','signal_id','strategy','execution_mode','profile','symbol','direction','state','created_ms','entered_ms','closed_ms',
                         'entry','fill','stop',*(f'tp{i}' for i in range(1,11)),'entry_balance_usd','risk_percent','risk_usd','virtual_quantity',
                         'remaining','realized_usd','unrealized_usd','reason','gross_realized_usd','costs_usd','cost_status','contract_volume','risk_budget_usd'])
        def safe(value):
            s='' if value is None else str(value)
            if re.fullmatch(r'-?[0-9]+(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?',s):return s
            return "'"+s if s.lstrip().startswith(('=','+','-','@','\t','\r','\n')) else s
        yield '\ufeff'+out.getvalue();out.seek(0);out.truncate(0)
        with self.engine.transaction(read_only=True,repeatable_read=True) as c:
            if not c.execute('SELECT id FROM s9_strategy_paper_runs WHERE id=? AND engine=?',(run_id,engine)).fetchone():raise ValueError('PAPER_RUN_NOT_FOUND')
            cursor=(-1,'')
            while True:
                rows=c.execute('SELECT * FROM s9_strategy_paper_trades WHERE run_id=? AND (created_ms>? OR (created_ms=? AND id>?)) ORDER BY created_ms,id LIMIT 200',(run_id,cursor[0],cursor[0],cursor[1])).fetchall()
                for row in rows:
                    p=json_load(row['payload']);plan=p['plan']
                    values=[row['id'],row['signal_id'],account_identity(engine)[0],p.get('execution_mode','PENDING'),p.get('profile_id'),plan['symbol'],plan['direction'],row['state'],
                            row['created_ms'],p.get('entered_ms'),p.get('closed_ms'),plan['entry'],p.get('fill_price'),plan['stop'],
                            *(plan.get(f'tp{i}') for i in range(1,11)),p.get('entry_balance_usd'),p.get('risk_percent'),
                            p.get('risk_usd'),p.get('quantity'),p.get('remaining'),p.get('realized_usd'),p.get('unrealized_usd'),p.get('reason'),p.get('gross_realized_usd',p.get('realized_usd')),p.get('costs_usd'),p.get('cost_status','UNKNOWN_NOT_ZERO'),p.get('contract_volume'),p.get('risk_budget_usd')]
                    writer.writerow([safe(v) for v in values])
                    yield out.getvalue();out.seek(0);out.truncate(0)
                if len(rows)<200:break
                cursor=(rows[-1]['created_ms'],rows[-1]['id'])

    def export_csv(self,engine,*,run_id):
        return ''.join(self.iter_csv(engine,run_id=run_id))

    def snapshot(self,engine,*,run_id=None,before=None,limit=50,runs_before=None,configuration_after=None):
        active=self.active(engine)
        stamp,key=page_cursor(before)
        selected_id=run_id or active['id']
        run_stamp,run_key=page_cursor(runs_before)
        if configuration_after is not None and (not isinstance(configuration_after,str) or len(configuration_after)>200):raise ValueError('PAPER_CONFIGURATION_CURSOR_INVALID')
        with self.engine.transaction(read_only=True) as c:
            selected=c.execute('SELECT id FROM s9_strategy_paper_runs WHERE id=? AND engine=?',(selected_id,engine)).fetchone()
            ready=paper_statistics.ready(c,selected_id) if selected else False
        if not selected:raise ValueError('PAPER_RUN_NOT_FOUND')
        if not ready:
            with self.engine.transaction() as c:
                self._lock(c,selected_id)
                paper_statistics.ensure(c,selected_id)
        with self.engine.transaction(read_only=True,repeatable_read=True) as c:
            runs=c.execute('SELECT * FROM s9_strategy_paper_runs WHERE engine=? AND (created_ms<? OR (created_ms=? AND id<?)) ORDER BY created_ms DESC,id DESC LIMIT 100',(engine,run_stamp,run_stamp,run_key)).fetchall()
            next_runs_before=f"{runs[-1]['created_ms']}:{runs[-1]['id']}" if len(runs)==100 else None
            selected=c.execute('SELECT * FROM s9_strategy_paper_runs WHERE id=? AND engine=?',
                               (run_id or active['id'],engine)).fetchone()
            if not selected:raise ValueError('PAPER_RUN_NOT_FOUND')
            if not any(r['id']==selected['id'] for r in runs):runs.append(selected)
            metrics=paper_statistics.read(c,selected['id'],initialize=False,profile_after=configuration_after or '')
            configuration_count=c.execute("SELECT COUNT(*) AS n FROM s9_paper_statistics WHERE run_id=? AND bucket LIKE 'profile:%'",(selected['id'],)).fetchone()['n']
            publication_rows=c.execute("""SELECT COALESCE(i.state,'UNAVAILABLE') AS state,COUNT(*) AS count
                FROM s9_strategy_paper_trades t LEFT JOIN s9_signal_inbox i ON i.id=t.signal_id
                WHERE t.run_id=? GROUP BY i.state""",(selected['id'],)).fetchall()
            rows=c.execute('''SELECT t.*,i.state AS publication_state FROM s9_strategy_paper_trades t
                LEFT JOIN s9_signal_inbox i ON i.id=t.signal_id
                WHERE t.run_id=? AND (t.created_ms<? OR (t.created_ms=? AND t.id<?))
                ORDER BY t.created_ms DESC,t.id DESC LIMIT ?''',(selected['id'],stamp,stamp,key,max(1,min(100,limit)))).fetchall()
        st=metrics['all'];closed=st['closed'];wins=st['wins']
        rp=json_load(selected['payload']);balance=D(rp['balance']);starting=D(rp['starting_balance'])
        unrealized=D(st['unrealized_usd']);open_risk=D(st['open_risk_usd'])
        gross_profit=D(st['gross_profit']);gross_loss=D(st['gross_loss'])
        configurations=[{'profile_id':key[8:],'signals':v['total_signals'],'closed':v['closed'],'wins':v['wins'],
            'win_rate':v['wins']/v['closed']*100 if v['closed'] else None,'realized_usd':v['realized_usd']}
            for key,v in sorted(metrics.items()) if key.startswith('profile:')]
        return {'account':{**selected,'payload':rp},
                'runs':[{'id':r['id'],'active':bool(r['active']),'created_ms':r['created_ms'],'payload':json_load(r['payload'])} for r in runs],
                'configurations':configurations,'configuration_count':configuration_count,'configurations_truncated':configuration_count>len(configurations),
                'next_runs_before':next_runs_before,'next_configuration_after':max(k for k in metrics if k!='all') if len(configurations)==100 else None,
                'stats':{**st,'publication_counts':{r['state']:r['count'] for r in publication_rows},
                         'win_rate':wins/closed*100 if closed else None,
                         'equity_usd':str(balance+unrealized),'equity_complete':not st['unresolved_positions'],
                         'open_risk_percent':str(open_risk/balance*100) if balance>0 else None,
                         'next_trade_risk_usd':str(max(D(0),balance)/100),
                         'return_percent':str((balance-starting)/starting*100) if starting>0 else None,
                         'peak_balance':rp.get('peak_balance',rp['starting_balance']),
                         'balance_drawdown_usd':str(max(D(0),D(rp.get('peak_balance',rp['starting_balance']))-balance)),
                         'max_balance_drawdown_usd':rp.get('max_balance_drawdown_usd','0'),
                         'profit_factor':str(gross_profit/-gross_loss) if gross_loss<0 else None,
                         'average_r':str(D(st['r_sum'])/closed) if closed else None,
                         'average_price_r':str(D(st['price_r_sum'])/closed) if closed else None,
                         'average_gross_budget_r':str(D(st['gross_r_sum'])/closed) if closed else None,
                         'average_mfe_r':str(D(st['mfe_r_sum'])/st['excursion_count']) if st['excursion_count'] else None,
                         'average_mae_r':str(D(st['mae_r_sum'])/st['excursion_count']) if st['excursion_count'] else None,
                         'r_basis':'ENTRY_RISK_BUDGET_USD','cohort_policy':'FROZEN_PROFILE_PER_TRADE',
                         'average_wait_ms':str(D(st['wait_ms_sum'])/st['wait_count']) if st['wait_count'] else None,
                         'strategy_only_win_rate':st['strategy_only_wins']/st['strategy_only_closed']*100 if st['strategy_only_closed'] else None,
                         'strategy_only_realized_usd':str(D(st['realized_usd'])-D(st['manual_realized_usd'])),
                         'fees_included':st['costs_unknown']==0 and st['entered']>0,'net_complete':st['costs_unknown']==0 and not st['unresolved_positions'],'all_time':False},
                'trades':[{**r,'payload':json_load(r['payload'])} for r in rows],
                'next_before':str(rows[-1]['created_ms'])+':'+rows[-1]['id'] if len(rows)==limit else None}
