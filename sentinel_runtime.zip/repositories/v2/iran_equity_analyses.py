"""Private TSETMC analysis snapshots; no global signal or paper enrollment."""

from modules.iran_equities import instrument_code
from repositories.v2.common import content_hash, json_dump, json_load
from repositories.v2.live_signal_inbox import page_cursor


class IranEquityAnalyses:
    def __init__(self, engine=None):
        from core.storage.engine import normalized_engine

        self.engine = engine or normalized_engine()

    def save(self, result):
        code = instrument_code(result.get("ins_code"))
        if (
            result.get("provider") != "tsetmc"
            or result.get("product") != "iran_cash_equity"
            or result.get("currency") != "IRR"
            or result.get("timeframe") not in {"4h", "1d"}
            or not isinstance(result.get("analysis"), dict)
        ):
            raise ValueError("IR_ANALYSIS_IDENTITY_INVALID")
        payload = {k: v for k, v in result.items() if k not in {"bars", "has_more", "poll_seconds"}}
        identity = {
            k: payload.get(k)
            for k in (
                "ins_code",
                "timeframe",
                "provider",
                "venue",
                "product",
                "currency",
                "adjustment",
                "close_basis",
                "last_closed_ms",
                "state",
                "analysis",
            )
        }
        identifier = content_hash(identity)[:32]
        with self.engine.transaction() as c:
            c.execute(
                """INSERT INTO s9_iran_equity_analyses(id,ins_code,symbol,timeframe,state,created_ms,payload)
                VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING""",
                (
                    identifier,
                    code,
                    result["symbol"],
                    result["timeframe"],
                    result["state"],
                    result["observed_ms"],
                    json_dump(payload),
                ),
            )
        return identifier

    def items(self, *, timeframe=None, before=None, limit=20):
        if timeframe not in {None, "4h", "1d"}:
            raise ValueError("IR_ANALYSIS_TIMEFRAME_INVALID")
        stamp, key = page_cursor(before)
        limit = max(1, min(50, int(limit)))
        with self.engine.transaction(read_only=True) as c:
            rows = c.execute(
                """SELECT * FROM s9_iran_equity_analyses WHERE (?='' OR timeframe=?)
                AND (created_ms<? OR (created_ms=? AND id<?)) ORDER BY created_ms DESC,id DESC LIMIT ?""",
                (timeframe or "", timeframe or "", stamp, stamp, key, limit),
            ).fetchall()
        return [{**r, "payload": json_load(r["payload"])} for r in rows]

    def get(self, identifier):
        with self.engine.transaction(read_only=True) as c:
            row = c.execute("SELECT * FROM s9_iran_equity_analyses WHERE id=?", (identifier,)).fetchone()
        return {**row, "payload": json_load(row["payload"])} if row else None

    def legacy_proposals(self, *, before=None, limit=20):
        from repositories.v2.live_signal_inbox import LiveSignalInbox

        rows = LiveSignalInbox(self.engine).items(market="iran", before=before, limit=limit)
        return [
            {
                "id": r["id"],
                "state": r["state"],
                "created_ms": r["created_ms"],
                "payload": {"plan": r["payload"]["plan"], "legacy": True, "read_only": True},
            }
            for r in rows
        ]
