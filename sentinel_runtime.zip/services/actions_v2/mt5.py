from __future__ import annotations

import os
from typing import Any

from config import SETTINGS
from repositories.v2.mt5_connectors import MT5ConnectorRepository
from services.actions_v2.context import ActionContext
from services.actions_v2.registry import action
from services.prop_guardian_service import account_guardian_snapshot, prop_guardian_dashboard
from services.risk_coach_service import (
    consolidated_behavioral_report,
    get_or_create_daily_plan,
    record_risk_checkin,
    update_daily_plan,
)


def _base_url() -> str:
    return str(getattr(SETTINGS, "webapp_url", "") or "").strip().rstrip("/")


@action("mt5_pairing_create")
def mt5_pairing_create(ctx: ActionContext) -> dict[str, Any]:
    account_id = str(ctx.payload.get("account_id") or "").strip()
    if not account_id:
        raise ValueError("TRADING_ACCOUNT_REQUIRED")
    if str(os.getenv("MT5_CONNECTOR_ENABLED", "true")).strip().lower() not in {"1", "true", "yes", "on"}:
        raise PermissionError("MT5_CONNECTOR_DISABLED")
    try:
        default_ttl = int(os.getenv("MT5_PAIRING_TTL_MINUTES", "15") or 15)
    except ValueError:
        default_ttl = 15
    pairing = MT5ConnectorRepository(ctx.engine).create_pairing(
        ctx.user_id,
        account_id,
        ttl_minutes=max(5, min(int(ctx.payload.get("ttl_minutes") or default_ttl), 60)),
        label=str(ctx.payload.get("label") or ""),
    )
    base = _base_url()
    return {
        **pairing,
        "api_url": base,
        "pairing_endpoint": f"{base}/api/v1/mt5/pair" if base else "/api/v1/mt5/pair",
        "download_source_url": f"{base}/downloads/SentinelConnector.mq5" if base else "/downloads/SentinelConnector.mq5",
        "download_package_url": f"{base}/downloads/Sentinel_MT5_Connector_Source.zip" if base else "/downloads/Sentinel_MT5_Connector_Source.zip",
        "installation_guide_url": f"{base}/downloads/Sentinel_MT5_Installation_FA.txt" if base else "/downloads/Sentinel_MT5_Installation_FA.txt",
        "readonly_mode": True,
        "instructions": [
            "فایل SentinelConnector.mq5 را در MetaEditor باز و با F7 کامپایل کنید.",
            "فایل EX5 تولیدشده را روی یک نمودار MT5 اجرا کنید.",
            "آدرس HTTPS مینی‌اپ را در Tools > Options > Expert Advisors > WebRequest مجاز کنید.",
            "کد اتصال را فقط یک‌بار در تنظیمات اکسپرت وارد کنید.",
        ],
    }


@action("mt5_connector_revoke")
def mt5_connector_revoke(ctx: ActionContext) -> dict[str, Any]:
    connector_id = str(ctx.payload.get("connector_id") or "").strip()
    if not connector_id:
        raise ValueError("MT5_CONNECTOR_REQUIRED")
    return MT5ConnectorRepository(ctx.engine).revoke(ctx.user_id, connector_id)


@action("mt5_connector_rename")
def mt5_connector_rename(ctx: ActionContext) -> dict[str, Any]:
    connector_id = str(ctx.payload.get("connector_id") or "").strip()
    if not connector_id:
        raise ValueError("MT5_CONNECTOR_REQUIRED")
    return MT5ConnectorRepository(ctx.engine).rename(ctx.user_id, connector_id, str(ctx.payload.get("name") or ""))


@action("prop_pretrade_assess", mutation=False, idempotency_required=False)
def prop_pretrade_assess(ctx: ActionContext) -> dict[str, Any]:
    account_id = str(ctx.payload.get("account_id") or "").strip()
    if not account_id:
        raise ValueError("TRADING_ACCOUNT_REQUIRED")
    candidate = dict(ctx.payload.get("candidate") or {}) if isinstance(ctx.payload.get("candidate"), dict) else {
        key: ctx.payload.get(key) for key in (
            "symbol", "side", "entry", "stop", "take_profit", "risk_percent", "risk_money", "volume",
        ) if key in ctx.payload
    }
    return account_guardian_snapshot(
        ctx.user_id,
        account_id,
        candidate=candidate,
        news_events=ctx.payload.get("news_events") if isinstance(ctx.payload.get("news_events"), list) else [],
        record=False,
        engine=ctx.engine,
    )


@action("prop_guardian_refresh_v2", mutation=False, idempotency_required=False)
def prop_guardian_refresh_v2(ctx: ActionContext) -> dict[str, Any]:
    return prop_guardian_dashboard(
        ctx.user_id,
        account_id=ctx.payload.get("account_id"),
        record=bool(ctx.payload.get("record", False)),
        engine=ctx.engine,
    )


@action("risk_daily_plan_refresh", mutation=False, idempotency_required=False)
def risk_daily_plan_refresh(ctx: ActionContext) -> dict[str, Any]:
    account_id = str(ctx.payload.get("account_id") or "").strip()
    if not account_id:
        raise ValueError("TRADING_ACCOUNT_REQUIRED")
    return get_or_create_daily_plan(
        ctx.user_id,
        account_id,
        engine=ctx.engine,
        force_refresh=bool(ctx.payload.get("force_refresh", False)),
    )


@action("risk_daily_plan_update")
def risk_daily_plan_update(ctx: ActionContext) -> dict[str, Any]:
    account_id = str(ctx.payload.get("account_id") or "").strip()
    if not account_id:
        raise ValueError("TRADING_ACCOUNT_REQUIRED")
    values = dict(ctx.payload.get("values") or {}) if isinstance(ctx.payload.get("values"), dict) else dict(ctx.payload)
    values.pop("account_id", None)
    values.pop("accept", None)
    return update_daily_plan(
        ctx.user_id,
        account_id,
        values,
        accept=bool(ctx.payload.get("accept", False)),
        engine=ctx.engine,
    )


@action("risk_daily_plan_accept")
def risk_daily_plan_accept(ctx: ActionContext) -> dict[str, Any]:
    account_id = str(ctx.payload.get("account_id") or "").strip()
    if not account_id:
        raise ValueError("TRADING_ACCOUNT_REQUIRED")
    return update_daily_plan(ctx.user_id, account_id, {}, accept=True, engine=ctx.engine)


@action("risk_checkin_create")
def risk_checkin_create(ctx: ActionContext) -> dict[str, Any]:
    return record_risk_checkin(ctx.user_id, ctx.payload, engine=ctx.engine)


@action("risk_coach_refresh_v2", mutation=False, idempotency_required=False)
def risk_coach_refresh_v2(ctx: ActionContext) -> dict[str, Any]:
    return consolidated_behavioral_report(ctx.user_id)
