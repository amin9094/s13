from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from core.storage.engine import DatabaseEngine, normalized_engine
from core.webapp_auth import TelegramWebAppIdentity
from modules.data_confidence import DataConfidenceService
from modules.market_analytics import CorrelationService
from modules.prop_rules_v2 import PropRuleEngine
from repositories.v2.accounts import AccountRepository
from repositories.v2.admin_commands import AdminCommandRepository
from repositories.v2.commerce import CommerceRepository
from repositories.v2.events import EventRepository
from repositories.v2.journal import JournalRepository
from repositories.v2.positions import PositionRepository
from repositories.v2.preferences import PreferenceRepository
from repositories.v2.signals import SignalRepository
from repositories.v2.support import SupportRepository


@dataclass
class ActionContext:
    identity: TelegramWebAppIdentity
    request_id: str
    action: str
    payload: dict[str, Any]
    transport: dict[str, Any]
    engine: DatabaseEngine
    accounts: AccountRepository
    positions: PositionRepository
    commerce: CommerceRepository
    support: SupportRepository
    events: EventRepository
    signals: SignalRepository
    preferences: PreferenceRepository
    journal: JournalRepository
    prop_rules: PropRuleEngine
    confidence: DataConfidenceService
    correlation: CorrelationService
    admin_commands: AdminCommandRepository

    @property
    def user_id(self) -> str:
        return str(self.identity.user_id)


def create_context(
    identity: TelegramWebAppIdentity,
    *,
    request_id: str,
    action: str,
    payload: dict[str, Any],
    transport: dict[str, Any] | None = None,
    engine: DatabaseEngine | None = None,
) -> ActionContext:
    db = engine or normalized_engine()
    return ActionContext(
        identity=identity, request_id=request_id, action=action, payload=payload, transport=dict(transport or {}), engine=db,
        accounts=AccountRepository(db), positions=PositionRepository(db), commerce=CommerceRepository(db),
        support=SupportRepository(db), events=EventRepository(db), signals=SignalRepository(db),
        preferences=PreferenceRepository(db), journal=JournalRepository(db), prop_rules=PropRuleEngine(db),
        confidence=DataConfidenceService(db), correlation=CorrelationService(db),
        admin_commands=AdminCommandRepository(db),
    )
