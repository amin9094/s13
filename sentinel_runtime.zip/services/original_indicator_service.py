"""Private provenance ledger. Imported data cannot silently become a live gate."""
import time,os
from core.storage.engine import normalized_engine
from repositories.v2.common import json_dump,json_load


def status(user,symbol='XAUUSD'):
    from services.upgrade_admin_service import _permit
    from modules.automated_market_scope import require_global_symbol
    _permit(user);require_global_symbol(symbol)
    with normalized_engine().transaction(read_only=True) as c:
        rows=c.execute('SELECT id,timeframe,available_ms,payload FROM s9_original_indicator_inputs WHERE symbol=? ORDER BY available_ms DESC,id DESC LIMIT 40',(symbol,)).fetchall()
    return {'script':'dmns-ICT-AMD-Goldbach','original_connected':False,
            'bridge_configured':len(os.getenv('DMNS_AMD_BRIDGE_SIGNING_KEY',''))>=32,
            'state':'AUTHORIZED_ORIGINAL_SOURCE_OR_STRUCTURED_OUTPUT_AND_PARITY_REQUIRED',
            'items':[{**r,'payload':json_load(r['payload'])} for r in rows],
            'independent_po3_is_original':False,'automatic_entry_gate_changed':False}


def ingest(user,payload,signature):
    from services.upgrade_admin_service import _permit
    _permit(user,'signal_templates')
    from modules.original_dmns_amd import validate
    try:proof=validate(payload,signature,now_ms=int(time.time()*1000))
    except (TypeError,ArithmeticError,KeyError):raise ValueError('ORIGINAL_DMNS_AMD_INPUT_INVALID') from None
    key=proof['input_hash'][:32]
    saved={'input':payload,'proof':proof,'actor':str(user),'received_ms':int(time.time()*1000)}
    with normalized_engine().transaction() as c:
        c.execute('INSERT INTO s9_original_indicator_inputs VALUES(?,?,?,?,?) ON CONFLICT DO NOTHING',(key,payload['symbol'],payload['timeframe'],payload['available_ms'],json_dump(saved)))
    return {'id':key,**proof,'used_for_live_signals':False}
