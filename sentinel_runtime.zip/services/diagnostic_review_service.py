"""Audited human decisions, source repair and fresh analysis; no forced signals."""
import uuid
from core.async_runtime import run_blocking
from repositories.v2.common import content_hash
from repositories.v2.strategy_reviews import StrategyReviewRepository
from repositories.v2.market_evidence import MarketEvidenceRepository
from services.live_signal_service import permitted


def case_snapshot(user, key):
    permitted(user)
    row=StrategyReviewRepository().get(key)
    if not row or row['payload'].get('review_kind')=='PREENTRY_PROPOSAL':raise ValueError('REVIEW_CASE_NOT_FOUND')
    # Include every revised timeframe in this symbol/provider: minute evidence
    # may also participate in a causal POC. Approval is bound to this exact list.
    revisions=MarketEvidenceRepository().pending_revisions(row['symbol'],row['payload'].get('provider'))
    digest=content_hash([row['state'],row['payload'],[r['id'] for r in revisions]])
    return {'case':row,'case_hash':digest,'revisions':revisions}


def case_list(user, before=None):
    permitted(user)
    rows=StrategyReviewRepository().diagnostics(before=before)
    return {'items':rows,'next_before':f"{rows[-1]['created_ms']}:{rows[-1]['id']}" if len(rows)==30 else None}


def accept_source_revisions(revisions, actor):
    """Commit source revisions and invalidate dependent *future* entries atomically.

    Published plans, old versions and paper outcomes remain frozen. Open paper
    trades lose evaluable coverage instead of being retrospectively repriced.
    """
    from repositories.v2.live_signal_inbox import LiveSignalInbox
    from repositories.v2.strategy_paper import StrategyPaperRepository
    from repositories.v2.common import json_load,json_dump
    evidence=MarketEvidenceRepository();engine=evidence.engine
    with engine.atomic() as c:
        families=evidence.accept_revisions([r['id'] for r in revisions],actor=actor)
        rows=c.execute("SELECT * FROM s9_signal_inbox WHERE state IN ('PENDING','QUEUED','STAGING')").fetchall()
        inbox=LiveSignalInbox(engine);paper=StrategyPaperRepository(engine)
        for r in rows:
            r={**r,'payload':json_load(r['payload'])};p=r['payload']['plan']
            if (p['symbol'],p['provider'],p['timeframe']) in families or any(p['symbol']==s and p['provider']==v and t=='1m' for s,v,t in families):
                inbox.terminate(r['id'],'NEEDS_REVIEW','SOURCE_CANDLES_REVISED')
                paper.cancel_waiting(r['id'],reason='SOURCE_CANDLES_REVISED')
        # Native preparation/old delivery routes must not bypass the desk.
        setups=c.execute("SELECT id,payload FROM s9_setups WHERE phase='PROPOSED_PRETOUCH'").fetchall()
        for r in setups:
            p=json_load(r['payload']);plan=p['plan']
            if any(plan['symbol']==s and plan['provider']==v for s,v,_ in families):
                p['tracking_state']='NEEDS_REVIEW';p['tracking_reason']='SOURCE_CANDLES_REVISED'
                c.execute('UPDATE s9_setups SET payload=? WHERE id=?',(json_dump(p),r['id']))
        reviews=c.execute("SELECT id,payload FROM s9_strategy_reviews WHERE state='NEEDS_REVIEW'").fetchall()
        for r in reviews:
            p=json_load(r['payload']);plan=p.get('draft_plan')
            if plan and p.get('review_kind')=='PREENTRY_PROPOSAL' and any(plan['symbol']==s and plan['provider']==v for s,v,_ in families):
                p['decision_reason']='SOURCE_CANDLES_REVISED'
                c.execute("UPDATE s9_strategy_reviews SET state='EXPIRED',payload=? WHERE id=? AND state='NEEDS_REVIEW'",(json_dump(p),r['id']))
        # Paper history is not rewritten. If an open run relied on revised
        # evidence, mark it unscored; its recorded fills remain inspectable.
        trades=c.execute("SELECT id,payload FROM s9_strategy_paper_trades WHERE state='OPEN'").fetchall()
        for r in trades:
            p=json_load(r['payload']);plan=p['plan']
            if any(plan['symbol']==s and plan['provider']==v for s,v,_ in families):
                p['reason']='SOURCE_CANDLES_REVISED';p['state']='NEEDS_REVIEW'
                c.execute("UPDATE s9_strategy_paper_trades SET state='NEEDS_REVIEW',payload=?,revision=revision+1 WHERE id=? AND state='OPEN'",(json_dump(p),r['id']))
    return families


async def review_decision(user, key, body):
    permitted(user)
    actions=('rescan','accept_rescan','no_signal','cancel')
    if not isinstance(body,dict) or set(body)!={'action','case_hash'} or body['action'] not in actions:
        raise ValueError('REVIEW_ACTION_INVALID')
    snap=await run_blocking(case_snapshot,user,key,timeout=5)
    if body['case_hash']!=snap['case_hash']:raise ValueError('REVIEW_CASE_CHANGED')
    action=body['action'];repo=StrategyReviewRepository();token=uuid.uuid4().hex
    if action=='accept_rescan' and not snap['revisions']:raise ValueError('CANDLE_REVISION_CHANGED')
    await run_blocking(repo.claim_diagnostic,key,expected_payload=snap['case']['payload'],actor=user,action=action,token=token,timeout=5)
    if action in {'no_signal','cancel'}:
        state='CLOSED_NO_SIGNAL' if action=='no_signal' else 'CANCELLED'
        await run_blocking(repo.finish_diagnostic,key,token=token,state=state,outcome={'action':action},timeout=5)
        return {'state':state,'signal_ids':[]}
    try:
        if action=='accept_rescan':
            await run_blocking(accept_source_revisions,snap['revisions'],user,timeout=15)
        from services import canonical_market_service as market
        # Explicit retries must fetch fresh evidence, not repeat a bad cache.
        symbol=snap['case']['symbol'];tf=snap['case']['timeframe'];p=snap['case']['payload']
        for cache_key in list(market._HISTORY_CACHE):
            if cache_key[0]==symbol:market._HISTORY_CACHE.pop(cache_key,None)
        from services.strategy_review_queue_service import analyze_and_store
        from services.keyless_market_data_service import supported_symbols
        indicative=symbol in supported_symbols()
        result=await analyze_and_store(user,symbol,tf,admin_review=indicative,
            **({'provider':'biquote'} if indicative else {}))
        ids=result.get('live_signal_ids',[])
        state='RESOLVED_SIGNAL' if ids else 'NEEDS_REVIEW' if result.get('state') in {'NEEDS_REVIEW','UNAVAILABLE'} else 'CLOSED_NO_SETUP'
        outcome={'state':result.get('state'),'reason':result.get('reason'),'signal_ids':ids}
    except Exception as exc:
        # Persist the decision/error and allow a deliberate retry. Cancellation
        # of this task leaves a claim that can be reclaimed after two minutes.
        await run_blocking(repo.finish_diagnostic,key,token=token,state='NEEDS_REVIEW',outcome={'error':type(exc).__name__},timeout=5)
        raise
    await run_blocking(repo.finish_diagnostic,key,token=token,state=state,outcome=outcome,timeout=5)
    return {'state':state,'signal_ids':ids,'reason':result.get('reason')}


def case_for_signal(user, identifier, digest):
    """Open a separate re-analysis case; never edit a frozen signal's levels."""
    import time
    from repositories.v2.live_signal_inbox import LiveSignalInbox
    permitted(user)
    row=LiveSignalInbox().get(identifier)
    if not row or row['payload']['plan_hash']!=digest or row['state'] not in {'PENDING','NEEDS_REVIEW','EXPIRED'}:
        raise ValueError('SIGNAL_PLAN_CHANGED')
    p=row['payload']['plan'];repo=StrategyReviewRepository()
    existing=repo.diagnostics(limit=40)
    for case in existing:
        if case['payload'].get('signal_id')==identifier:return case['id']
    case={'engine':p['engine'],'symbol':p['symbol'],'timeframe':p['timeframe'],'provider':p['provider'],
          'state':'NEEDS_REVIEW','available_ms':int(time.time()*1000),'reason':'SIGNAL_RESCAN_REQUESTED',
          'title_fa':'بررسی دوبارهٔ سیگنال','signal_id':identifier,
          'thesis_key':identifier+':'+uuid.uuid4().hex}
    return repo.store([case])[0]
