"""Permission-gated strategy route selection and honest comparison reports."""
import csv
import io
from repositories.v2.strategy_paths import StrategyPaths,parameters_registry,parameter_snapshot,effective_configuration
from repositories.v2.live_signal_inbox import STRATEGIES


def _permit(user,strategy,write=False):
    from services.live_signal_service import permitted
    permitted(user,**({'paper_action':'reset'} if write else {}))
    if strategy not in STRATEGIES:raise ValueError('PAPER_STRATEGY_INVALID')


def path_overview(user,strategy,*,from_ms=0,to_ms=None):
    _permit(user,strategy)
    paths=StrategyPaths()
    custom=None
    if strategy=='custom':
        from services.custom_strategy_service import current_settings
        custom=current_settings().dto()
    paths.ensure(strategy,custom_config=custom)
    result=paths.snapshot(strategy,from_ms=from_ms,to_ms=to_ms)
    labels=['تنظیم پایه','جابجایی قوی‌تر ۱','جابجایی قوی‌تر ۲','آستانهٔ روند ۲۰','آستانهٔ روند ۳۰',
            'فیلتر حجم ۱٫۵','فیلتر حجم ۲','ساختار سه کندلی','حداقل اندازهٔ FVG بیشتر','بافر استاپ بیشتر']
    registered=parameters_registry();base=parameter_snapshot(next(iter(registered.values())))
    result['profiles']=[{'profile_id':key,'label':labels[max(0,index-1)] if index else 'تنظیم پایهٔ اصلی',
        'changes':{k:v for k,v in parameter_snapshot(value).items() if k!='profile_id' and base.get(k)!=v}}
        for index,(key,value) in enumerate(registered.items())] if strategy!='custom' else []
    if strategy=='custom':
        from modules.custom_strategy import parse_settings
        candidates=[]
        for name,changes in (('ترکیب فعلی',{}),('تأیید فیبوناچی',{'require_fibonacci':True}),('تأیید نقدینگی',{'require_liquidity':True}),('هم‌پوشانی FVG و اوردر بلاک',{'require_fvg':True,'require_ob':True})):
            config=parse_settings({**custom,'enabled':True,**changes})
            if all(c['profile_id']!=config.profile_id for c in candidates):candidates.append({'label':name,'profile_id':config.profile_id,'config':config.dto()})
        result['custom_candidates']=candidates
        from repositories.v2.custom_presets import CustomPresets
        result['custom_presets']=CustomPresets(paths.engine).items()
        result['custom_config']=custom
    if strategy!='custom':
        used=[effective_configuration(strategy,p['payload']['configuration']) for p in result['items']]
        distinct=[];seen=list(used)
        for p in result['profiles']:
            effective=effective_configuration(strategy,parameter_snapshot(registered[p['profile_id']]))
            if effective in seen:continue
            distinct.append(p);seen.append(effective)
        result['profiles']=distinct
    return result


def path_action(user,strategy,body):
    _permit(user,strategy,write=True)
    if not isinstance(body,dict):raise ValueError('INVALID_REQUEST')
    paths=StrategyPaths();action=body.get('action')
    if action=='create' and set(body)<={'action','name','profile_id','custom_config'} and isinstance(body.get('name'),str):
        return paths.create(strategy,name=body['name'],profile_id=body.get('profile_id'),
                            custom_config=body.get('custom_config'),actor=user)
    if action=='select' and set(body)=={'action','id','active_id','revision'}:
        import re
        if not all(isinstance(body[k],str) and re.fullmatch('[a-f0-9]{32}',body[k]) for k in ('id','active_id')) or type(body['revision']) is not int:
            raise ValueError('INVALID_REQUEST')
        return paths.select(strategy,body['id'],expected_active_id=body['active_id'],expected_revision=body['revision'],actor=user)
    if action=='control' and set(body)=={'action','enabled','revision'}:
        return paths.control(strategy,enabled=body['enabled'],revision=body['revision'],actor=user)
    raise ValueError('INVALID_REQUEST')


def path_report(user,strategy,*,from_ms=0,to_ms=None):
    data=path_overview(user,strategy,from_ms=from_ms,to_ms=to_ms)
    output=io.StringIO(newline='');writer=csv.writer(output)
    writer.writerow(['مسیر','فعال','حالت ورود','شناسه تنظیم','از زمان ms','تا زمان ms','سیگنال','بسته','نامعلوم','برد',
                     'سود/زیان ثبت‌شده دلار','خالص دلار','هزینه نامعلوم','میانگین R','دوره‌های فعال‌سازی','مداخلهٔ دستی','بسته بدون مداخلهٔ دستی'])
    def safe(value):
        text=str(value if value is not None else 'نامعلوم')
        import re
        return "'"+text if text.lstrip().startswith(('=','+','-','@')) and not re.fullmatch(r'-?[0-9]+(?:\.[0-9]+)?',text) else text
    for path in data['items']:
        p=path['payload']
        for mode,s in path['results'].items():
            writer.writerow([safe(x) for x in (p['name'],bool(path['active']),mode,p['profile_id'],data['from_ms'],data['to_ms'],
                s['total_signals'],s['closed'],s['unresolved_positions'],s['wins'],s['realized_usd'],s['net_realized_usd'],
                s['costs_unknown'],s['average_r'],len(p['activations']),s['manual_signals'],s['strategy_only_closed'])])
    return ('\ufeff'+output.getvalue()).encode('utf-8')
