from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from config import is_admin
from modules.admin_access import has_permission, is_any_admin
from modules.admin_control_center import MODULE_BY_KEY, is_module_enabled
from modules.management_suite import is_admin_on_shift
from modules.i18n import user_language
from modules.rules import user_has_accepted_rules


@dataclass(frozen=True, slots=True)
class ActionPolicy:
    module: str
    permission: str | None = None
    admin_only: bool = False
    owner_only: bool = False
    rules_required: bool = True


def enforce_action_policy(
    db: dict[str, Any],
    user_id: int | str,
    policy: ActionPolicy,
    *,
    owner_id: int | str | None = None,
) -> None:
    """Apply the same authorization rules to Telegram, Mini App and HTTP actions."""
    uid = str(int(user_id))
    if policy.module and not is_module_enabled(db, policy.module):
        module = MODULE_BY_KEY.get(policy.module)
        label = module.label if module else "این قابلیت"
        raise PermissionError(f"{label} موقتاً توسط مدیریت غیرفعال شده است.")
    language = user_language(db, uid) or "fa"
    if policy.rules_required and not is_any_admin(db, uid) and not user_has_accepted_rules(db, uid, language):
        raise PermissionError(
            "Please accept the current rules before using this feature."
            if language == "en"
            else "برای استفاده از امکانات، ابتدا قوانین جاری را در ربات تأیید کنید."
        )
    if policy.owner_only:
        if owner_id is None or int(uid) != int(owner_id):
            raise PermissionError("این عملیات فقط برای ادمین اصلی مجاز است.")
        return
    if not policy.admin_only:
        return
    if not is_any_admin(db, uid):
        raise PermissionError("این عملیات فقط برای مدیران مجاز است.")
    if not is_admin_on_shift(db, uid):
        raise PermissionError("شیفت مدیریتی شما در حال حاضر فعال نیست.")
    if policy.permission and not has_permission(db, uid, policy.permission):
        raise PermissionError("دسترسی لازم برای این عملیات به شما داده نشده است.")


def enabled_feature_payload(db: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Return the authoritative feature state consumed by the Mini App."""
    return {
        module.key: {
            "enabled": bool(is_module_enabled(db, module.key)),
            "label": module.label,
            "category": module.category,
        }
        for module in MODULE_BY_KEY.values()
    }


def primary_admin(user_id: int | str, owner_id: int | str | None = None) -> bool:
    """Keep owner-only checks explicit while preserving configured primary admins."""
    if owner_id is not None:
        try:
            return int(user_id) == int(owner_id)
        except (TypeError, ValueError):
            return False
    return is_admin(user_id)
