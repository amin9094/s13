from __future__ import annotations

import hashlib
import hmac
import math
import os
from datetime import UTC, datetime
from typing import Any

from core.storage.engine import DatabaseEngine, normalized_engine
from repositories.v2.accounts import AccountRepository
from repositories.v2.common import content_hash, json_dump, json_load, new_id, utc_iso
from repositories.v2.journal import JournalRepository
from repositories.v2.events import EventRepository
from repositories.v2.mt5_connectors import MT5ConnectorRepository
from repositories.v2.positions import PositionRepository

_MAX_POSITIONS = 300
_MAX_DEALS = 500
def _env_int(name: str, default: int, *, minimum: int, maximum: int) -> int:
    try:
        return max(minimum, min(int(os.getenv(name, str(default)) or default), maximum))
    except (TypeError, ValueError):
        return default


_MAX_EVENT_BYTES = _env_int("MT5_CONNECTOR_MAX_PAYLOAD_BYTES", 1_500_000, minimum=64_000, maximum=8_000_000)
_SYNC_SECONDS = _env_int("MT5_CONNECTOR_SYNC_SECONDS", 5, minimum=2, maximum=300)


def _finite(value: Any, default: float = 0.0) -> float:
    try:
        parsed = float(value)
        return parsed if math.isfinite(parsed) else default
    except (TypeError, ValueError):
        return default


def _parse_time(value: Any) -> datetime:
    parsed = datetime.fromisoformat(str(value or "").replace("Z", "+00:00"))
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=UTC)


def verify_connector_request(
    repository: MT5ConnectorRepository,
    *,
    connector_id: str,
    device_token: str,
    timestamp: str,
    nonce: str,
    signature: str,
    body: bytes,
) -> dict[str, Any]:
    if len(body) > _MAX_EVENT_BYTES:
        raise ValueError("CONNECTOR_PAYLOAD_TOO_LARGE")
    connector = repository.authenticate(connector_id, device_token)
    try:
        sent = int(timestamp)
    except (TypeError, ValueError) as exc:
        raise PermissionError("CONNECTOR_TIMESTAMP_INVALID") from exc
    now = int(datetime.now(UTC).timestamp())
    if abs(now - sent) > 180:
        raise PermissionError("CONNECTOR_TIMESTAMP_EXPIRED")
    body_hash = hashlib.sha256(body).hexdigest()
    material = f"{timestamp}\n{nonce}\n{body_hash}".encode("utf-8")
    expected = hmac.new(str(connector["connector_secret"]).encode("utf-8"), material, hashlib.sha256).hexdigest()
    if not signature or not hmac.compare_digest(expected, str(signature).lower()):
        raise PermissionError("CONNECTOR_SIGNATURE_INVALID")
    repository.consume_nonce(connector_id, nonce)
    return connector


def pair_connector(code: str, payload: dict[str, Any], engine: DatabaseEngine | None = None) -> dict[str, Any]:
    return MT5ConnectorRepository(engine).consume_pairing(code, payload)


def _position_external_id(row: dict[str, Any]) -> str:
    return str(row.get("external_id") or row.get("ticket") or row.get("identifier") or "").strip()


def _position_side(value: Any) -> str:
    text = str(value or "").upper()
    return "SELL" if text in {"1", "SELL", "SHORT", "POSITION_TYPE_SELL"} or "SELL" in text else "BUY"


def _sync_positions(
    engine: DatabaseEngine,
    connector: dict[str, Any],
    account: dict[str, Any],
    positions_payload: list[dict[str, Any]],
    observed_at: str,
) -> dict[str, int]:
    repo = PositionRepository(engine)
    active = repo.list_for_user(connector["user_id"], account_id=account["id"], status="active", limit=100)["items"]
    existing: dict[str, dict[str, Any]] = {
        _position_external_id(row): row
        for row in active
        if str(row.get("data_source") or "") == "mt5_connector" and _position_external_id(row)
    }
    seen: set[str] = set()
    created = updated = missing_stop = closed = 0
    balance_basis = max(_finite(account.get("equity") or account.get("balance")), 1e-9)

    for raw in positions_payload[:_MAX_POSITIONS]:
        if not isinstance(raw, dict):
            continue
        external_id = _position_external_id(raw)
        if not external_id:
            continue
        seen.add(external_id)
        symbol = str(raw.get("symbol") or "").upper().replace("/", "")[:40]
        side = _position_side(raw.get("side") or raw.get("type"))
        entry = _finite(raw.get("price_open") or raw.get("entry"))
        stop = _finite(raw.get("sl") or raw.get("stop"))
        volume = max(0.0, _finite(raw.get("volume")))
        current = _finite(raw.get("price_current") or raw.get("current_price"), entry)
        profit = _finite(raw.get("profit")) + _finite(raw.get("swap")) + _finite(raw.get("commission"))
        risk_money = max(0.0, _finite(raw.get("risk_money")))
        risk_percent = max(0.0, _finite(raw.get("risk_percent"), risk_money / balance_basis * 100 if risk_money else 0.0))
        has_stop = stop > 0 and entry > 0 and stop != entry
        if not has_stop:
            missing_stop += 1
        payload = {
            **raw,
            "external_id": external_id,
            "connector_id": connector["id"],
            "broker": connector.get("broker"),
            "server_name": connector.get("server_name"),
            "source": "mt5_connector",
            "missing_stop": not has_stop,
            "observed_at": observed_at,
        }
        current_row = existing.get(external_id)
        if current_row:
            # Preserve the normalized position row even when SL is removed. The
            # risk amount comes from MT5 OrderCalcProfit and the payload carries
            # the explicit missing-stop safety flag used by Prop Guardian.
            safe_stop = stop if has_stop else float(current_row.get("actual_stop") or entry or 0.00000001)
            with engine.transaction() as cursor:
                cursor.execute(
                    """UPDATE v8_positions SET symbol=?,side=?,status='open',actual_entry=?,actual_stop=?,actual_volume=?,
                       remaining_volume=?,risk_percent=?,risk_money=?,unrealized_pnl=?,updated_at=?,data_source='mt5_connector',
                       data_confidence=0.99,payload=? WHERE id=? AND user_id=?""",
                    (
                        symbol, side, entry, safe_stop, volume, volume, risk_percent, risk_money, profit,
                        observed_at, json_dump({**current_row, **payload}), str(current_row["id"]), str(connector["user_id"]),
                    ),
                )
            updated += 1
        elif symbol and entry > 0 and volume > 0:
            safe_stop = stop if has_stop else (entry * (0.999999 if side == "BUY" else 1.000001))
            try:
                repo.open({
                    **payload,
                    "user_id": connector["user_id"], "account_id": account["id"], "symbol": symbol, "side": side,
                    "status": "open", "actual_entry": entry, "actual_stop": safe_stop, "actual_volume": volume,
                    "remaining_volume": volume, "risk_percent": risk_percent, "risk_money": risk_money,
                    "unrealized_pnl": profit, "opened_at": str(raw.get("opened_at") or raw.get("time") or observed_at),
                    "data_source": "mt5_connector", "data_confidence": 0.99,
                })
                created += 1
            except ValueError:
                continue

    for external_id, row in existing.items():
        if external_id in seen:
            continue
        with engine.transaction() as cursor:
            cursor.execute(
                """UPDATE v8_positions SET status='closed',remaining_volume=0,closed_at=?,updated_at=?,payload=?
                   WHERE id=? AND user_id=? AND status IN ('planned','open','partial')""",
                (
                    observed_at, observed_at,
                    json_dump({**row, "status": "closed", "closed_at": observed_at, "close_source": "mt5_snapshot_absent"}),
                    str(row["id"]), str(connector["user_id"]),
                ),
            )
        closed += 1
    return {"created": created, "updated": updated, "closed": closed, "missing_stop": missing_stop}


def _existing_journal_external_ids(engine: DatabaseEngine, user_id: str, limit: int = 1000) -> set[str]:
    with engine.transaction(read_only=True) as cursor:
        rows = cursor.execute(
            "SELECT payload FROM v8_journal_entries WHERE user_id=? ORDER BY opened_at DESC,id DESC LIMIT ?",
            (str(user_id), max(1, min(limit, 5000))),
        ).fetchall()
    values: set[str] = set()
    for row in rows:
        payload = json_load(row.get("payload"), {}) or {}
        if str(payload.get("source") or "") == "mt5_connector" and payload.get("external_id"):
            values.add(str(payload["external_id"]))
    return values


def _sync_deals(
    engine: DatabaseEngine,
    connector: dict[str, Any],
    account: dict[str, Any],
    deals_payload: list[dict[str, Any]],
) -> dict[str, int]:
    connector_repo = MT5ConnectorRepository(engine)
    journal = JournalRepository(engine)
    existing = _existing_journal_external_ids(engine, str(connector["user_id"]))
    imported = skipped = 0
    balance_basis = max(_finite(account.get("starting_balance") or account.get("balance")), 1e-9)
    for raw in deals_payload[:_MAX_DEALS]:
        if not isinstance(raw, dict):
            continue
        entry_kind = str(raw.get("entry_kind") or raw.get("entry") or "").lower()
        if entry_kind not in {"out", "out_by", "close", "closed", "1", "3"}:
            continue
        external_id = str(raw.get("ticket") or raw.get("deal") or raw.get("external_id") or "").strip()
        if not external_id or external_id in existing:
            skipped += 1
            continue
        event_type = "deal_closed"
        checksum = content_hash(raw)
        if not connector_repo.record_event(
            connector, external_id=external_id, event_type=event_type,
            occurred_at=str(raw.get("time") or raw.get("occurred_at") or utc_iso()), checksum=checksum, payload=raw,
        ):
            skipped += 1
            continue
        pnl_amount = _finite(raw.get("profit")) + _finite(raw.get("commission")) + _finite(raw.get("swap")) + _finite(raw.get("fee"))
        side = _position_side(raw.get("side") or raw.get("type"))
        symbol = str(raw.get("symbol") or "").upper().replace("/", "")[:40]
        volume = max(0.0, _finite(raw.get("volume")))
        if not symbol or volume <= 0:
            skipped += 1
            continue
        occurred = str(raw.get("time") or raw.get("occurred_at") or utc_iso())
        journal.add(connector["user_id"], {
            "account_id": account["id"], "symbol": symbol, "side": side, "status": "closed",
            "entry_price": _finite(raw.get("price_open") or raw.get("entry_price")),
            "exit_price": _finite(raw.get("price") or raw.get("exit_price")),
            "volume": volume, "remaining_volume": 0.0, "pnl_amount": pnl_amount,
            "pnl_percent": pnl_amount / balance_basis * 100, "opened_at": str(raw.get("opened_at") or occurred),
            "closed_at": occurred, "source": "mt5_connector", "external_id": external_id,
            "broker": connector.get("broker"), "server_name": connector.get("server_name"),
            "commission": _finite(raw.get("commission")), "swap": _finite(raw.get("swap")),
            "comment": str(raw.get("comment") or "")[:500], "connector_id": connector["id"],
            "result_r": raw.get("result_r"), "entry_reason_type": "broker_sync",
        })
        existing.add(external_id)
        imported += 1
    return {"imported": imported, "skipped": skipped}



def _guardian_alert_text(account: dict[str, Any], alert: dict[str, Any]) -> str:
    severity = str(alert.get("severity") or "warning")
    icon = "🚨" if severity == "critical" else "⚠️"
    title = str(alert.get("title_fa") or alert.get("code") or "هشدار مدیریت ریسک")
    account_name = str(account.get("name") or account.get("broker_account_reference") or "حساب متصل")
    details: list[str] = []
    if alert.get("usage_percent") is not None:
        details.append(f"مصرف محدودیت: {float(alert.get('usage_percent') or 0):.1f}%")
    if alert.get("remaining") is not None:
        details.append(f"ظرفیت باقی‌مانده: {float(alert.get('remaining') or 0):.2f}%")
    if alert.get("count") is not None:
        details.append(f"تعداد: {int(alert.get('count') or 0)}")
    suffix = "\n" + "\n".join(details) if details else ""
    return (
        f"{icon} <b>هشدار نگهبان پراپ</b>\n"
        f"حساب: <b>{account_name}</b>\n"
        f"{title}{suffix}\n\n"
        "وضعیت حساب و معاملات باز را در بخش نگهبان پراپ بررسی کنید."
    )


def _queue_guardian_notifications(
    user_id: int | str, account: dict[str, Any], new_alerts: list[dict[str, Any]]
) -> None:
    if not new_alerts:
        return
    try:
        from config import SETTINGS
        from core.db import with_db
        from modules.automation_outbox import enqueue_automation_message

        def mutate(legacy_db: dict[str, Any]) -> None:
            for alert in new_alerts[:20]:
                severity = str(alert.get("severity") or "warning")
                fingerprint = str(alert.get("fingerprint") or content_hash(alert))[:64]
                activated_at = str(alert.get("activated_at") or utc_iso())
                buttons: list[list[dict[str, str]]] = []
                webapp_url = str(getattr(SETTINGS, "webapp_url", "") or "").strip()
                if webapp_url:
                    buttons = [[{"label": "بازکردن نگهبان پراپ", "web_app": webapp_url}]]
                enqueue_automation_message(
                    legacy_db,
                    dedupe_key=f"prop-guardian:{account.get('id')}:{fingerprint}:{activated_at}",
                    kind="prop_guardian_alert",
                    recipient_id=user_id,
                    recipient_scope="user",
                    priority=5 if severity == "critical" else 3,
                    payload={
                        "text": _guardian_alert_text(account, alert),
                        "parse_mode": "HTML",
                        "buttons": buttons,
                    },
                )

        with_db(mutate)
    except Exception:
        # Alert persistence and the durable v8 event are canonical. Telegram
        # delivery is a best-effort secondary channel and must never reject an
        # otherwise valid broker snapshot.
        return

def ingest_snapshot(
    connector: dict[str, Any],
    payload: dict[str, Any],
    *,
    engine: DatabaseEngine | None = None,
) -> dict[str, Any]:
    db = engine or normalized_engine()
    account_payload = payload.get("account") if isinstance(payload.get("account"), dict) else {}
    positions_payload = payload.get("positions") if isinstance(payload.get("positions"), list) else []
    deals_payload = payload.get("deals") if isinstance(payload.get("deals"), list) else []
    observed_at = str(payload.get("observed_at") or utc_iso())
    observed = _parse_time(observed_at)
    age = (datetime.now(UTC) - observed.astimezone(UTC)).total_seconds()
    if age < -60 or age > 600:
        raise ValueError("CONNECTOR_SNAPSHOT_STALE")
    login = str(account_payload.get("login") or account_payload.get("account_login") or "")
    server = str(account_payload.get("server") or account_payload.get("server_name") or "")
    if login and login != str(connector.get("account_login") or ""):
        raise PermissionError("CONNECTOR_ACCOUNT_MISMATCH")
    if server and server != str(connector.get("server_name") or ""):
        raise PermissionError("CONNECTOR_SERVER_MISMATCH")

    accounts = AccountRepository(db)
    current = accounts.get(connector["user_id"], connector["account_id"])
    if not current:
        raise ValueError("TRADING_ACCOUNT_NOT_FOUND")
    balance = _finite(account_payload.get("balance"), _finite(current.get("balance")))
    equity = _finite(account_payload.get("equity"), balance)
    floating = _finite(account_payload.get("profit"), equity - balance)
    updated = accounts.upsert(connector["user_id"], {
        "balance": balance, "equity": equity, "floating_pnl": floating,
        "starting_balance": _finite(current.get("starting_balance"), balance) or balance,
        "high_water_mark": max(_finite(current.get("high_water_mark")), equity),
        "currency": str(account_payload.get("currency") or current.get("currency") or "USD")[:12],
        "leverage": max(1.0, _finite(account_payload.get("leverage"), _finite(current.get("leverage"), 1.0))),
        "provider": str(connector.get("broker") or "MT5"),
        "broker_account_reference": str(connector.get("account_login") or ""),
        "data_source": "mt5_connector", "data_confidence": 0.99, "data_observed_at": observed_at,
        "mt5_server": connector.get("server_name"), "mt5_connector_id": connector.get("id"),
    }, account_id=connector["account_id"])
    accounts.record_equity(
        connector["user_id"], updated["id"], balance=balance, equity=equity, floating_pnl=floating,
        source="mt5_connector", confidence=0.99, observed_at=observed_at,
        payload={"connector_id": connector["id"], "margin": account_payload.get("margin"), "free_margin": account_payload.get("free_margin")},
    )

    snapshot_payload = {
        "provider": "SentinelConnectorMT5", "connector_id": connector["id"],
        "account_reference": str(connector.get("account_login") or ""), "balance": balance, "equity": equity,
        "floating_pnl": floating, "margin": _finite(account_payload.get("margin")),
        "free_margin": _finite(account_payload.get("free_margin")), "margin_level": _finite(account_payload.get("margin_level")),
        "positions": positions_payload[:_MAX_POSITIONS], "observed_at": observed_at, "confidence": 0.99,
        "terminal": payload.get("terminal") if isinstance(payload.get("terminal"), dict) else {},
    }
    checksum = content_hash(snapshot_payload)
    with db.transaction() as cursor:
        cursor.execute(
            """INSERT INTO v8_broker_snapshots(id,user_id,account_id,provider,account_reference,observed_at,confidence,checksum,payload)
               VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(account_id,observed_at) DO UPDATE SET
               provider=excluded.provider,confidence=excluded.confidence,checksum=excluded.checksum,payload=excluded.payload""",
            (
                new_id("brk"), str(connector["user_id"]), str(updated["id"]), "SentinelConnectorMT5",
                str(connector.get("account_login") or ""), observed_at, 0.99, checksum, json_dump(snapshot_payload),
            ),
        )
    position_result = _sync_positions(db, connector, updated, positions_payload, observed_at)
    deal_result = _sync_deals(db, connector, updated, deals_payload)
    MT5ConnectorRepository(db).touch(
        connector["id"], snapshot=True,
        payload={
            "connector_version": (payload.get("terminal") or {}).get("connector_version") if isinstance(payload.get("terminal"), dict) else None,
            "terminal_build": (payload.get("terminal") or {}).get("build") if isinstance(payload.get("terminal"), dict) else None,
            "last_reason": payload.get("reason"), "last_checksum": checksum,
        },
    )
    from services.prop_guardian_service import account_guardian_snapshot

    guardian = account_guardian_snapshot(
        connector["user_id"], updated["id"], record=True, engine=db,
    )
    EventRepository(db).append(
        connector["user_id"],
        "mt5.snapshot_ingested",
        {
            "account_id": str(updated["id"]),
            "connector_id": str(connector["id"]),
            "observed_at": observed_at,
            "status": guardian.get("status"),
            "position_changes": position_result,
            "deal_changes": deal_result,
        },
        entity_type="trading_account",
        entity_id=str(updated["id"]),
    )
    for alert in guardian.get("new_alerts") or []:
        EventRepository(db).append(
            connector["user_id"],
            "prop_guardian.alert",
            {"account_id": str(updated["id"]), "connector_id": str(connector["id"]), **dict(alert)},
            entity_type="prop_alert",
            entity_id=str(alert.get("fingerprint") or alert.get("code") or ""),
        )
    # The public API uses the default production engine. Tests and offline tools
    # pass an explicit engine and intentionally do not touch the legacy Telegram
    # outbox.
    if engine is None:
        _queue_guardian_notifications(connector["user_id"], updated, list(guardian.get("new_alerts") or []))
    return {
        "accepted": True,
        "account_id": str(updated["id"]),
        "observed_at": observed_at,
        "positions": position_result,
        "deals": deal_result,
        "prop_decision": guardian.get("decision"),
        "guardian_status": guardian.get("status"),
        "hard_blocks": list(guardian.get("hard_blocks") or []),
        "warnings": list(guardian.get("warnings") or []),
        "alerts": list(guardian.get("alerts") or []),
        "new_alerts": list(guardian.get("new_alerts") or []),
        "metrics": dict(guardian.get("metrics") or {}),
        "capacity": dict(guardian.get("capacity") or {}),
        "what_if": dict(guardian.get("what_if") or {}),
        "next_sync_seconds": _SYNC_SECONDS,
    }


def record_connector_event(
    connector: dict[str, Any], payload: dict[str, Any], *, engine: DatabaseEngine | None = None
) -> dict[str, Any]:
    db = engine or normalized_engine()
    external_id = str(payload.get("external_id") or payload.get("transaction_id") or new_id("evt"))[:128]
    event_type = str(payload.get("event_type") or "trade_transaction")[:80]
    occurred_at = str(payload.get("occurred_at") or utc_iso())
    checksum = content_hash(payload)
    stored = MT5ConnectorRepository(db).record_event(
        connector, external_id=external_id, event_type=event_type, occurred_at=occurred_at, checksum=checksum, payload=payload,
    )
    MT5ConnectorRepository(db).touch(connector["id"], event=True)
    return {"accepted": True, "stored": stored, "request_snapshot": True}
