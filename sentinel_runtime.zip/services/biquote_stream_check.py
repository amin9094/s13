"""Bounded on-demand indicative stream diagnostic, never an execution owner."""

from __future__ import annotations

import asyncio
import json
import time
from decimal import Decimal

from modules.canonical_market import price
from services.keyless_market_data_service import _utc_ms, supported_symbols

HUB = "wss://biquote.io/hubs/tick"
_CACHE = {}
_INFLIGHT = {}


class StreamCheck:
    def __init__(self, symbol, metadata):
        self.symbol = symbol
        if not isinstance(metadata, dict) or metadata.get("name") != symbol:
            raise ValueError("STREAM_METADATA_INVALID")
        self.source = metadata.get("source")
        if not isinstance(self.source, str) or not 1 <= len(self.source) <= 100:
            raise ValueError("STREAM_METADATA_INVALID")
        self.exchange = metadata.get("exchange")
        if not isinstance(self.exchange, str) or not 1 <= len(self.exchange) <= 100:
            raise ValueError("STREAM_METADATA_INVALID")
        self.tick = price(metadata.get("tickSize"))
        self.digits = metadata.get("digits")
        if type(self.digits) is not int or not 0 <= self.digits <= 12 or self.tick % (Decimal(10) ** -self.digits):
            raise ValueError("STREAM_METADATA_INVALID")
        self.buffer = ""
        self.ack = False
        self.seeded = False
        self.quotes = 0
        self.updates = 0
        self.last = None
        self.first = None
        self.last_received_ms = None
        self.grid_consistent = True

    def receive(self, raw, received_ms):
        if not isinstance(raw, str) or len(raw) > 128000:
            raise ValueError("STREAM_FRAME_INVALID")
        self.buffer += raw
        if len(self.buffer) > 128000:
            raise ValueError("STREAM_FRAME_INVALID")
        records = self.buffer.split("\x1e")
        self.buffer = records.pop()
        if len(records) > 128:
            raise ValueError("STREAM_FRAME_INVALID")
        for record in records:
            try:
                row = json.loads(record, parse_float=Decimal)
            except (ValueError, TypeError):
                raise ValueError("STREAM_FRAME_INVALID") from None
            if not isinstance(row, dict):
                raise ValueError("STREAM_FRAME_INVALID")
            kind = row.get("type")
            if kind == 3:
                if row.get("invocationId") != "1" or "error" in row:
                    raise ValueError("STREAM_SUBSCRIPTION_REJECTED")
                self.ack = True
            elif kind == 7:
                raise ValueError("STREAM_CLOSED")
            elif kind == 1 and row.get("target") == "ReceiveSubscriptionState":
                args = row.get("arguments")
                if not isinstance(args, list) or len(args) != 1 or not isinstance(args[0], list):
                    raise ValueError("STREAM_STATE_INVALID")
                for state in args[0]:
                    if not isinstance(state, dict) or state.get("symbol") != self.symbol:
                        raise ValueError("STREAM_SYMBOL_MISMATCH")
                    if state.get("seeded") is not True or state.get("state") != "open":
                        raise ValueError("STREAM_SOURCE_NOT_OPEN")
                    self.seeded = True
            elif kind == 1 and row.get("target") == "ReceiveTick":
                args = row.get("arguments")
                if not isinstance(args, list) or len(args) != 1 or not isinstance(args[0], dict):
                    raise ValueError("STREAM_FRAME_INVALID")
                tick = args[0]
                if (
                    tick.get("symbol") != self.symbol
                    or tick.get("source") != self.source
                    or tick.get("exchange") != self.exchange
                ):
                    raise ValueError("STREAM_SOURCE_MISMATCH")
                bid, ask = price(tick.get("bid")), price(tick.get("ask"))
                if ask < bid or "spread" in tick and Decimal(str(tick["spread"])) != ask - bid:
                    raise ValueError("STREAM_PRICE_INVALID")
                if "mid" in tick and price(tick["mid"]) != (bid + ask) / 2:
                    raise ValueError("STREAM_PRICE_INVALID")
                stamp = _utc_ms(tick.get("timestamp"))
                if not 0 <= received_ms - stamp <= 5000:
                    raise ValueError("STREAM_TIMESTAMP_INVALID")
                if self.last is not None and stamp < self.last:
                    raise ValueError("STREAM_TIMESTAMP_REGRESSION")
                # Updates must follow the subscription state and acknowledgement,
                # and advance the native timestamp. Seeded ticks do not count.
                if self.ack and self.seeded and self.last is not None and stamp > self.last:
                    self.updates += 1
                self.first = stamp if self.first is None else self.first
                self.last = stamp
                self.last_received_ms = received_ms
                self.quotes += 1
                self.grid_consistent = self.grid_consistent and bid % self.tick == ask % self.tick == 0

    def report(self):
        return {
            "state": "UPDATES_OBSERVED" if self.updates else "INITIAL_QUOTES_ONLY" if self.quotes else "NO_QUOTES",
            "provider": "biquote",
            "symbol": self.symbol,
            "source_label": self.source,
            "subscription_acknowledged": self.ack,
            "initial_state_received": self.seeded,
            "quotes_received": self.quotes,
            "timestamp_advancing_updates": self.updates,
            "first_event_ms": self.first,
            "last_event_ms": self.last,
            "last_received_ms": self.last_received_ms,
            "reported_grid_consistent": self.grid_consistent if self.quotes else None,
            "reported_tick_size": str(self.tick),
            "native_sequence_verified": False,
            "continuous_pretouch_proof": False,
            "execution_eligible": False,
            "is_signal": False,
            "scope": "BOUNDED_UNSEQUENCED_INDICATIVE_STREAM_SAMPLE",
        }


async def _sample(symbol):
    from websockets.asyncio.client import connect

    from services.canonical_market_service import _request
    from services.keyless_market_data_service import BIQUOTE_ORIGIN

    check = None
    try:
        async with asyncio.timeout(20):
            metadata = await _request(f"{BIQUOTE_ORIGIN}/api/symbols/{symbol}")
            check = StreamCheck(symbol, metadata)
            async with connect(
                HUB, open_timeout=8, close_timeout=1, max_size=128000, max_queue=16, ping_interval=10, ping_timeout=5
            ) as socket:
                await socket.send('{"protocol":"json","version":1}\x1e')
                hello = await asyncio.wait_for(socket.recv(), timeout=6)
                if hello != "{}\x1e":
                    raise ValueError("STREAM_HANDSHAKE_INVALID")
                await socket.send(
                    json.dumps({"type": 1, "invocationId": "1", "target": "Subscribe", "arguments": [[symbol]]})
                    + "\x1e"
                )
                while check.updates < 2:
                    check.receive(await socket.recv(), int(time.time() * 1000))
    except TimeoutError:
        result = check.report() if check else {}
        return {
            **result,
            "state": "SAMPLE_TIMEOUT",
            "provider": "biquote",
            "symbol": symbol,
            "execution_eligible": False,
            "continuous_pretouch_proof": False,
            "is_signal": False,
        }
    except Exception:
        # Bound the public error; never return provider exception text or URLs.
        return {
            "state": "STREAM_UNAVAILABLE_OR_INVALID",
            "provider": "biquote",
            "symbol": symbol,
            "execution_eligible": False,
            "continuous_pretouch_proof": False,
            "is_signal": False,
        }
    return check.report()


async def sample_stream(symbol):
    symbol = str(symbol).strip().upper().replace("/", "")
    if symbol not in supported_symbols():
        raise ValueError("STREAM_MARKET_UNSUPPORTED")
    cached = _CACHE.get(symbol)
    if cached and cached[0] > time.monotonic():
        return cached[1]
    key = (asyncio.get_running_loop(), symbol)
    task = _INFLIGHT.get(key)
    if task is None:

        async def work():
            try:
                result = {**await _sample(symbol), "sample_observed_ms": int(time.time() * 1000)}
                if len(_CACHE) >= 32:
                    _CACHE.pop(next(iter(_CACHE)))
                _CACHE[symbol] = (time.monotonic() + 30, result)
                return result
            finally:
                _INFLIGHT.pop(key, None)

        task = asyncio.create_task(work())
        _INFLIGHT[key] = task
    return await asyncio.shield(task)
