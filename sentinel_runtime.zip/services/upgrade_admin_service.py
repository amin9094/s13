"""Manual operational diagnostics; no background governance is enabled here."""
import time,re
from core.storage.engine import normalized_engine
from repositories.v2.common import json_load,json_dump,content_hash


def _permit(user,permission=None):
    from services.live_signal_service import permitted
    permitted(user)
    if permission:
        from modules.admin_access import has_permission
        from core.db import read_db_sections
        if not has_permission(read_db_sections(('delegated_admins','admin_shifts')),user,permission):raise PermissionError('FORBIDDEN')


def operations(user):
    _permit(user);db=normalized_engine();now=int(time.time()*1000)
    from core.async_runtime import blocking_executor_snapshot
    from core.observability import public_health_snapshot
    with db.transaction(read_only=True,repeatable_read=True) as c:
        pending=c.execute("SELECT COUNT(*) AS n,MIN(created_ms) AS oldest_ms FROM s9_signal_inbox WHERE state='PENDING'").fetchone()
        paper=c.execute('SELECT state,COUNT(*) AS n FROM s9_strategy_paper_trades GROUP BY state').fetchall()
        deliveries=c.execute("SELECT state,COUNT(*) AS n FROM s9_deliveries GROUP BY state").fetchall()
        quotes=c.execute('SELECT provider,MAX(received_ms) AS last_ms FROM s9_quote_archive GROUP BY provider').fetchall()
        candles=c.execute('SELECT provider,MAX(end_ms) AS last_ms FROM s9_candles GROUP BY provider').fetchall()
        cases=c.execute('SELECT MAX(created_ms) AS last_ms,COUNT(*) AS n FROM s9_research_cases').fetchone()
        exports=c.execute('SELECT state,COUNT(*) AS n FROM s9_export_jobs WHERE expires_ms>? GROUP BY state',(now,)).fetchall()
    from repositories.v2.desk_insights import funnel
    from core.full_backup import backup_health
    from core.db import read_db_sections
    return {'discovery':funnel(db),'backup_health':backup_health(read_db_sections(('operations',))),'observed_ms':now,'health':public_health_snapshot(),'workers':blocking_executor_snapshot(),
            'pending_decisions':pending,'paper':paper,'deliveries':deliveries,'quote_coverage':quotes,'closed_candles':candles,
            'research_capture':cases,'exports':exports,'operation_mode':'MANUAL_READ_ONLY','governance_auto_enabled':False,
            'read_only_outage_policy':'CACHED_SNAPSHOT_LABELLED_STALE_NO_MUTATION_OR_PUBLICATION'}


def provider_usage(user):
    _permit(user);now=int(time.time()*1000);db=normalized_engine();groups={}
    with db.transaction(read_only=True) as c:rows=c.execute('SELECT id,payload FROM s9_provider_budget').fetchall()
    for row in rows:
        provider=row['id'].split(':',1)[0];events=json_load(row['payload']);g=groups.setdefault(provider,{'provider':provider,'reserved_today':0,'reserved_last_minute':0,'gold_credits_today':0})
        for e in events:
            if e[0]>=now//86400000*86400000:
                g['reserved_today']+=e[1];g['gold_credits_today']+=e[1] if len(e)>2 and e[2]=='gold' else 0
            if e[0]>now-60000:g['reserved_last_minute']+=e[1]
    from core.provider_usage import snapshot
    from repositories.v2.provider_budget import _limit
    limits={'twelve_data':{'minute':_limit('TWELVE_DATA_MINUTE_BUDGET',7,8),'daily':_limit('TWELVE_DATA_DAILY_BUDGET',720,800),'non_gold_daily':_limit('TWELVE_DATA_NON_GOLD_DAILY_BUDGET',360,_limit('TWELVE_DATA_DAILY_BUDGET',720,800))},
            'streamdata':{'minute':_limit('STREAMDATA_MINUTE_BUDGET',20,30),'daily':_limit('STREAMDATA_DAILY_BUDGET',2000,43200)}}
    return {'observed_ms':now,'items':list(groups.values()),'http_and_cache':snapshot(),'coverage':'QUOTA_RESERVATIONS_FOR_METERED_PROVIDERS_ONLY','configured_limits_per_credential':limits,'provider_account_remaining_quota':None,'limits_scope':'LOCAL_CONFIGURED_RESERVATION_LIMITS_NOT_PROVIDER_ACCOUNT_BALANCE',
            'failed_requests_consume_reservations':True,'successful_calls':None,'cache_hits':None,
            'unmetered_calls_not_claimed_counted':True,'secrets_included':False}


def permissions(user,target=None):
    _permit(user)
    from modules.admin_access import has_permission,ALL_PERMISSIONS,PERMISSION_LABELS
    from core.db import read_db_sections
    db=read_db_sections(('delegated_admins','admin_shifts'))
    target=str(user) if target is None else str(target)
    if target!=str(user) and not has_permission(db,user,'admin_management'):raise PermissionError('FORBIDDEN')
    return {'target':target,'read_only':True,'items':[{'permission':p,'label':PERMISSION_LABELS.get(p,p),'allowed':has_permission(db,target,p)} for p in ALL_PERMISSIONS],
            'paper_actions_require_separate_grants':True,'preview_changes_permissions':False}


def retention(user,body=None):
    _permit(user,'retention');db=normalized_engine();now=int(time.time()*1000)
    with db.transaction(read_only=True) as c:
        rows=c.execute('SELECT id,state FROM s9_export_jobs WHERE expires_ms<?',(now,)).fetchall()
        research=c.execute("SELECT id FROM s9_research_jobs WHERE created_ms<? AND state NOT IN ('QUEUED','RUNNING')",(now-86400000,)).fetchall()
    ids=sorted(r['id'] for r in rows);jobs=sorted(r['id'] for r in research)
    fingerprint=content_hash({'exports':ids,'research_jobs':jobs})
    result={'revision':fingerprint,'expired_exports':len(ids),'old_research_job_results':len(jobs),
            'preserved':['SIGNALS','PAPER_RUNS','PAPER_TRADES','EQUITY','RESEARCH_INPUT_CASES','ANNOTATIONS','PUBLICATIONS','FINANCIAL_RECORDS'],
            'automatic_cleanup_enabled':False,'research_result_retention_hours':24,'export_expiry_minutes':30}
    if body is None:return result
    if not isinstance(body,dict) or body!={'revision':fingerprint,'action':'cleanup_temporary'}:raise ValueError('RETENTION_PREVIEW_CHANGED')
    from services.paper_export_service import _directory
    for key in ids:
        if re.fullmatch('[a-f0-9]{32}',key):
            (_directory()/(key+'.csv')).unlink(missing_ok=True);(_directory()/(key+'.partial')).unlink(missing_ok=True)
    with db.transaction() as c:
        for key in ids:c.execute('DELETE FROM s9_export_jobs WHERE id=? AND expires_ms<?',(key,now))
        for key in jobs:c.execute("DELETE FROM s9_research_jobs WHERE id=? AND created_ms<? AND state NOT IN ('QUEUED','RUNNING')",(key,now-86400000))
        from repositories.v2.signal_timeline import record
        record(c,'maintenance','TEMPORARY_RETENTION',now,{'actor':str(user),'exports':len(ids),'research_jobs':len(jobs),'preview':fingerprint})
    return {**result,'state':'COMPLETED'}
