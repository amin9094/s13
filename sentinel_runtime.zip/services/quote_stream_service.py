"""Read-only exchange quotes; snapshots and reconnection do not prove a touch."""

from __future__ import annotations

import asyncio
import json
import time
from datetime import datetime
from decimal import Decimal

from modules.canonical_market import Quote

OKX_PUBLIC_WS = "wss://ws.okx.com/ws/v5/public"
KRAKEN_PUBLIC_WS = "wss://ws.kraken.com/v2"


async def stream_kraken_ordered_quotes(symbol_tick_sizes, *, epoch):
    """Continuous v2 spot book with CRC32, local ordinals and exact decimals."""
    from websockets.asyncio.client import connect

    from modules.ordered_quotes import KrakenBook

    if not symbol_tick_sizes or len(symbol_tick_sizes) > 25:
        raise ValueError('ORDERED_QUOTE_SUBSCRIPTION_SIZE_INVALID')
    books = {symbol[:-4]+'/USDT':KrakenBook(symbol,tick,epoch) for symbol,tick in symbol_tick_sizes.items()}
    params = {'channel':'book','symbol':list(books),'depth':10,'snapshot':True}
    async with connect(KRAKEN_PUBLIC_WS,open_timeout=10,ping_interval=20,ping_timeout=10,
                       max_size=2_000_000,max_queue=32) as socket:
        await socket.send(json.dumps({'method':'subscribe','params':params}))
        try:
            while True:
                raw = await asyncio.wait_for(socket.recv(),timeout=20)
                payload = json.loads(raw,parse_float=Decimal)
                if payload.get('method') == 'subscribe' and not payload.get('success',False):
                    raise ValueError('ORDERED_QUOTE_SUBSCRIPTION_REJECTED')
                if payload.get('channel') != 'book':
                    continue
                for row in payload.get('data') or []:
                    pair = row.get('symbol')
                    if pair not in books:
                        raise ValueError('ORDERED_QUOTE_SYMBOL_MISMATCH')
                    yield books[pair].update(row,action=payload.get('type'),received_ms=int(time.time()*1000))
        finally:
            if socket.close_code is None:
                await socket.send(json.dumps({'method':'unsubscribe','params':params}))


async def stream_okx_ordered_quotes(symbol_tick_sizes, *, epoch):
    """Public incremental books. Validate prevSeqId; never join reconnect epochs."""
    from websockets.asyncio.client import connect

    from modules.ordered_quotes import OKXBook

    if not symbol_tick_sizes or len(symbol_tick_sizes) > 25:
        raise ValueError('ORDERED_QUOTE_SUBSCRIPTION_SIZE_INVALID')
    books = {symbol[:-4]+'-USDT':OKXBook(symbol,tick,epoch) for symbol,tick in symbol_tick_sizes.items()}
    args = [{'channel':'books','instId':pair} for pair in books]
    async with connect(OKX_PUBLIC_WS,open_timeout=10,ping_interval=20,ping_timeout=10,max_size=2_000_000,max_queue=32) as socket:
        await socket.send(json.dumps({'op':'subscribe','args':args}))
        try:
            while True:
                try:
                    raw = await asyncio.wait_for(socket.recv(),timeout=20)
                except TimeoutError:
                    await socket.send('ping')
                    raw = await asyncio.wait_for(socket.recv(),timeout=10)
                if raw == 'pong':
                    continue
                payload = json.loads(raw)
                if payload.get('event') == 'error' or payload.get('code') not in {None,'','0',0}:
                    raise ValueError('ORDERED_QUOTE_SUBSCRIPTION_INTERRUPTED')
                if payload.get('arg',{}).get('channel') != 'books' or payload.get('event') == 'subscribe':
                    continue
                pair = payload['arg'].get('instId')
                if pair not in books:
                    raise ValueError('ORDERED_QUOTE_SYMBOL_MISMATCH')
                for row in payload.get('data') or []:
                    frame = books[pair].update(row,action=payload.get('action'),received_ms=int(time.time()*1000))
                    if frame is not None:
                        yield frame
        finally:
            if socket.close_code is None:
                await socket.send(json.dumps({'op':'unsubscribe','args':args}))


def kraken_ticker_quote(row, *, tick_size, received_ms=None, snapshot=False):
    base, quote_currency = str(row["symbol"]).upper().split("/")
    if quote_currency not in {"USDT", "USD"}:
        raise ValueError("QUOTE_MARKET_UNSUPPORTED")
    symbol = {"XBT": "BTC", "XDG": "DOGE"}.get(base, base) + quote_currency
    stamp = str(row["timestamp"])
    event_ms = int(datetime.fromisoformat(stamp.replace("Z", "+00:00")).timestamp() * 1000)
    received_ms = received_ms or int(time.time() * 1000)
    flags = ("INITIAL_SNAPSHOT_NO_CONTINUITY",) if snapshot else ()
    return Quote(
        symbol,
        "kraken",
        f"kraken_spot_{quote_currency}",
        "spot",
        event_ms,
        received_ms,
        Decimal(str(row["bid"])),
        Decimal(str(row["ask"])),
        Decimal(str(tick_size)),
        f"kraken:{row['symbol']}:{stamp}:{row['bid']}:{row['ask']}",
        flags,
    )


async def stream_kraken_quotes(symbol_tick_sizes):
    """One subscription, graceful unsubscribe, no automatic reconnect across gaps.

    The owning job must mark active setups NEEDS_REVIEW on stream failure, then
    reconcile full quote history before a new subscription can resume tracking.
    No order-creation endpoint exists in this module.
    """
    from websockets.asyncio.client import connect

    symbols = {}
    for symbol, size in symbol_tick_sizes.items():
        quote_currency = "USDT" if symbol.endswith("USDT") else "USD" if symbol.endswith("USD") else None
        if quote_currency is None:
            raise ValueError("QUOTE_MARKET_UNSUPPORTED")
        base = symbol[: -len(quote_currency)]
        symbols[base + "/" + quote_currency] = size
    if not symbols:
        raise ValueError("QUOTE_SYMBOLS_REQUIRED")
    async with connect(
        "wss://ws.kraken.com/v2", open_timeout=10, ping_interval=20, ping_timeout=10, max_size=1_000_000
    ) as socket:
        params = {"channel": "ticker", "symbol": list(symbols), "event_trigger": "bbo", "snapshot": True}
        await socket.send(json.dumps({"method": "subscribe", "params": params}))
        try:
            async for raw in socket:
                payload = json.loads(raw)
                if payload.get("method") == "subscribe" and not payload.get("success", False):
                    raise ValueError("QUOTE_SUBSCRIPTION_REJECTED")
                if payload.get("channel") != "ticker":
                    continue
                for row in payload.get("data") or []:
                    if row.get("symbol") not in symbols:
                        raise ValueError("QUOTE_SYMBOL_MISMATCH")
                    yield kraken_ticker_quote(
                        row, tick_size=symbols[row["symbol"]], snapshot=payload.get("type") == "snapshot"
                    )
        finally:
            if socket.close_code is None:
                await socket.send(json.dumps({"method": "unsubscribe", "params": params}))


def okx_bbo_quote(row, *, tick_size, received_ms=None, snapshot=False):
    base, quote_currency = str(row["instId"]).split("-")
    if quote_currency != "USDT":
        raise ValueError("QUOTE_MARKET_UNSUPPORTED")
    bid, ask = row["bids"][0][0], row["asks"][0][0]
    stamp = int(row["ts"])
    return Quote(
        base + "USDT",
        "okx",
        "okx_spot_USDT",
        "spot",
        stamp,
        received_ms or int(time.time() * 1000),
        Decimal(str(bid)),
        Decimal(str(ask)),
        Decimal(str(tick_size)),
        f"okx:{row['instId']}:{stamp}:{row.get('seqId')}:{bid}:{ask}",
        ("INITIAL_SNAPSHOT_NO_CONTINUITY",) if snapshot else (),
    )


async def stream_okx_quotes(symbol_tick_sizes):
    """Native read-only BBO snapshots; a new connection cannot repair a gap."""
    from websockets.asyncio.client import connect

    symbols = {}
    for symbol, tick in symbol_tick_sizes.items():
        if not symbol.endswith("USDT"):
            raise ValueError("CRYPTO_USDT_MARKET_REQUIRED")
        symbols[symbol[:-4] + "-USDT"] = tick
    if not symbols:
        raise ValueError("QUOTE_SYMBOLS_REQUIRED")
    args = [{"channel": "bbo-tbt", "instId": name} for name in symbols]
    seen = set()
    async with connect(OKX_PUBLIC_WS, open_timeout=10, ping_interval=20, ping_timeout=10, max_size=1_000_000) as socket:
        await socket.send(json.dumps({"op": "subscribe", "args": args}))
        try:
            while True:
                try:
                    raw = await asyncio.wait_for(socket.recv(), timeout=20)
                except TimeoutError:
                    await socket.send("ping")
                    raw = await asyncio.wait_for(socket.recv(), timeout=10)
                if raw == "pong":
                    continue
                payload = json.loads(raw)
                if payload.get("event") == "error" or payload.get("code") == "64008":
                    raise ValueError("QUOTE_SUBSCRIPTION_FAILED_OR_INTERRUPTED")
                if payload.get("arg", {}).get("channel") != "bbo-tbt":
                    continue
                name = payload["arg"].get("instId")
                if name not in symbols:
                    raise ValueError("QUOTE_SYMBOL_MISMATCH")
                for row in payload.get("data") or []:
                    if row.get("instId", name) != name:
                        raise ValueError("QUOTE_SYMBOL_MISMATCH")
                    quote = okx_bbo_quote({**row, "instId": name}, tick_size=symbols[name], snapshot=name not in seen)
                    seen.add(name)
                    yield quote
        finally:
            if socket.close_code is None:
                await socket.send(json.dumps({"op": "unsubscribe", "args": args}))
