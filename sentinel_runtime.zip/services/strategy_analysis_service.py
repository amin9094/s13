"""Explicit admin analysis, with real spread/precision prerequisites."""

from __future__ import annotations

import time
from decimal import Decimal

from core.async_runtime import run_blocking
from modules.canonical_market import ANALYSIS_TIMEFRAMES
from services.canonical_market_service import historical_bars
from services.market_data_issues import data_block, safe_market_error


async def _research_analysis(symbol, timeframe, *, instrument=None, parameters=None, engine_parameters=(),
                            provider=None, expected_venue=None, expected_product=None, admin_review=False):
    if timeframe not in ANALYSIS_TIMEFRAMES:
        raise ValueError("ANALYSIS_TIMEFRAME_UNAPPROVED")
    from services.canonical_market_service import CORE_SYMBOLS, kraken_rest_pair

    symbol = str(symbol).upper().strip().replace("/", "")
    from modules.automated_market_scope import require_global_symbol
    require_global_symbol(symbol)
    if admin_review:
        from services.keyless_market_data_service import supported_symbols
        if symbol not in supported_symbols() or provider not in {None,'biquote'} or expected_venue not in {None,'biquote_aggregate_indicative'} or expected_product not in {None,'indicative'}:
            raise ValueError('ADMIN_REVIEW_SOURCE_INVALID')
        from services.admin_review_market_service import analyze_admin_review
        return await analyze_admin_review(symbol,timeframe,parameters=parameters,engine_parameters=engine_parameters)
    if symbol not in CORE_SYMBOLS and not symbol.endswith("USDT"):
        raise ValueError("CRYPTO_USDT_MARKET_REQUIRED")
    from services.canonical_market_service import MarketUnavailable
    try:
        bars = await historical_bars(symbol, timeframe, limit=300, **({"provider":provider} if provider else {}))
    except MarketUnavailable as exc:
        return data_block(safe_market_error(exc),symbol=symbol,timeframe=timeframe)
    if not bars:
        return data_block('MARKET_BARS_EMPTY',symbol=symbol,timeframe=timeframe)
    if (provider is not None and bars[-1].provider != provider
            or expected_venue is not None and bars[-1].venue != expected_venue
            or expected_product is not None and bars[-1].product != expected_product):
        return data_block('CHART_ANALYSIS_MARKET_IDENTITY_MISMATCH',symbol=symbol,timeframe=timeframe,
                          provider=bars[-1].provider,product=bars[-1].product)
    if symbol in CORE_SYMBOLS and instrument is None:
        # Analysis is independent of execution: no guessed spread, grid or POC.
        from modules.strategies.common import Parameters
        from modules.strategies.observations import ObservationContext,evaluate_observations
        context = ObservationContext(tuple(bars),int(time.time()*1000),parameters or Parameters(),tuple(engine_parameters))
        try:
            result = await run_blocking(evaluate_observations,context,timeout=20)
        except ValueError as exc:
            allowed = {'INDICATOR_WARMUP_INCOMPLETE','MARKET_DATA_STALE_OR_SESSION_CLOSED',
                       'DELAYED_ANALYSIS_SOURCE','ENGINE_PROFILE_SELECTION_INVALID'}
            reason = str(exc) if str(exc) in allowed else 'INVALID_ANALYSIS_CANDLES'
            return data_block(reason,symbol=symbol,timeframe=timeframe,provider=bars[-1].provider)
        from repositories.v2.market_evidence import MarketEvidenceRepository
        try:
            await run_blocking(lambda:MarketEvidenceRepository().save_candles(bars),timeout=15)
        except ValueError as exc:
            if str(exc) not in {'CLOSED_CANDLE_CORRECTION_REQUIRES_REVIEW','CANDLE_PROVENANCE_CHANGE_REQUIRES_REVIEW','CLOSED_CANDLE_REOPEN_OR_STALE_REVISION_REQUIRES_REVIEW'}:
                raise
            return data_block(str(exc),symbol=symbol,timeframe=timeframe,provider=bars[-1].provider)
        if symbol == 'XAUUSD':
            from services.market_reference_service import gold_reference
            try:
                result['independent_reference'] = await gold_reference(symbol)
            except Exception:
                result['independent_reference'] = {'state':'UNAVAILABLE','execution_eligible':False}
        return result
    if symbol in {"US30", "US100", "NAS100"} and bars[-1].product != "cfd":
        return data_block('REQUESTED_CFD_HISTORY_UNAVAILABLE_CASH_INDEX_IS_DIFFERENT_PRODUCT',
                          symbol=symbol,timeframe=timeframe,provider=bars[-1].provider,product=bars[-1].product)
    if instrument is None and bars[-1].provider == "kraken":
        from services.canonical_market_service import _request

        pair = kraken_rest_pair(symbol)
        metadata = await _request("https://api.kraken.com/0/public/AssetPairs", {"pair": pair})
        ticker = await _request("https://api.kraken.com/0/public/Ticker", {"pair": pair})
        details = next(iter((metadata.get("result") or {}).values()), None)
        book = next(iter((ticker.get("result") or {}).values()), None)
        if details and book and details.get("tick_size"):
            spread = Decimal(str(book["a"][0])) - Decimal(str(book["b"][0]))
            instrument = {
                "verified": spread >= 0,
                "provider": "kraken",
                "tick_size": details["tick_size"],
                "spread": str(spread),
                "quote_time_kind": "REST_RECEIPT_ONLY_NOT_VERIFIED_ENTRY",
            }
    if instrument is None and bars[-1].provider == "okx":
        from services.canonical_market_service import _crypto_base, _request

        pair = _crypto_base(symbol) + "-USDT"
        metadata = await _request("https://www.okx.com/api/v5/public/instruments", {"instType": "SPOT", "instId": pair})
        ticker = await _request("https://www.okx.com/api/v5/market/ticker", {"instId": pair})
        details = next(
            (row for row in metadata.get("data") or [] if row.get("instId") == pair and row.get("state") == "live"),
            None,
        )
        book = next((row for row in ticker.get("data") or [] if row.get("instId") == pair), None)
        if metadata.get("code") == ticker.get("code") == "0" and details and book and details.get("tickSz"):
            spread = Decimal(str(book["askPx"])) - Decimal(str(book["bidPx"]))
            age = int(time.time() * 1000) - int(book["ts"])
            instrument = {
                "verified": spread >= 0 and 0 <= age <= 5000,
                "provider": "okx",
                "tick_size": details["tickSz"],
                "spread": str(spread),
                "quote_time_kind": "NATIVE_REST_SNAPSHOT_NOT_VERIFIED_ENTRY",
            }
    # No guessed FX spread, precision, or missing broker/venue equivalence.
    if not instrument or not instrument.get("verified") or instrument.get("provider") != bars[-1].provider:
        return data_block('MATCHING_SPREAD_AND_TICK_SIZE_UNVERIFIED',symbol=symbol,timeframe=timeframe,
                          provider=bars[-1].provider,data_gap='SOURCE_BOUND_SPREAD_AND_NATIVE_PRICE_GRID_REQUIRED')
    from modules.strategy_engines import Context, Parameters, evaluate_all
    from services.strategy_quote_owner import current_owner
    owner=current_owner()
    owner_ready=bool(owner and await owner.ensure(symbol,bars[-1].provider,instrument['tick_size']))

    # Discover real causal OB windows before paging minute volume. Shared
    # cached history is never used as quote continuity or publication proof.
    from services.causal_profile_service import wave_profile
    initial_cutoff=max(bar.available_ms for bar in bars)
    context = Context(tuple(bars), initial_cutoff, Decimal(str(instrument["tick_size"])), Decimal(str(instrument["spread"])),
                      parameters=parameters or Parameters(),
                      ob_departure_proofs=tuple(instrument.get("ob_departure_proofs") or ()),
                      pip_size=Decimal(str(instrument["pip_size"])) if instrument.get("pip_size") else None)
    profile=await wave_profile(context,engine_parameters=engine_parameters)
    from dataclasses import replace
    context=replace(context,profile_candles=profile,cutoff_ms=max(b.available_ms for b in (*bars,*profile)))
    if engine_parameters:
        from dataclasses import replace
        context = replace(context, engine_parameters=tuple(engine_parameters))
    # Profile ingestion must not move the chart observation cutoff into an
    # unobserved gap. Refresh the same provider's current bar after pagination.
    if owner_ready or profile and context.cutoff_ms > max(bar.available_ms for bar in bars):
        from dataclasses import replace

        from services.canonical_market_service import _historical_bars

        refreshed = await _historical_bars(symbol, timeframe, limit=300, provider=bars[-1].provider)
        if refreshed:
            cutoff = max(bar.available_ms for bar in (*refreshed, *profile))
            context = replace(context, candles=tuple(refreshed), cutoff_ms=cutoff)
    if owner_ready:
        from dataclasses import replace
        journal=owner.journal_for(symbol,bars[-1].provider)
        known=next((frame.quote for frame in reversed(journal.rows) if frame.quote.event_ms<=context.cutoff_ms and not frame.snapshot),None) if journal and not journal.failure else None
        if known and known.fresh(int(time.time()*1000)):
            context=replace(context,current_quote=known,spread=known.ask-known.bid)
    from repositories.v2.market_evidence import MarketEvidenceRepository

    from dataclasses import replace
    from services.goldbach_settings_service import settings_for
    from services.custom_strategy_service import current_settings
    context=replace(context,goldbach_settings=await run_blocking(settings_for,symbol,timeout=5),
                    custom_settings=await run_blocking(current_settings,timeout=5))
    context.validate()
    await run_blocking(lambda: MarketEvidenceRepository().save_candles([*context.candles, *profile]), timeout=15)
    result = await run_blocking(evaluate_all, context, timeout=20)
    if bars[-1].provider == "okx":
        from dataclasses import replace

        from services.ordered_trade_evidence_service import okx_departure_proof

        unresolved = [row for row in result["results"] if row.get("reason") == "OB_FIRST_DEPARTURE_ORDER_UNPROVEN"][-3:]
        proofs = list(context.ob_departure_proofs)
        for row in unresolved:
            index = next((i for i, bar in enumerate(context.closed) if bar.source_id == row["ob_source_id"]), None)
            if index is None or index + 1 >= len(context.closed):
                continue
            proof = await okx_departure_proof(context.closed[index], context.closed[index + 1])
            if proof:
                proofs.append(proof)
        if len(proofs) > len(context.ob_departure_proofs):
            # Trade-history receipt is new evidence. Refresh current coverage
            # before advancing the cutoff; never pretend it was known earlier.
            from services.canonical_market_service import _historical_bars

            refreshed = await _historical_bars(symbol, timeframe, limit=300, provider=bars[-1].provider)
            if refreshed:
                context = replace(context, candles=tuple(refreshed), ob_departure_proofs=tuple(proofs),
                                  cutoff_ms=max(*(bar.available_ms for bar in refreshed),
                                                *(proof["available_ms"] for proof in proofs)))
                context.validate()
                await run_blocking(lambda: MarketEvidenceRepository().save_candles(context.candles), timeout=15)
                result = await run_blocking(evaluate_all, context, timeout=20)
    try:
        from services.custom_shadow_service import compare as compare_shadow
        result['shadow_comparison']=await run_blocking(compare_shadow,context,result,timeout=10)
    except Exception:
        result['shadow_comparison']={'state':'COMPARISON_UNAVAILABLE'}
    # Preserve actual inputs only for newly discovered proposals. Capture is
    # separate from eligibility and cannot turn missing evidence into a signal.
    try:
        from repositories.v2.research_cases import ResearchCases
        epoch=None
        journal=owner.journal_for(symbol,context.candles[-1].provider) if owner_ready else None
        if journal and context.current_quote:
            frame=next((f for f in reversed(journal.rows) if getattr(f,'quote',None)==context.current_quote),None)
            epoch=getattr(frame,'epoch',None)
        result['research_capture']=await run_blocking(ResearchCases(MarketEvidenceRepository().engine).capture,context,result,quote_epoch=epoch,timeout=10)
    except Exception:
        result['research_capture']={'state':'INPUT_CAPTURE_UNAVAILABLE'}
    return result


async def research_analysis(symbol, timeframe, **kwargs):
    # All entry paths (native, explicit instruments and indicative review)
    # expose an actionable data case instead of an unhandled storage error.
    try:
        return await _research_analysis(symbol,timeframe,**kwargs)
    except ValueError as exc:
        if str(exc) not in {'CLOSED_CANDLE_CORRECTION_REQUIRES_REVIEW','CANDLE_PROVENANCE_CHANGE_REQUIRES_REVIEW','CLOSED_CANDLE_REOPEN_OR_STALE_REVISION_REQUIRES_REVIEW'}:
            raise
        return data_block(str(exc),symbol=str(symbol).upper().replace('/',''),timeframe=timeframe,
                          **({'provider':kwargs['provider']} if kwargs.get('provider') else {}))
