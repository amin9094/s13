"""Explicit admin analysis storage, never automatic public signal approval."""

from __future__ import annotations

import time

from core.async_runtime import run_blocking
from services.setup_review_service import can_review_setups


def _save_analysis(result):
    from modules.setup_lifecycle import SetupPlan
    from repositories.v2.setup_proposals import SetupRepository
    from repositories.v2.strategy_reviews import StrategyReviewRepository

    result = dict(result)
    rows = list(result.get("results") or [])
    # A failed manual analysis has no candidate plan, but still needs a durable
    # admin case. Otherwise the chart UI mistakes a source failure for no setup.
    if not rows and result.get('state') in {'NEEDS_REVIEW','UNAVAILABLE'} and result.get('symbol') and result.get('timeframe'):
        rows.append({'engine':'market_data','symbol':result['symbol'],'timeframe':result['timeframe'],
                     'state':'NEEDS_REVIEW','reason':result.get('reason','MARKET_DATA_UNAVAILABLE'),
                     'title_fa':'نیازمند بررسی: اتصال دادهٔ این بازار کامل نیست',
                     'available_ms':int(time.time()*1000),
                     **{key:result[key] for key in ('explanation_fa','required_action_fa','provider','product','data_gap') if key in result}})
    result['results']=rows
    reviews = [row for row in rows if row.get("state") in {"NEEDS_REVIEW","ANALYTICAL_OBSERVATION"}]
    saved = []
    repository = SetupRepository()
    for row in rows:
        if row.get('state') == 'ANALYTICAL_OBSERVATION' or row.get('observation'):
            if row.get('plan'):
                raise ValueError('OBSERVATION_CANNOT_BECOME_EXECUTABLE_PLAN')
            continue
        if not row.get("plan"):
            continue
        plan = SetupPlan.from_dict(row["plan"])
        created_ms = int(time.time() * 1000)
        if row["freshness_proof"].get("observed_through_ms", 0) < created_ms:
            # Never backdate creation to the earlier analysis cutoff. The
            # missing interval requires the continuous quote owner's proof.
            reviews.append({"engine": plan.engine, "symbol": plan.symbol, "timeframe": plan.timeframe,
                            "state": "NEEDS_REVIEW", "reason": "ANALYSIS_TO_PROPOSAL_FRESHNESS_GAP",
                            "title_fa": "نیازمند بررسی: تازگی محدوده تا زمان ارسال تأیید نشده",
                            "available_ms": created_ms, "thesis_key": plan.thesis_key,
                            "profile_id": row["profile_id"], "draft_plan": plan.as_dict()})
            continue
        saved.append(repository.propose(plan, proposed_ms=created_ms,
                                        freshness_proof=row["freshness_proof"],
                                        profile_id=row["profile_id"], sample_kind="shadow_forward"))
    result["stored_setups"] = saved
    result["new_review_ids"] = StrategyReviewRepository().store(reviews)
    result["publicly_approved"] = False
    return result


async def analyze_and_store(user_id, symbol, timeframe, *, profile_id=None, provider=None, expected_venue=None, expected_product=None, admin_review=False):
    if not await run_blocking(can_review_setups, user_id, timeout=5):
        raise PermissionError("FORBIDDEN")
    from services.strategy_analysis_service import research_analysis

    parameters = None
    if profile_id:
        from modules.strategy_engines import Parameters
        from modules.strategy_experiments import research_profiles

        parameters = next((p for p in research_profiles(Parameters()) if p.profile_id == profile_id), None)
        if parameters is None:
            raise ValueError("RESEARCH_PROFILE_NOT_REGISTERED")
    async def work():
        from services.strategy_quote_owner import current_owner
        market_identity = {key:value for key,value in (("provider",provider),("expected_venue",expected_venue),
                           ("expected_product",expected_product)) if value is not None}
        if admin_review:market_identity['admin_review']=True
        from services.live_signal_service import scanner_parameters
        profiles=await run_blocking(scanner_parameters,{},timeout=5) if parameters is None else ()
        result = await research_analysis(symbol, timeframe, parameters=parameters,
                                         **({'engine_parameters':profiles} if profiles else {}), **market_identity)
        owner=current_owner()
        saved=await owner.prepare_result(result) if owner else await run_blocking(_save_analysis,result,timeout=10)
        from services.live_signal_service import stage_results
        saved['live_signal_ids'] = await stage_results(saved,owner)
        return saved
    # PTB owns the streams. The API server may run in another thread/loop.
    from core.miniapp_server import _run_on_telegram_loop
    result=await _run_on_telegram_loop(work())
    return result if result is not None else await work()


def review_cases(user_id, **filters):
    if not can_review_setups(user_id):
        raise PermissionError("FORBIDDEN")
    from repositories.v2.strategy_reviews import StrategyReviewRepository

    return {"admin": True, "items": StrategyReviewRepository().list(**filters)}
