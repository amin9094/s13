"""Admin-selected research profiles for future scans, never automatic winners."""

from core.db import read_db_sections, with_db_sections
from services.setup_review_service import can_review_setups

SELECTABLE_ENGINES = frozenset({'indicators', 'sweep_fvg', 'order_block', 'fibonacci_pullback'})


def selected_parameters(settings):
    from modules.strategy_engines import Parameters
    from modules.strategy_experiments import research_profiles

    registered = {p.profile_id: p for p in research_profiles(Parameters())}
    selected = settings.get('selected_profiles') or {}
    if not isinstance(selected, dict) or set(selected) - SELECTABLE_ENGINES or any(not isinstance(value,str) or value not in registered for value in selected.values()):
        raise ValueError('STORED_RESEARCH_PROFILE_INVALID')
    return tuple((engine, registered[value]) for engine, value in sorted(selected.items()))


def profile_selection(user_id):
    if not can_review_setups(user_id):
        raise PermissionError('FORBIDDEN')
    db = read_db_sections(('settings',))
    settings = db.get('settings', {}).get('strategyResearch', {})
    return {'selected_profiles': {engine: p.profile_id for engine, p in selected_parameters(settings)},
            'selectable_engines': sorted(SELECTABLE_ENGINES), 'automatic_live_selection': False}


def select_profile(user_id, engine, profile_id):
    if not can_review_setups(user_id):
        raise PermissionError('FORBIDDEN')
    # The same validator is used again by the recurring scanner.
    selected_parameters({'selected_profiles': {engine: profile_id}})
    import time

    def mutate(db):
        target = db.setdefault('settings', {}).setdefault('strategyResearch', {})
        target.setdefault('selected_profiles', {})[engine] = profile_id
        target['selection_by'] = str(user_id)
        target['selection_ms'] = int(time.time() * 1000)

    with_db_sections(('settings',), mutate)
    return {'engine': engine, 'profile_id': profile_id, 'applies_to': 'FUTURE_RESEARCH_SCANS',
            'production_qualified': False, 'automatic_live_selection': False}
