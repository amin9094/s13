"""Private, bounded experiments using immutable input cases and captured quotes."""
import re,time,uuid
from core.async_runtime import blocking_lane,run_blocking
from core.storage.engine import normalized_engine
from repositories.v2.research_cases import ResearchCases
from repositories.v2.common import json_dump,json_load,content_hash
from modules.research_context import decode


def _permit(user):
    from services.live_signal_service import permitted
    permitted(user)


def cases(user,before=None):
    _permit(user);return ResearchCases().page(before)


def case(user,key):
    _permit(user);r=ResearchCases().get(key)
    if not r:raise ValueError('RESEARCH_CASE_NOT_FOUND')
    p=r['payload'];context=decode(p['bundle'])
    return {'id':key,'symbol':r['symbol'],'timeframe':r['timeframe'],'created_ms':r['created_ms'],
            'kind':p.get('kind','PROPOSAL'),'regime':p.get('regime'),'implementation_hash':p['bundle']['implementation_hash'],
            'candles':[b.as_dict() for b in context.candles if b.end_ms<=context.cutoff_ms],
            'results':p['original_results']['results'],'near_misses':p.get('near_misses',[]),
            'indicator_observations':p.get('indicator_observations',[]),
            'future_revealed':False,'input_hash':content_hash(p['bundle'])}


async def _review_samples(p):
    from services.admin_review_market_service import source_monitor
    from services.live_signal_service import _review_tick
    context=decode(p['bundle']);q=context.current_quote
    if q is None:return []
    m=source_monitor(q.symbol)
    if str(m.epoch)!=str(p['quote_epoch']) or m.failure:return []
    rows=[_review_tick(t,m.epoch) for t in tuple(m.rows.get(q.symbol,()))]
    at=next((i for i,t in enumerate(rows) if (t['bid'],t['ask'],t['event_ms'],t['received_ms'])==(str(q.bid),str(q.ask),q.event_ms,q.received_ms)),None)
    return rows[at:at+2001] if at is not None else []


def _native_samples(p):
    from repositories.v2.quote_archive import QuoteArchive
    context=decode(p['bundle']);q=context.current_quote
    if q is None or p.get('quote_epoch') is None:return []
    frames=QuoteArchive().replay(q.provider,q.symbol,str(p['quote_epoch']),q.source_id)
    if frames and frames[0].quote!=q:raise ValueError('RESEARCH_QUOTE_ANCHOR_CHANGED')
    return [{'id':f.quote.source_id,'epoch':f.epoch,'bid':str(f.quote.bid),'ask':str(f.quote.ask),
             'event_ms':f.quote.event_ms,'received_ms':f.quote.received_ms} for f in frames]


def _enqueue(user,key,mode,ticks):
    if mode not in {'replay','variants','ablation','sensitivity'}:raise ValueError('RESEARCH_MODE_INVALID')
    db=normalized_engine();now=int(time.time()*1000);job=uuid.uuid4().hex
    with db.transaction() as c:
        if db.dialect.name=='postgres':c.execute('SELECT pg_advisory_xact_lock(719084413)')
        c.execute("UPDATE s9_research_jobs SET state='INTERRUPTED_RETRY_REQUIRED' WHERE state IN ('QUEUED','RUNNING') AND created_ms<?",(now-120000,))
        rows=c.execute("SELECT owner FROM s9_research_jobs WHERE state IN ('QUEUED','RUNNING')").fetchall()
        if len(rows)>=2 or any(r['owner']==str(user) for r in rows):raise ValueError('RESEARCH_CAPACITY_BUSY')
        payload={'mode':mode,'ticks':ticks,'tape_hash':content_hash(ticks),'tape_limit_reached':len(ticks)>=2001,'expires_ms':now+86400000}
        c.execute('INSERT INTO s9_research_jobs VALUES(?,?,?,?,?,?)',(job,key,str(user),'QUEUED',now,json_dump(payload)))
    return {'id':job,'state':'QUEUED'}


async def start(user,key,body):
    await run_blocking(_permit,user,timeout=5)
    if not isinstance(body,dict) or set(body)!={'mode'}:raise ValueError('RESEARCH_REQUEST_INVALID')
    # Experimental outcomes also reveal the future. Requiring a recorded
    # opinion only on the chart endpoint would leave this route as a bypass.
    from services.research_review_service import review
    opinion=await run_blocking(review,user,key,timeout=5)
    if not opinion['payload'].get('revealed'):raise PermissionError('BLIND_VOTE_AND_REVEAL_REQUIRED')
    r=await run_blocking(ResearchCases().get,key,timeout=5)
    if not r:raise ValueError('RESEARCH_CASE_NOT_FOUND')
    p=r['payload'];ticks=[]
    try:
        if p['bundle']['context_type']=='review':
            from core.miniapp_server import _run_on_telegram_loop
            ticks=await _run_on_telegram_loop(_review_samples(p)) or []
        else:ticks=await run_blocking(_native_samples,p,timeout=10)
    except (ValueError,TimeoutError):ticks=[]
    return await run_blocking(_enqueue,user,key,body['mode'],ticks,timeout=5)


def build(key):
    db=normalized_engine()
    with db.transaction() as c:
        r=c.execute("SELECT * FROM s9_research_jobs WHERE id=? AND state='QUEUED'",(key,)).fetchone()
        if not r:return
        c.execute("UPDATE s9_research_jobs SET state='RUNNING' WHERE id=? AND state='QUEUED'",(key,))
        if c.rowcount!=1:return
    p=json_load(r['payload'])
    try:
        from modules.strategy_replay import experiment
        case=ResearchCases(db).get(r['case_id'])
        if not case:raise ValueError('RESEARCH_CASE_NOT_FOUND')
        p['report']=experiment(case['payload']['bundle'],p['mode'],p['ticks']);p.pop('ticks')
        p['completed_ms']=int(time.time()*1000);state='READY'
    except Exception as exc:
        p.pop('ticks',None);p['failure']=type(exc).__name__;state='FAILED_RETRY_REQUIRED'
    with db.transaction() as c:c.execute("UPDATE s9_research_jobs SET state=?,payload=? WHERE id=? AND state='RUNNING'",(state,json_dump(p),key))


async def build_async(key):
    with blocking_lane('default'):await run_blocking(build,key,timeout=90,acquire_timeout=2)


def job(user,key):
    _permit(user)
    if not isinstance(key,str) or not re.fullmatch('[a-f0-9]{32}',key):raise ValueError('RESEARCH_JOB_NOT_FOUND')
    with normalized_engine().transaction(read_only=True) as c:r=c.execute('SELECT * FROM s9_research_jobs WHERE id=? AND owner=?',(key,str(user))).fetchone()
    if not r:raise ValueError('RESEARCH_JOB_NOT_FOUND')
    p=json_load(r['payload']);p.pop('ticks',None)
    if p.get('report',{}).get('tape_samples',0)>1:
        from services.research_review_service import review
        if not review(user,r['case_id'])['payload'].get('revealed'):raise PermissionError('BLIND_VOTE_AND_REVEAL_REQUIRED')
    if r['state'] in {'RUNNING','QUEUED'} and int(time.time()*1000)-r['created_ms']>120000:r['state']='INTERRUPTED_RETRY_REQUIRED'
    return {**r,'payload':p}
