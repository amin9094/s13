from __future__ import annotations

from collections import defaultdict
from datetime import UTC, datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo

from core.db import read_db_sections
from core.storage.engine import DatabaseEngine, normalized_engine
from modules.platform_expansion import behavioral_risk_report
from repositories.v2.accounts import AccountRepository
from repositories.v2.common import json_dump, json_load, new_id, utc_iso
from repositories.v2.journal import JournalRepository
from repositories.v2.preferences import PreferenceRepository
from repositories.v2.signals import SignalRepository


def _parse(value: Any) -> datetime | None:
    try:
        result = datetime.fromisoformat(str(value or "").replace("Z", "+00:00"))
        return result if result.tzinfo else result.replace(tzinfo=UTC)
    except (TypeError, ValueError):
        return None


def _number(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _normalized_trades(user_id: int | str, *, limit: int = 500, engine: DatabaseEngine | None = None) -> list[dict[str, Any]]:
    repo = JournalRepository(engine or normalized_engine())
    return list(reversed(repo.list_for_user(user_id, limit=max(1, min(limit, 100)))["items"]))


def _daily_groups(rows: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        dt = _parse(row.get("opened_at") or row.get("created_at"))
        if dt:
            groups[dt.astimezone(UTC).date().isoformat()].append(row)
    return groups


def _risk_value(row: dict[str, Any]) -> float:
    risk = _number(row.get("risk_percent"))
    if risk > 0:
        return risk
    pnl = abs(_number(row.get("pnl_percent")))
    return min(10.0, pnl)


def _trade_result(row: dict[str, Any]) -> float:
    if row.get("result_r") not in {None, ""}:
        return _number(row.get("result_r"))
    return _number(row.get("pnl_percent"))


def _behavioral_details(rows: list[dict[str, Any]], max_trades_per_day: int) -> dict[str, Any]:
    revenge = risk_escalation = missing_plan = early_exit = stop_widening = 0
    overtrading_days: list[dict[str, Any]] = []
    max_loss_streak = current_loss_streak = 0
    previous: dict[str, Any] | None = None
    for row in rows:
        result = _trade_result(row)
        if result < 0:
            current_loss_streak += 1
            max_loss_streak = max(max_loss_streak, current_loss_streak)
        else:
            current_loss_streak = 0
        if not any(row.get(key) for key in ("setup", "strategy", "entry_reason", "signal_id")):
            missing_plan += 1
        note = str(row.get("note") or row.get("comment") or "").casefold()
        if any(token in note for token in ("early", "زود", "ترس", "بستن سریع")):
            early_exit += 1
        if bool(row.get("stop_widened")) or any(token in note for token in ("widen stop", "جابجایی استاپ", "دور کردن استاپ")):
            stop_widening += 1
        if previous and _trade_result(previous) < 0:
            previous_closed = _parse(previous.get("closed_at") or previous.get("updated_at"))
            current_opened = _parse(row.get("opened_at") or row.get("created_at"))
            if previous_closed and current_opened and 0 <= (current_opened - previous_closed).total_seconds() <= 30 * 60:
                revenge += 1
            previous_risk = _risk_value(previous)
            current_risk = _risk_value(row)
            if previous_risk > 0 and current_risk > max(previous_risk * 1.25, previous_risk + 0.25):
                risk_escalation += 1
                revenge += 1
        previous = row
    for date_key, daily_rows in _daily_groups(rows).items():
        if len(daily_rows) > max_trades_per_day:
            overtrading_days.append({"date": date_key, "count": len(daily_rows), "limit": max_trades_per_day})
    return {
        "revenge_flags": revenge,
        "risk_escalation_count": risk_escalation,
        "missing_plan_count": missing_plan,
        "early_exit_count": early_exit,
        "stop_widening_count": stop_widening,
        "overtrading_days": overtrading_days,
        "max_loss_streak": max_loss_streak,
    }


def _discipline_score(details: dict[str, Any], sample: int, missing_stop_count: int) -> tuple[float, dict[str, float]]:
    penalties = {
        "revenge": min(24.0, details["revenge_flags"] * 6.0),
        "risk_escalation": min(18.0, details["risk_escalation_count"] * 6.0),
        "overtrading": min(18.0, len(details["overtrading_days"]) * 5.0),
        "missing_plan": min(16.0, details["missing_plan_count"] / max(sample, 1) * 30.0),
        "stop_management": min(18.0, details["stop_widening_count"] * 7.0 + missing_stop_count * 9.0),
        "loss_streak": min(12.0, max(0, details["max_loss_streak"] - 2) * 4.0),
    }
    return round(max(0.0, 100.0 - sum(penalties.values())), 1), {key: round(value, 1) for key, value in penalties.items()}


def _account_missing_stops(engine: DatabaseEngine, user_id: int | str) -> int:
    with engine.transaction(read_only=True) as cursor:
        rows = cursor.execute(
            "SELECT payload FROM v8_broker_snapshots WHERE user_id=? ORDER BY observed_at DESC LIMIT 10",
            (str(user_id),),
        ).fetchall()
    seen_accounts: set[str] = set()
    count = 0
    for row in rows:
        payload = json_load(row.get("payload"), {}) or {}
        account = str(payload.get("account_reference") or "")
        if account in seen_accounts:
            continue
        seen_accounts.add(account)
        for position in payload.get("positions") or []:
            if isinstance(position, dict) and _number(position.get("sl") or position.get("stop")) <= 0:
                count += 1
    return count


def get_or_create_daily_plan(
    user_id: int | str,
    account_id: int | str,
    *,
    engine: DatabaseEngine | None = None,
    force_refresh: bool = False,
) -> dict[str, Any]:
    db = engine or normalized_engine()
    account = AccountRepository(db).get(user_id, account_id)
    if not account:
        raise ValueError("TRADING_ACCOUNT_NOT_FOUND")
    try:
        local_date = datetime.now(UTC).astimezone(ZoneInfo(str(account.get("timezone") or "UTC"))).date().isoformat()
    except Exception:
        local_date = datetime.now(UTC).date().isoformat()
    if not force_refresh:
        with db.transaction(read_only=True) as cursor:
            row = cursor.execute(
                "SELECT * FROM v8_risk_daily_plans WHERE user_id=? AND account_id=? AND local_date=?",
                (str(user_id), str(account_id), local_date),
            ).fetchone()
        if row:
            payload = json_load(row.get("payload"), {}) or {}
            payload.update({key: row.get(key) for key in row if key != "payload"})
            return payload
    recent = _normalized_trades(user_id, engine=db)
    details = _behavioral_details(recent[-100:], max_trades_per_day=3)
    missing_stops = _account_missing_stops(db, user_id)
    score, _ = _discipline_score(details, len(recent), missing_stops)
    default_risk = max(0.1, _number(account.get("default_risk_percent"), 1.0))
    risk_multiplier = 0.5 if score < 50 else 0.75 if score < 70 else 1.0
    max_per_trade = round(min(default_risk, 1.0) * risk_multiplier, 2)
    max_daily = round(min(_number(account.get("max_daily_risk_percent"), 3.0), max(max_per_trade * 3, max_per_trade)), 2)
    row_id = new_id("rplan")
    now = utc_iso()
    payload = {
        "id": row_id, "user_id": str(user_id), "account_id": str(account_id), "local_date": local_date,
        "status": "draft", "max_daily_risk_percent": max_daily,
        "max_risk_per_trade_percent": max_per_trade, "max_trades": 3,
        "stop_after_losses": 2 if score < 70 else 3, "minimum_rr": 2.0,
        "cooldown_minutes_after_loss": 30 if details["revenge_flags"] else 15,
        "discipline_score_at_creation": score, "created_at": now, "updated_at": now,
    }
    with db.transaction() as cursor:
        cursor.execute(
            """INSERT INTO v8_risk_daily_plans(id,user_id,account_id,local_date,status,max_daily_risk_percent,
               max_risk_per_trade_percent,max_trades,stop_after_losses,minimum_rr,accepted_at,created_at,updated_at,payload)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(user_id,account_id,local_date) DO UPDATE SET
               max_daily_risk_percent=excluded.max_daily_risk_percent,max_risk_per_trade_percent=excluded.max_risk_per_trade_percent,
               max_trades=excluded.max_trades,stop_after_losses=excluded.stop_after_losses,minimum_rr=excluded.minimum_rr,
               updated_at=excluded.updated_at,payload=excluded.payload""",
            (
                row_id, str(user_id), str(account_id), local_date, "draft", max_daily, max_per_trade, 3,
                payload["stop_after_losses"], 2.0, None, now, now, json_dump(payload),
            ),
        )
    return payload


def update_daily_plan(
    user_id: int | str,
    account_id: int | str,
    values: dict[str, Any],
    *,
    accept: bool = False,
    engine: DatabaseEngine | None = None,
) -> dict[str, Any]:
    db = engine or normalized_engine()
    plan = get_or_create_daily_plan(user_id, account_id, engine=db)
    allowed = {
        "max_daily_risk_percent": (0.1, 20.0),
        "max_risk_per_trade_percent": (0.1, 10.0),
        "max_trades": (1, 50),
        "stop_after_losses": (1, 20),
        "minimum_rr": (0.5, 20.0),
        "cooldown_minutes_after_loss": (0, 1440),
    }
    for key, bounds in allowed.items():
        if key not in values:
            continue
        number = _number(values[key])
        if not bounds[0] <= number <= bounds[1]:
            raise ValueError("INVALID_RISK_PLAN_VALUE")
        plan[key] = int(number) if key in {"max_trades", "stop_after_losses", "cooldown_minutes_after_loss"} else round(number, 3)
    now = utc_iso()
    plan["status"] = "accepted" if accept else str(plan.get("status") or "draft")
    plan["accepted_at"] = now if accept else plan.get("accepted_at")
    plan["updated_at"] = now
    with db.transaction() as cursor:
        cursor.execute(
            """UPDATE v8_risk_daily_plans SET status=?,max_daily_risk_percent=?,max_risk_per_trade_percent=?,
               max_trades=?,stop_after_losses=?,minimum_rr=?,accepted_at=?,updated_at=?,payload=?
               WHERE user_id=? AND account_id=? AND local_date=?""",
            (
                plan["status"], plan["max_daily_risk_percent"], plan["max_risk_per_trade_percent"],
                plan["max_trades"], plan["stop_after_losses"], plan["minimum_rr"], plan.get("accepted_at"), now,
                json_dump(plan), str(user_id), str(account_id), str(plan["local_date"]),
            ),
        )
    return plan


def record_risk_checkin(
    user_id: int | str,
    payload: dict[str, Any],
    *,
    engine: DatabaseEngine | None = None,
) -> dict[str, Any]:
    db = engine or normalized_engine()
    checkin_type = str(payload.get("checkin_type") or "pretrade")[:40]
    allowed = {"pretrade", "posttrade", "emotion", "cooldown", "rule_override"}
    if checkin_type not in allowed:
        raise ValueError("INVALID_RISK_CHECKIN")
    row = {
        "id": new_id("checkin"), "user_id": str(user_id),
        "account_id": str(payload.get("account_id") or "") or None,
        "journal_id": str(payload.get("journal_id") or "") or None,
        "checkin_type": checkin_type, "occurred_at": utc_iso(),
        "emotion": str(payload.get("emotion") or "")[:40],
        "confidence": max(0, min(10, int(_number(payload.get("confidence"), 0)))),
        "followed_plan": bool(payload.get("followed_plan", False)),
        "moved_stop": bool(payload.get("moved_stop", False)),
        "note": str(payload.get("note") or "")[:1000],
    }
    with db.transaction() as cursor:
        cursor.execute(
            """INSERT INTO v8_risk_checkins(id,user_id,account_id,journal_id,checkin_type,occurred_at,payload)
               VALUES(?,?,?,?,?,?,?)""",
            (row["id"], row["user_id"], row["account_id"], row["journal_id"], row["checkin_type"], row["occurred_at"], json_dump(row)),
        )
    return row


def consolidated_behavioral_report(user_id: int | str) -> dict[str, Any]:
    """Portfolio-wide coach using journal, signals and live MT5 evidence."""
    uid = str(user_id)
    db_legacy = read_db_sections((
        "enterprise_control", "platform_registry", "platform_settings",
        "journal_entries", "user_journal", "journal", "paper_trades",
    ))
    engine = normalized_engine()
    normalized = JournalRepository(engine).list_for_user(uid, limit=100)["items"]
    paper = [
        row for row in (db_legacy.get("paper_trades") or [])
        if isinstance(row, dict) and str(row.get("user_id")) == uid
    ]
    merged: dict[str, dict[str, Any]] = {}
    for row in [*normalized, *paper]:
        if not isinstance(row, dict):
            continue
        key = str(row.get("id") or f"{row.get('signal_id')}:{row.get('opened_at') or row.get('created_at')}")
        merged[key] = dict(row)
    db_legacy["journal_entries"] = list(merged.values())
    try:
        legacy_report = behavioral_risk_report(db_legacy, uid)
    except (PermissionError, ValueError):
        legacy_report = {
            "sample_size": len(merged), "wins": 0, "losses": 0, "net_r": 0.0,
            "max_loss_streak": 0, "discipline_score": 100.0, "findings": [], "recommendations": [],
        }

    trades = sorted(merged.values(), key=lambda row: str(row.get("opened_at") or row.get("created_at") or ""))
    accounts = AccountRepository(engine).list_for_user(uid)
    default_account = accounts[0] if accounts else None
    plan = get_or_create_daily_plan(uid, default_account["id"], engine=engine) if default_account else None
    details = _behavioral_details(trades, int((plan or {}).get("max_trades") or 3))
    missing_stops = _account_missing_stops(engine, uid)
    score, penalties = _discipline_score(details, len(trades), missing_stops)
    findings: list[dict[str, Any]] = []
    definitions = (
        ("revenge_risk", details["revenge_flags"], "احتمال معامله انتقامی", "high"),
        ("risk_escalation", details["risk_escalation_count"], "افزایش ریسک پس از زیان", "high"),
        ("overtrading", len(details["overtrading_days"]), "بیش‌معامله‌گری روزانه", "high"),
        ("missing_plan", details["missing_plan_count"], "معامله بدون پلن ثبت‌شده", "medium"),
        ("stop_widening", details["stop_widening_count"], "جابجایی نامناسب حد ضرر", "high"),
        ("missing_stop", missing_stops, "معامله باز بدون حد ضرر", "critical"),
    )
    for code, count, title, severity in definitions:
        if count:
            findings.append({"code": code, "count": count, "title": title, "severity": severity})
    recommendations: list[str] = []
    if missing_stops:
        recommendations.append("برای تمام معاملات باز فوراً حد ضرر معتبر تعیین کن.")
    if details["revenge_flags"]:
        recommendations.append("پس از هر زیان، Cooldown برنامه روزانه را کامل اجرا کن.")
    if details["risk_escalation_count"]:
        recommendations.append("ریسک معامله بعد از زیان نباید از معامله قبلی بیشتر شود.")
    if details["overtrading_days"]:
        recommendations.append(f"سقف امروز را روی {int((plan or {}).get('max_trades') or 3)} معامله نگه دار.")
    if details["max_loss_streak"] >= int((plan or {}).get("stop_after_losses") or 3):
        recommendations.append("حد توقف زیان متوالی فعال شده؛ ادامه معاملات امروز پیشنهاد نمی‌شود.")
    if not recommendations:
        recommendations.append("انضباط در محدوده مناسب است؛ برنامه روزانه را قبل از اولین معامله تأیید کن.")

    choices = PreferenceRepository().get(uid, "user_signal_choices", {})
    choices = choices if isinstance(choices, dict) else {}
    signals: list[dict[str, Any]] = []
    total_active_risk = 0.0
    risks: list[float] = []
    for signal_id, choice in choices.items():
        if not isinstance(choice, dict) or str(choice.get("choice") or "") != "taken":
            continue
        signal = SignalRepository().get(signal_id)
        if not signal:
            continue
        risk = _number(choice.get("risk_percent") or signal.get("risk_percent") or signal.get("risk"))
        risks.append(risk)
        if str(signal.get("status") or "open").lower() not in {"closed", "cancelled", "expired", "stopped", "tp", "win", "loss", "breakeven", "be"}:
            total_active_risk += risk
        signals.append({
            "signal_id": str(signal_id), "symbol": signal.get("symbol"), "side": signal.get("side"),
            "status": signal.get("status"), "risk_percent": risk, "selected_at": choice.get("selected_at"),
        })
    report = {
        **legacy_report,
        "sample_size": len(trades),
        "discipline_score": score,
        "discipline_breakdown": {"score": score, "penalties": penalties},
        "max_loss_streak": details["max_loss_streak"],
        "findings": findings,
        "recommendations": recommendations,
        "behavior": details,
        "daily_plan": plan,
        "account_count": len(accounts),
        "missing_stop_count": missing_stops,
        "signal_risk": {
            "taken_count": len(signals), "active_risk_percent": round(total_active_risk, 3),
            "average_risk_percent": round(sum(risks) / len(risks), 3) if risks else 0.0,
            "items": sorted(signals, key=lambda row: str(row.get("selected_at") or ""), reverse=True)[:30],
        },
        "weekly_risk": weekly_signal_risk_summary(uid, default_account),
        "sources": ["normalized_journal", "paper_trading", "signal_choices", "mt5_connector"],
        "generated_at": utc_iso(),
    }
    return report


def weekly_signal_risk_summary(user_id: int | str, account: dict[str, Any] | None = None) -> dict[str, Any]:
    from modules.signal_status import signal_is_final

    now = datetime.now(UTC)
    week_start = (now - timedelta(days=now.weekday())).replace(hour=0, minute=0, second=0, microsecond=0)
    choices = PreferenceRepository().get(user_id, "user_signal_choices", {})
    choices = choices if isinstance(choices, dict) else {}
    daily_limit = float((account or {}).get("max_daily_risk_percent") or 2.0)
    weekly_limit = float((account or {}).get("max_weekly_risk_percent") or min(max(daily_limit * 5, 5.0), 15.0))
    used = active = 0.0
    count = 0
    rows: list[dict[str, Any]] = []
    for signal_id, choice in choices.items():
        if not isinstance(choice, dict) or str(choice.get("choice") or "") != "taken":
            continue
        selected = _parse(choice.get("selected_at") or choice.get("updated_at"))
        if not selected or selected.astimezone(UTC) < week_start:
            continue
        signal = SignalRepository().get(signal_id)
        if not signal:
            continue
        risk = max(0.0, _number(choice.get("risk_percent") or signal.get("risk_percent") or signal.get("risk")))
        used += risk
        if not signal_is_final(signal):
            active += risk
        count += 1
        rows.append({
            "signal_id": str(signal_id), "symbol": signal.get("symbol"), "status": signal.get("status"),
            "risk_percent": round(risk, 3), "selected_at": selected.isoformat(), "active": not signal_is_final(signal),
        })
    remaining = max(0.0, weekly_limit - used)
    ratio = used / weekly_limit if weekly_limit > 0 else 1.0
    if ratio >= 1:
        level, can_trade = "stop", False
        guidance_fa = "سقف ریسک هفتگی پر شده؛ تا شروع هفته بعد معامله جدید باز نکن."
        guidance_en = "Your weekly risk budget is exhausted. Do not open another trade this week."
    elif ratio >= 0.8:
        level, can_trade = "caution", remaining >= 0.25
        guidance_fa = "به سقف هفتگی نزدیک شده‌ای؛ فقط ستاپ بسیار باکیفیت و با ریسک کمتر بررسی شود."
        guidance_en = "You are near the weekly limit. Consider only a high-quality setup at reduced risk."
    else:
        level, can_trade = "ok", True
        guidance_fa = "ریسک هفتگی در محدوده مجاز است؛ همچنان حد ریسک هر معامله را رعایت کن."
        guidance_en = "Weekly risk is within budget. Keep respecting the per-trade limit."
    return {
        "week_start": week_start.isoformat(), "week_end": (week_start + timedelta(days=7)).isoformat(),
        "limit_percent": round(weekly_limit, 3), "used_percent": round(used, 3),
        "remaining_percent": round(remaining, 3), "active_risk_percent": round(active, 3),
        "taken_count": count, "usage_percent": round(min(200.0, ratio * 100), 2),
        "level": level, "can_trade": can_trade, "guidance_fa": guidance_fa, "guidance_en": guidance_en,
        "items": sorted(rows, key=lambda row: row["selected_at"], reverse=True)[:30],
    }
