"""Read-only admin feedback; a chart/query flag cannot grant this access."""

from __future__ import annotations

from modules.canonical_market import ANALYSIS_TIMEFRAMES
from services.setup_review_service import can_review_setups


def strategy_feedback(user_id, *, symbol=None, timeframe=None, engine=None, limit=500):
    if not can_review_setups(user_id):
        raise PermissionError("FORBIDDEN")
    if timeframe and timeframe not in ANALYSIS_TIMEFRAMES:
        raise ValueError("ANALYSIS_TIMEFRAME_UNAPPROVED")
    from repositories.v2.setup_proposals import SetupRepository

    return SetupRepository().feedback(
        symbol=symbol.upper() if symbol else None, timeframe=timeframe, engine=engine, limit=limit
    )
