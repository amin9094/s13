"""Named snapshots of the existing owner-approved poster, never a silent redesign."""
import hashlib,time,re
from base64 import b64encode,b64decode
from pathlib import Path
from core.storage.engine import normalized_engine
from repositories.v2.common import content_hash,json_dump,json_load,utc_iso


def _permit(user,write=False):
    from services.upgrade_admin_service import _permit
    _permit(user,'signal_templates' if write else None)


def directory():
    from config import SETTINGS
    p=Path(SETTINGS.db_file).parent/'poster_snapshots';p.mkdir(exist_ok=True,parents=True,mode=0o700);return p


def capture(user,name):
    _permit(user,True)
    if not isinstance(name,str) or not 1<=len(name.strip())<=60:raise ValueError('POSTER_NAME_INVALID')
    db=normalized_engine()
    from modules.signal import signal_template_render_settings,signal_image_text_settings
    from modules.signal_image import _sentinel_template_path
    from PIL import Image
    p={'name':name.strip(),'actor':str(user),'created_ms':int(time.time()*1000),'sides':{},'texts':signal_image_text_settings()};assets={}
    for side in ('buy','sell'):
        layout,filename=signal_template_render_settings(side);source=Path(filename) if filename else _sentinel_template_path(side)
        raw=source.read_bytes()
        if len(raw)>10_000_000:raise ValueError('POSTER_IMAGE_SIZE_LIMIT')
        with Image.open(source) as im:im.verify()
        digest=hashlib.sha256(raw).hexdigest();assets[digest]=b64encode(raw).decode('ascii')
        p['sides'][side]={'layout':layout,'image_sha256':digest}
    key=content_hash(p)[:32]
    with db.transaction() as c:
        if db.dialect.name=='postgres':c.execute('SELECT pg_advisory_xact_lock(719084415)')
        if c.execute('SELECT COUNT(*) AS n FROM s9_poster_presets').fetchone()['n']>=30:raise ValueError('POSTER_PRESET_LIMIT')
        used=c.execute('SELECT COALESCE(SUM(LENGTH(payload)),0) AS n FROM s9_poster_assets').fetchone()['n']
        for digest,encoded in assets.items():
            if c.execute('SELECT 1 AS found FROM s9_poster_assets WHERE id=?',(digest,)).fetchone():continue
            used+=len(encoded)
            if used>50_000_000:raise ValueError('POSTER_ASSET_STORAGE_LIMIT')
            c.execute('INSERT INTO s9_poster_assets VALUES(?,?)',(digest,encoded))
        c.execute('INSERT INTO s9_poster_presets VALUES(?,?,?,?)',(key,p['name'],p['created_ms'],json_dump(p)))
    return {'id':key,'name':p['name'],'snapshot_hash':content_hash(p)}


def get(key):
    with normalized_engine().transaction(read_only=True) as c:r=c.execute('SELECT * FROM s9_poster_presets WHERE id=?',(key,)).fetchone()
    if not r:raise ValueError('POSTER_PRESET_NOT_FOUND')
    p=json_load(r['payload'])
    if content_hash(p)[:32]!=key:raise ValueError('POSTER_PRESET_CHANGED')
    return {'id':key,'snapshot':p,'snapshot_hash':content_hash(p)}


def listing(user):
    _permit(user)
    with normalized_engine().transaction(read_only=True) as c:rows=c.execute('SELECT id,name,created_ms FROM s9_poster_presets ORDER BY created_ms DESC,id DESC').fetchall()
    from repositories.v2.live_signal_inbox import LiveSignalInbox
    signals=LiveSignalInbox().items(limit=20,publication_state='PENDING')
    return {'items':rows,'selections':{a:selection(a) for a in ('telegram_public','telegram_private')},
            'preview_signals':[{'id':r['id'],'symbol':r['payload']['plan']['symbol'],'direction':r['payload']['plan']['direction'],'timeframe':r['payload']['plan']['timeframe']} for r in signals],
            'new_design_created':False}


def select(user,body):
    _permit(user,True)
    if not isinstance(body,dict) or set(body)!={'audience','preset_id','expected_id'} or body['audience'] not in {'telegram_public','telegram_private'}:raise ValueError('POSTER_SELECTION_INVALID')
    value=get(body['preset_id']) if body['preset_id'] is not None else None;db=normalized_engine();key='poster_selection:'+body['audience']
    with db.transaction() as c:
        if db.dialect.name=='postgres':c.execute('SELECT pg_advisory_xact_lock(hashtextextended(?,0))',(key,))
        row=c.execute('SELECT value FROM v8_meta WHERE key=?',(key,)).fetchone()
        current=json_load(row['value']).get('selected') if row else None
        if (current or {}).get('id')!=body['expected_id']:raise ValueError('POSTER_SELECTION_CHANGED')
        saved={'selected':value,'actor':str(user),'at_ms':int(time.time()*1000)}
        c.execute('INSERT INTO v8_meta VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at',(key,json_dump(saved),utc_iso()))
    return {'state':'SAVED_FOR_FUTURE_PUBLICATIONS','preset_id':body['preset_id']}


def selection(audience,*,engine=None):
    with (engine or normalized_engine()).transaction(read_only=True) as c:r=c.execute('SELECT value FROM v8_meta WHERE key=?',('poster_selection:'+audience,)).fetchone()
    return json_load(r['value']).get('selected') if r else None


def render_spec(snapshot,side):
    p=snapshot['snapshot']
    if content_hash(p)!=snapshot.get('snapshot_hash') or content_hash(p)[:32]!=snapshot.get('id'):raise ValueError('POSTER_PRESET_CHANGED')
    data=p['sides'][side];digest=data['image_sha256']
    if not re.fullmatch('[a-f0-9]{64}',digest):raise ValueError('POSTER_IMAGE_HASH_INVALID')
    image=directory()/(digest+'.png')
    if not image.is_file() or hashlib.sha256(image.read_bytes()).hexdigest()!=digest:
        with normalized_engine().transaction(read_only=True) as c:r=c.execute('SELECT payload FROM s9_poster_assets WHERE id=?',(digest,)).fetchone()
        if not r:raise ValueError('POSTER_ASSET_UNAVAILABLE')
        try:raw=b64decode(r['payload'],validate=True)
        except ValueError:raise ValueError('POSTER_IMAGE_CHANGED') from None
        if hashlib.sha256(raw).hexdigest()!=digest:raise ValueError('POSTER_IMAGE_CHANGED')
        import tempfile,os
        fd,temp=tempfile.mkstemp(dir=image.parent,prefix='poster-',suffix='.partial')
        try:
            with os.fdopen(fd,'wb') as out:out.write(raw)
            os.replace(temp,image)
        finally:Path(temp).unlink(missing_ok=True)
    return data['layout'],str(image),p['texts']


async def preview(user,key,signal_id):
    from core.async_runtime import run_blocking
    from modules.signal import create_signal_async
    from services.signal_workspace_service import _signal
    from modules.signal_targets import TARGET_KEYS
    from base64 import b64encode
    await run_blocking(_permit,user,timeout=5)
    _,row=await run_blocking(_signal,user,signal_id,timeout=5);p=row['payload']['plan']
    snapshot=await run_blocking(get,key,timeout=5)
    image=await create_signal_async(p['symbol'],p['entry'],[p[k] for k in TARGET_KEYS if p.get(k) is not None],p['stop'],p['direction'],'1',poster_snapshot=snapshot,timeframe=p['timeframe'])
    from modules.signal_price_contract import assert_parity
    assert_parity(p,image)
    from modules.signal_price_contract import assert_identity
    assert_identity(p,image,signal_number='1')
    path=Path(image['image_path'])
    try:return {'image':'data:image/png;base64,'+b64encode(path.read_bytes()).decode(),'signal_id':signal_id,'plan_hash':row['payload']['plan_hash'],'snapshot_hash':snapshot['snapshot_hash'],'is_publication':False}
    finally:path.unlink(missing_ok=True)
