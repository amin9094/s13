from __future__ import annotations

import asyncio
import logging
from typing import Any

from config import SETTINGS
from core.async_runtime import run_blocking
from modules.vip import restore_vip_channel_access
from repositories.v2.commerce import CommerceRepository
from services.vip_entitlement_projection import project_normalized_entitlements_to_legacy
from services.vip_order_projection import project_normalized_order_to_legacy, mark_projected_order_notification
from services.vip_discount_bridge import consume_normalized_order_discount, release_normalized_order_discount
from repositories.v2.events import EventRepository

logger = logging.getLogger(__name__)


async def approve_manual_vip_order(bot: Any, order_id: int | str, admin_id: int | str) -> dict[str, Any]:
    """Approve a normalized manual-payment order through one shared workflow.

    The order is first atomically claimed. Telegram access is prepared before
    entitlement finalization. Any failure releases the claim and revokes the
    unused invite when possible, so the order remains reviewable rather than
    becoming half-approved.
    """
    repo = CommerceRepository()
    claimed = await run_blocking(repo.claim_order_for_approval, order_id, actor_id=str(admin_id))
    if str(claimed.get("status")) == "approved":
        return await _finish_approved_order(bot, claimed, admin_id)

    invite_url = str(claimed.get("processing_invite_link") or "")
    try:
        if not invite_url:
            invite_url = await restore_vip_channel_access(bot, int(claimed["user_id"]), None)
            await run_blocking(
                repo.store_order_approval_invite, claimed["id"], actor_id=str(admin_id), invite_link=invite_url
            )
        approved = await run_blocking(
            repo.finalize_order_approval,
            claimed["id"],
            actor_id=str(admin_id),
            invite_link=invite_url,
        )
    except Exception as exc:
        logger.exception("Manual VIP approval failed order_id=%s", order_id)
        if invite_url:
            try:
                await bot.revoke_chat_invite_link(
                    chat_id=SETTINGS.private_channel_id,
                    invite_link=invite_url,
                )
            except Exception:
                logger.exception("Could not revoke unused VIP invite order_id=%s", order_id)
        try:
            await run_blocking(repo.release_order_approval, order_id, actor_id=str(admin_id), error=str(exc)[:500])
        except Exception:
            logger.exception("Could not release VIP approval claim order_id=%s", order_id)
        raise

    return await _finish_approved_order(bot, approved, admin_id)


async def _finish_approved_order(bot, approved, admin_id):
    repo = CommerceRepository()
    current = await run_blocking(repo.get, approved["id"])
    if current and current.get("refund_status") == "full":
        await run_blocking(repo.mark_finalization, approved["id"], success=True)
        return current
    approved = current or approved
    try:
        await run_blocking(consume_normalized_order_discount, approved)
        await run_blocking(project_normalized_entitlements_to_legacy, approved["user_id"])
        projected = await run_blocking(project_normalized_order_to_legacy, approved["id"])
        from core.db import with_db
        from core.domain import record_vip_purchase_rewards

        if not (projected or {}).get("refund_status") == "full":
            await run_blocking(with_db, lambda db: record_vip_purchase_rewards(db, approved), timeout=15)
        await run_blocking(
            EventRepository().append,
            user_id=approved["user_id"],
            event_type="order.status_changed",
            payload={"entity": approved, "source": "manual_payment_orchestrator", "actor_id": str(admin_id)},
            idempotency_key=f"order-approved:{approved['id']}",
            timeout=10,
        )
        await run_blocking(repo.mark_finalization, approved["id"], success=True)
    except Exception as exc:
        logger.exception("Approved order finalization failed order_id=%s", approved.get("id"))
        await run_blocking(repo.mark_finalization, approved["id"], success=False, error=type(exc).__name__)
        raise
    if not (projected or {}).get("user_notified_at"):
        notified = await notify_manual_order_user(bot, approved)
        await run_blocking(mark_projected_order_notification, approved["id"], audience="user", success=notified)
    return approved


async def reconcile_approved_orders(bot):
    """Bounded repair; each failure remains recorded for the next due attempt."""
    await reconcile_refunded_invites(bot)
    rows = await run_blocking(CommerceRepository().pending_finalizations)
    for row in rows:
        try:
            await _finish_approved_order(bot, row, row.get("approved_by") or "system")
        except Exception as exc:
            from core.observability import record_error

            record_error("payment_finalization", exc)
            logger.exception("Payment finalization retry failed order_id=%s", row["id"])
            # The existing incident worker handles administrator delivery.
            try:
                from core.db import with_db
                from modules.incident_center import record_incident

                await run_blocking(
                    with_db,
                    lambda db, kind=type(exc).__name__, oid=row["id"]: record_incident(
                        db,
                        source="payment_finalization",
                        kind=kind,
                        detail=f"order={oid}",
                        severity="critical",
                        dedupe_minutes=30,
                    ),
                )
            except Exception:
                logger.exception("Could not persist finalization incident")

    notifications = await run_blocking(CommerceRepository().pending_user_notifications)
    for order in notifications:
        success = await notify_manual_order_user(bot, order)
        await run_blocking(mark_projected_order_notification, order["id"], audience="user", success=success)


async def reject_manual_vip_order(
    bot: Any,
    order_id: int | str,
    admin_id: int | str,
    reason: str,
) -> dict[str, Any]:
    repo = CommerceRepository()
    rejected = await run_blocking(repo.reject_order, order_id, actor_id=str(admin_id), reason=reason)
    await run_blocking(release_normalized_order_discount, rejected)
    await run_blocking(project_normalized_order_to_legacy, rejected["id"])
    notified = await notify_manual_order_user(bot, rejected)
    await run_blocking(mark_projected_order_notification, rejected["id"], audience="user", success=notified)
    return rejected


async def notify_manual_order_user(bot: Any, order: dict[str, Any]) -> bool:
    from core.db import with_db
    from modules.notification_router import route_notification
    from modules.economic_refunds import notification_order_snapshot

    order = await run_blocking(with_db, lambda db: notification_order_snapshot(db, order))
    if not order:
        return False
    if order.get("refund_status") == "full":
        return True  # Suppress obsolete approval, including a stale queue snapshot.
    if not await run_blocking(with_db, lambda db: route_notification(db, order["user_id"], "payment")):
        return True
    status = str(order.get("status") or "")
    uid = int(order["user_id"])
    if status == "approved":
        text = (
            "✅ پرداخت شما به‌صورت دستی تأیید شد و اشتراک VIP فعال شد.\n"
            f"اعتبار اشتراک تا: {order.get('expires_at') or 'ثبت‌شده در حساب شما'}"
        )
        if order.get("invite_link"):
            text += f"\n\n🔗 لینک یک‌بارمصرف ورود به کانال VIP:\n{order['invite_link']}"
    elif status == "rejected":
        reason = str(order.get("rejection_reason") or "رسید پرداخت تأیید نشد.")[:700]
        text = f"❌ پرداخت VIP تأیید نشد.\nدلیل: {reason}\nمی‌توانید رسید صحیح را دوباره ارسال کنید."
    else:
        return False
    try:
        async with asyncio.timeout(10):
            await bot.send_message(uid, text)
        return True
    except Exception:
        logger.exception("Could not notify VIP order user=%s order=%s", uid, order.get("id"))
        return False


async def reconcile_refunded_invites(bot, *, order_id=None):
    """Use existing order delivery fields as a durable, bounded revocation job."""
    from telegram.error import BadRequest
    from core.db import with_db
    from modules.economic_refunds import refund_invite_due, refund_invite_result, repair_refunded_purchase_points
    from modules.incident_center import record_incident

    await run_blocking(with_db, repair_refunded_purchase_points, timeout=20)
    repo = CommerceRepository()
    rows = [(row, True) for row in await run_blocking(repo.pending_refund_invites, order_id=order_id, limit=10)]

    def legacy_pending(db):
        return [
            dict(row)
            for row in db.get("vip_orders", [])
            if refund_invite_due(row) and (order_id is None or str(row.get("order_id")) == str(order_id))
        ][:10]

    rows += [(row, False) for row in await run_blocking(with_db, legacy_pending)]
    for order, normalized in rows:
        oid = str(order.get("order_id") or order.get("id"))
        success, error = False, ""
        try:
            async with asyncio.timeout(5):
                await bot.revoke_chat_invite_link(chat_id=SETTINGS.private_channel_id, invite_link=order["invite_link"])
            success = True
        except BadRequest as exc:
            # Only explicit terminal link states count as success; permission
            # and invalid-chat errors remain retryable and visible to admins.
            success = any(
                s in str(exc).lower()
                for s in (
                    "invite_hash_expired",
                    "invite_hash_invalid",
                    "invite_revoked",
                    "already revoked",
                    "invite link expired",
                )
            )
            if not success:
                error = type(exc).__name__
                logger.exception("Refund invite revocation failed order=%s", oid)
        except Exception as exc:
            error = type(exc).__name__
            logger.exception("Refund invite revocation failed order=%s", oid)
        if normalized:
            result = await run_blocking(repo.mark_refund_invite, oid, success=success, error=error)
        else:

            def mark(db):
                current = next((r for r in db.get("vip_orders", []) if str(r.get("order_id")) == oid), None)
                if current:
                    refund_invite_result(current, success, error)
                    return dict(current)

            result = await run_blocking(with_db, mark)
        if not success:
            severity = "critical"  # A refunded private-channel invite remains usable until revocation succeeds.
            await run_blocking(
                with_db,
                lambda db: record_incident(
                    db,
                    source="refund_invite",
                    kind="revocation_failed",
                    detail=f"order={oid}; error={error}",
                    severity=severity,
                    dedupe_minutes=30,
                ),
            )
