"""Admin-only, independent Iran equity desk for H4 / D1 analysis."""

from repositories.v2.iran_equity_analyses import IranEquityAnalyses
from services.live_signal_service import permitted


def snapshot(user, *, timeframe=None, before=None, legacy_before=None, section="all"):
    permitted(user)
    if section not in {"all", "analyses", "legacy"}:
        raise ValueError("IR_DESK_SECTION_INVALID")
    repo = IranEquityAnalyses()
    rows = repo.items(timeframe=timeframe, before=before) if section != "legacy" else []
    legacy = repo.legacy_proposals(before=legacy_before) if section != "analyses" else []
    return {
        "items": rows,
        "legacy_items": legacy,
        "timeframes": ["4h", "1d"],
        "next_before": f"{rows[-1]['created_ms']}:{rows[-1]['id']}" if len(rows) == 20 else None,
        "legacy_next_before": f"{legacy[-1]['created_ms']}:{legacy[-1]['id']}" if len(legacy) == 20 else None,
        "scope": "IRAN_EQUITIES_ADMIN_ONLY",
        "currency": "IRR",
        "publicly_approved": False,
    }


def detail(user, identifier):
    permitted(user)
    row = IranEquityAnalyses().get(identifier)
    if not row:
        raise ValueError("IR_ANALYSIS_NOT_FOUND")
    return row


def legacy_detail(user, identifier):
    permitted(user)
    from repositories.v2.live_signal_inbox import LiveSignalInbox

    row = LiveSignalInbox().get(identifier)
    if not row or row["market"] != "iran":
        raise ValueError("IR_ANALYSIS_NOT_FOUND")
    return {
        "id": row["id"],
        "state": row["state"],
        "created_ms": row["created_ms"],
        "payload": {"plan": row["payload"]["plan"], "legacy": True, "read_only": True},
    }
