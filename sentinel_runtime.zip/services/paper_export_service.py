"""Private bounded-memory exports, independent from the interactive worker lane."""
import asyncio
import hashlib
import re
import time
import uuid
from pathlib import Path
from config import SETTINGS
from core.async_runtime import blocking_lane,run_blocking
from core.storage.engine import normalized_engine
from modules.signal_execution import account_identity
from repositories.v2.common import json_dump,json_load
from repositories.v2.strategy_paper import StrategyPaperRepository


def _directory():
    path=Path(SETTINGS.db_file).parent/'private_exports'
    path.mkdir(parents=True,exist_ok=True,mode=0o700)
    return path


def start(user,engine,run_id):
    from services.live_signal_service import permitted
    permitted(user);account_identity(engine)
    if not re.fullmatch('[a-f0-9]{32}',run_id):raise ValueError('PAPER_RUN_NOT_FOUND')
    db=normalized_engine();now=int(time.time()*1000);key=uuid.uuid4().hex
    with db.transaction() as c:
        if db.dialect.name=='postgres':c.execute('SELECT pg_advisory_xact_lock(719084411)')
        if not c.execute('SELECT id FROM s9_strategy_paper_runs WHERE id=? AND engine=?',(run_id,engine)).fetchone():raise ValueError('PAPER_RUN_NOT_FOUND')
        count=c.execute("SELECT COUNT(*) AS n FROM s9_export_jobs WHERE state IN ('QUEUED','RUNNING') AND expires_ms>?",(now,)).fetchone()['n']
        own=c.execute("SELECT COUNT(*) AS n FROM s9_export_jobs WHERE owner=? AND state IN ('QUEUED','RUNNING') AND expires_ms>?",(str(user),now)).fetchone()['n']
        if count>=4 or own>=2:raise ValueError('EXPORT_CAPACITY_BUSY')
        c.execute('INSERT INTO s9_export_jobs(id,owner,state,created_ms,expires_ms,payload) VALUES(?,?,?, ?,?,?)',
                  (key,str(user),'QUEUED',now,now+1800000,json_dump({'engine':engine,'run_id':run_id})))
    return {'id':key,'state':'QUEUED','expires_ms':now+1800000}


def status(user,key):
    from services.live_signal_service import permitted
    permitted(user)
    if not re.fullmatch('[a-f0-9]{32}',key):raise ValueError('EXPORT_NOT_FOUND')
    with normalized_engine().transaction(read_only=True) as c:
        r=c.execute('SELECT * FROM s9_export_jobs WHERE id=? AND owner=?',(key,str(user))).fetchone()
    if not r:raise ValueError('EXPORT_NOT_FOUND')
    p=json_load(r['payload']);state=r['state'];now=int(time.time()*1000)
    if now>=r['expires_ms']:state='EXPIRED'
    elif state=='RUNNING' and now-p.get('started_ms',now)>125000:state='FAILED_RETRY_REQUIRED'
    elif state=='READY' and not (_directory()/(key+'.csv')).is_file():state='FAILED_RETRY_REQUIRED'
    return {'id':key,'state':state,'expires_ms':r['expires_ms'],'size_bytes':p.get('size_bytes'),
            'sha256':p.get('sha256'),'run_id':p['run_id']}


def build(key):
    db=normalized_engine();now=int(time.time()*1000)
    with db.transaction() as c:
        row=c.execute("SELECT * FROM s9_export_jobs WHERE id=? AND state='QUEUED' AND expires_ms>?",(key,now)).fetchone()
        if not row:return
        payload=json_load(row['payload']);payload['started_ms']=now
        c.execute("UPDATE s9_export_jobs SET state='RUNNING',payload=? WHERE id=? AND state='QUEUED'",(json_dump(payload),key))
        if c.rowcount!=1:return
    target=_directory()/(key+'.csv');partial=target.with_suffix('.partial')
    try:
        digest=hashlib.sha256();size=0;started=time.monotonic()
        with partial.open('wb') as f:
            partial.chmod(0o600)
            for chunk in StrategyPaperRepository(db).iter_csv(payload['engine'],run_id=payload['run_id']):
                raw=chunk.encode('utf-8');size+=len(raw)
                if size>100_000_000 or time.monotonic()-started>90:raise ValueError('EXPORT_LIMIT_REACHED')
                digest.update(raw);f.write(raw)
        partial.replace(target)
        payload.update(size_bytes=size,sha256=digest.hexdigest(),completed_ms=int(time.time()*1000))
        with db.transaction() as c:c.execute("UPDATE s9_export_jobs SET state='READY',payload=? WHERE id=? AND state='RUNNING'",(json_dump(payload),key))
    except Exception:
        partial.unlink(missing_ok=True);target.unlink(missing_ok=True)
        with db.transaction() as c:c.execute("UPDATE s9_export_jobs SET state='FAILED' WHERE id=? AND state='RUNNING'",(key,))


async def build_async(key):
    with blocking_lane('default'):
        await run_blocking(build,key,timeout=100,acquire_timeout=2)


def download(user,key):
    result=status(user,key)
    if result['state']!='READY':raise ValueError('EXPORT_NOT_READY')
    return _directory()/(key+'.csv'),result
