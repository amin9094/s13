"""Keyless gold reference, explicitly independent of candles and executions."""
from __future__ import annotations

import asyncio
import os
import time
from datetime import UTC, datetime
from decimal import Decimal

from core.http_client import get_json

_CACHE = {}
_INFLIGHT = {}
_COOLDOWNS = {}


async def _gold_api_reference(symbol):
    metal = symbol[:3]
    raw = await get_json(f'https://api.gold-api.com/price/{metal}',retries=0)
    if raw.get('symbol') != metal or raw.get('currency','USD') != 'USD':
        raise ValueError('REFERENCE_IDENTITY_MISMATCH')
    price = Decimal(str(raw['price']))
    if not price.is_finite() or price <= 0:
        raise ValueError('REFERENCE_PRICE_INVALID')
    stamp = datetime.fromisoformat(raw['updatedAt'].replace('Z','+00:00'))
    if stamp.tzinfo is None:
        raise ValueError('REFERENCE_TIMESTAMP_UNVERIFIED')
    stamp = stamp.astimezone(UTC)
    observed = int(time.time()*1000)
    event = int(stamp.timestamp()*1000)
    if event > observed + 1000:
        raise ValueError('REFERENCE_TIMESTAMP_IN_FUTURE')
    return {'symbol':symbol,'provider':'gold_api','price':str(price),'currency':'USD',
            'event_ms':event,'observed_ms':observed,'updated_at':stamp.isoformat(),
            'timestamp_kind':'NATIVE_ASSET_TIME','kind':'INDEPENDENT_REFERENCE_ONLY','execution_eligible':False,
            'state':'CURRENT_REFERENCE' if observed-event <= 120000 else 'STALE_OR_SESSION_CLOSED'}


async def gold_reference(symbol='XAUUSD',*,provider=None):
    if symbol not in {'XAUUSD','XAGUSD'}:
        raise ValueError('REFERENCE_SYMBOL_UNSUPPORTED')
    allowed={'gold_api','goldpricetoday_ir'}
    names=[provider] if provider else list(dict.fromkeys(os.getenv('MARKET_GOLD_REFERENCE_PROVIDERS','gold_api,goldpricetoday_ir').split(',')))
    if not names or set(names)-allowed:
        raise ValueError('REFERENCE_PROVIDER_MISMATCH')
    cache_key=(symbol,provider)
    cached = _CACHE.get(cache_key)
    if cached and cached[0] > time.monotonic():
        return dict(cached[1])
    key = (asyncio.get_running_loop(),cache_key)
    task = _INFLIGHT.get(key)
    if task is None:
        async def fetch():
            try:
                first_error=None
                for name in names:
                    if _COOLDOWNS.get((symbol,name),0)>time.monotonic():
                        continue
                    try:
                        if name=='gold_api':
                            result=await _gold_api_reference(symbol)
                        else:
                            from services.iran_market_data_service import IRAN_GOLD_REFERENCE_URL,parse_iran_gold_reference
                            raw=await get_json(IRAN_GOLD_REFERENCE_URL,retries=0)
                            result=parse_iran_gold_reference(raw,symbol=symbol,observed_ms=int(time.time()*1000))
                        ttl=60 if name=='goldpricetoday_ir' else 30
                        _CACHE[cache_key]=(time.monotonic()+ttl,result)
                        _CACHE[(symbol,name)]=_CACHE[cache_key]
                        _COOLDOWNS.pop((symbol,name),None)
                        return result
                    except Exception as exc:
                        if first_error is None:first_error=exc
                        _COOLDOWNS[(symbol,name)]=time.monotonic()+60
                # Only internal bounded validation codes may be returned. HTTP
                # exception text can contain URLs/credentials and is discarded.
                safe={'REFERENCE_IDENTITY_MISMATCH','REFERENCE_PRICE_INVALID','REFERENCE_TIMESTAMP_UNVERIFIED',
                      'REFERENCE_TIMESTAMP_IN_FUTURE','REFERENCE_SYMBOL_UNSUPPORTED'}
                if isinstance(first_error,ValueError) and str(first_error) in safe:
                    raise ValueError(str(first_error)) from None
                raise RuntimeError('REFERENCE_SOURCES_UNAVAILABLE') from None
            finally:
                _INFLIGHT.pop(key,None)
        task = asyncio.create_task(fetch())
        _INFLIGHT[key] = task
    return dict(await asyncio.shield(task))

