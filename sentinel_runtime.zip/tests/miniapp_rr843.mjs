import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const source = fs.readFileSync(new URL('../webapp/src/signals-home.js', import.meta.url), 'utf8');
const start = source.indexOf('function signalRiskRewardMetric(');
const end = source.indexOf('function showSignalModal(', start);
assert.ok(start >= 0 && end > start);
const context = vm.createContext({
    state: {lang: 'fa'},
    num: n => Number(n).toFixed(2),
    metric: (label, value, basis) => `${label}|${value}|${basis}`,
});
vm.runInContext(source.slice(start, end), context);
const render = value => { context.fixture = value; return vm.runInContext('signalRiskRewardMetric(fixture)', context); };
for (const risk_reward of [null, undefined, NaN, Infinity, -2]) assert.equal(render({risk_reward}), '');
assert.match(render({risk_reward: 2, rr_basis: 'published_entry'}), /2\.00R.*ورود و استاپ ثبت‌شده/);
context.state.lang = 'en';
assert.match(render({risk_reward: 2, rr_basis: 'average_entries'}), /2\.00R.*published entry average/);
assert.ok(source.includes('${signalRiskRewardMetric(entryState)}'));
console.log('Mini App RR presentation: 7 scenarios passed');
