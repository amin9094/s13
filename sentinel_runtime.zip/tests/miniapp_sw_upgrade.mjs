import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
const source=fs.readFileSync(new URL('../webapp/sw.js',import.meta.url),'utf8');
let checked=0;
for(const mount of ['/','/miniapp/']){
 const scope='https://fixture.test'+mount,handlers={},stores=new Map(),calls=[],writes=[];
 let offline=false,responseStatus=200,claimed=0,storageFailure=false,writeFailure=false,partialMedia=false;
 const keyOf=v=>new URL(typeof v==='string'?v:v.url,scope).href;
 const caches={
  async open(name){if(storageFailure)throw new Error('STORAGE_FIXTURE');if(!stores.has(name))stores.set(name,new Map());const rows=stores.get(name);
   return {async match(k){return rows.get(keyOf(k))?.clone();},async put(k,r){if(writeFailure)throw new Error('QUOTA_FIXTURE');if(r.status===206)throw new TypeError('Partial response cannot be cached');writes.push(keyOf(k));rows.set(keyOf(k),r.clone());},async addAll(){}};},
  async keys(){return [...stores.keys()];},async delete(k){return stores.delete(k);}
 };
 const context=vm.createContext({URL,Response,Promise,JSON,console,caches,
  self:{registration:{scope},clients:{claim:async()=>{claimed++;}},skipWaiting:async()=>{},
   addEventListener:(name,fn)=>handlers[name]=fn},
  fetch:async(request,options)=>{const url=keyOf(request);calls.push({url,options});if(offline)throw new Error('OFFLINE_FIXTURE');
   if(url.includes('/api/'))return new Response('private-live-response',{headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});
   if(url.endsWith('/manifest.webmanifest'))return new Response('{}',{headers:{'Content-Type':'application/manifest+json'}});
   if(url.endsWith('/sw.js'))return new Response('worker',{headers:{'Content-Type':'text/javascript'}});
   if(url.includes('/assets/private'))return new Response('uncacheable',{headers:{'Cache-Control':'private, no-store'}});
   if(url.includes('/assets/'))return new Response('fixture-asset',{status:partialMedia?206:200,headers:{'Content-Type':'text/javascript'}});
   return new Response(responseStatus===200?'<html>updated-shell</html>':'failed',{status:responseStatus,headers:{'Content-Type':'text/html'}});
  }});
 vm.runInContext(source,context);
 const name=vm.runInContext('CACHE_NAME',context),cache=await caches.open(name);
 await cache.put('./index.html',new Response('<html>old-shell</html>',{headers:{'Content-Type':'text/html'}}));
 for(const url of [scope+'api/v1/admin/live-signals','https://fixture.test/api/v1/bot-identity']){
  await cache.put(url,new Response('stale-private-response'));
 }
 async function serve(url,mode='cors',method='GET',range=false){
  let result;
  handlers.fetch({request:{url:keyOf(url),mode,method,headers:{has:name=>range&&name==='Range'}},respondWith:r=>{result=Promise.resolve(r);}});
  return result===undefined?null:await result;
 }
 for(const url of [scope+'api/v1/admin/live-signals','https://fixture.test/api/v1/bot-identity']){
  const before=writes.length;
  assert.equal(await (await serve(url)).text(),'private-live-response');
  assert.equal(calls.at(-1).options.cache,'no-store');
  offline=true;const r=await serve(url);assert.equal(r.status,503);assert.equal((await r.json()).error.code,'OFFLINE');
  assert.equal(r.headers.get('Cache-Control'),'no-store');assert.equal(writes.length,before);offline=false;
  checked+=2;
 }
 const launch=scope+'?tgWebAppData=PRIVATE_LAUNCH_FIXTURE';
 assert.match(await (await serve(launch,'navigate')).text(),/updated-shell/);
 assert.equal(calls.at(-1).options.cache,'no-store');
 assert.ok(!writes.some(url=>url.includes('PRIVATE_LAUNCH_FIXTURE')),'launch credentials must not become a cache key');
 offline=true;assert.match(await (await serve(scope,'navigate')).text(),/updated-shell/);offline=false;
 responseStatus=503;assert.equal((await serve(scope,'navigate')).status,503);responseStatus=200;
 checked+=4;
 offline=true;
 for(const relative of ['sw.js','manifest.webmanifest']){
  const r=await serve(scope+relative);assert.equal(r.status,503);assert.equal(await r.text(),'Offline');
 }
 offline=false;checked+=2;
 const before=calls.length;
 assert.equal(await (await serve(scope+'assets/app.fixture.js')).text(),'fixture-asset');
 assert.equal(await (await serve(scope+'assets/app.fixture.js')).text(),'fixture-asset');
 assert.equal(calls.length,before+1);
 const privateBefore=writes.length;await serve(scope+'assets/private.bin');assert.equal(writes.length,privateBefore);
 assert.equal(await serve('https://external.test/assets/app.js'),null);
 assert.equal(await serve(scope+'api/v1/admin/live-signals','cors','POST'),null);
 assert.equal(await serve(scope+'health'),null);checked+=5;
 assert.equal(await serve(scope+'assets/media/video.mp4','cors','GET',true),null);
 partialMedia=true;const beforePartial=writes.length;
 assert.equal((await serve(scope+'assets/media/partial.mp4')).status,206);
 assert.equal(writes.length,beforePartial);partialMedia=false;
 writeFailure=true;
 assert.match(await (await serve(scope,'navigate')).text(),/updated-shell/);
 assert.equal(await (await serve(scope+'assets/quota.js')).text(),'fixture-asset');writeFailure=false;
 storageFailure=true;
 assert.match(await (await serve(scope,'navigate')).text(),/updated-shell/);
 assert.equal(await (await serve(scope+'assets/no-storage.js')).text(),'fixture-asset');
 offline=true;assert.equal((await serve(scope,'navigate')).status,503);offline=false;storageFailure=false;
 checked+=7;
 await caches.open('unrelated-app-cache');await caches.open('9.0.0-candidate.16');
 await caches.open('sentinel-shell-old');let completion;
 handlers.activate({waitUntil:p=>{completion=p;}});await completion;
 assert.ok(stores.has('unrelated-app-cache')&&stores.has(name));
 assert.ok(!stores.has('9.0.0-candidate.16')&&!stores.has('sentinel-shell-old'));assert.equal(claimed,1);checked+=2;
}
console.log(JSON.stringify({passed:true,checks:checked,scopes:['/','/miniapp/'],data:'SYNTHETIC_NO_NETWORK',private_api_cached:false}));
