"""Sentinel test package.

Keeping tests importable as a package makes direct ``pytest`` and
``python -m pytest`` use the same local Telegram test shim.
"""
